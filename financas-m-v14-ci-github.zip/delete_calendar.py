import re

with open('app/src/main/java/com/example/ui/FinancasDialogs.kt', 'r') as f:
    content = f.read()

# Match from @Composable fun FutureFlowCalendarDialog up to the next @Composable or EOF
# We know the next one is fun MonthYearFastPickerDialog
pattern = re.compile(r'// \------------------- TELA AUXILIAR: DIALOG DE PROJEÇÃO DE FLUXO FUTURO \-------------------.*?@Composable\s*fun MonthYearFastPickerDialog', re.DOTALL)
new_content = pattern.sub('@Composable\nfun MonthYearFastPickerDialog', content)

with open('app/src/main/java/com/example/ui/FinancasDialogs.kt', 'w') as f:
    f.write(new_content)

print("Done")
