import re

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'r') as f:
    content = f.read()

replacement = """
    val startOfMonth = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val currentExpenses = transactions.filter { it.tipo == "Despesa" && it.data >= startOfMonth && !it.ajusteCaixa }
    val totalExpenses = currentExpenses.sumOf { it.valor }
    
    val categoryTotals = currentExpenses.groupBy { it.categoriaId }
        .map { (catId, txs) -> 
            val cat = categories.find { it.id == catId }
            Pair(cat?.nome ?: "Outros", txs.sumOf { it.valor })
        }
        .sortedByDescending { it.second }
        .take(5)
    
    val totalTop5 = categoryTotals.sumOf { it.second }
    val others = totalExpenses - totalTop5
    val finalCategories = if (others > 0) categoryTotals + Pair("Outros", others) else categoryTotals
    
    val defaultColors = listOf(Color(0xFF3B82F6), Color(0xFF10B981), Color(0xFF8B5CF6), Color(0xFFF59E0B), Color(0xFF94A3B8), Color(0xFFEC4899))
"""

sig_old = 'fun ExpenseDistributionCard(idioma: String)'
sig_new = 'fun ExpenseDistributionCard(idioma: String, transactions: List<Transaction>, categories: List<Category>, mo: String)'

content = content.replace(sig_old, sig_new)
content = content.replace('ExpenseDistributionCard(idioma)', 'ExpenseDistributionCard(idioma, transactions, categories, mo)')

# Replace the donut drawing and legend logic
content = re.sub(
    r'                // Donut Chart.*?Row\(verticalAlignment = Alignment\.CenterVertically, modifier = Modifier\.fillMaxWidth\(\)\) \{\n.*?\}\n                    \}\n                \}',
    """
                // Donut Chart
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(140.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeW = 16.dp.toPx()
                        var startAngle = -90f
                        
                        if (totalExpenses > 0) {
                            finalCategories.forEachIndexed { index, pair ->
                                val sweepAngle = (pair.second / totalExpenses) * 360f
                                drawArc(defaultColors[index % defaultColors.size], startAngle.toFloat(), sweepAngle.toFloat(), false, style = Stroke(strokeW))
                                startAngle += sweepAngle.toFloat()
                            }
                        } else {
                            drawArc(Color(0xFFE2E8F0), -90f, 360f, false, style = Stroke(strokeW))
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(String.format(Locale.getDefault(), "%,.0f", totalExpenses).replace(",", "X").replace(".", ",").replace("X", "."), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(mo, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                
                Spacer(modifier = Modifier.width(20.dp))
                
                // Legend
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                    if (totalExpenses > 0) {
                        finalCategories.forEachIndexed { index, pair ->
                            val perc = ((pair.second / totalExpenses) * 100).toInt()
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(defaultColors[index % defaultColors.size]))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(pair.first, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                Text("$perc%", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    } else {
                        Text(if (idioma == "PT") "Sem despesas" else "No expenses", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }""",
    content,
    flags=re.DOTALL
)

# Insert the data calc at the start of the function body
content = content.replace('fun ExpenseDistributionCard(idioma: String, transactions: List<Transaction>, categories: List<Category>, mo: String) {', 'fun ExpenseDistributionCard(idioma: String, transactions: List<Transaction>, categories: List<Category>, mo: String) {' + replacement)

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'w') as f:
    f.write(content)
