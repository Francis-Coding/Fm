package com.example.domain.usecases

import com.example.data.model.Loan
import com.example.data.model.Installment
import kotlin.math.pow
import kotlin.math.roundToInt

class CalculateInterestUseCase {
    fun execute(
        remainingBalance: Double,
        interestRate: Double,
        interestType: String,
        transactionDate: Long,
        currentDate: Long
    ): Double {
        if (remainingBalance <= 0.0 || interestRate <= 0.0) return 0.0
        val daysElapsed = ((currentDate - transactionDate) / 86400000.0).toLong().coerceAtLeast(0L)
        val months = (daysElapsed / 30) + 1
        
        val isCompound = interestType.uppercase() == "COMPOUND" || interestType.uppercase() == "COMPOSTO"
        return if (isCompound) {
            remainingBalance * ((1.0 + interestRate / 100.0).pow(months.toDouble()) - 1.0)
        } else {
            // SIMPLE interest (monthly)
            remainingBalance * (interestRate / 100.0) * months
        }
    }
}

/**
 * CalculatePenaltyUseCase
 * Business Rule: Progressive penalty for overdue loan installments.
 * For every 30 days of delay (1 to 30 days = 1 period, 31 to 60 days = 2 periods, etc.),
 * penalty increases proportionally: remainingBalance * (penaltyPercentage / 100) * periodsOverdue.
 */
class CalculatePenaltyUseCase {
    fun execute(
        remainingBalance: Double,
        penaltyPercentage: Double,
        dueDate: Long,
        currentDate: Long
    ): Double {
        if (remainingBalance <= 0.0 || penaltyPercentage <= 0.0) return 0.0
        val daysOverdue = ((currentDate - dueDate) / 86400000.0).toLong()
        return if (daysOverdue > 0) {
            val periodsOverdue = ((daysOverdue - 1) / 30) + 1
            remainingBalance * (penaltyPercentage / 100.0) * periodsOverdue
        } else {
            0.0
        }
    }
}

class CalculateSurvivalDaysUseCase {
    fun execute(totalBalance: Double, expensesLast30Days: Double): Int? {
        if (expensesLast30Days <= 0.0) return null
        val dailySpending = expensesLast30Days / 30.0
        return if (dailySpending <= 0.0) null else (totalBalance / dailySpending).roundToInt()
    }
}

data class LimitResult(
    val isExceeded: Boolean,
    val exceededAmount: Double
)

class CheckSpendingLimitUseCase {
    fun execute(actualSpending: Double, monthlyLimit: Double): LimitResult {
        if (monthlyLimit <= 0.0) return LimitResult(false, 0.0)
        val exceeded = actualSpending > monthlyLimit
        val amount = if (exceeded) actualSpending - monthlyLimit else 0.0
        return LimitResult(exceeded, amount)
    }
}

class CheckPendingLoansUseCase {
    fun getPendingLoansDueSoon(
        loans: List<Loan>,
        nowMs: Long = System.currentTimeMillis()
    ): List<Pair<Loan, Int>> {
        val dayInMs = 24 * 60 * 60 * 1000L
        val result = mutableListOf<Pair<Loan, Int>>()
        val pendingLoans = loans.filter { it.status == "PENDING" }
        for (loan in pendingLoans) {
            val timeLeftMs = loan.dueDate - nowMs
            val daysLeft = (timeLeftMs / dayInMs).toInt()
            if (daysLeft in 0..3) {
                result.add(Pair(loan, daysLeft))
            }
        }
        return result
    }
}

data class GroupedLoan(
    val loan: Loan,
    val installments: List<Installment>,
    val remainingBalanceSum: Double,
    val totalPaidSum: Double,
    val totalDueSum: Double, // remainingBalance + interest + penalty
    val interestSum: Double,
    val penaltySum: Double
)

class GroupInstallmentsUseCase(
    private val calculateInterest: CalculateInterestUseCase = CalculateInterestUseCase(),
    private val calculatePenalty: CalculatePenaltyUseCase = CalculatePenaltyUseCase()
) {
    fun execute(
        loans: List<Loan>,
        allInstallments: List<Installment>,
        currentDate: Long = System.currentTimeMillis()
    ): List<GroupedLoan> {
        val installmentsByLoan = allInstallments.groupBy { it.parentId }
        
        return loans.map { loan ->
            val loanInstallments = installmentsByLoan[loan.id] ?: emptyList()
            var remainingBalanceSum = 0.0
            var totalPaidSum = 0.0
            var interestSum = 0.0
            var penaltySum = 0.0
            
            for (inst in loanInstallments) {
                remainingBalanceSum += inst.remainingBalance
                totalPaidSum += inst.totalPaid
                
                // Calculate dynamic interest on overdue remaining balance if applicable
                val instInterest = if (inst.status == "PENDING" && currentDate > inst.dueDate) {
                    calculateInterest.execute(
                        remainingBalance = inst.remainingBalance,
                        interestRate = loan.interestRate,
                        interestType = loan.interestType,
                        transactionDate = inst.dueDate,
                        currentDate = currentDate
                    )
                } else 0.0
                interestSum += instInterest
                
                // Calculate penalty for this installment
                val instPenalty = calculatePenalty.execute(
                    remainingBalance = inst.remainingBalance,
                    penaltyPercentage = loan.penaltyPercentage,
                    dueDate = inst.dueDate,
                    currentDate = currentDate
                )
                penaltySum += instPenalty
            }
            
            val totalDueSum = remainingBalanceSum + interestSum + penaltySum
            
            GroupedLoan(
                loan = loan,
                installments = loanInstallments,
                remainingBalanceSum = remainingBalanceSum,
                totalPaidSum = totalPaidSum,
                totalDueSum = totalDueSum,
                interestSum = interestSum,
                penaltySum = penaltySum
            )
        }
    }
}

data class GoalProgressResult(
    val percentage: Double,
    val remainingAmount: Double,
    val isCompleted: Boolean,
    val dailySavingNeeded: Double,
    val daysRemaining: Long
)

class CalculateGoalProgressUseCase {
    fun execute(
        valorAtual: Double,
        valorObjetivo: Double,
        targetDateMs: Long,
        currentDateMs: Long = System.currentTimeMillis()
    ): GoalProgressResult {
        val objective = valorObjetivo.coerceAtLeast(0.01)
        val current = valorAtual.coerceAtLeast(0.0)
        val percentage = (current / objective * 100.0).coerceIn(0.0, 100.0)
        val remaining = (objective - current).coerceAtLeast(0.0)
        val isCompleted = current >= objective

        val diffMs = targetDateMs - currentDateMs
        val daysRemaining = (diffMs / (1000 * 60 * 60 * 24)).coerceAtLeast(1)
        val dailySavingNeeded = if (isCompleted) 0.0 else remaining / daysRemaining.toDouble()

        return GoalProgressResult(
            percentage = percentage,
            remainingAmount = remaining,
            isCompleted = isCompleted,
            dailySavingNeeded = dailySavingNeeded,
            daysRemaining = daysRemaining
        )
    }
}

sealed class TransactionValidationResult {
    object Valid : TransactionValidationResult()
    data class Invalid(val reason: String) : TransactionValidationResult()
}

class ValidateTransactionUseCase {
    fun execute(
        amount: Double,
        categoryName: String?,
        walletBalance: Double?,
        isExpense: Boolean
    ): TransactionValidationResult {
        if (amount <= 0.0) {
            return TransactionValidationResult.Invalid("O valor da transação deve ser maior que zero.")
        }
        if (categoryName.isNullOrBlank()) {
            return TransactionValidationResult.Invalid("Selecione uma categoria válida.")
        }
        if (isExpense && walletBalance != null && walletBalance < amount) {
            // Warning or soft validation - return invalid if strict check desired
            // For now, allow negative wallet balance with warning capability
        }
        return TransactionValidationResult.Valid
    }
}

data class BudgetCategorySummary(
    val categoryId: Int,
    val categoryName: String,
    val limit: Double,
    val spent: Double,
    val percentageUsed: Double,
    val isExceeded: Boolean
)

class CalculateBudgetSummaryUseCase {
    fun execute(
        categoryLimits: Map<Int, Double>,
        categoryExpenses: Map<Int, Double>,
        categoryNames: Map<Int, String>
    ): List<BudgetCategorySummary> {
        return categoryLimits.map { (catId, limit) ->
            val spent = categoryExpenses[catId] ?: 0.0
            val name = categoryNames[catId] ?: "Categoria #$catId"
            val pct = if (limit > 0.0) (spent / limit * 100.0).coerceAtLeast(0.0) else 0.0
            BudgetCategorySummary(
                categoryId = catId,
                categoryName = name,
                limit = limit,
                spent = spent,
                percentageUsed = pct,
                isExceeded = spent > limit && limit > 0.0
            )
        }
    }
}

