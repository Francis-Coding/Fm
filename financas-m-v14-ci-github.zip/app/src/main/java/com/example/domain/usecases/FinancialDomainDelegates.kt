package com.example.domain.usecases

import com.example.data.model.FinancialGoal
import com.example.data.model.FinancialTransaction
import com.example.data.model.Wallet
import com.example.util.MoneyFormatter

/**
 * Domain delegates for orchestrating clean business rules in Finanças M.
 * Houses pure business domain functions decoupled from Android framework UI dependencies.
 */
object FinancialDomainDelegates {

    private val goalProgressUseCase = CalculateGoalProgressUseCase()
    private val validateTransactionUseCase = ValidateTransactionUseCase()
    private val checkSpendingLimitUseCase = CheckSpendingLimitUseCase()

    fun calculateGoalProgress(goal: FinancialGoal): GoalProgressResult {
        return goalProgressUseCase.execute(
            valorAtual = goal.valorAtual,
            valorObjetivo = goal.valorObjetivo,
            targetDateMs = goal.dataLimite
        )
    }

    fun validateTransaction(
        amount: Double,
        categoryName: String?,
        walletBalance: Double?,
        isExpense: Boolean
    ): TransactionValidationResult {
        return validateTransactionUseCase.execute(
            amount = amount,
            categoryName = categoryName,
            walletBalance = walletBalance,
            isExpense = isExpense
        )
    }

    fun checkMonthlySpendingLimit(actualSpending: Double, monthlyLimit: Double): LimitResult {
        return checkSpendingLimitUseCase.execute(actualSpending, monthlyLimit)
    }

    fun calculateNetBalance(wallets: List<Wallet>): Double {
        return wallets.sumOf { it.saldoAtual }
    }

    fun calculateTotalIncome(transactions: List<FinancialTransaction>): Double {
        return transactions.filter { it.tipo == "RECEITA" }.sumOf { it.valor }
    }

    fun calculateTotalExpense(transactions: List<FinancialTransaction>): Double {
        return transactions.filter { it.tipo == "DESPESA" }.sumOf { it.valor }
    }

    fun formatFormattedMoney(amount: Double, currency: String = "MZN"): String {
        return MoneyFormatter.formatWithDecimals(amount, currency)
    }
}
