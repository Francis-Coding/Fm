package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.*
import com.example.data.model.*

@Database(
    entities = [
        UserSettings::class,
        Wallet::class,
        Category::class,
        FinancialTransaction::class,
        DailyClosure::class,
        FinancialGoal::class,
        RecycleBin::class,
        SpendingLimit::class,
        Loan::class,
        Installment::class,
        ShoppingItem::class,
        ShoppingList::class,
        ShoppingCategory::class,
        ShoppingPriceHistory::class,
        LoanReceipt::class,
        Subscription::class,
        CreditCard::class,
        ExportedReport::class,
        ScheduledTransfer::class,
        NotificationEntity::class
    ],
    version = 18,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userSettingsDao(): UserSettingsDao
    abstract fun walletDao(): WalletDao
    abstract fun categoryDao(): CategoryDao
    abstract fun transactionDao(): TransactionDao
    abstract fun dailyClosureDao(): DailyClosureDao
    abstract fun financialGoalDao(): FinancialGoalDao
    abstract fun recycleBinDao(): RecycleBinDao
    abstract fun spendingLimitDao(): SpendingLimitDao
    abstract fun loanDao(): LoanDao
    abstract fun installmentDao(): InstallmentDao
    abstract fun shoppingItemDao(): ShoppingItemDao
    abstract fun shoppingListDao(): ShoppingListDao
    abstract fun shoppingCategoryDao(): ShoppingCategoryDao
    abstract fun shoppingPriceHistoryDao(): ShoppingPriceHistoryDao
    abstract fun loanReceiptDao(): LoanReceiptDao
    abstract fun subscriptionDao(): SubscriptionDao
    abstract fun creditCardDao(): CreditCardDao
    abstract fun exportedReportDao(): ExportedReportDao
    abstract fun scheduledTransferDao(): ScheduledTransferDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS spending_limits (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        categoryId INTEGER NOT NULL,
                        monthlyLimit REAL NOT NULL,
                        month TEXT NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS loans (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        counterparty TEXT NOT NULL,
                        principalAmount REAL NOT NULL,
                        interestRate REAL NOT NULL,
                        interestType TEXT NOT NULL,
                        penaltyPercentage REAL NOT NULL,
                        transactionDate INTEGER NOT NULL,
                        dueDate INTEGER NOT NULL,
                        installmentCount INTEGER NOT NULL,
                        isCredit INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        paidOffDate INTEGER
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS installments (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        parentId INTEGER NOT NULL,
                        dueDate INTEGER NOT NULL,
                        remainingBalance REAL NOT NULL,
                        totalPaid REAL NOT NULL,
                        status TEXT NOT NULL,
                        FOREIGN KEY(parentId) REFERENCES loans(id) ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_installments_parentId ON installments(parentId)")
            }
        }

        val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS itens_compra (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        listaId INTEGER NOT NULL DEFAULT 1,
                        nome TEXT NOT NULL,
                        preco REAL NOT NULL DEFAULT 0.0,
                        quantidade REAL NOT NULL DEFAULT 1.0,
                        unidade TEXT NOT NULL DEFAULT 'un',
                        pago INTEGER NOT NULL DEFAULT 0,
                        prioridade TEXT NOT NULL DEFAULT 'MEDIA',
                        categoriaId INTEGER,
                        observacoes TEXT NOT NULL DEFAULT ''
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS listas_compra (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        nome TEXT NOT NULL,
                        isTemplate INTEGER NOT NULL DEFAULT 0,
                        originalListId INTEGER
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS categorias_compra (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        nome TEXT NOT NULL,
                        ordem INTEGER NOT NULL DEFAULT 0
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS historico_precos_compra (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        nomeProduto TEXT NOT NULL,
                        preco REAL NOT NULL,
                        data INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS loan_receipts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        loanId INTEGER NOT NULL,
                        imageUri TEXT NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_6_7 = object : androidx.room.migration.Migration(6, 7) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE user_settings ADD COLUMN biometricsEnabled INTEGER NOT NULL DEFAULT 0")
                } catch (e: Exception) {
                    android.util.Log.w("AppDatabase", "Column biometricsEnabled might already exist in schema 6->7 transition: ${e.message}")
                }
            }
        }

        val MIGRATION_7_8 = object : androidx.room.migration.Migration(7, 8) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE user_settings ADD COLUMN onboardingCompleted INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE user_settings ADD COLUMN aprovarRecorrentes INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE transacoes ADD COLUMN recurrenceFrequency TEXT")
                db.execSQL("ALTER TABLE transacoes ADD COLUMN nextOccurrenceDate INTEGER")
            }
        }

        val MIGRATION_8_9 = object : androidx.room.migration.Migration(8, 9) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS subscriptions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        nome TEXT NOT NULL,
                        valor REAL NOT NULL,
                        cicloCobranca TEXT NOT NULL DEFAULT 'MENSAL',
                        diaCobranca INTEGER NOT NULL DEFAULT 1,
                        dataCobranca INTEGER NOT NULL DEFAULT 0,
                        ativa INTEGER NOT NULL DEFAULT 1,
                        icone TEXT NOT NULL DEFAULT 'netflix',
                        corHex TEXT NOT NULL DEFAULT '#E50914',
                        categoriaId INTEGER NOT NULL DEFAULT 0,
                        carteiraId INTEGER NOT NULL DEFAULT 0,
                        moeda TEXT NOT NULL DEFAULT 'MZN'
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_9_10 = object : androidx.room.migration.Migration(9, 10) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS credit_cards (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        nome TEXT NOT NULL,
                        tipo TEXT NOT NULL DEFAULT 'Físico',
                        bandeira TEXT NOT NULL DEFAULT 'Visa',
                        ultimos4Digitos TEXT NOT NULL DEFAULT '4321',
                        limiteTotal REAL NOT NULL DEFAULT 50000.0,
                        limiteDisponivel REAL NOT NULL DEFAULT 35000.0,
                        diaFechamento INTEGER NOT NULL DEFAULT 15,
                        diaVencimento INTEGER NOT NULL DEFAULT 25,
                        corHex TEXT NOT NULL DEFAULT '#1A73E8',
                        carteiraPagamentoId INTEGER NOT NULL DEFAULT 0,
                        ativa INTEGER NOT NULL DEFAULT 1
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_10_11 = object : androidx.room.migration.Migration(10, 11) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transacoes ADD COLUMN metaId INTEGER")
            }
        }

        val MIGRATION_11_12 = object : androidx.room.migration.Migration(11, 12) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `transacoes_new` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `data` INTEGER NOT NULL,
                        `categoriaId` INTEGER,
                        `descricao` TEXT NOT NULL,
                        `valor` REAL NOT NULL,
                        `tipo` TEXT NOT NULL,
                        `carteiraOrigemId` INTEGER NOT NULL,
                        `comprovanteUrl` TEXT,
                        `recorrente` INTEGER NOT NULL,
                        `ajusteCaixa` INTEGER NOT NULL,
                        `moedaOriginal` TEXT NOT NULL,
                        `valorOriginal` REAL NOT NULL,
                        `taxaCambioUsada` REAL NOT NULL,
                        `observacoes` TEXT,
                        `recurrenceFrequency` TEXT,
                        `nextOccurrenceDate` INTEGER,
                        `metaId` INTEGER,
                        FOREIGN KEY(`categoriaId`) REFERENCES `categorias`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO `transacoes_new` SELECT `id`, `data`, `categoriaId`, `descricao`, `valor`, `tipo`, `carteiraOrigemId`, `comprovanteUrl`, `recorrente`, `ajusteCaixa`, `moedaOriginal`, `valorOriginal`, `taxaCambioUsada`, `observacoes`, `recurrenceFrequency`, `nextOccurrenceDate`, `metaId` FROM `transacoes`
                """.trimIndent())
                db.execSQL("DROP TABLE `transacoes`")
                db.execSQL("ALTER TABLE `transacoes_new` RENAME TO `transacoes`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_transacoes_categoriaId` ON `transacoes` (`categoriaId`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `credit_cards_new` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `nome` TEXT NOT NULL,
                        `tipo` TEXT NOT NULL,
                        `bandeira` TEXT NOT NULL,
                        `ultimos4Digitos` TEXT NOT NULL,
                        `limiteTotal` REAL NOT NULL,
                        `limiteDisponivel` REAL NOT NULL,
                        `diaFechamento` INTEGER NOT NULL,
                        `diaVencimento` INTEGER NOT NULL,
                        `corHex` TEXT NOT NULL,
                        `carteiraPagamentoId` INTEGER NOT NULL,
                        `ativa` INTEGER NOT NULL,
                        FOREIGN KEY(`carteiraPagamentoId`) REFERENCES `carteiras`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO `credit_cards_new` SELECT `id`, `nome`, `tipo`, `bandeira`, `ultimos4Digitos`, `limiteTotal`, `limiteDisponivel`, `diaFechamento`, `diaVencimento`, `corHex`, `carteiraPagamentoId`, `ativa` FROM `credit_cards`
                """.trimIndent())
                db.execSQL("DROP TABLE `credit_cards`")
                db.execSQL("ALTER TABLE `credit_cards_new` RENAME TO `credit_cards`")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_credit_cards_carteiraPagamentoId` ON `credit_cards` (`carteiraPagamentoId`)")
            }
        }

        val MIGRATION_12_13 = object : androidx.room.migration.Migration(12, 13) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE categorias ADD COLUMN isSystemCategory INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE categorias SET isSystemCategory = 1 WHERE LOWER(nome) = 'ajuste'")
            }
        }

        val MIGRATION_13_14 = object : androidx.room.migration.Migration(13, 14) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exported_reports` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `fileName` TEXT NOT NULL,
                        `format` TEXT NOT NULL,
                        `timestamp` INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_14_15 = object : androidx.room.migration.Migration(14, 15) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `scheduled_transfers` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `carteiraOrigemId` INTEGER NOT NULL,
                        `carteiraDestinoId` INTEGER NOT NULL,
                        `valor` REAL NOT NULL,
                        `dataHora` INTEGER NOT NULL,
                        `executada` INTEGER NOT NULL DEFAULT 0,
                        `dataCriacao` INTEGER NOT NULL,
                        FOREIGN KEY(`carteiraOrigemId`) REFERENCES `carteiras`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE ,
                        FOREIGN KEY(`carteiraDestinoId`) REFERENCES `carteiras`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_scheduled_transfers_carteiraOrigemId` ON `scheduled_transfers` (`carteiraOrigemId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_scheduled_transfers_carteiraDestinoId` ON `scheduled_transfers` (`carteiraDestinoId`)")
            }
        }

        val MIGRATION_15_16 = object : androidx.room.migration.Migration(15, 16) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE metas ADD COLUMN pausada INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE exported_reports ADD COLUMN filePath TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_16_17 = object : androidx.room.migration.Migration(16, 17) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE subscriptions ADD COLUMN sourceTransactionId INTEGER")
                val cursor = db.query("SELECT id, descricao, valor, recurrenceFrequency, nextOccurrenceDate, data, categoriaId, carteiraOrigemId, moedaOriginal FROM transacoes WHERE recorrente = 1")
                while (cursor.moveToNext()) {
                    val txId = cursor.getInt(0)
                    val desc = cursor.getString(1) ?: ""
                    val valor = cursor.getDouble(2)
                    val freq = if (cursor.isNull(3)) "Mensal" else (cursor.getString(3) ?: "Mensal")
                    val nextDate = if (cursor.isNull(4) || cursor.getLong(4) == 0L) cursor.getLong(5) else cursor.getLong(4)
                    val catId = if (cursor.isNull(6)) 0 else cursor.getInt(6)
                    val walletId = cursor.getInt(7)
                    val moeda = if (cursor.isNull(8)) "MZN" else (cursor.getString(8) ?: "MZN")
                    
                    val ciclo = when (freq.lowercase()) {
                        "semanal" -> "SEMANAL"
                        "anual" -> "ANUAL"
                        else -> "MENSAL"
                    }
                    val cal = java.util.Calendar.getInstance().apply { timeInMillis = nextDate }
                    val dia = cal.get(java.util.Calendar.DAY_OF_MONTH)
                    
                    val sql = "INSERT INTO subscriptions (nome, valor, cicloCobranca, diaCobranca, dataCobranca, ativa, icone, corHex, categoriaId, carteiraId, moeda, sourceTransactionId) VALUES (?, ?, ?, ?, ?, 1, 'custom', '#1A73E8', ?, ?, ?, ?)"
                    db.execSQL(sql, arrayOf(desc, valor, ciclo, dia, nextDate, catId, walletId, moeda, txId))
                }
                cursor.close()
            }
        }

        val MIGRATION_17_18 = object : androidx.room.migration.Migration(17, 18) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS notifications (
                        notificationId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        type TEXT NOT NULL,
                        title TEXT NOT NULL,
                        message TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        readAt INTEGER,
                        entityType TEXT NOT NULL,
                        entityId INTEGER NOT NULL,
                        action TEXT,
                        priority TEXT NOT NULL,
                        status TEXT NOT NULL
                    )
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "financas_m_db"
                )
                .addMigrations(
                    MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7,
                    MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13,
                    MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17, MIGRATION_17_18
                )
                // Commented out to prevent accidental destructive migrations in production as requested in Phase 0.
                // .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
