package com.example.data.service

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class CurrencyExchangeService(context: Context) {
    private val prefs = context.getSharedPreferences("exchange_rates_cache", Context.MODE_PRIVATE)

    // Fallback default exchange rates (How much of currency X is 1 Metical MZN?)
    // E.g. 1 USD = 63.85 MZN -> 1 MZN = 0.01566 USD
    // 1 ZAR = 3.51 MZN -> 1 MZN = 0.285 ZAR
    // 1 EUR = 68.50 MZN -> 1 MZN = 0.0146 EUR
    private val defaultRates = mapOf(
        "MZN" to 1.0,
        "MT" to 1.0,
        "USD" to 0.01566,
        "ZAR" to 0.285,
        "EUR" to 0.0146
    )

    // Get current rate for a currency (1 MZN = X of that currency)
    fun getRate(currency: String): Double {
        val strRate = prefs.getString("rate_$currency", null)?.toDoubleOrNull()
        if (strRate != null && strRate > 0.0) {
            return strRate
        }
        val legacyFloatRate = prefs.getFloat(currency, 0.0f).toDouble()
        if (legacyFloatRate > 0.0) {
            return legacyFloatRate
        }
        return defaultRates[currency] ?: 0.0
    }

    // Standard conversion: convert [amount] from [fromCurrency] to MZN
    fun convertToMZN(amount: Double, fromCurrency: String): Double {
        if (fromCurrency == "MZN" || fromCurrency == "MT") return amount
        val rate = getRate(fromCurrency)
        if (rate > 0.0) {
            val result = amount / rate
            return java.math.BigDecimal.valueOf(result)
                .setScale(2, java.math.RoundingMode.HALF_UP)
                .toDouble()
        }
        return amount
    }

    // Backward compatibility wrappers for old MT-based method names
    fun convertToMT(amount: Double, fromCurrency: String): Double {
        return convertToMZN(amount, fromCurrency)
    }

    // Standard conversion: convert [amount] in MZN to [toCurrency]
    fun convertFromMZN(amountInMZN: Double, toCurrency: String): Double {
        if (toCurrency == "MZN" || toCurrency == "MT") return amountInMZN
        val rateToMZN = getRate(toCurrency)
        if (rateToMZN <= 0.0) return amountInMZN
        val result = amountInMZN * rateToMZN
        return java.math.BigDecimal.valueOf(result)
            .setScale(2, java.math.RoundingMode.HALF_UP)
            .toDouble()
    }

    fun convertFromMT(amountInMT: Double, toCurrency: String): Double {
        return convertFromMZN(amountInMT, toCurrency)
    }

    fun getLastUpdatedTime(): Long {
        return prefs.getLong("last_updated", 0L)
    }

    // Fetch latest rates asynchronously from a keyless public API
    suspend fun fetchLatestRates() = withContext(Dispatchers.IO) {
        val lastUpdated = prefs.getLong("last_updated", 0L)
        val now = System.currentTimeMillis()
        
        // 1 hour cache limit
        if (now - lastUpdated < 3600 * 1000) {
            Log.d("CurrencyExchange", "Rates cache is fresh. Skipping network request.")
            return@withContext
        }

        try {
            val url = URL("https://open.er-api.com/v6/latest/MZN") // MZN is ISO code
            val urlConnection = url.openConnection() as HttpURLConnection
            try {
                urlConnection.requestMethod = "GET"
                urlConnection.connectTimeout = 5000
                urlConnection.readTimeout = 5000

                val responseCode = urlConnection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val responseText = urlConnection.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(responseText)
                    val ratesObject = json.getJSONObject("rates")

                    val editor = prefs.edit()
                    // Translate MZN for Mozambique user-friendly display
                    val mznToUsd = ratesObject.optDouble("USD", 0.01566)
                    val mznToZar = ratesObject.optDouble("ZAR", 0.285)
                    val mznToEur = ratesObject.optDouble("EUR", 0.0146)

                    editor.putString("rate_MZN", "1.0")
                    editor.putString("rate_MT", "1.0")
                    editor.putString("rate_USD", mznToUsd.toString())
                    editor.putString("rate_ZAR", mznToZar.toString())
                    editor.putString("rate_EUR", mznToEur.toString())
                    editor.putFloat("MZN", 1.0f)
                    editor.putFloat("MT", 1.0f)
                    editor.putFloat("USD", mznToUsd.toFloat())
                    editor.putFloat("ZAR", mznToZar.toFloat())
                    editor.putFloat("EUR", mznToEur.toFloat())
                    editor.putLong("last_updated", now)
                    editor.apply()

                    Log.d("CurrencyExchange", "Rates updated successfully: USD=$mznToUsd, ZAR=$mznToZar, EUR=$mznToEur")
                }
            } finally {
                urlConnection.disconnect()
            }
        } catch (e: Exception) {
            Log.e("CurrencyExchange", "Failed to fetch currency rates online, using offline default fallback values", e)
        }
    }
}
