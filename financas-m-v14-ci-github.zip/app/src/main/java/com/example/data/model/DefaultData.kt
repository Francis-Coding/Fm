package com.example.data.model

object DefaultData {
    val defaultCategories = listOf(
        Category(nome = "Alimentação", icone = "restaurant", cor = "#FF5722", tipo = "Despesa", limiteMensal = 8000.0),
        Category(nome = "Transporte", icone = "directions_car", cor = "#2196F3", tipo = "Despesa", limiteMensal = 3000.0),
        Category(nome = "Habitação", icone = "home", cor = "#9C27B0", tipo = "Despesa", limiteMensal = 15000.0),
        Category(nome = "Lazer", icone = "movie", cor = "#E91E63", tipo = "Despesa", limiteMensal = 4000.0),
        Category(nome = "Saúde", icone = "local_hospital", cor = "#4CAF50", tipo = "Despesa", limiteMensal = 5000.0),
        Category(nome = "Ajuste", icone = "tune", cor = "#607D8B", tipo = "Despesa", limiteMensal = 0.0, isSystemCategory = true),
        
        Category(nome = "Salário", icone = "payments", cor = "#4CAF50", tipo = "Injecao"),
        Category(nome = "Negócio", icone = "trending_up", cor = "#00BCD4", tipo = "Injecao"),
        Category(nome = "Investimento", icone = "savings", cor = "#FFEB3B", tipo = "Injecao"),
        Category(nome = "Ajuste", icone = "tune", cor = "#607D8B", tipo = "Injecao", isSystemCategory = true)
    )

    val defaultShoppingLists = listOf(
        ShoppingList(nome = "Supermercado"),
        ShoppingList(nome = "Feira de Sábado")
    )

    val defaultShoppingCategories = listOf(
        ShoppingCategory(nome = "Mercado & Supermercado", ordem = 0),
        ShoppingCategory(nome = "Hortifruti (Frutas/Legumes)", ordem = 1),
        ShoppingCategory(nome = "Laticínios & Frios", ordem = 2),
        ShoppingCategory(nome = "Talho & Carnes", ordem = 3),
        ShoppingCategory(nome = "Mercearia (Arroz, Óleo, Massas)", ordem = 4),
        ShoppingCategory(nome = "Bebidas", ordem = 5),
        ShoppingCategory(nome = "Produtos de Limpeza", ordem = 6),
        ShoppingCategory(nome = "Higiene Pessoal", ordem = 7),
        ShoppingCategory(nome = "Utensílios & Casa", ordem = 8),
        ShoppingCategory(nome = "Vestuário", ordem = 9),
        ShoppingCategory(nome = "Outros", ordem = 10)
    )
}
