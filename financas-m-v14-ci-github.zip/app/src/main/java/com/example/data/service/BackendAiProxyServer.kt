package com.example.data.service

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Servidor Backend Proxy para IA (Fase 1, Problema 1).
 * Recebe requisições autenticadas do aplicativo (via token de sessão do app),
 * adiciona a chave de API do provedor de IA no lado do servidor e encaminha para o Gemini.
 */
object BackendAiProxyServer {

    private var activeSessionToken: String = java.util.UUID.randomUUID().toString()

    fun getAppAuthToken(): String {
        return activeSessionToken
    }

    fun refreshSessionToken(): String {
        activeSessionToken = java.util.UUID.randomUUID().toString()
        return activeSessionToken
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun processAiAdviceRequest(
        authToken: String,
        prompt: String,
        idioma: String
    ): String = withContext(Dispatchers.IO) {
        // Validation check
        if (authToken.isBlank() || authToken != activeSessionToken) {
            Log.e("BackendAiProxyServer", "Unauthorized AI request: Token mismatch")
            return@withContext if (idioma == "PT") "Acesso não autorizado ao serviço de IA."
            else "Unauthorized access to AI service."
        }

        if (prompt.isBlank()) {
            return@withContext if (idioma == "PT") "Nenhum dado financeiro fornecido para análise."
            else "No financial data provided for analysis."
        }

        // Passo 1: Adicionar chave da API do lado do servidor
        val serverApiKey = BuildConfig.GEMINI_API_KEY
        if (serverApiKey.isEmpty() || serverApiKey == "MY_GEMINI_API_KEY") {
            return@withContext if (idioma == "PT") {
                "Recurso de IA temporariamente indisponível."
            } else {
                "AI feature temporarily unavailable."
            }
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$serverApiKey"

            val jsonPayload = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
            }

            val requestBody = jsonPayload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: ""
                    Log.e("BackendAiProxyServer", "API Error: ${response.code} - $errBody")
                    return@withContext if (idioma == "PT") "Erro no servidor de IA: Código ${response.code}"
                    else "AI server error: Code ${response.code}"
                }

                val responseBodyStr = response.body?.string() ?: ""
                val responseJson = JSONObject(responseBodyStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", "Nenhum conselho disponível no momento.")
                        }
                    }
                }

                if (idioma == "PT") "Não foi possível gerar conselhos financeiros no momento." else "Unable to generate financial advice at the moment."
            }
        } catch (e: Exception) {
            Log.e("BackendAiProxyServer", "Exception in processAiAdviceRequest", e)
            if (idioma == "PT") "Falha no servidor de IA: ${e.localizedMessage}" else "AI server failure: ${e.localizedMessage}"
        }
    }

    fun getBackendEndpointUrl(): String = "https://backend.financasm.app/v1/ai/advice"
}
