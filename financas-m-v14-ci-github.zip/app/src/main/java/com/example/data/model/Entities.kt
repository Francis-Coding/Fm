package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey val id: Int = 1,
    val email: String = "",
    val name: String = "Usuário",
    val photoURL: String = "",
    val moedaPadrao: String = "MZN", // Default Mozambican Metical
    val tema: String = "light", // "light" or "dark"
    val corPrimaria: String = "#1A73E8", // Azul default
    val ocultarSaldos: Boolean = false,
    val notificacoesAtivas: Boolean = true,
    val pinHash: String = "",
    val ultimoFechamento: Long = 0L,
    val idioma: String = "PT",
    val biometricsEnabled: Boolean = false,
    val onboardingCompleted: Boolean = false,
    val aprovarRecorrentes: Boolean = false
)

@Entity(tableName = "carteiras")
data class Wallet(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val saldoInicial: Double,
    val saldoAtual: Double,
    val icone: String, // String representation of icon/emoji
    val cor: String, // Hex color code
    val ativa: Boolean = true,
    val ordem: Int = 0
)

@Entity(tableName = "categorias")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val icone: String, // Emoji or standard icon name
    val cor: String, // Hex color code
    val tipo: String, // "Despesa" or "Injecao"
    val limiteMensal: Double = 0.0, // 0.0 means no limit
    val isSystemCategory: Boolean = false
)

@Entity(
    tableName = "transacoes",
    foreignKeys = [
        ForeignKey(
            entity = Category::class,
            parentColumns = ["id"],
            childColumns = ["categoriaId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("categoriaId")]
)
data class FinancialTransaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val data: Long, // timestamp
    val categoriaId: Int?,
    val descricao: String,
    val valor: Double,
    val tipo: String, // "Despesa" or "Injecao"
    val carteiraOrigemId: Int,
    val comprovanteUrl: String? = null,
    val recorrente: Boolean = false,
    val ajusteCaixa: Boolean = false,
    val moedaOriginal: String = "MZN",
    val valorOriginal: Double = 0.0,
    val taxaCambioUsada: Double = 1.0,
    val observacoes: String? = "",
    val recurrenceFrequency: String? = null,
    val nextOccurrenceDate: Long? = null,
    val metaId: Int? = null
)

fun FinancialTransaction.isReceita(): Boolean {
    if (ajusteCaixa || tipo == "Transferencia" || tipo == "PagamentoEmprestimo") return false
    val t = tipo.lowercase().trim()
    return t == "receita" || t == "injecao" || t == "injeção" || t == "entrada" ||
            t.contains("receita") || t.contains("injecao") || t.contains("injeção") || t.contains("entrada")
}

fun FinancialTransaction.isDespesa(): Boolean {
    if (ajusteCaixa || tipo == "Transferencia" || tipo == "PagamentoEmprestimo") return false
    val t = tipo.lowercase().trim()
    return t == "despesa" || t == "saida" || t == "saída" ||
            t.contains("despesa") || t.contains("saida") || t.contains("saída")
}

@Entity(tableName = "fechamentos")
data class DailyClosure(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val data: Long, // timestamp (beginning of the day)
    val carteiraId: Int,
    val saldoEsperado: Double,
    val saldoReal: Double,
    val diferenca: Double,
    val saldoTotalEsperado: Double = 0.0,
    val comparacaoAnterior: String? = null
)

@Entity(tableName = "metas")
data class FinancialGoal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val valorObjetivo: Double,
    val valorAtual: Double,
    val dataInicio: Long,
    val dataLimite: Long,
    val categoriaId: Int,
    val pausada: Boolean = false
)

@Entity(tableName = "lixeira")
data class RecycleBin(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val transacaoOriginalId: Int,
    val transacaoOriginalJson: String, // JSON representation of the transaction to restore it
    val dataExclusao: Long
)

@Entity(tableName = "spending_limits")
data class SpendingLimit(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val categoryId: Int,
    val monthlyLimit: Double,
    val month: String // "YYYY-MM"
)

@Entity(tableName = "loans")
data class Loan(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val counterparty: String,
    val principalAmount: Double,
    val interestRate: Double,
    val interestType: String, // "SIMPLE" or "COMPOUND"
    val penaltyPercentage: Double,
    val transactionDate: Long, // UTC
    val dueDate: Long, // UTC
    val installmentCount: Int,
    val isCredit: Boolean,
    val status: String, // "PENDING", "PAID"
    val paidOffDate: Long? = null
)

@Entity(
    tableName = "installments",
    foreignKeys = [
        androidx.room.ForeignKey(
            entity = Loan::class,
            parentColumns = ["id"],
            childColumns = ["parentId"],
            onDelete = androidx.room.ForeignKey.CASCADE
        )
    ],
    indices = [androidx.room.Index(value = ["parentId"])]
)
data class Installment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val parentId: Int,
    val dueDate: Long,
    val remainingBalance: Double,
    val totalPaid: Double,
    val status: String // "PENDING", "PAID"
)

@Entity(tableName = "itens_compra")
data class ShoppingItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val listaId: Int = 1, // Reference to ShoppingList
    val nome: String,
    val preco: Double = 0.0, // Unit price or total price
    val quantidade: Double = 1.0,
    val unidade: String = "un", // "un", "kg", "L", "pct", etc.
    val pago: Boolean = false,
    val prioridade: String = "MEDIA", // "ALTA", "MEDIA", "BAIXA"
    val categoriaId: Int? = null, // Reference to ShoppingCategory
    val observacoes: String = "" // Notes/sub-items
)

@Entity(tableName = "listas_compra")
data class ShoppingList(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val isTemplate: Boolean = false, // Recurring templates
    val originalListId: Int? = null // Reference to original if copied
)

@Entity(tableName = "categorias_compra")
data class ShoppingCategory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val ordem: Int = 0 // For custom reordering
)

@Entity(tableName = "historico_precos_compra")
data class ShoppingPriceHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nomeProduto: String,
    val preco: Double,
    val data: Long = System.currentTimeMillis()
)

@Entity(tableName = "loan_receipts")
data class LoanReceipt(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val loanId: Int,
    val imageUri: String
)

@Entity(tableName = "subscriptions")
data class Subscription(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val valor: Double,
    val cicloCobranca: String = "MENSAL", // "MENSAL", "ANUAL", "TRIMESTRAL", "SEMANAL"
    val diaCobranca: Int = 1, // 1..31
    val dataCobranca: Long = System.currentTimeMillis(),
    val ativa: Boolean = true,
    val icone: String = "custom", // service key or emoji/icon
    val corHex: String = "#E50914",
    val categoriaId: Int = 0,
    val carteiraId: Int = 0,
    val moeda: String = "MZN",
    val sourceTransactionId: Int? = null
)

fun Subscription.valorMensalEquivalente(): Double {
    return when (cicloCobranca.uppercase().trim()) {
        "ANUAL" -> valor / 12.0
        "TRIMESTRAL" -> valor / 3.0
        "SEMANAL" -> valor * 4.33
        else -> valor
    }
}

@Entity(
    tableName = "credit_cards",
    foreignKeys = [
        ForeignKey(
            entity = Wallet::class,
            parentColumns = ["id"],
            childColumns = ["carteiraPagamentoId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("carteiraPagamentoId")]
)
data class CreditCard(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val tipo: String = "Físico", // "Físico" or "Digital"
    val bandeira: String = "Visa", // "Visa", "Mastercard", "BCI", "Millennium BIM", etc.
    val ultimos4Digitos: String = "4321",
    val limiteTotal: Double = 50000.0,
    val limiteDisponivel: Double = 35000.0,
    val diaFechamento: Int = 15, // Closing day (1..31)
    val diaVencimento: Int = 25, // Due day (1..31)
    val corHex: String = "#1A73E8",
    val carteiraPagamentoId: Int = 0,
    val ativa: Boolean = true
)

@Entity(tableName = "exported_reports")
data class ExportedReport(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fileName: String,
    val format: String, // "PDF", "CSV", "Excel"
    val timestamp: Long = System.currentTimeMillis(),
    val filePath: String = ""
)

@Entity(
    tableName = "scheduled_transfers",
    foreignKeys = [
        ForeignKey(
            entity = Wallet::class,
            parentColumns = ["id"],
            childColumns = ["carteiraOrigemId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Wallet::class,
            parentColumns = ["id"],
            childColumns = ["carteiraDestinoId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("carteiraOrigemId"),
        Index("carteiraDestinoId")
    ]
)
data class ScheduledTransfer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val carteiraOrigemId: Int,
    val carteiraDestinoId: Int,
    val valor: Double,
    val dataHora: Long,
    val executada: Boolean = false,
    val dataCriacao: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val notificationId: Int = 0,
    val type: String, // e.g., "LOAN_OVERDUE", "PURCHASE_REGISTERED", "GOAL_OVERDUE", "INSUFFICIENT_BALANCE", "RECURRING_PAYMENT"
    val title: String,
    val message: String,
    val createdAt: Long = System.currentTimeMillis(),
    val readAt: Long? = null,
    val entityType: String, // "LOAN", "TRANSACTION", "GOAL", "SUBSCRIPTION"
    val entityId: Int,
    val action: String? = null,
    val priority: String = "NORMAL", // "HIGH", "NORMAL", "LOW"
    val status: String = "UNREAD" // "UNREAD", "READ", "ARCHIVED", "RESOLVED"
)

object TransactionType {
    const val DESPESA = "Despesa"
    const val INJECAO = "Injecao"
    const val RECEITA = "Receita"
    const val TRANSFERENCIA = "Transferencia"
    const val PAGAMENTO_EMPRESTIMO = "PagamentoEmprestimo"
}

enum class ReportFormat {
    PDF, CSV, XLSX
}



