package com.example.data.service

import android.content.Context
import android.net.Uri
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.regex.Pattern

class OcrService(private val context: Context) {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    data class ScannedReceipt(
        val total: Double?,
        val date: String?,
        val establishment: String?,
        val extractedProducts: List<Pair<String, Double>>
    )

    suspend fun scanReceipt(uri: Uri): ScannedReceipt = withContext(Dispatchers.IO) {
        try {
            val image = InputImage.fromFilePath(context, uri)
            val task = recognizer.process(image)
            val result = Tasks.await(task, 15, java.util.concurrent.TimeUnit.SECONDS)
            parseText(result.text ?: "")
        } catch (e: Exception) {
            Log.e("OcrService", "Failed to scan receipt image via ML Kit", e)
            ScannedReceipt(null, null, null, emptyList())
        }
    }

    fun parseText(text: String): ScannedReceipt {
        val lines = text.split("\n")
        var total: Double? = null
        var date: String? = null
        var establishment: String? = null
        val products = mutableListOf<Pair<String, Double>>()

        // Find establishment - usually first non-empty lines
        establishment = lines.firstOrNull { it.isNotBlank() && it.length > 3 && !it.contains("RECEIPT", true) && !it.contains("RECIBO", true) }?.trim()

        // Regular expressions to find date (DD/MM/YYYY, YYYY-MM-DD, DD-MM-YYYY, etc.)
        val dateRegex = Pattern.compile("\\b(\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4})\\b")
        val priceRegex = Pattern.compile("\\b(\\d+[,.]\\d{2})\\b")

        var totalFromPureTotalLine: Double? = null
        var totalFromOtherKeywordLine: Double? = null

        for (line in lines) {
            val upperLine = line.uppercase()
            
            // Check for date in line
            val dateMatcher = dateRegex.matcher(line)
            if (date == null && dateMatcher.find()) {
                date = dateMatcher.group(1)
            }

            // Exclude lines containing "SUBTOTAL", "SUB TOTAL", or "SUB" prefix before "TOTAL"
            val isSubtotalLine = upperLine.contains("SUBTOTAL") || upperLine.contains("SUB TOTAL") || upperLine.contains("SUB-TOTAL") || upperLine.contains("SUB")

            // Prioritize lines containing "TOTAL" without "SUB"
            if (!isSubtotalLine && upperLine.contains("TOTAL")) {
                val priceMatcher = priceRegex.matcher(line)
                val pricesInLine = mutableListOf<Double>()
                while (priceMatcher.find()) {
                    val priceStr = priceMatcher.group(1).replace(",", ".")
                    priceStr.toDoubleOrNull()?.let { pricesInLine.add(it) }
                }
                if (pricesInLine.isNotEmpty()) {
                    val lineTotal = pricesInLine.maxOrNull()
                    if (totalFromPureTotalLine == null || (lineTotal != null && lineTotal > totalFromPureTotalLine)) {
                        totalFromPureTotalLine = lineTotal
                    }
                }
            } else if (!isSubtotalLine && (upperLine.contains("VALOR") || upperLine.contains("MZN") || upperLine.contains("SUM") || upperLine.contains("PAGO"))) {
                val priceMatcher = priceRegex.matcher(line)
                val pricesInLine = mutableListOf<Double>()
                while (priceMatcher.find()) {
                    val priceStr = priceMatcher.group(1).replace(",", ".")
                    priceStr.toDoubleOrNull()?.let { pricesInLine.add(it) }
                }
                if (pricesInLine.isNotEmpty()) {
                    val lineTotal = pricesInLine.maxOrNull()
                    if (totalFromOtherKeywordLine == null || (lineTotal != null && lineTotal > totalFromOtherKeywordLine)) {
                        totalFromOtherKeywordLine = lineTotal
                    }
                }
            } else if (!isSubtotalLine) {
                // Look for potential products: line with product name + price
                val priceMatcher = priceRegex.matcher(line)
                if (priceMatcher.find()) {
                    val priceStr = priceMatcher.group(1).replace(",", ".")
                    val priceVal = priceStr.toDoubleOrNull()
                    if (priceVal != null && priceVal > 0.0) {
                        val prodName = line.substring(0, priceMatcher.start()).trim().replace(Regex("[^a-zA-Z0-9 ]"), "")
                        if (prodName.length > 2 && !prodName.contains("TOTAL", ignoreCase = true) && !prodName.contains("MZN", ignoreCase = true)) {
                            products.add(Pair(prodName, priceVal))
                        }
                    }
                }
            }
        }

        total = totalFromPureTotalLine ?: totalFromOtherKeywordLine

        return ScannedReceipt(total, date, establishment, products)
    }
}
