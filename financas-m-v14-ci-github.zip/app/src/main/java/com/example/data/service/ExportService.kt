package com.example.data.service

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.util.Log
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Category
import com.example.data.model.FinancialTransaction
import com.example.data.model.Wallet
import com.example.data.model.isDespesa
import com.example.data.model.isReceita
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExportService(private val context: Context) {

    private val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    private fun escapeCsvField(field: String): String {
        return if (field.contains(",") || field.contains("\"") || field.contains("\n") || field.contains("\r")) {
            "\"" + field.replace("\"", "\"\"") + "\""
        } else {
            field
        }
    }

    private fun xmlEscape(str: String): String {
        return str.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun getColumnLetter(colIndex: Int): String {
        var temp = colIndex
        var colName = ""
        while (temp > 0) {
            val rem = (temp - 1) % 26
            colName = (65 + rem).toChar() + colName
            temp = (temp - 1) / 26
        }
        return colName
    }

    // Generates an RFC 4180 compliant CSV file in cache
    fun generateCombinedZipReport(
        transactions: List<FinancialTransaction>,
        categories: List<Category>,
        wallets: List<Wallet>,
        periodName: String,
        moeda: String = "MZN"
    ): File {
        val pdfFile = generateRealPdfFile(transactions, categories, wallets, periodName, moeda)
        val csvFile = generateCsvFile(transactions, categories, wallets, moeda)
        val xlsxFile = generateXlsxFile(transactions, categories, wallets, periodName, moeda)

        val cacheDir = context.cacheDir
        val safePeriod = periodName.replace(" ", "_").replace("/", "-")
        val zipFile = File(cacheDir, "pacote_relatorios_financas_m_${System.currentTimeMillis()}.zip")

        java.util.zip.ZipOutputStream(zipFile.outputStream()).use { zip ->
            fun addFile(file: File, name: String) {
                if (!file.exists()) return
                zip.putNextEntry(java.util.zip.ZipEntry(name))
                file.inputStream().use { input -> input.copyTo(zip) }
                zip.closeEntry()
            }
            addFile(pdfFile, "Relatorio_$safePeriod.pdf")
            addFile(csvFile, "Dados_$safePeriod.csv")
            addFile(xlsxFile, "Planilha_$safePeriod.xlsx")
        }
        return zipFile
    }

    // Generates an RFC 4180 compliant CSV file in cache
    fun generateCsvFile(
        transactions: List<FinancialTransaction>,
        categories: List<Category>,
        wallets: List<Wallet>,
        moeda: String = "MZN"
    ): File {
        val categoryMap = categories.associateBy { it.id }
        val walletMap = wallets.associateBy { it.id }

        val csvHeader = "ID,Data,Descrição,Categoria,Tipo,Valor (MT),Moeda Original,Valor Original,Taxa Câmbio,Carteira/Conta,Recorrente,Ajuste\n"
        val csvBody = StringBuilder()

        for (t in transactions) {
            val dateStr = sdf.format(Date(t.data))
            val rawCatName = categoryMap[t.categoriaId]?.nome ?: "Desconhecido"
            val rawWalletName = walletMap[t.carteiraOrigemId]?.nome ?: "Desconhecido"

            csvBody.append("${t.id},")
                .append("${escapeCsvField(dateStr)},")
                .append("${escapeCsvField(t.descricao)},")
                .append("${escapeCsvField(rawCatName)},")
                .append("${escapeCsvField(t.tipo)},")
                .append(String.format(Locale.US, "%.2f", t.valor)).append(",")
                .append("${escapeCsvField(t.moedaOriginal)},")
                .append(String.format(Locale.US, "%.2f", t.valorOriginal)).append(",")
                .append(String.format(Locale.US, "%.4f", t.taxaCambioUsada)).append(",")
                .append("${escapeCsvField(rawWalletName)},")
                .append(if (t.recorrente) "Sim" else "Não").append(",")
                .append(if (t.ajusteCaixa) "Sim" else "Não")
                .append("\n")
        }

        val fullCsv = csvHeader + csvBody.toString()
        val cacheDir = context.cacheDir
        val file = File(cacheDir, "relatorio_financas_m_${System.currentTimeMillis()}.csv")
        file.writeText(fullCsv, Charsets.UTF_8)
        return file
    }

    // Generates a real native Microsoft Excel (.xlsx) file with worksheets, styles, and formulas
    fun generateXlsxFile(
        transactions: List<FinancialTransaction>,
        categories: List<Category>,
        wallets: List<Wallet>,
        periodName: String,
        moeda: String = "MZN"
    ): File {
        val categoryMap = categories.associateBy { it.id }
        val walletMap = wallets.associateBy { it.id }

        val sheet1Sb = StringBuilder()
        sheet1Sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sheet1Sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        sheet1Sb.append("""<sheetViews><sheetView tabSelected="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>""")
        sheet1Sb.append("""<sheetData>""")

        val headers = listOf("ID", "Data", "Descrição", "Categoria", "Tipo", "Valor em ${moeda}", "Moeda Original", "Valor Original", "Taxa Câmbio", "Carteira", "Recorrente", "Ajuste")
        sheet1Sb.append("""<row r="1">""")
        headers.forEachIndexed { colIdx, h ->
            val colLetter = getColumnLetter(colIdx + 1)
            sheet1Sb.append("""<c r="${colLetter}1" t="inlineStr" s="1"><is><t>${xmlEscape(h)}</t></is></c>""")
        }
        sheet1Sb.append("""</row>""")

        var rIndex = 2
        for (t in transactions) {
            val dateStr = sdf.format(Date(t.data))
            val catName = categoryMap[t.categoriaId]?.nome ?: "Desconhecido"
            val walletName = walletMap[t.carteiraOrigemId]?.nome ?: "Desconhecido"

            sheet1Sb.append("""<row r="$rIndex">""")
            sheet1Sb.append("""<c r="A$rIndex"><v>${t.id}</v></c>""")
            sheet1Sb.append("""<c r="B$rIndex" t="inlineStr"><is><t>${xmlEscape(dateStr)}</t></is></c>""")
            sheet1Sb.append("""<c r="C$rIndex" t="inlineStr"><is><t>${xmlEscape(t.descricao)}</t></is></c>""")
            sheet1Sb.append("""<c r="D$rIndex" t="inlineStr"><is><t>${xmlEscape(catName)}</t></is></c>""")
            sheet1Sb.append("""<c r="E$rIndex" t="inlineStr"><is><t>${xmlEscape(t.tipo)}</t></is></c>""")
            sheet1Sb.append("""<c r="F$rIndex" s="2"><v>${t.valor}</v></c>""")
            sheet1Sb.append("""<c r="G$rIndex" t="inlineStr"><is><t>${xmlEscape(t.moedaOriginal)}</t></is></c>""")
            sheet1Sb.append("""<c r="H$rIndex" s="2"><v>${t.valorOriginal}</v></c>""")
            sheet1Sb.append("""<c r="I$rIndex" s="3"><v>${t.taxaCambioUsada}</v></c>""")
            sheet1Sb.append("""<c r="J$rIndex" t="inlineStr"><is><t>${xmlEscape(walletName)}</t></is></c>""")
            sheet1Sb.append("""<c r="K$rIndex" t="inlineStr"><is><t>${if (t.recorrente) "Sim" else "Não"}</t></is></c>""")
            sheet1Sb.append("""<c r="L$rIndex" t="inlineStr"><is><t>${if (t.ajusteCaixa) "Sim" else "Não"}</t></is></c>""")
            sheet1Sb.append("""</row>""")
            rIndex++
        }
        sheet1Sb.append("""</sheetData></worksheet>""")

        val totalInjecoes = transactions.filter { it.isReceita() }.sumOf { it.valor }
        val totalDespesas = transactions.filter { it.isDespesa() }.sumOf { it.valor }
        val saldoLiquido = totalInjecoes - totalDespesas

        val sheet2Sb = StringBuilder()
        sheet2Sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sheet2Sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        sheet2Sb.append("""<sheetData>""")
        sheet2Sb.append("""<row r="1"><c r="A1" t="inlineStr" s="1"><is><t>Métrica</t></is></c><c r="B1" t="inlineStr" s="1"><is><t>Valor (MT)</t></is></c></row>""")
        sheet2Sb.append("""<row r="2"><c r="A2" t="inlineStr"><is><t>Total de Injeções</t></is></c><c r="B2" s="2"><v>$totalInjecoes</v></c></row>""")
        sheet2Sb.append("""<row r="3"><c r="A3" t="inlineStr"><is><t>Total de Despesas</t></is></c><c r="B3" s="2"><v>$totalDespesas</v></c></row>""")
        sheet2Sb.append("""<row r="4"><c r="A4" t="inlineStr" s="1"><is><t>Saldo Líquido</t></is></c><c r="B4" s="2"><f>B2-B3</f><v>$saldoLiquido</v></c></row>""")
        sheet2Sb.append("""</sheetData></worksheet>""")

        val cacheDir = context.cacheDir
        val file = File(cacheDir, "relatorio_financas_m_${System.currentTimeMillis()}.xlsx")
        writeXlsxPackage(sheet1Sb.toString(), sheet2Sb.toString(), file)
        return file
    }

    private fun writeXlsxPackage(sheet1Xml: String, sheet2Xml: String, outputFile: File) {
        val contentTypesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

        val rootRelsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

        val workbookRelsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

        val workbookXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Lançamentos" sheetId="1" r:id="rId1"/>
    <sheet name="Resumo" sheetId="2" r:id="rId2"/>
  </sheets>
</workbook>"""

        val stylesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font><sz val="10"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
  </fonts>
  <fills count="2">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF1A73E8"/></patternFill></fill>
  </fills>
  <borders count="1"><border/></borders>
  <cellStyleXfs count="1"><xf/></cellStyleXfs>
  <cellXfs count="4">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
    <xf numFmtId="0" fontId="1" fillId="1" borderId="0" applyFont="1" applyFill="1"/>
    <xf numFmtId="4" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/>
    <xf numFmtId="2" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/>
  </cellXfs>
</styleSheet>"""

        java.util.zip.ZipOutputStream(outputFile.outputStream()).use { zip ->
            fun addZipEntry(path: String, content: String) {
                zip.putNextEntry(java.util.zip.ZipEntry(path))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }

            addZipEntry("[Content_Types].xml", contentTypesXml)
            addZipEntry("_rels/.rels", rootRelsXml)
            addZipEntry("xl/_rels/workbook.xml.rels", workbookRelsXml)
            addZipEntry("xl/workbook.xml", workbookXml)
            addZipEntry("xl/styles.xml", stylesXml)
            addZipEntry("xl/worksheets/sheet1.xml", sheet1Xml)
            addZipEntry("xl/worksheets/sheet2.xml", sheet2Xml)
        }
    }

    // Generates a professional, genuine vector PDF file in cache
    fun generateRealPdfFile(
        transactions: List<FinancialTransaction>,
        categories: List<Category>,
        wallets: List<Wallet>,
        periodName: String,
        moeda: String = "MZN"
    ): File {
        val categoryMap = categories.associateBy { it.id }
        val walletMap = wallets.associateBy { it.id }

        val totalDespesas = transactions.filter { it.isDespesa() }.sumOf { it.valor }
        val totalInjecoes = transactions.filter { it.isReceita() }.sumOf { it.valor }
        val saldoLiquido = totalInjecoes - totalDespesas

        val pdfDocument = PdfDocument()
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        val paintText = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.BLACK
            textSize = 10f
        }

        val paintHeader = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.parseColor("#1A73E8")
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 20f
        }

        val paintSub = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.GRAY
            textSize = 10f
        }

        val paintBold = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.BLACK
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 11f
        }

        val paintRect = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = android.graphics.Color.parseColor("#E0E0E0")
        }

        val drawTextSafe = { text: String, x: Float, y: Float, paint: Paint, maxWidth: Float ->
            var safeText = text
            if (paint.measureText(safeText) > maxWidth) {
                while (safeText.isNotEmpty() && paint.measureText("$safeText...") > maxWidth) {
                    safeText = safeText.substring(0, safeText.length - 1)
                }
                safeText = "$safeText..."
            }
            canvas.drawText(safeText, x, y, paint)
        }

        // Draw header
        canvas.drawText("FINANÇAS M", 40f, 50f, paintHeader)
        canvas.drawText("Gestão Financeira Pessoal", 40f, 65f, paintSub)

        canvas.drawText("Relatório de Lançamentos", 380f, 50f, paintBold)
        canvas.drawText("Período: $periodName", 380f, 65f, paintSub)

        // Horizontal divider
        canvas.drawLine(40f, 80f, 555f, 80f, paintRect)

        // Summary Cards Section
        paintBold.textSize = 11f
        canvas.drawText("RESUMO FINANCEIRO", 40f, 105f, paintBold)

        // Rounded Cards
        canvas.drawRoundRect(40f, 115f, 190f, 160f, 8f, 8f, paintRect)
        canvas.drawRoundRect(210f, 115f, 360f, 160f, 8f, 8f, paintRect)
        canvas.drawRoundRect(380f, 115f, 555f, 160f, 8f, 8f, paintRect)

        val paintGreenText = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.parseColor("#2E7D32")
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 12f
        }

        val paintRedText = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.parseColor("#D32F2F")
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 12f
        }

        val paintBlueText = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.parseColor("#1A73E8")
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 12f
        }

        // Card Labels & Values
        paintSub.textSize = 9f
        canvas.drawText("TOTAL INJEÇÕES", 50f, 130f, paintSub)
        canvas.drawText("${String.format("%,.2f", totalInjecoes)} ${moeda}", 50f, 148f, paintGreenText)

        canvas.drawText("TOTAL DESPESAS", 220f, 130f, paintSub)
        canvas.drawText("${String.format("%,.2f", totalDespesas)} ${moeda}", 220f, 148f, paintRedText)

        canvas.drawText("BALANÇO LÍQUIDO", 390f, 130f, paintSub)
        canvas.drawText("${String.format("%,.2f", saldoLiquido)} ${moeda}", 390f, 148f, paintBlueText)

        // Table Header
        paintBold.textSize = 11f
        canvas.drawText("DETALHES DOS LANÇAMENTOS", 40f, 190f, paintBold)

        canvas.drawRect(40f, 200f, 555f, 220f, paintRect)
        paintBold.textSize = 9f
        canvas.drawText("DATA", 45f, 214f, paintBold)
        canvas.drawText("DESCRIÇÃO", 145f, 214f, paintBold)
        canvas.drawText("CATEGORIA", 295f, 214f, paintBold)
        canvas.drawText("CARTEIRA", 395f, 214f, paintBold)
        canvas.drawText("VALOR", 495f, 214f, paintBold)

        var y = 238f

        paintText.textSize = 8f
        for (t in transactions) {
            // Check page overflow
            if (y > 800f) {
                pdfDocument.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                
                // Draw headers on new page
                canvas.drawText("FINANÇAS M (Continuação) - Pág. $pageNumber", 40f, 40f, paintSub)
                canvas.drawLine(40f, 48f, 555f, 48f, paintRect)
                
                // Draw table header again
                canvas.drawRect(40f, 58f, 555f, 78f, paintRect)
                canvas.drawText("DATA", 45f, 72f, paintBold)
                canvas.drawText("DESCRIÇÃO", 145f, 72f, paintBold)
                canvas.drawText("CATEGORIA", 295f, 72f, paintBold)
                canvas.drawText("CARTEIRA", 395f, 72f, paintBold)
                canvas.drawText("VALOR", 495f, 72f, paintBold)
                
                y = 96f
            }

            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(t.data))
            val catName = categoryMap[t.categoriaId]?.nome ?: "Desconhecido"
            val walletName = walletMap[t.carteiraOrigemId]?.nome ?: "Desconhecido"
            val descText = if (t.recorrente) "${t.descricao} [Recorrente]" else t.descricao
            // Cada linha do extrato inclui TODOS os tipos (não só Despesa/Receita), incluindo
            // pernas de Transferência e pagamentos de Empréstimo — "tipo == Despesa" tratava
            // tudo o resto como entrada (+/verde), mostrando pagamentos de empréstimo e a
            // perna de saída de uma transferência como se fossem receita.
            val isOutflow = when {
                t.tipo == "Despesa" || t.tipo == "PagamentoEmprestimo" -> true
                t.tipo == "Transferencia" -> t.descricao.endsWith(" (Saída)") || t.descricao.endsWith(" (Out)")
                else -> false
            }
            val valText = "${if (isOutflow) "-" else "+"} ${String.format("%,.2f", t.valor)} ${moeda}"
            val paintVal = if (isOutflow) paintRedText else paintGreenText
            paintVal.textSize = 8f

            drawTextSafe(dateStr, 45f, y, paintText, 95f)
            drawTextSafe(descText, 145f, y, paintText, 145f)
            drawTextSafe(catName, 295f, y, paintText, 95f)
            drawTextSafe(walletName, 395f, y, paintText, 95f)
            
            // Align value to right
            val valWidth = paintVal.measureText(valText)
            canvas.drawText(valText, 550f - valWidth, y, paintVal)

            canvas.drawLine(40f, y + 6f, 555f, y + 6f, paintRect)
            y += 18f
        }

        // Draw footer on the last page
        if (y > 780f) {
            pdfDocument.finishPage(page)
            pageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            y = 50f
        }

        canvas.drawLine(40f, y + 10f, 555f, y + 10f, paintRect)
        val footerText = "Relatório gerado em ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())} pelo Finanças M."
        canvas.drawText(footerText, 40f, y + 25f, paintSub)

        pdfDocument.finishPage(page)

        val cacheDir = context.cacheDir
        val file = File(cacheDir, "relatorio_financas_m_${System.currentTimeMillis()}.pdf")
        file.outputStream().use { pdfDocument.writeTo(it) }
        pdfDocument.close()
        return file
    }

    // Saves file to system Downloads folder
    fun saveFileToDownloads(file: File, fileName: String, mimeType: String) {
        var filePathSaved: String? = null
        val success = try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Download")
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues) ?: throw Exception("Failed to insert MediaStore download entry")
                resolver.openOutputStream(uri)?.use { output ->
                    file.inputStream().use { input ->
                        input.copyTo(output)
                    }
                }
                filePathSaved = "/storage/emulated/0/Download/$fileName"
                true
            } else {
                val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val targetFile = File(downloadsDir, fileName)
                file.copyTo(targetFile, overwrite = true)
                filePathSaved = targetFile.absolutePath
                true
            }
        } catch (e: Exception) {
            Log.e("ExportService", "Failed to copy export file to downloads", e)
            false
        }

        val msg = if (success && filePathSaved != null) {
            "Relatório exportado com sucesso em: $filePathSaved"
        } else {
            "Erro ao exportar o relatório"
        }
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
        }
    }

    // Triggers sharing of a cache file
    fun shareFile(file: File, mimeType: String, chooserTitle: String) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Relatório de Lançamentos - Finanças M")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(intent, chooserTitle).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("ExportService", "Failed to share file", e)
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(context, "Erro ao partilhar ficheiro", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
