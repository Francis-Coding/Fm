package com.example.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class FinancialRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val userSettingsDao = db.userSettingsDao()
    private val walletDao = db.walletDao()
    private val categoryDao = db.categoryDao()
    private val transactionDao = db.transactionDao()
    private val dailyClosureDao = db.dailyClosureDao()
    private val financialGoalDao = db.financialGoalDao()
    private val recycleBinDao = db.recycleBinDao()
    private val spendingLimitDao = db.spendingLimitDao()
    private val loanDao = db.loanDao()
    private val installmentDao = db.installmentDao()
    private val shoppingItemDao = db.shoppingItemDao()
    private val shoppingListDao = db.shoppingListDao()
    private val shoppingCategoryDao = db.shoppingCategoryDao()
    private val shoppingPriceHistoryDao = db.shoppingPriceHistoryDao()
    private val loanReceiptDao = db.loanReceiptDao()
    private val subscriptionDao = db.subscriptionDao()
    private val creditCardDao = db.creditCardDao()
    private val exportedReportDao = db.exportedReportDao()
    private val scheduledTransferDao = db.scheduledTransferDao()
    private val notificationDao = db.notificationDao()

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val transactionAdapter = moshi.adapter(FinancialTransaction::class.java)

    // Flow Data
    val userSettings: Flow<UserSettings?> = userSettingsDao.getUserSettings()
    val wallets: Flow<List<Wallet>> = walletDao.getAllWallets()
    val categories: Flow<List<Category>> = categoryDao.getAllCategories()
    val transactions: Flow<List<FinancialTransaction>> = transactionDao.getAllTransactionsFlow()
    val closures: Flow<List<DailyClosure>> = dailyClosureDao.getAllClosures()
    val goals: Flow<List<FinancialGoal>> = financialGoalDao.getAllGoals()
    val trashItems: Flow<List<RecycleBin>> = recycleBinDao.getAllTrashItems()
    val spendingLimits: Flow<List<SpendingLimit>> = spendingLimitDao.getAllSpendingLimits()
    val loans: Flow<List<Loan>> = loanDao.getAllLoans()
    val installments: Flow<List<Installment>> = installmentDao.getAllInstallments()
    val shoppingItems: Flow<List<ShoppingItem>> = shoppingItemDao.getAllShoppingItems()
    val shoppingLists: Flow<List<ShoppingList>> = shoppingListDao.getAllLists()
    val shoppingCategories: Flow<List<ShoppingCategory>> = shoppingCategoryDao.getAllCategories()
    val allPriceHistory: Flow<List<ShoppingPriceHistory>> = shoppingPriceHistoryDao.getAllPriceHistory()
    val distinctProductNames: Flow<List<String>> = shoppingItemDao.getDistinctProductNames()
    val subscriptions: Flow<List<Subscription>> = subscriptionDao.getAllSubscriptions()
    val creditCards: Flow<List<CreditCard>> = creditCardDao.getAllCreditCards()
    val scheduledTransfers: Flow<List<ScheduledTransfer>> = scheduledTransferDao.getAllScheduledTransfers()
    val notifications: Flow<List<NotificationEntity>> = notificationDao.getActiveNotifications()

    fun getUnreadNotificationsCount(): Flow<Int> = notificationDao.getUnreadCount()

    suspend fun markNotificationAsRead(id: Int) = withContext(Dispatchers.IO) {
        notificationDao.markAsRead(id, System.currentTimeMillis())
    }

    suspend fun markAllNotificationsAsRead() = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead(System.currentTimeMillis())
    }

    /**
     * Recalcula os alertas acionáveis (empréstimos, faturas de cartão, assinaturas e limites de
     * categoria perto do vencimento/limite) e sincroniza-os com a tabela `notifications`, que
     * alimenta o badge do sino no Dashboard e o ecrã "Central de Notificações".
     *
     * Reaproveita exatamente as mesmas condições que o ReminderReceiver usa para as notificações
     * push do sistema, para as duas fontes de alerta nunca divergirem.
     *
     * Idempotente: uma notificação já lida pelo utilizador não é reaberta só por esta função ter
     * corrido de novo. Só é recriada como não lida se tinha sido marcada como resolvida e a mesma
     * condição voltou a aplicar-se (ex.: nova fatura do mesmo cartão no mês seguinte).
     */
    suspend fun syncNotifications(idioma: String = "PT") = withContext(Dispatchers.IO) {
        val candidates = mutableListOf<NotificationEntity>()
        val cal = Calendar.getInstance()
        val currentDayOfMonth = cal.get(Calendar.DAY_OF_MONTH)

        // 1. Empréstimos pendentes a vencer em até 3 dias
        val loansList = loanDao.getAllLoans().firstOrNull() ?: emptyList()
        val dueSoonLoans = com.example.domain.usecases.CheckPendingLoansUseCase().getPendingLoansDueSoon(loansList)
        for ((loan, daysLeft) in dueSoonLoans) {
            val title = if (idioma == "PT") {
                if (daysLeft == 0) "Empréstimo vence hoje!" else "Vencimento de Empréstimo"
            } else {
                if (daysLeft == 0) "Loan due today!" else "Loan Due Date"
            }
            val msg = if (idioma == "PT") {
                if (daysLeft == 0) "O empréstimo de ${loan.counterparty} no valor de ${String.format(Locale.US, "%,.2f", loan.principalAmount)} MZN vence hoje!"
                else "O empréstimo de ${loan.counterparty} no valor de ${String.format(Locale.US, "%,.2f", loan.principalAmount)} MZN vence em $daysLeft dias."
            } else {
                if (daysLeft == 0) "The loan from ${loan.counterparty} (${String.format(Locale.US, "%,.2f", loan.principalAmount)} MZN) is due today!"
                else "The loan from ${loan.counterparty} (${String.format(Locale.US, "%,.2f", loan.principalAmount)} MZN) is due in $daysLeft days."
            }
            candidates.add(
                NotificationEntity(
                    notificationId = 20000 + loan.id,
                    type = "LOAN_OVERDUE",
                    title = title,
                    message = msg,
                    entityType = "LOAN",
                    entityId = loan.id,
                    priority = if (daysLeft == 0) "HIGH" else "NORMAL"
                )
            )
        }

        // 2. Faturas de cartão de crédito a vencer em até 3 dias
        val creditCardsList = creditCardDao.getAllCreditCardsDirect()
        for (card in creditCardsList) {
            if (!card.ativa) continue
            val invoiceAmount = card.limiteTotal - card.limiteDisponivel
            if (invoiceAmount <= 0) continue
            val diffDays = card.diaVencimento - currentDayOfMonth
            if (diffDays in 0..3) {
                val title = if (idioma == "PT") {
                    if (diffDays == 0) "Fatura do Cartão Vence Hoje!" else "Vencimento de Fatura"
                } else {
                    if (diffDays == 0) "Card Bill Due Today!" else "Bill Due Date"
                }
                val msg = if (idioma == "PT") {
                    if (diffDays == 0) "A fatura do cartão ${card.nome} (${String.format(Locale.US, "%,.2f", invoiceAmount)} MZN) vence hoje!"
                    else "A fatura do cartão ${card.nome} (${String.format(Locale.US, "%,.2f", invoiceAmount)} MZN) vence em $diffDays dias."
                } else {
                    if (diffDays == 0) "The bill for card ${card.nome} (${String.format(Locale.US, "%,.2f", invoiceAmount)} MZN) is due today!"
                    else "The bill for card ${card.nome} (${String.format(Locale.US, "%,.2f", invoiceAmount)} MZN) is due in $diffDays days."
                }
                candidates.add(
                    NotificationEntity(
                        notificationId = 60000 + card.id,
                        type = "RECURRING_PAYMENT",
                        title = title,
                        message = msg,
                        entityType = "CARD",
                        entityId = card.id,
                        priority = if (diffDays == 0) "HIGH" else "NORMAL"
                    )
                )
            }
        }

        // 3. Assinaturas a cobrar em até 3 dias
        val subsList = subscriptionDao.getAllSubscriptionsDirect()
        for (sub in subsList) {
            if (!sub.ativa) continue
            val diffDays = sub.diaCobranca - currentDayOfMonth
            if (diffDays in 0..3) {
                val title = if (idioma == "PT") {
                    if (diffDays == 0) "Cobrança de Assinatura Hoje" else "Próxima Cobrança de Assinatura"
                } else {
                    if (diffDays == 0) "Subscription Charge Today" else "Upcoming Subscription Charge"
                }
                val msg = if (idioma == "PT") {
                    if (diffDays == 0) "A assinatura de ${sub.nome} (${String.format(Locale.US, "%,.2f", sub.valor)} MZN) é cobrada hoje!"
                    else "A assinatura de ${sub.nome} (${String.format(Locale.US, "%,.2f", sub.valor)} MZN) será cobrada em $diffDays dias."
                } else {
                    if (diffDays == 0) "The subscription ${sub.nome} (${String.format(Locale.US, "%,.2f", sub.valor)} MZN) is charged today!"
                    else "The subscription ${sub.nome} (${String.format(Locale.US, "%,.2f", sub.valor)} MZN) will be charged in $diffDays days."
                }
                candidates.add(
                    NotificationEntity(
                        notificationId = 70000 + sub.id,
                        type = "RECURRING_PAYMENT",
                        title = title,
                        message = msg,
                        entityType = "SUBSCRIPTION",
                        entityId = sub.id,
                        priority = if (diffDays == 0) "HIGH" else "NORMAL"
                    )
                )
            }
        }

        // 4. Categorias que atingiram 80%+ do limite mensal
        val categoriesList = categoryDao.getAllCategoriesDirect()
        val monthStart = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val currentMonthExpenses = transactionDao.getTransactionsSinceDirect(monthStart).filter { it.isDespesa() }
        for (catItem in categoriesList) {
            if (catItem.limiteMensal > 0) {
                val spent = currentMonthExpenses.filter { it.categoriaId == catItem.id }.sumOf { it.valor }
                val percent = ((spent / catItem.limiteMensal) * 100).toInt()
                if (percent >= 80) {
                    val title = if (idioma == "PT") "Alerta de Limite de Gastos" else "Spending Limit Alert"
                    val msg = if (idioma == "PT") "A categoria '${catItem.nome}' já atingiu $percent% do seu limite mensal!"
                              else "The '${catItem.nome}' category has reached $percent% of its monthly limit!"
                    candidates.add(
                        NotificationEntity(
                            notificationId = 40000 + catItem.id,
                            type = "INSUFFICIENT_BALANCE",
                            title = title,
                            message = msg,
                            entityType = "BUDGET",
                            entityId = catItem.id,
                            priority = if (percent >= 100) "HIGH" else "NORMAL"
                        )
                    )
                }
            }
        }

        // Upsert idempotente: preserva o estado UNREAD/READ já dado pelo utilizador; só cria
        // notificações novas ou reabre as que tinham sido marcadas como resolvidas/arquivadas.
        for (candidate in candidates) {
            val existing = notificationDao.getNotificationById(candidate.notificationId)
            if (existing == null) {
                notificationDao.insertNotification(candidate)
            } else if (existing.status == "RESOLVED" || existing.status == "ARCHIVED") {
                notificationDao.insertNotification(candidate.copy(status = "UNREAD", readAt = null))
            }
        }

        // Resolve alertas cuja condição já não se aplica (empréstimo pago, fatura quitada, etc.)
        val stillActiveIds = candidates.map { it.notificationId }.toSet()
        val currentlyActive = notificationDao.getAllNotifications().firstOrNull()
            ?.filter { it.status == "UNREAD" || it.status == "READ" } ?: emptyList()
        for (existingNotif in currentlyActive) {
            if (existingNotif.entityType in listOf("LOAN", "CARD", "SUBSCRIPTION", "BUDGET") &&
                existingNotif.notificationId !in stillActiveIds
            ) {
                notificationDao.resolveNotificationsForEntity(existingNotif.entityType, existingNotif.entityId)
            }
        }
    }

    // Setup default values if database is empty
    suspend fun populateDefaultsIfEmpty() = withContext(Dispatchers.IO) {
        // 1. User Settings
        val currentSettings = userSettingsDao.getUserSettingsDirect()
        if (currentSettings == null) {
            userSettingsDao.insertOrUpdate(UserSettings())
        }

        // 2. Wallets
        // Removed default wallets prepopulation so that the app starts with empty accounts/wallets as requested by the user.

        // 3. Categories
        val existingCategories = categoryDao.getAllCategoriesDirect()
        if (existingCategories.isEmpty()) {
            for (category in DefaultData.defaultCategories) {
                categoryDao.insertCategory(category)
            }
        }

        // 4. Default Shopping List
        val lists = shoppingLists.firstOrNull() ?: emptyList()
        if (lists.isEmpty()) {
            for (l in DefaultData.defaultShoppingLists) {
                shoppingListDao.insertList(l)
            }
        }

        // 5. Default Shopping Categories
        val shopCategories = shoppingCategories.firstOrNull() ?: emptyList()
        if (shopCategories.isEmpty()) {
            for (cat in DefaultData.defaultShoppingCategories) {
                shoppingCategoryDao.insertCategory(cat)
            }
        }

        // 6. Default Subscriptions (Empty by default for clean user input & cleanup non-expense recurring subscriptions)
        val allSubs = subscriptionDao.getAllSubscriptionsDirect()
        val allTxs = transactionDao.getAllTransactionsDirect()
        for (sub in allSubs) {
            if (sub.sourceTransactionId != null) {
                val tx = allTxs.find { it.id == sub.sourceTransactionId }
                if (tx != null && (tx.tipo != "Despesa" || !tx.recorrente)) {
                    subscriptionDao.update(sub.copy(ativa = false))
                }
            }
        }

        // 7. Default Credit Cards (Empty by default for clean user input)
    }

    // Credit Card Operations
    suspend fun addCreditCard(card: CreditCard) = withContext(Dispatchers.IO) {
        creditCardDao.insertCreditCard(card)
    }

    suspend fun updateCreditCard(card: CreditCard) = withContext(Dispatchers.IO) {
        creditCardDao.updateCreditCard(card)
    }

    suspend fun deleteCreditCard(card: CreditCard) = withContext(Dispatchers.IO) {
        creditCardDao.deleteCreditCard(card)
    }

    // Descrições geradas automaticamente pelo repositório (pagamentos de fatura, assinaturas,
    // metas, reconciliações, etc.) ficavam sempre gravadas em português, independentemente do
    // idioma escolhido pelo utilizador, porque esta camada não recebia esse dado. Lido aqui,
    // centralizado, cobre também as chamadas em segundo plano (ex. ReminderReceiver) que não
    // têm acesso direto ao estado da UI.
    private suspend fun currentIdioma(): String = userSettingsDao.getUserSettingsDirect()?.idioma ?: "PT"

    suspend fun payCreditCardInvoice(cardId: Int, amount: Double, walletId: Int) = withContext(Dispatchers.IO) {
        db.withTransaction {
            val card = creditCardDao.getCreditCardById(cardId) ?: return@withTransaction
            val newDisponivel = (card.limiteDisponivel + amount).coerceAtMost(card.limiteTotal)
            creditCardDao.updateCreditCard(card.copy(limiteDisponivel = newDisponivel))

            // Subtract amount from paying wallet
            val wallet = walletDao.getWalletById(walletId)
            if (wallet != null) {
                walletDao.updateWallet(wallet.copy(saldoAtual = wallet.saldoAtual - amount))
            }

            // Add payment transaction
            val cats = categoryDao.getAllCategoriesDirect()
            val cat = cats.find { it.tipo == "Despesa" } ?: cats.firstOrNull()
            if (cat != null) {
                val idioma = currentIdioma()
                val tx = FinancialTransaction(
                    data = System.currentTimeMillis(),
                    categoriaId = cat.id,
                    descricao = if (idioma == "PT") "Pagamento da Fatura - ${card.nome}" else "Invoice Payment - ${card.nome}",
                    valor = amount,
                    tipo = "Despesa",
                    carteiraOrigemId = walletId
                )
                transactionDao.insertTransaction(tx)
            }
        }
    }

    suspend fun suggestCategoryForDescription(description: String): Int? = withContext(Dispatchers.IO) {
        if (description.trim().length < 2) return@withContext null
        val transactions = transactionDao.getAllTransactionsDirect()
        val match = transactions.filter { 
            it.descricao.contains(description.trim(), ignoreCase = true) 
        }.groupBy { it.categoriaId }
         .maxByOrNull { it.value.size }
        match?.key
    }

    suspend fun addCreditCardPurchase(cardId: Int, amount: Double, description: String, categoryId: Int) = withContext(Dispatchers.IO) {
        db.withTransaction {
            val card = creditCardDao.getCreditCardById(cardId) ?: return@withTransaction
            val newDisponivel = (card.limiteDisponivel - amount).coerceAtLeast(0.0)
            creditCardDao.updateCreditCard(card.copy(limiteDisponivel = newDisponivel))

            val walletsList = walletDao.getAllWalletsDirect()
            val walletId = card.carteiraPagamentoId.takeIf { id -> walletsList.any { it.id == id } } ?: (walletsList.firstOrNull()?.id ?: 1)

            val idioma = currentIdioma()
            val tx = FinancialTransaction(
                data = System.currentTimeMillis(),
                categoriaId = categoryId,
                descricao = if (idioma == "PT") "Compra no Cartão (${card.nome}): $description" else "Card Purchase (${card.nome}): $description",
                valor = amount,
                tipo = "Despesa",
                carteiraOrigemId = walletId,
                ajusteCaixa = true // Doesn't immediately debit cash wallet because it's on credit limit
            )
            transactionDao.insertTransaction(tx)
        }
    }

    // Subscription Operations
    suspend fun addSubscription(subscription: Subscription) = withContext(Dispatchers.IO) {
        subscriptionDao.insert(subscription)
    }

    suspend fun updateSubscription(subscription: Subscription) = withContext(Dispatchers.IO) {
        subscriptionDao.update(subscription)
    }

    suspend fun deleteSubscription(id: Int) = withContext(Dispatchers.IO) {
        subscriptionDao.deleteById(id)
    }

    suspend fun paySubscriptionNow(subscription: Subscription) = withContext(Dispatchers.IO) {
        db.withTransaction {
            val wallets = walletDao.getAllWalletsDirect()
            val wallet = wallets.find { it.id == subscription.carteiraId } ?: wallets.firstOrNull() ?: return@withTransaction

            // Deduct from wallet
            walletDao.updateWallet(wallet.copy(saldoAtual = wallet.saldoAtual - subscription.valor))

            // Find or get category
            val categories = categoryDao.getAllCategoriesDirect()
            val category = categories.find { it.id == subscription.categoriaId } ?: categories.find { it.tipo == TransactionType.DESPESA || it.tipo == "DESPESA" } ?: categories.firstOrNull()

            val tx = FinancialTransaction(
                data = System.currentTimeMillis(),
                categoriaId = category?.id ?: 0,
                descricao = if (currentIdioma() == "PT") "Assinatura: ${subscription.nome}" else "Subscription: ${subscription.nome}",
                valor = subscription.valor,
                tipo = TransactionType.DESPESA,
                carteiraOrigemId = wallet.id
            )
            transactionDao.insertTransaction(tx)
            subscriptionDao.update(subscription.copy(dataCobranca = System.currentTimeMillis()))
        }
    }

    suspend fun processPendingSubscriptionBills() = withContext(Dispatchers.IO) {
        db.withTransaction {
            val activeSubs = subscriptionDao.getAllSubscriptionsDirect().filter { it.ativa }
            val calNow = Calendar.getInstance()
            val currentYearMonth = calNow.get(Calendar.YEAR) * 12 + calNow.get(Calendar.MONTH)
            val currentDayOfMonth = calNow.get(Calendar.DAY_OF_MONTH)
            val idioma = currentIdioma()

            for (sub in activeSubs) {
                val calLastBilled = Calendar.getInstance().apply { timeInMillis = sub.dataCobranca }
                val lastBilledYearMonth = calLastBilled.get(Calendar.YEAR) * 12 + calLastBilled.get(Calendar.MONTH)

                // If not billed for current month and current day is past or equal to billing day
                if (currentYearMonth > lastBilledYearMonth && currentDayOfMonth >= sub.diaCobranca) {
                    val wallets = walletDao.getAllWalletsDirect()
                    val wallet = wallets.find { it.id == sub.carteiraId } ?: wallets.firstOrNull() ?: continue
                    walletDao.updateWallet(wallet.copy(saldoAtual = wallet.saldoAtual - sub.valor))

                    val categories = categoryDao.getAllCategoriesDirect()
                    val category = categories.find { it.id == sub.categoriaId } ?: categories.find { it.tipo == TransactionType.DESPESA || it.tipo == "DESPESA" } ?: categories.firstOrNull()

                    val tx = FinancialTransaction(
                        data = System.currentTimeMillis(),
                        categoriaId = category?.id ?: 0,
                        descricao = if (idioma == "PT") "Assinatura (Auto): ${sub.nome}" else "Subscription (Auto): ${sub.nome}",
                        valor = sub.valor,
                        tipo = TransactionType.DESPESA,
                        carteiraOrigemId = wallet.id
                    )
                    transactionDao.insertTransaction(tx)
                    subscriptionDao.update(sub.copy(dataCobranca = System.currentTimeMillis()))
                }
            }
        }
    }

    // User Settings Operations
    suspend fun updateUserSettings(settings: UserSettings) = withContext(Dispatchers.IO) {
        userSettingsDao.insertOrUpdate(settings)
    }

    // Wallet Operations
    suspend fun addWallet(wallet: Wallet) = withContext(Dispatchers.IO) {
        walletDao.insertWallet(wallet)
    }

    suspend fun updateWallet(wallet: Wallet) = withContext(Dispatchers.IO) {
        walletDao.updateWallet(wallet)
    }

    suspend fun updateWallets(wallets: List<Wallet>) = withContext(Dispatchers.IO) {
        walletDao.updateWallets(wallets)
    }

    suspend fun deleteWallet(wallet: Wallet) = withContext(Dispatchers.IO) {
        walletDao.deleteWallet(wallet)
    }

    // Category Operations
    suspend fun addCategory(category: Category) = withContext(Dispatchers.IO) {
        categoryDao.insertCategory(category)
    }

    suspend fun updateCategory(category: Category) = withContext(Dispatchers.IO) {
        categoryDao.updateCategory(category)
    }

    suspend fun deleteCategory(category: Category) = withContext(Dispatchers.IO) {
        categoryDao.deleteCategory(category)
    }

    // Transaction Operations (with automatic wallet balance adjustments)
    suspend fun syncRecurringTransactionToSubscription(transaction: FinancialTransaction) = withContext(Dispatchers.IO) {
        if (!transaction.recorrente || transaction.tipo != "Despesa") {
            if (transaction.id > 0) {
                val existingSub = subscriptionDao.getSubscriptionBySourceTransactionId(transaction.id)
                if (existingSub != null && existingSub.ativa) {
                    subscriptionDao.update(existingSub.copy(ativa = false))
                }
            }
            return@withContext
        }

        val existingSub = if (transaction.id > 0) subscriptionDao.getSubscriptionBySourceTransactionId(transaction.id) else null

        val ciclo = when (transaction.recurrenceFrequency?.lowercase()) {
            "semanal" -> "SEMANAL"
            "trimestral" -> "TRIMESTRAL"
            "anual" -> "ANUAL"
            else -> "MENSAL"
        }
        val targetDate = transaction.nextOccurrenceDate ?: transaction.data
        val cal = Calendar.getInstance().apply { timeInMillis = targetDate }
        val dia = cal.get(Calendar.DAY_OF_MONTH)

        if (existingSub != null) {
            val updatedSub = existingSub.copy(
                nome = transaction.descricao,
                valor = transaction.valor,
                cicloCobranca = ciclo,
                diaCobranca = dia,
                dataCobranca = targetDate,
                ativa = true,
                categoriaId = transaction.categoriaId ?: 0,
                carteiraId = transaction.carteiraOrigemId,
                moeda = transaction.moedaOriginal
            )
            subscriptionDao.update(updatedSub)
        } else {
            val newSub = Subscription(
                nome = transaction.descricao,
                valor = transaction.valor,
                cicloCobranca = ciclo,
                diaCobranca = dia,
                dataCobranca = targetDate,
                ativa = true,
                icone = "custom",
                corHex = "#1A73E8",
                categoriaId = transaction.categoriaId ?: 0,
                carteiraId = transaction.carteiraOrigemId,
                moeda = transaction.moedaOriginal,
                sourceTransactionId = if (transaction.id > 0) transaction.id else null
            )
            subscriptionDao.insert(newSub)
        }
    }

    suspend fun addTransaction(transaction: FinancialTransaction) = withContext(Dispatchers.IO) {
        db.withTransaction {
            // Insert transaction
            val insertedId = transactionDao.insertTransaction(transaction).toInt()
            val insertedTx = transaction.copy(id = insertedId)

            // Adjust wallet balance
            if (!transaction.ajusteCaixa) {
                val wallet = walletDao.getWalletById(transaction.carteiraOrigemId)
                if (wallet != null) {
                    val novoSaldo = if (transaction.tipo == "Despesa") {
                        wallet.saldoAtual - transaction.valor
                    } else {
                        wallet.saldoAtual + transaction.valor
                    }
                    walletDao.updateWallet(wallet.copy(saldoAtual = novoSaldo))
                }
            }

            if (insertedTx.recorrente) {
                syncRecurringTransactionToSubscription(insertedTx)
            }
        }
    }

    suspend fun updateTransaction(oldTransaction: FinancialTransaction, newTransaction: FinancialTransaction) = withContext(Dispatchers.IO) {
        db.withTransaction {
            // 1. Reverse old transaction's wallet balance
            if (!oldTransaction.ajusteCaixa) {
                val oldWallet = walletDao.getWalletById(oldTransaction.carteiraOrigemId)
                if (oldWallet != null) {
                    val oldReversedSaldo = if (oldTransaction.tipo == "Despesa") {
                        oldWallet.saldoAtual + oldTransaction.valor
                    } else {
                        oldWallet.saldoAtual - oldTransaction.valor
                    }
                    walletDao.updateWallet(oldWallet.copy(saldoAtual = oldReversedSaldo))
                }
            }

            // 2. Apply new transaction's wallet balance
            if (!newTransaction.ajusteCaixa) {
                val newWallet = walletDao.getWalletById(newTransaction.carteiraOrigemId)
                if (newWallet != null) {
                    // Fetch updated newWallet from DB to ensure accurate balance
                    val updatedNewWallet = walletDao.getWalletById(newTransaction.carteiraOrigemId) ?: newWallet
                    val newSaldo = if (newTransaction.tipo == "Despesa") {
                        updatedNewWallet.saldoAtual - newTransaction.valor
                    } else {
                        updatedNewWallet.saldoAtual + newTransaction.valor
                    }
                    walletDao.updateWallet(updatedNewWallet.copy(saldoAtual = newSaldo))
                }
            }

            // 3. Update transaction in database
            transactionDao.updateTransaction(newTransaction)

            // 4. Sync recurring status to Subscription
            syncRecurringTransactionToSubscription(newTransaction)
        }
    }

    // Checking for a potential duplicate transaction on the same day, category, amount, wallet and type
    suspend fun checkPotentialDuplicate(date: Long, categoryId: Int, amount: Double, walletId: Int, tipo: String = "Despesa", excludeId: Int = -1): Boolean = withContext(Dispatchers.IO) {
        // Use system default TimeZone explicitly for day bounds calculations
        val cal = Calendar.getInstance(TimeZone.getDefault())
        cal.timeInMillis = date
        // Day bounds
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startOfDay = cal.timeInMillis

        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        val endOfDay = cal.timeInMillis

        val todaysTransactions = transactionDao.getTransactionsInRange(startOfDay, endOfDay)
        todaysTransactions.any { 
            it.id != excludeId &&
            it.categoriaId == categoryId && 
            Math.abs(it.valor - amount) < 0.01 && 
            it.carteiraOrigemId == walletId &&
            it.tipo == tipo
        }
    }

    // Deleting a transaction moves it to Recycle Bin and reverses the wallet balance
    suspend fun deleteTransaction(transaction: FinancialTransaction) = withContext(Dispatchers.IO) {
        db.withTransaction {
            // Move to recycle bin
            val originalJson = transactionAdapter.toJson(transaction)
            val recycleBinItem = RecycleBin(
                transacaoOriginalId = transaction.id,
                transacaoOriginalJson = originalJson,
                dataExclusao = System.currentTimeMillis()
            )
            recycleBinDao.insertTrash(recycleBinItem)

            // Delete from transactions
            transactionDao.deleteTransactionById(transaction.id)

            // Deactivate linked subscription if present
            val linkedSub = subscriptionDao.getSubscriptionBySourceTransactionId(transaction.id)
            if (linkedSub != null && linkedSub.ativa) {
                subscriptionDao.update(linkedSub.copy(ativa = false))
            }

            // Reverse wallet balance impact
            if (!transaction.ajusteCaixa) {
                val wallet = walletDao.getWalletById(transaction.carteiraOrigemId)
                if (wallet != null) {
                    val novoSaldo = if (transaction.tipo == "Despesa") {
                        wallet.saldoAtual + transaction.valor // Add back the expense
                    } else {
                        wallet.saldoAtual - transaction.valor // Subtract the income
                    }
                    walletDao.updateWallet(wallet.copy(saldoAtual = novoSaldo))
                }
            }
        }
    }

    // Uma Transferência gera duas transações-espelho (Saída/Entrada, ver transferBetweenWallets
    // e logScheduledTransferTransactions) sem uma FK que as ligue explicitamente. Encontramos a
    // outra perna pelo mesmo valor, o mesmo tipo, a mesma descrição base (só o sufixo Saída/
    // Entrada muda, em PT ou EN conforme o idioma de quem criou a transferência) e uma data
    // muito próxima — as duas são sempre inseridas na mesma operação.
    private val TRANSFER_OUT_SUFFIXES = listOf(" (Saída)", " (Out)")
    private val TRANSFER_IN_SUFFIXES = listOf(" (Entrada)", " (In)")

    private fun stripTransferSuffix(descricao: String): String {
        for (suf in TRANSFER_OUT_SUFFIXES + TRANSFER_IN_SUFFIXES) {
            if (descricao.endsWith(suf)) return descricao.removeSuffix(suf)
        }
        return descricao
    }

    private fun isTransferEntrada(descricao: String): Boolean = TRANSFER_IN_SUFFIXES.any { descricao.endsWith(it) }

    private suspend fun findTransferSibling(transaction: FinancialTransaction): FinancialTransaction? {
        val baseDescricao = stripTransferSuffix(transaction.descricao)
        val nearby = transactionDao.getTransactionsInRange(transaction.data - 5000, transaction.data + 5000)
        return nearby.firstOrNull {
            it.id != transaction.id &&
            it.tipo == "Transferencia" &&
            Math.abs(it.valor - transaction.valor) < 0.01 &&
            stripTransferSuffix(it.descricao) == baseDescricao &&
            it.carteiraOrigemId != transaction.carteiraOrigemId
        }
    }

    private fun reverseTransferLegBalance(wallet: Wallet, transaction: FinancialTransaction): Wallet {
        val isEntrada = isTransferEntrada(transaction.descricao)
        val novoSaldo = if (isEntrada) wallet.saldoAtual - transaction.valor else wallet.saldoAtual + transaction.valor
        return wallet.copy(saldoAtual = novoSaldo)
    }

    private fun applyTransferLegBalance(wallet: Wallet, transaction: FinancialTransaction): Wallet {
        val isEntrada = isTransferEntrada(transaction.descricao)
        val novoSaldo = if (isEntrada) wallet.saldoAtual + transaction.valor else wallet.saldoAtual - transaction.valor
        return wallet.copy(saldoAtual = novoSaldo)
    }

    // Elimina as DUAS pernas de uma Transferência em conjunto e reverte o saldo de ambas as
    // carteiras. Apagar só a perna selecionada (o comportamento antigo, herdado do
    // deleteTransaction genérico) deixava o dinheiro "preso": o saldo não voltava atrás — porque
    // ajusteCaixa=true faz deleteTransaction saltar a reversão — e ficava um registo órfão sem
    // par na outra carteira. Devolve a perna irmã (ou null) para o "Desfazer" conseguir reverter
    // exatamente este efeito.
    suspend fun deleteTransferTransaction(transaction: FinancialTransaction): FinancialTransaction? = withContext(Dispatchers.IO) {
        db.withTransaction {
            val sibling = findTransferSibling(transaction)

            val wallet = walletDao.getWalletById(transaction.carteiraOrigemId)
            if (wallet != null) walletDao.updateWallet(reverseTransferLegBalance(wallet, transaction))
            recycleBinDao.insertTrash(
                RecycleBin(
                    transacaoOriginalId = transaction.id,
                    transacaoOriginalJson = transactionAdapter.toJson(transaction),
                    dataExclusao = System.currentTimeMillis()
                )
            )
            transactionDao.deleteTransactionById(transaction.id)

            if (sibling != null) {
                val siblingWallet = walletDao.getWalletById(sibling.carteiraOrigemId)
                if (siblingWallet != null) walletDao.updateWallet(reverseTransferLegBalance(siblingWallet, sibling))
                recycleBinDao.insertTrash(
                    RecycleBin(
                        transacaoOriginalId = sibling.id,
                        transacaoOriginalJson = transactionAdapter.toJson(sibling),
                        dataExclusao = System.currentTimeMillis()
                    )
                )
                transactionDao.deleteTransactionById(sibling.id)
            }
            sibling
        }
    }

    // Desfaz deleteTransferTransaction: restaura as duas pernas e reaplica o saldo de ambas.
    suspend fun undoDeleteTransferTransaction(transaction: FinancialTransaction, sibling: FinancialTransaction?) = withContext(Dispatchers.IO) {
        db.withTransaction {
            transactionDao.insertTransaction(transaction)
            val wallet = walletDao.getWalletById(transaction.carteiraOrigemId)
            if (wallet != null) walletDao.updateWallet(applyTransferLegBalance(wallet, transaction))
            recycleBinDao.deleteTrashByOriginalId(transaction.id)

            if (sibling != null) {
                transactionDao.insertTransaction(sibling)
                val siblingWallet = walletDao.getWalletById(sibling.carteiraOrigemId)
                if (siblingWallet != null) walletDao.updateWallet(applyTransferLegBalance(siblingWallet, sibling))
                recycleBinDao.deleteTrashByOriginalId(sibling.id)
            }
        }
    }

    // Delete multiple transactions in a single atomic database transaction
    suspend fun deleteTransactions(transactions: List<FinancialTransaction>) = withContext(Dispatchers.IO) {
        if (transactions.isEmpty()) return@withContext
        db.withTransaction {
            for (transaction in transactions) {
                val originalJson = transactionAdapter.toJson(transaction)
                val recycleBinItem = RecycleBin(
                    transacaoOriginalId = transaction.id,
                    transacaoOriginalJson = originalJson,
                    dataExclusao = System.currentTimeMillis()
                )
                recycleBinDao.insertTrash(recycleBinItem)
                transactionDao.deleteTransactionById(transaction.id)

                if (!transaction.ajusteCaixa) {
                    val wallet = walletDao.getWalletById(transaction.carteiraOrigemId)
                    if (wallet != null) {
                        val novoSaldo = if (transaction.tipo == "Despesa") {
                            wallet.saldoAtual + transaction.valor
                        } else {
                            wallet.saldoAtual - transaction.valor
                        }
                        walletDao.updateWallet(wallet.copy(saldoAtual = novoSaldo))
                    }
                }
            }
        }
    }

    suspend fun undoDeleteTransaction(transaction: FinancialTransaction) = withContext(Dispatchers.IO) {
        db.withTransaction {
            transactionDao.insertTransaction(transaction)
            if (!transaction.ajusteCaixa) {
                val wallet = walletDao.getWalletById(transaction.carteiraOrigemId)
                if (wallet != null) {
                    val novoSaldo = if (transaction.tipo == "Despesa") {
                        wallet.saldoAtual - transaction.valor
                    } else {
                        wallet.saldoAtual + transaction.valor
                    }
                    walletDao.updateWallet(wallet.copy(saldoAtual = novoSaldo))
                }
            }
            recycleBinDao.deleteTrashByOriginalId(transaction.id)
        }
    }

    // Recycle Bin Operations
    suspend fun restoreTransaction(trash: RecycleBin) = withContext(Dispatchers.IO) {
        val original = transactionAdapter.fromJson(trash.transacaoOriginalJson)
        if (original != null) {
            // Restore transaction with a new ID (resetting ID to 0 to auto-generate a valid key)
            val restored = original.copy(id = 0)
            addTransaction(restored) // Adding it will automatically recalculate the wallet balance
        }
        recycleBinDao.deleteTrash(trash)
    }

    suspend fun deleteTrashPermanently(trash: RecycleBin) = withContext(Dispatchers.IO) {
        recycleBinDao.deleteTrash(trash)
    }

    // Helper for closure comparison string
    private fun buildComparisonText(lastClosure: DailyClosure?, totalExpected: Double, totalAnterior: Double, moeda: String = "MZN", idioma: String = "PT"): String {
        return if (lastClosure == null) {
            if (idioma == "PT") "Primeira Reconciliação" else "First Reconciliation"
        } else {
            val diffFromAnterior = totalExpected - totalAnterior
            if (diffFromAnterior > 0.005) {
                val formatted = String.format(java.util.Locale.US, "%.2f", diffFromAnterior)
                if (idioma == "PT") "Aumento de $formatted $moeda" else "Increase of $formatted $moeda"
            } else if (diffFromAnterior < -0.005) {
                val formatted = String.format(java.util.Locale.US, "%.2f", Math.abs(diffFromAnterior))
                if (idioma == "PT") "Falta/Diminuição de $formatted $moeda" else "Shortfall/Decrease of $formatted $moeda"
            } else {
                if (idioma == "PT") "Sem variação" else "No change"
            }
        }
    }

    private suspend fun createAdjustmentTransaction(
        diferenca: Double,
        walletId: Int,
        baseDescription: String,
        observacoes: String? = null
    ) {
        if (Math.abs(diferenca) <= 0.01) return
        val categoriesList = categoryDao.getAllCategoriesDirect()
        val tipoAjuste = if (diferenca > 0) "Injecao" else "Despesa"
        val ajusteCategory = categoriesList.find { (it.isSystemCategory || it.nome.lowercase() == "ajuste") && it.tipo == tipoAjuste }
            ?: run {
                val newCat = Category(nome = "Ajuste", icone = "tune", cor = "#607D8B", tipo = tipoAjuste, isSystemCategory = true)
                categoryDao.insertCategory(newCat)
                categoryDao.getAllCategoriesDirect().find { it.nome == "Ajuste" && it.tipo == tipoAjuste }
            }

        if (ajusteCategory == null) return

        val adjustmentTransaction = FinancialTransaction(
            data = System.currentTimeMillis(),
            categoriaId = ajusteCategory.id,
            descricao = baseDescription,
            valor = Math.abs(diferenca),
            tipo = tipoAjuste,
            carteiraOrigemId = walletId,
            ajusteCaixa = true,
            moedaOriginal = "MZN",
            valorOriginal = Math.abs(diferenca),
            taxaCambioUsada = 1.0,
            observacoes = observacoes ?: ""
        )
        transactionDao.insertTransaction(adjustmentTransaction)
    }

    // Unified Daily Closure / Reconciliation routine (Fase 2, Problema 2)
    suspend fun applyReconciliation(
        targetWalletId: Int? = null,
        actualBalances: Map<Int, Double> = emptyMap(),
        consolidatedSaldoReal: Double? = null
    ) = withContext(Dispatchers.IO) {
        db.withTransaction {
            // Fix explicit TimeZone for daily closure boundary calculation
            val todayStart = Calendar.getInstance(TimeZone.getDefault()).apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis

            val allWallets = walletDao.getAllWalletsDirect()
            if (allWallets.isEmpty()) return@withTransaction

            val totalExpected = allWallets.sumOf { it.saldoAtual }
            val calculatedActuals = mutableMapOf<Int, Double>()
            var totalActual: Double

            when {
                actualBalances.isNotEmpty() -> {
                    totalActual = 0.0
                    allWallets.forEach { w ->
                        val actual = actualBalances[w.id] ?: w.saldoAtual
                        calculatedActuals[w.id] = actual
                        totalActual += actual
                    }
                }
                targetWalletId != null && targetWalletId > 0 && consolidatedSaldoReal != null -> {
                    // Reconcile a single specific wallet with the given real balance; every
                    // other wallet is left untouched. Folded into the same consolidated path
                    // (instead of a separate branch) so it produces one carteiraId=0 closure
                    // record like every other reconciliation — the old separate branch stored
                    // carteiraId=wallet.id, which the Histórico/pending-badge UI never reads
                    // (both only ever look for carteiraId==0), so that record was invisible.
                    allWallets.forEach { w ->
                        calculatedActuals[w.id] = if (w.id == targetWalletId) consolidatedSaldoReal else w.saldoAtual
                    }
                    totalActual = calculatedActuals.values.sum()
                }
                consolidatedSaldoReal != null -> {
                    totalActual = consolidatedSaldoReal
                    val diffToDistribute = consolidatedSaldoReal - totalExpected
                    if (Math.abs(diffToDistribute) < 0.001) {
                        allWallets.forEach { w -> calculatedActuals[w.id] = w.saldoAtual }
                    } else {
                        // Distribute total difference proportionally across all wallets
                        var allocatedDiff = 0.0
                        allWallets.forEachIndexed { index, w ->
                            if (index == allWallets.size - 1) {
                                val walletDiff = diffToDistribute - allocatedDiff
                                calculatedActuals[w.id] = w.saldoAtual + walletDiff
                            } else {
                                val proportion = if (totalExpected > 0) (w.saldoAtual / totalExpected) else (1.0 / allWallets.size)
                                val walletDiff = Math.round(diffToDistribute * proportion * 100.0) / 100.0
                                allocatedDiff += walletDiff
                                calculatedActuals[w.id] = w.saldoAtual + walletDiff
                            }
                        }
                    }
                }
                else -> {
                    allWallets.forEach { w -> calculatedActuals[w.id] = w.saldoAtual }
                    totalActual = totalExpected
                }
            }

            val totalDiff = totalActual - totalExpected

            // Update each wallet's real balance individually (this alone keeps every
            // account's saldoAtual correct), but DO NOT log one "Ajuste" transaction per
            // wallet — that used to spam the Histórico with N per-account entries for a
            // single reconciliation. Instead we log ONE consolidated adjustment transaction
            // for the total difference, keeping the per-account breakdown only as an
            // internal note (observacoes) for later auditing if ever needed. This adjustment
            // transaction is flagged ajusteCaixa=true, which every income/expense sum in the
            // app must exclude — see the ajusteCaixa audit fixes across the UI layer.
            val perWalletBreakdown = mutableListOf<String>()
            allWallets.forEach { wallet ->
                val expected = wallet.saldoAtual
                val actual = calculatedActuals[wallet.id] ?: expected
                val diff = actual - expected

                if (Math.abs(diff) > 0.01) {
                    walletDao.updateWallet(wallet.copy(saldoAtual = actual))
                    val sign = if (diff > 0) "+" else ""
                    perWalletBreakdown.add("${wallet.nome}: $sign${String.format(java.util.Locale.US, "%.2f", diff)}")
                }
            }

            if (Math.abs(totalDiff) > 0.01) {
                // Anchor the single consolidated record to a real wallet (schema requires
                // carteiraOrigemId); this does not affect any wallet's balance math, it's
                // only where the audit-trail entry is filed from.
                val anchorWalletId = targetWalletId?.takeIf { id -> id > 0 && allWallets.any { it.id == id } }
                    ?: allWallets.minByOrNull { it.ordem }?.id ?: allWallets.first().id
                val reconciliationIdioma = currentIdioma()
                val baseDescription = if (reconciliationIdioma == "PT") {
                    "Ajuste por ${if (totalDiff > 0) "Injeção" else "Falta"} de Caixa (Reconciliação)"
                } else {
                    "Adjustment for Cash ${if (totalDiff > 0) "Injection" else "Shortfall"} (Reconciliation)"
                }
                val observacoesText = if (perWalletBreakdown.size > 1) {
                    (if (reconciliationIdioma == "PT") "Detalhe por conta: " else "Per-account detail: ") + perWalletBreakdown.joinToString("; ")
                } else null
                createAdjustmentTransaction(
                    diferenca = totalDiff,
                    walletId = anchorWalletId,
                    baseDescription = baseDescription,
                    observacoes = observacoesText
                )
            }

            val userMoeda = userSettingsDao.getUserSettingsDirect()?.moedaPadrao ?: "MZN"
            val lastClosure = dailyClosureDao.getLastClosureDirect()
            val totalAnterior = lastClosure?.saldoTotalEsperado ?: 0.0
            val comp = buildComparisonText(lastClosure, totalExpected, totalAnterior, userMoeda, currentIdioma())

            val closure = DailyClosure(
                data = todayStart,
                carteiraId = 0, // 0 signals consolidated — the only kind of closure ever produced now
                saldoEsperado = totalExpected,
                saldoReal = totalActual,
                diferenca = totalDiff,
                saldoTotalEsperado = totalExpected,
                comparacaoAnterior = comp
            )
            dailyClosureDao.insertClosure(closure)

            // Update user settings to record the last closure timestamp
            val settings = userSettingsDao.getUserSettingsDirect() ?: UserSettings()
            userSettingsDao.insertOrUpdate(settings.copy(ultimoFechamento = todayStart))
        }
    }

    // Atomic wallet-to-wallet transfer. Reads wallet balances fresh from the DB (not from a
    // possibly-stale in-memory/StateFlow snapshot) and wraps both balance updates plus both
    // transaction inserts in a single db.withTransaction, so a crash or process death mid-way
    // can never leave money debited from one wallet without being credited to the other.
    suspend fun transferBetweenWallets(
        fromWalletId: Int,
        toWalletId: Int,
        amount: Double,
        description: String
    ) = withContext(Dispatchers.IO) {
        if (fromWalletId == toWalletId || amount <= 0.0) return@withContext
        db.withTransaction {
            val fromWallet = walletDao.getWalletById(fromWalletId) ?: return@withTransaction
            val toWallet = walletDao.getWalletById(toWalletId) ?: return@withTransaction

            walletDao.updateWallet(fromWallet.copy(saldoAtual = fromWallet.saldoAtual - amount))
            walletDao.updateWallet(toWallet.copy(saldoAtual = toWallet.saldoAtual + amount))

            val cats = categoryDao.getAllCategoriesDirect()
            val catExpense = cats.find { it.tipo == "Despesa" } ?: cats.firstOrNull()
            val catIncome = cats.find { it.tipo == "Injecao" } ?: cats.firstOrNull()
            val idioma = currentIdioma()
            val outSuffix = if (idioma == "PT") " (Saída)" else " (Out)"
            val inSuffix = if (idioma == "PT") " (Entrada)" else " (In)"

            // ajusteCaixa = true on both legs: a transfer between the user's own wallets is
            // not income or an expense, so it must not enter any despesa/receita total — it
            // should only ever show up as a Histórico entry.
            transactionDao.insertTransaction(
                FinancialTransaction(
                    data = System.currentTimeMillis(),
                    categoriaId = catExpense?.id ?: 0,
                    descricao = "$description$outSuffix",
                    valor = amount,
                    tipo = "Transferencia",
                    carteiraOrigemId = fromWalletId,
                    ajusteCaixa = true
                )
            )
            transactionDao.insertTransaction(
                FinancialTransaction(
                    data = System.currentTimeMillis(),
                    categoriaId = catIncome?.id ?: 0,
                    descricao = "$description$inSuffix",
                    valor = amount,
                    tipo = "Transferencia",
                    carteiraOrigemId = toWalletId,
                    ajusteCaixa = true
                )
            )
        }
    }

    suspend fun applyConsolidatedReconciliation(actualBalances: Map<Int, Double>) {
        applyReconciliation(targetWalletId = null, actualBalances = actualBalances)
    }

    suspend fun applyDailyClosure(walletId: Int, saldoReal: Double) {
        if (walletId <= 0) {
            applyReconciliation(targetWalletId = null, consolidatedSaldoReal = saldoReal)
        } else {
            applyReconciliation(targetWalletId = walletId, consolidatedSaldoReal = saldoReal)
        }
    }

    // Financial Goal Operations
    suspend fun addGoal(goal: FinancialGoal): Long = withContext(Dispatchers.IO) {
        financialGoalDao.insertGoal(goal)
    }

    suspend fun updateGoal(goal: FinancialGoal) = withContext(Dispatchers.IO) {
        financialGoalDao.insertGoal(goal)
    }

    suspend fun deleteGoal(goal: FinancialGoal) = withContext(Dispatchers.IO) {
        financialGoalDao.deleteGoal(goal)
    }

    // Elimina a meta e, se tinha progresso, devolve o valor à carteira numa única transação
    // de BD — devolve o id da transação de estorno (ou null se não houve estorno) para que
    // undoGoalDeletion consiga reverter exatamente este efeito, em vez de só restaurar a meta
    // e deixar o estorno "à solta" a duplicar o dinheiro (ver undoGoalDeletion).
    suspend fun deleteGoalWithRefund(goal: FinancialGoal, walletId: Int): Int? = withContext(Dispatchers.IO) {
        db.withTransaction {
            financialGoalDao.deleteGoal(goal)
            if (goal.valorAtual > 0) {
                val wallet = walletDao.getWalletById(walletId)
                if (wallet != null) {
                    walletDao.updateWallet(wallet.copy(saldoAtual = wallet.saldoAtual + goal.valorAtual))
                }
                val estornoTx = FinancialTransaction(
                    data = System.currentTimeMillis(),
                    categoriaId = goal.categoriaId,
                    descricao = "Estorno Meta Eliminada: ${goal.nome}",
                    valor = goal.valorAtual,
                    tipo = "Injecao",
                    carteiraOrigemId = walletId,
                    metaId = goal.id,
                    ajusteCaixa = false
                )
                transactionDao.insertTransaction(estornoTx).toInt()
            } else {
                null
            }
        }
    }

    // Reverte exatamente o que deleteGoalWithRefund fez: restaura a meta E desfaz o estorno
    // (retira o valor devolvido da carteira e apaga a transação de estorno), para que o botão
    // "Desfazer" nunca deixe o mesmo valor contado tanto na meta restaurada como na carteira.
    suspend fun undoGoalDeletion(goal: FinancialGoal, estornoTransactionId: Int?, walletId: Int) = withContext(Dispatchers.IO) {
        db.withTransaction {
            financialGoalDao.insertGoal(goal)
            if (estornoTransactionId != null) {
                val wallet = walletDao.getWalletById(walletId)
                if (wallet != null) {
                    walletDao.updateWallet(wallet.copy(saldoAtual = wallet.saldoAtual - goal.valorAtual))
                }
                transactionDao.deleteTransactionById(estornoTransactionId)
            }
        }
    }

    suspend fun withdrawFromGoal(goalId: Int, walletId: Int, amount: Double) = withContext(Dispatchers.IO) {
        if (amount <= 0.0) return@withContext
        db.withTransaction {
            val goal = financialGoalDao.getGoalById(goalId) ?: return@withTransaction
            val newGoalAmount = (goal.valorAtual - amount).coerceAtLeast(0.0)
            financialGoalDao.insertGoal(goal.copy(valorAtual = newGoalAmount))

            val wallet = walletDao.getWalletById(walletId) ?: return@withTransaction
            walletDao.updateWallet(wallet.copy(saldoAtual = wallet.saldoAtual + amount))

            val tx = FinancialTransaction(
                data = System.currentTimeMillis(),
                categoriaId = goal.categoriaId,
                descricao = if (currentIdioma() == "PT") "Retirada de Meta: ${goal.nome}" else "Goal Withdrawal: ${goal.nome}",
                valor = amount,
                tipo = "Injecao",
                carteiraOrigemId = walletId,
                metaId = goalId,
                // A contribuição original para a meta é gravada como Despesa real
                // (ajusteCaixa = false, ver contributeToGoal). Para que o levantamento
                // reverta corretamente essa despesa nos totais do período — tal como já
                // acontece em deleteGoalWithRefund — este estorno também tem de ser uma
                // Receita real. O saldo da carteira é ajustado diretamente acima; este
                // insert usa o DAO diretamente (não addTransaction) para não o duplicar.
                ajusteCaixa = false
            )
            transactionDao.insertTransaction(tx)
        }
    }

    // Spending Limit Operations
    suspend fun addSpendingLimit(limit: SpendingLimit) = withContext(Dispatchers.IO) {
        spendingLimitDao.insertOrUpdateLimit(limit)
    }

    suspend fun deleteSpendingLimit(limit: SpendingLimit) = withContext(Dispatchers.IO) {
        spendingLimitDao.deleteLimit(limit)
    }

    suspend fun getLimitByCategoryAndMonth(categoryId: Int, month: String): SpendingLimit? = withContext(Dispatchers.IO) {
        spendingLimitDao.getLimitByCategoryAndMonth(categoryId, month)
    }

    // Loan & Installment Operations
    suspend fun addLoan(loan: Loan, installmentsList: List<Installment>, walletId: Int? = null) = withContext(Dispatchers.IO) {
        val loanId = loanDao.insertLoan(loan).toInt()
        val updatedInstallments = installmentsList.map { it.copy(parentId = loanId) }
        installmentDao.insertInstallments(updatedInstallments)

        if (walletId != null) {
            val wallet = walletDao.getWalletById(walletId)
            if (wallet != null) {
                // Adjust wallet balance
                val novoSaldo = if (loan.isCredit) wallet.saldoAtual - loan.principalAmount else wallet.saldoAtual + loan.principalAmount
                walletDao.updateWallet(wallet.copy(saldoAtual = novoSaldo))

                // Insert movement transaction with ajusteCaixa = true so it is excluded from living expenses total
                val categoriesList = categoryDao.getAllCategoriesDirect()
                val tipoTransacao = if (loan.isCredit) "Despesa" else "Injecao"
                val cat = categoriesList.find { it.tipo == tipoTransacao } ?: categoriesList.firstOrNull()
                if (cat != null) {
                    val tx = FinancialTransaction(
                        data = System.currentTimeMillis(),
                        categoriaId = cat.id,
                        descricao = if (loan.isCredit) "Empréstimo Concedido (${loan.counterparty})" else "Empréstimo Tomado (${loan.counterparty})",
                        valor = loan.principalAmount,
                        tipo = tipoTransacao,
                        carteiraOrigemId = walletId,
                        ajusteCaixa = true // Excluded from living expenses sum (!it.ajusteCaixa)
                    )
                    transactionDao.insertTransaction(tx)
                }
            }
        }
    }

    suspend fun updateLoan(loan: Loan) = withContext(Dispatchers.IO) {
        loanDao.updateLoan(loan)
    }

    suspend fun deleteLoan(loan: Loan) = withContext(Dispatchers.IO) {
        loanDao.deleteLoan(loan)
    }

    suspend fun getInstallmentsForLoanDirect(loanId: Int): List<Installment> = withContext(Dispatchers.IO) {
        installmentDao.getInstallmentsByParentIdDirect(loanId)
    }

    suspend fun updateInstallment(installment: Installment) = withContext(Dispatchers.IO) {
        installmentDao.updateInstallment(installment)
    }

    suspend fun payInstallment(installment: Installment, amount: Double, walletId: Int, isCredit: Boolean) = withContext(Dispatchers.IO) {
        db.withTransaction {
            if (installment.status == "PAID" || installment.remainingBalance <= 0.0) {
                return@withTransaction
            }
            // 1. Update installment balance
            val novoPaid = installment.totalPaid + amount
            val novoRem = Math.max(0.0, installment.remainingBalance - amount)
            val novoStatus = if (novoRem <= 0.0) "PAID" else "PENDING"
            val updatedInst = installment.copy(totalPaid = novoPaid, remainingBalance = novoRem, status = novoStatus)
            installmentDao.updateInstallment(updatedInst)

            // 2. Adjust wallet balance
            val wallet = walletDao.getWalletById(walletId)
            if (wallet != null) {
                val isDebit = !isCredit
                val novoSaldo = if (isDebit) wallet.saldoAtual - amount else wallet.saldoAtual + amount
                walletDao.updateWallet(wallet.copy(saldoAtual = novoSaldo))
            }

            // 3. Create a financial transaction representing this payment
            val categoriesList = categoryDao.getAllCategoriesDirect()
            val cat = categoriesList.find { !it.isSystemCategory && it.nome.lowercase() != "ajuste" } ?: categoriesList.firstOrNull()
            val idioma = currentIdioma()
            val tx = FinancialTransaction(
                data = System.currentTimeMillis(),
                categoriaId = cat?.id ?: 0,
                descricao = if (idioma == "PT") "Pagamento de Empréstimo (${if (isCredit) "Recebido" else "Pago"})" else "Loan Payment (${if (isCredit) "Received" else "Paid"})",
                valor = amount,
                tipo = "PagamentoEmprestimo",
                carteiraOrigemId = walletId,
                ajusteCaixa = true
            )
            transactionDao.insertTransaction(tx)

            // 4. Check if all installments are paid, update Loan status
            val parentInstallments = installmentDao.getInstallmentsByParentIdDirect(installment.parentId)
            val allPaid = parentInstallments.all { 
                (it.id == installment.id && novoRem <= 0.0) || (it.id != installment.id && it.remainingBalance <= 0.0)
            }
            if (allPaid) {
                val loan = loanDao.getLoanById(installment.parentId)
                if (loan != null) {
                    loanDao.updateLoan(loan.copy(status = "PAID", paidOffDate = System.currentTimeMillis()))
                }
            }
        }
    }

    suspend fun deleteDailyClosure(closure: DailyClosure) = withContext(Dispatchers.IO) {
        dailyClosureDao.deleteClosure(closure)
    }

    // Shopping List Operations
    fun getShoppingItemsForList(listaId: Int): Flow<List<ShoppingItem>> {
        return shoppingItemDao.getShoppingItemsForList(listaId)
    }

    suspend fun addShoppingItem(item: ShoppingItem): Long = withContext(Dispatchers.IO) {
        shoppingItemDao.insertShoppingItem(item)
    }

    suspend fun updateShoppingItem(item: ShoppingItem) = withContext(Dispatchers.IO) {
        shoppingItemDao.updateShoppingItem(item)
    }

    suspend fun deleteShoppingItem(item: ShoppingItem) = withContext(Dispatchers.IO) {
        shoppingItemDao.deleteShoppingItem(item)
    }

    suspend fun clearPaidShoppingItems() = withContext(Dispatchers.IO) {
        shoppingItemDao.clearPaidItems()
    }

    suspend fun clearPaidShoppingItemsForList(listaId: Int) = withContext(Dispatchers.IO) {
        shoppingItemDao.clearPaidItemsForList(listaId)
    }

    // List Operations
    suspend fun addShoppingList(list: ShoppingList): Long = withContext(Dispatchers.IO) {
        shoppingListDao.insertList(list)
    }

    suspend fun updateShoppingList(list: ShoppingList) = withContext(Dispatchers.IO) {
        shoppingListDao.updateList(list)
    }

    suspend fun deleteShoppingList(list: ShoppingList) = withContext(Dispatchers.IO) {
        shoppingListDao.deleteItemsByListId(list.id)
        shoppingListDao.deleteList(list)
    }

    // Category Operations
    suspend fun addShoppingCategory(category: ShoppingCategory): Long = withContext(Dispatchers.IO) {
        shoppingCategoryDao.insertCategory(category)
    }

    suspend fun updateShoppingCategory(category: ShoppingCategory) = withContext(Dispatchers.IO) {
        shoppingCategoryDao.updateCategory(category)
    }

    suspend fun deleteShoppingCategory(category: ShoppingCategory) = withContext(Dispatchers.IO) {
        shoppingCategoryDao.deleteCategory(category)
    }

    suspend fun updateShoppingCategoryOrder(id: Int, ordem: Int) = withContext(Dispatchers.IO) {
        shoppingCategoryDao.updateCategoryOrder(id, ordem)
    }

    // Price History Operations
    suspend fun addPriceHistory(history: ShoppingPriceHistory) = withContext(Dispatchers.IO) {
        shoppingPriceHistoryDao.insertPriceHistory(history)
    }

    suspend fun getAveragePriceForProduct(nomeProduto: String): Double? = withContext(Dispatchers.IO) {
        shoppingPriceHistoryDao.getAveragePriceForProduct(nomeProduto)
    }

    fun getPriceHistoryForProduct(nomeProduto: String): Flow<List<ShoppingPriceHistory>> {
        return shoppingPriceHistoryDao.getPriceHistoryForProduct(nomeProduto)
    }

    // Loan Receipts Operations
    fun getLoanReceipts(loanId: Int): Flow<List<LoanReceipt>> {
        return loanReceiptDao.getReceiptsForLoan(loanId)
    }

    suspend fun addLoanReceipt(loanId: Int, imageUri: String) = withContext(Dispatchers.IO) {
        loanReceiptDao.insertReceipt(LoanReceipt(loanId = loanId, imageUri = imageUri))
    }

    suspend fun deleteLoanReceipt(receipt: LoanReceipt) = withContext(Dispatchers.IO) {
        loanReceiptDao.deleteReceipt(receipt)
    }

    // Exported Reports Operations
    fun getExportedReports(): Flow<List<ExportedReport>> {
        return exportedReportDao.getAllExportedReports()
    }

    suspend fun addExportedReport(fileName: String, format: String, filePath: String = "") = withContext(Dispatchers.IO) {
        exportedReportDao.insertExportedReport(
            ExportedReport(
                fileName = fileName,
                format = format,
                timestamp = System.currentTimeMillis(),
                filePath = filePath
            )
        )
    }

    suspend fun deleteExportedReport(report: ExportedReport) = withContext(Dispatchers.IO) {
        exportedReportDao.deleteExportedReport(report)
    }

    // Scheduled Transfers Operations
    suspend fun addScheduledTransfer(transfer: ScheduledTransfer) = withContext(Dispatchers.IO) {
        db.withTransaction {
            scheduledTransferDao.insert(transfer)
        }
    }

    suspend fun deleteScheduledTransfer(id: Int) = withContext(Dispatchers.IO) {
        db.withTransaction {
            scheduledTransferDao.deleteById(id)
        }
    }

    // Logs the two linked "Saída"/"Entrada" transaction records for a wallet transfer, matching
    // transferBetweenWallets exactly. Both legs are ajusteCaixa=true (not income/expense — only
    // Histórico), and each is tied to its own wallet so both wallets' filtered history shows it.
    private suspend fun logScheduledTransferTransactions(
        srcId: Int,
        srcNome: String,
        destId: Int,
        destNome: String,
        amount: Double,
        `when`: Long
    ) {
        val categoriesList = categoryDao.getAllCategoriesDirect()
        val catExpense = categoriesList.find { it.tipo == "Despesa" } ?: categoriesList.firstOrNull()
        val catIncome = categoriesList.find { it.tipo == "Injecao" } ?: categoriesList.firstOrNull()
        val idioma = currentIdioma()
        val description = if (idioma == "PT") "Transferência Agendada: $srcNome -> $destNome" else "Scheduled Transfer: $srcNome -> $destNome"
        val outSuffix = if (idioma == "PT") " (Saída)" else " (Out)"
        val inSuffix = if (idioma == "PT") " (Entrada)" else " (In)"

        transactionDao.insertTransaction(
            FinancialTransaction(
                data = `when`,
                categoriaId = catExpense?.id ?: 0,
                descricao = "$description$outSuffix",
                valor = amount,
                tipo = "Transferencia",
                carteiraOrigemId = srcId,
                ajusteCaixa = true
            )
        )
        transactionDao.insertTransaction(
            FinancialTransaction(
                data = `when`,
                categoriaId = catIncome?.id ?: 0,
                descricao = "$description$inSuffix",
                valor = amount,
                tipo = "Transferencia",
                carteiraOrigemId = destId,
                ajusteCaixa = true
            )
        )
    }

    suspend fun executeScheduledTransferNow(transfer: ScheduledTransfer) = withContext(Dispatchers.IO) {
        db.withTransaction {
            val src = walletDao.getWalletById(transfer.carteiraOrigemId)
            val dest = walletDao.getWalletById(transfer.carteiraDestinoId)
            if (src != null && dest != null) {
                walletDao.updateWallet(src.copy(saldoAtual = src.saldoAtual - transfer.valor))
                walletDao.updateWallet(dest.copy(saldoAtual = dest.saldoAtual + transfer.valor))

                logScheduledTransferTransactions(
                    src.id, src.nome, dest.id, dest.nome, transfer.valor, System.currentTimeMillis()
                )
                scheduledTransferDao.update(transfer.copy(executada = true))
            }
        }
    }

    suspend fun processPendingScheduledTransfers() = withContext(Dispatchers.IO) {
        db.withTransaction {
            val now = System.currentTimeMillis()
            val pending = scheduledTransferDao.getPendingTransfersDue(now)
            for (transfer in pending) {
                val src = walletDao.getWalletById(transfer.carteiraOrigemId)
                val dest = walletDao.getWalletById(transfer.carteiraDestinoId)
                if (src != null && dest != null) {
                    walletDao.updateWallet(src.copy(saldoAtual = src.saldoAtual - transfer.valor))
                    walletDao.updateWallet(dest.copy(saldoAtual = dest.saldoAtual + transfer.valor))

                    logScheduledTransferTransactions(
                        src.id, src.nome, dest.id, dest.nome, transfer.valor, transfer.dataHora
                    )
                    scheduledTransferDao.update(transfer.copy(executada = true))
                }
            }
        }
    }
}
