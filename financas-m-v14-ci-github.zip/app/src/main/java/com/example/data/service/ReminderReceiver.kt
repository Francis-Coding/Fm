package com.example.data.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.database.AppDatabase
import com.example.data.model.UserSettings
import com.example.data.model.isDespesa
import com.example.data.model.isReceita
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "com.example.ACTION_TRIGGER_REMINDER") {
            
            // Re-schedule the alarm for the next day
            rescheduleAlarm(context)

            val pendingResult = goAsync()

            // Trigger notification checks in a background coroutine
            val db = AppDatabase.getDatabase(context)
            val notificationService = NotificationService(context)

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    // Process any due scheduled transfers and subscriptions automatically
                    val repo = com.example.data.repository.FinancialRepository(context)
                    repo.processPendingScheduledTransfers()
                    repo.processPendingSubscriptionBills()

                    // 1. Check if notifications are enabled in settings
                    val settings = db.userSettingsDao().getUserSettings().firstOrNull() ?: UserSettings()
                    if (!settings.notificacoesAtivas) return@launch

                    // 1b. Sincroniza a Central de Notificações in-app (badge do sino + ecrã de
                    // notificações) com as mesmas condições usadas abaixo para as notificações
                    // push do sistema.
                    repo.syncNotifications(settings.idioma)

                    // 2. Check pending loans for notifications using unified CheckPendingLoansUseCase
                    val loans = db.loanDao().getAllLoans().firstOrNull() ?: emptyList()
                    val dueSoon = com.example.domain.usecases.CheckPendingLoansUseCase().getPendingLoansDueSoon(loans)
                    for ((loan, daysLeft) in dueSoon) {
                        notificationService.notifyLoanDueDate(loan.counterparty, loan.principalAmount, daysLeft)
                    }

                    // 3. Check Credit Cards due soon
                    val creditCards = db.creditCardDao().getAllCreditCardsDirect()
                    val cal = Calendar.getInstance()
                    val currentDayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
                    for (card in creditCards) {
                        if (!card.ativa) continue
                        val invoiceAmount = card.limiteTotal - card.limiteDisponivel
                        if (invoiceAmount <= 0) continue
                        val diffDays = card.diaVencimento - currentDayOfMonth
                        if (diffDays in 0..3) {
                            notificationService.notifyCreditCardDueDate(card.nome, invoiceAmount, diffDays)
                        }
                    }

                    // 4. Check active subscriptions due soon
                    val subscriptions = db.subscriptionDao().getAllSubscriptionsDirect()
                    for (sub in subscriptions) {
                        if (!sub.ativa) continue
                        val diffDays = sub.diaCobranca - currentDayOfMonth
                        if (diffDays in 0..3) {
                            notificationService.notifySubscriptionDueDate(sub.nome, sub.valor, diffDays)
                        }
                    }

                    // 5. Check Category Budget thresholds
                    val categories = db.categoryDao().getAllCategoriesDirect()
                    val monthStart = cal.apply {
                        set(Calendar.DAY_OF_MONTH, 1)
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    val currentMonthExpenses = db.transactionDao().getTransactionsSinceDirect(monthStart)
                        .filter { it.isDespesa() }
                    for (cat in categories) {
                        if (cat.limiteMensal > 0) {
                            val spent = currentMonthExpenses.filter { it.categoriaId == cat.id }.sumOf { it.valor }
                            val percent = ((spent / cat.limiteMensal) * 100).toInt()
                            if (percent >= 80) {
                                notificationService.notifyBudgetThreshold(cat.nome, percent)
                            }
                        }
                    }

                    // 6. Check forgotten shopping list items
                    val activeLists = db.shoppingListDao().getAllLists().firstOrNull() ?: emptyList()
                    for (list in activeLists) {
                        val items = db.shoppingItemDao().getShoppingItemsForList(list.id).firstOrNull() ?: emptyList()
                        val unpaid = items.filter { !it.pago }
                        if (unpaid.size >= 3) {
                            notificationService.notifyForgottenShoppingItems(list.nome, unpaid.size)
                        }
                    }

                    // 7. Check if Weekly Summary is enabled and it is Sunday
                    val prefs = context.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
                    val weeklyEnabled = prefs.getBoolean("weekly_summary_enabled", true)
                    val isSunday = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
                    if (weeklyEnabled && isSunday) {
                        val sevenDaysAgo = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000L)
                        val recentTransactions = db.transactionDao().getTransactionsSinceDirect(sevenDaysAgo)

                        val incomeTotal = recentTransactions.filter { it.isReceita() }.sumOf { it.valor }
                        val expenseTotal = recentTransactions.filter { it.isDespesa() }.sumOf { it.valor }
                        
                        notificationService.notifyWeeklySummary(expenseTotal, incomeTotal)
                    }
                } catch (e: Exception) {
                    Log.e("ReminderReceiver", "Error in async broadcast execution", e)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }

    private fun rescheduleAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = "com.example.ACTION_TRIGGER_REMINDER"
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val prefs = context.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        val timeStr = prefs.getString("reminder_time", "09:00") ?: "09:00"
        val parts = timeStr.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 9
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            // If scheduled time today has already passed, schedule for tomorrow
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
        } catch (e: Exception) {
            Log.e("ReminderReceiver", "Failed to reschedule alarm", e)
        }
    }
}
