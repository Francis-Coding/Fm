package com.example.data.service

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import androidx.room.withTransaction
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.security.MessageDigest
import java.security.SecureRandom

class BackupService(private val context: Context) {

    companion object {
        const val CURRENT_BACKUP_SCHEMA_VERSION = 2
    }

    private val db = AppDatabase.getDatabase(context)
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    // Combined data wrapper for the entire DB
    data class BackupPayload(
        val schemaVersion: Int = CURRENT_BACKUP_SCHEMA_VERSION,
        val settings: List<UserSettings> = emptyList(),
        val wallets: List<Wallet> = emptyList(),
        val categories: List<Category> = emptyList(),
        val transactions: List<FinancialTransaction> = emptyList(),
        val closures: List<DailyClosure> = emptyList(),
        val goals: List<FinancialGoal> = emptyList(),
        val spendingLimits: List<SpendingLimit> = emptyList(),
        val loans: List<Loan> = emptyList(),
        val installments: List<Installment> = emptyList(),
        val shoppingItems: List<ShoppingItem> = emptyList(),
        val shoppingLists: List<ShoppingList> = emptyList(),
        val shoppingCategories: List<ShoppingCategory> = emptyList(),
        val shoppingPriceHistories: List<ShoppingPriceHistory> = emptyList(),
        val loanReceipts: List<LoanReceipt> = emptyList(),
        val recycleBin: List<RecycleBin> = emptyList(),
        val subscriptions: List<Subscription> = emptyList(),
        val creditCards: List<CreditCard> = emptyList(),
        val scheduledTransfers: List<ScheduledTransfer> = emptyList(),
        val exportedReports: List<ExportedReport> = emptyList()
    )

    private val payloadAdapter = moshi.adapter(BackupPayload::class.java)

    // Export entire database as a compressed (and optionally encrypted) GZIP JSON file and share
    suspend fun createCompressedBackup(pin: String? = null) = withContext(Dispatchers.IO) {
        try {
            // Read current database state
            val settings = db.userSettingsDao().getUserSettingsDirect()?.let { listOf(it) } ?: emptyList()
            val wallets = db.walletDao().getAllWallets().firstOrNull() ?: emptyList()
            val categories = db.categoryDao().getAllCategories().firstOrNull() ?: emptyList()
            val transactions = db.transactionDao().getAllTransactionsFlow().firstOrNull() ?: emptyList()
            val closures = db.dailyClosureDao().getAllClosures().firstOrNull() ?: emptyList()
            val goals = db.financialGoalDao().getAllGoals().firstOrNull() ?: emptyList()
            val spendingLimits = db.spendingLimitDao().getAllSpendingLimits().firstOrNull() ?: emptyList()
            val loans = db.loanDao().getAllLoans().firstOrNull() ?: emptyList()
            val installments = db.installmentDao().getAllInstallments().firstOrNull() ?: emptyList()
            val shoppingItems = db.shoppingItemDao().getAllShoppingItems().firstOrNull() ?: emptyList()
            val shoppingLists = db.shoppingListDao().getAllLists().firstOrNull() ?: emptyList()
            val shoppingCategories = db.shoppingCategoryDao().getAllCategories().firstOrNull() ?: emptyList()
            val shoppingPriceHistories = db.shoppingPriceHistoryDao().getAllPriceHistory().firstOrNull() ?: emptyList()
            val loanReceipts = db.loanReceiptDao().getAllReceiptsDirect()
            val recycleBin = db.recycleBinDao().getAllTrashDirect()
            val subscriptions = db.subscriptionDao().getAllSubscriptionsDirect()
            val creditCards = db.creditCardDao().getAllCreditCardsDirect()
            val scheduledTransfers = db.scheduledTransferDao().getAllScheduledTransfersDirect()
            val exportedReports = db.exportedReportDao().getAllExportedReportsDirect()

            val payload = BackupPayload(
                schemaVersion = CURRENT_BACKUP_SCHEMA_VERSION,
                settings = settings,
                wallets = wallets,
                categories = categories,
                transactions = transactions,
                closures = closures,
                goals = goals,
                spendingLimits = spendingLimits,
                loans = loans,
                installments = installments,
                shoppingItems = shoppingItems,
                shoppingLists = shoppingLists,
                shoppingCategories = shoppingCategories,
                shoppingPriceHistories = shoppingPriceHistories,
                loanReceipts = loanReceipts,
                recycleBin = recycleBin,
                subscriptions = subscriptions,
                creditCards = creditCards,
                scheduledTransfers = scheduledTransfers,
                exportedReports = exportedReports
            )

            // Serialize to JSON string
            val jsonString = payloadAdapter.toJson(payload)

            // Compress to GZIP
            val outputStream = ByteArrayOutputStream()
            GZIPOutputStream(outputStream).use { gzip ->
                gzip.write(jsonString.toByteArray(Charsets.UTF_8))
            }
            var resultBytes = outputStream.toByteArray()

            // Optional encryption with AES-256
            if (!pin.isNullOrEmpty()) {
                resultBytes = encryptBytes(resultBytes, pin)
            }

            // Write to temporary cache file
            val cacheDir = context.cacheDir
            val suffix = if (!pin.isNullOrEmpty()) ".enc" else ".gz"
            val backupFile = File(cacheDir, "FinancasMT_Backup_${System.currentTimeMillis()}.json$suffix")
            FileOutputStream(backupFile).use { fos ->
                fos.write(resultBytes)
            }

            // Share file with the system
            shareBackupFile(backupFile, pin != null)
        } catch (e: Exception) {
            Log.e("BackupService", "Failed to create backup", e)
        }
    }

    private fun shareBackupFile(file: File, isEncrypted: Boolean) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = if (isEncrypted) "application/octet-stream" else "application/gzip"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Finanças MT - Cópia de Segurança")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chooser = Intent.createChooser(intent, "Guardar Backup (Google Drive, WhatsApp...)").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    // Decompress, parse, and restore/overwrite database contents from a selected backup URI
    suspend fun restoreFromBackupUri(uri: Uri, pin: String? = null): Boolean = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val inputStream = contentResolver.openInputStream(uri) ?: return@withContext false

            val rawBytesOutputStream = ByteArrayOutputStream()
            inputStream.use { input ->
                val buffer = ByteArray(1024)
                var len: Int
                while (input.read(buffer).also { len = it } > 0) {
                    rawBytesOutputStream.write(buffer, 0, len)
                }
            }
            var finalBytes = rawBytesOutputStream.toByteArray()

            // Optional decryption
            if (!pin.isNullOrEmpty()) {
                finalBytes = decryptBytes(finalBytes, pin)
            }

            // Decompress GZIP
            val byteBufferStream = ByteArrayOutputStream()
            val gzipInputStream = GZIPInputStream(finalBytes.inputStream())
            gzipInputStream.use { gzip ->
                val buffer = ByteArray(1024)
                var len: Int
                while (gzip.read(buffer).also { len = it } > 0) {
                    byteBufferStream.write(buffer, 0, len)
                }
            }

            val jsonString = String(byteBufferStream.toByteArray(), Charsets.UTF_8)
            val payload = payloadAdapter.fromJson(jsonString) ?: return@withContext false

            // Clear existing database tables and write new payload inside a single transaction for atomicity and data safety
            db.withTransaction {
                db.clearAllTables()

                // 1. User settings
                payload.settings.firstOrNull()?.let {
                    db.userSettingsDao().insertOrUpdate(it)
                }
                // 2. Wallets
                for (w in payload.wallets) {
                    val normalized = w.copy(icone = com.example.util.AppIcons.normalizeIconKey(w.icone))
                    db.walletDao().insertWallet(normalized)
                }
                // 3. Categories
                for (c in payload.categories) {
                    val normalized = c.copy(icone = com.example.util.AppIcons.normalizeIconKey(c.icone))
                    db.categoryDao().insertCategory(normalized)
                }
                // 4. Transactions
                for (t in payload.transactions) {
                    db.transactionDao().insertTransaction(t)
                }
                // 5. Daily closures
                for (fc in payload.closures) {
                    db.dailyClosureDao().insertClosure(fc)
                }
                // 6. Financial goals
                for (g in payload.goals) {
                    db.financialGoalDao().insertGoal(g)
                }
                // 7. Spending limits
                for (sl in payload.spendingLimits) {
                    db.spendingLimitDao().insertOrUpdateLimit(sl)
                }
                // 8. Loans & Installments
                for (l in payload.loans) {
                    db.loanDao().insertLoan(l)
                }
                for (inst in payload.installments) {
                    db.installmentDao().insertInstallment(inst)
                }
                // 9. Shopping List Tables
                for (sl in payload.shoppingLists) {
                    db.shoppingListDao().insertList(sl)
                }
                for (sc in payload.shoppingCategories) {
                    db.shoppingCategoryDao().insertCategory(sc)
                }
                for (si in payload.shoppingItems) {
                    db.shoppingItemDao().insertShoppingItem(si)
                }
                for (sph in payload.shoppingPriceHistories) {
                    db.shoppingPriceHistoryDao().insertPriceHistory(sph)
                }
                // 10. Loan Receipts & Recycle Bin & Subscriptions & Credit Cards
                for (lr in payload.loanReceipts) {
                    db.loanReceiptDao().insertReceipt(lr)
                }
                for (rb in payload.recycleBin) {
                    db.recycleBinDao().insertTrash(rb)
                }
                for (sub in payload.subscriptions) {
                    db.subscriptionDao().insert(sub)
                }
                for (cc in payload.creditCards) {
                    db.creditCardDao().insertCreditCard(cc)
                }
                for (st in payload.scheduledTransfers) {
                    db.scheduledTransferDao().insert(st)
                }
                for (er in payload.exportedReports) {
                    db.exportedReportDao().insertExportedReport(er)
                }

                // Post-restore sync: Backfill subscriptions for recurring transactions
                val allTx = db.transactionDao().getAllTransactionsDirect()
                val recurringTx = allTx.filter { it.recorrente }
                val currentSubs = db.subscriptionDao().getAllSubscriptionsDirect().toMutableList()

                for (tx in recurringTx) {
                    val alreadyLinked = currentSubs.find { it.sourceTransactionId == tx.id }
                    if (alreadyLinked == null) {
                        // Casar apenas por nome+valor é ambíguo (ex.: duas subscrições
                        // "Netflix" em moedas/planos diferentes, ou nomes coincidentes de
                        // utilizadores distintos). Exigir também a mesma carteira e — quando a
                        // transação tem categoria definida — a mesma categoria, reduz falsos
                        // positivos na reconciliação pós-restauro.
                        val unlinkedMatch = currentSubs.find { 
                            it.sourceTransactionId == null && 
                            it.nome.equals(tx.descricao, ignoreCase = true) && 
                            Math.abs(it.valor - tx.valor) < 0.01 &&
                            it.carteiraId == tx.carteiraOrigemId &&
                            (tx.categoriaId == null || it.categoriaId == tx.categoriaId)
                        }
                        if (unlinkedMatch != null) {
                            val updated = unlinkedMatch.copy(sourceTransactionId = tx.id)
                            db.subscriptionDao().update(updated)
                            currentSubs.remove(unlinkedMatch)
                            currentSubs.add(updated)
                        } else {
                            val ciclo = when (tx.recurrenceFrequency?.lowercase()) {
                                "semanal" -> "SEMANAL"
                                "anual" -> "ANUAL"
                                else -> "MENSAL"
                            }
                            val targetDate = tx.nextOccurrenceDate ?: tx.data
                            val cal = java.util.Calendar.getInstance().apply { timeInMillis = targetDate }
                            val dia = cal.get(java.util.Calendar.DAY_OF_MONTH)
                            val newSub = Subscription(
                                nome = tx.descricao,
                                valor = tx.valor,
                                cicloCobranca = ciclo,
                                diaCobranca = dia,
                                dataCobranca = targetDate,
                                ativa = true,
                                icone = "custom",
                                corHex = "#1A73E8",
                                categoriaId = tx.categoriaId ?: 0,
                                carteiraId = tx.carteiraOrigemId,
                                moeda = tx.moedaOriginal,
                                sourceTransactionId = tx.id
                            )
                            val newId = db.subscriptionDao().insert(newSub).toInt()
                            currentSubs.add(newSub.copy(id = newId))
                        }
                    }
                }

                // Fallback safeguards: Ensure core defaults exist if restoring from an older schema backup
                if (db.subscriptionDao().getAllSubscriptionsDirect().isEmpty()) {
                    val defaultSubs = listOf(
                        Subscription(nome = "Netflix", valor = 12.99, diaCobranca = 15, cicloCobranca = "MENSAL", ativa = true, icone = "tv", corHex = "#E50914"),
                        Subscription(nome = "Spotify Premium", valor = 9.99, diaCobranca = 5, cicloCobranca = "MENSAL", ativa = true, icone = "music", corHex = "#1DB954"),
                        Subscription(nome = "iCloud+", valor = 2.99, diaCobranca = 1, cicloCobranca = "MENSAL", ativa = true, icone = "cloud", corHex = "#3B82F6")
                    )
                    for (sub in defaultSubs) {
                        db.subscriptionDao().insert(sub)
                    }
                }

                // Fallback safeguards: Ensure core defaults exist if restoring from an older schema backup
                if (db.userSettingsDao().getUserSettingsDirect() == null) {
                    db.userSettingsDao().insertOrUpdate(UserSettings())
                }
                if (db.walletDao().getAllWalletsDirect().isEmpty()) {
                    db.walletDao().insertWallet(Wallet(nome = "Carteira Principal", icone = "account_balance_wallet", cor = "#2196F3", saldoInicial = 0.0, saldoAtual = 0.0, ativa = true))
                }
                if (db.categoryDao().getAllCategoriesDirect().isEmpty()) {
                    for (c in DefaultData.defaultCategories) {
                        db.categoryDao().insertCategory(c)
                    }
                }
                val currentLists = db.shoppingListDao().getAllLists().firstOrNull() ?: emptyList()
                if (currentLists.isEmpty()) {
                    for (sl in DefaultData.defaultShoppingLists) {
                        db.shoppingListDao().insertList(sl)
                    }
                }
                val currentShopCat = db.shoppingCategoryDao().getAllCategories().firstOrNull() ?: emptyList()
                if (currentShopCat.isEmpty()) {
                    for (sc in DefaultData.defaultShoppingCategories) {
                        db.shoppingCategoryDao().insertCategory(sc)
                    }
                }
            }

            Log.d("BackupService", "Database restored successfully!")
            true
        } catch (e: Exception) {
            Log.e("BackupService", "Failed to restore database from backup", e)
            false
        }
    }

    private fun deriveKeyPbkdf2(pin: String, salt: ByteArray): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(pin.toCharArray(), salt, 100000, 256)
        val tmp = factory.generateSecret(spec)
        return SecretKeySpec(tmp.encoded, "AES")
    }

    // AES Encryption helpers with PBKDF2, random 16-byte salt, and 12-byte IV for AES/GCM authenticated encryption
    private fun encryptBytes(data: ByteArray, pin: String): ByteArray {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)

        val iv = ByteArray(12) // Standard 12-byte IV for GCM
        random.nextBytes(iv)

        val secretKey = deriveKeyPbkdf2(pin, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, javax.crypto.spec.GCMParameterSpec(128, iv))
        val ciphertext = cipher.doFinal(data)

        val output = ByteArray(salt.size + iv.size + ciphertext.size)
        System.arraycopy(salt, 0, output, 0, salt.size)
        System.arraycopy(iv, 0, output, salt.size, iv.size)
        System.arraycopy(ciphertext, 0, output, salt.size + iv.size, ciphertext.size)
        return output
    }

    private fun decryptBytes(encryptedData: ByteArray, pin: String): ByteArray {
        // 1. Attempt AES/GCM/NoPadding (16-byte salt + 12-byte IV)
        if (encryptedData.size >= 28) {
            try {
                val salt = ByteArray(16)
                val iv = ByteArray(12)
                System.arraycopy(encryptedData, 0, salt, 0, 16)
                System.arraycopy(encryptedData, 16, iv, 0, 12)

                val ciphertextLength = encryptedData.size - 28
                val ciphertext = ByteArray(ciphertextLength)
                System.arraycopy(encryptedData, 28, ciphertext, 0, ciphertextLength)

                val secretKey = deriveKeyPbkdf2(pin, salt)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, secretKey, javax.crypto.spec.GCMParameterSpec(128, iv))
                return cipher.doFinal(ciphertext)
            } catch (e: Exception) {
                Log.w("BackupService", "AES/GCM decryption failed, trying legacy CBC fallback", e)
            }
        }

        // 2. Legacy AES/CBC fallback (16-byte salt + 16-byte IV)
        if (encryptedData.size >= 32) {
            try {
                val salt = ByteArray(16)
                val iv = ByteArray(16)
                System.arraycopy(encryptedData, 0, salt, 0, 16)
                System.arraycopy(encryptedData, 16, iv, 0, 16)

                val ciphertextLength = encryptedData.size - 32
                val ciphertext = ByteArray(ciphertextLength)
                System.arraycopy(encryptedData, 32, ciphertext, 0, ciphertextLength)

                val secretKey = deriveKeyPbkdf2(pin, salt)
                val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
                cipher.init(Cipher.DECRYPT_MODE, secretKey, IvParameterSpec(iv))
                return cipher.doFinal(ciphertext)
            } catch (e: Exception) {
                Log.w("BackupService", "PBKDF2 CBC decryption failed, trying legacy SHA-256 decryption fallback", e)
            }
        }

        // 3. Legacy SHA-256 fallback
        val keyBytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray(Charsets.UTF_8))
        val secretKey = SecretKeySpec(keyBytes, "AES")
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        val iv = ByteArray(16)
        val ivSpec = IvParameterSpec(iv)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec)
        return cipher.doFinal(encryptedData)
    }
}
