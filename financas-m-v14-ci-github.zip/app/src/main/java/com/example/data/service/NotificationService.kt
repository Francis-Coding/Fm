package com.example.data.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity

class NotificationService(private val context: Context) {
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    companion object {
        const val CHANNEL_ID = "financas_m_notifications"
        const val CHANNEL_NAME = "Alertas e Lembretes Financeiros"
        const val CHANNEL_DESC = "Notificações inteligentes sobre empréstimos, faturas e listas de compras"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
                enableLights(true)
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            notificationManager?.createNotificationChannel(channel)
        }
    }

    fun sendNotification(
        title: String,
        message: String,
        notificationId: Int = (System.currentTimeMillis() % 100000).toInt(),
        targetTab: String? = null
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            if (targetTab != null) putExtra("navigate_to", targetTab)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId, // Unique request code per notificationId
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    notificationManager?.notify(notificationId, builder.build())
                } else {
                    android.util.Log.w("NotificationService", "POST_NOTIFICATIONS permission not granted.")
                }
            } else {
                notificationManager?.notify(notificationId, builder.build())
            }
        } catch (e: Exception) {
            android.util.Log.e("NotificationService", "Failed to send notification", e)
        }
    }

    // Helper for Loans
    fun notifyLoanDueDate(counterparty: String, amount: Double, daysLeft: Int) {
        val title = if (daysLeft == 0) "Empréstimo vence hoje!" else "Vencimento de Empréstimo"
        val desc = if (daysLeft == 0) {
            "O empréstimo de $counterparty no valor de ${String.format("%,.2f", amount)} MZN vence hoje!"
        } else {
            "O empréstimo de $counterparty no valor de ${String.format("%,.2f", amount)} MZN vence em $daysLeft dias."
        }
        val uniqueId = 2000 + Math.abs((counterparty + amount.toString()).hashCode() % 1000)
        sendNotification(title, desc, uniqueId, targetTab = "loans")
    }

    // Helper for forgotten shopping list items
    fun notifyForgottenShoppingItems(listName: String, itemCount: Int) {
        val title = "Lista de Compras Pendente"
        val desc = "Esqueceu-se de comprar $itemCount itens na lista '$listName'. Toque para abrir."
        val uniqueId = 3000 + Math.abs(listName.hashCode() % 1000)
        sendNotification(title, desc, uniqueId, targetTab = "shopping_list")
    }

    // Helper for Credit Card Due Date
    fun notifyCreditCardDueDate(cardName: String, invoiceAmount: Double, daysLeft: Int) {
        val title = if (daysLeft == 0) "Fatura do Cartão Vence Hoje!" else "Vencimento de Fatura"
        val desc = if (daysLeft == 0) {
            "A fatura do cartão $cardName (${String.format("%,.2f", invoiceAmount)} MZN) vence hoje!"
        } else {
            "A fatura do cartão $cardName (${String.format("%,.2f", invoiceAmount)} MZN) vence em $daysLeft dias."
        }
        val uniqueId = 6000 + Math.abs((cardName + invoiceAmount.toString()).hashCode() % 1000)
        sendNotification(title, desc, uniqueId, targetTab = "contas")
    }

    // Helper for Subscriptions
    fun notifySubscriptionDueDate(subscriptionName: String, amount: Double, daysLeft: Int) {
        val title = if (daysLeft == 0) "Cobrança de Assinatura Hoje" else "Próxima Cobrança de Assinatura"
        val desc = if (daysLeft == 0) {
            "A assinatura de $subscriptionName (${String.format("%,.2f", amount)} MZN) é cobrada hoje!"
        } else {
            "A assinatura de $subscriptionName (${String.format("%,.2f", amount)} MZN) será cobrada em $daysLeft dias."
        }
        val uniqueId = 7000 + Math.abs((subscriptionName + amount.toString()).hashCode() % 1000)
        sendNotification(title, desc, uniqueId, targetTab = "contas")
    }

    // Helper for budget thresholds
    fun notifyBudgetThreshold(categoryName: String, percent: Int) {
        val title = "Alerta de Limite de Gastos"
        val desc = "A categoria '$categoryName' já atingiu $percent% do seu limite mensal!"
        val uniqueId = 4000 + Math.abs(categoryName.hashCode() % 1000)
        sendNotification(title, desc, uniqueId, targetTab = "categories")
    }

    // Helper for weekly summaries
    fun notifyWeeklySummary(expenseTotal: Double, incomeTotal: Double) {
        val title = "Resumo Financeiro Semanal"
        val desc = "Esta semana: Receitas de ${String.format("%,.2f", incomeTotal)} MZN e Despesas de ${String.format("%,.2f", expenseTotal)} MZN. Mantenha o foco!"
        sendNotification(title, desc, 5000, targetTab = "relatorios")
    }
}
