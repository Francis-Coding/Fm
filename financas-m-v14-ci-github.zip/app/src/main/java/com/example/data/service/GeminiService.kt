package com.example.data.service

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Cliente de IA do App.
 * Aponta para o endpoint do serviço backend com token de sessão dinâmica.
 */
class GeminiService {

    private val appAuthToken get() = BackendAiProxyServer.getAppAuthToken()

    suspend fun getFinancialAdvice(
        totalIncomes: Double,
        totalExpenses: Double,
        balance: Double,
        categoryBreakdown: Map<String, Double>,
        goalsSummary: String,
        idioma: String = "PT"
    ): String = withContext(Dispatchers.IO) {

        val prompt = if (idioma == "PT") {
            """
            Você é o "Finanças M AI Coach", um consultor financeiro inteligente para Moçambique.
            Aqui está o resumo financeiro mensal atual do usuário:
            - Receitas totais: ${String.format("%,.2f", totalIncomes)} MZN
            - Despesas totais: ${String.format("%,.2f", totalExpenses)} MZN
            - Saldo atual disponível: ${String.format("%,.2f", balance)} MZN
            - Despesas por categoria: ${categoryBreakdown.entries.joinToString { "${it.key}: ${String.format("%,.2f", it.value)} MZN" }}
            - Metas financeiras ativas: $goalsSummary

            Forneça conselhos financeiros práticos, personalizados e diretos (máximo 4 parágrafos ou marcadores). Seja empático e encorajador. Destaque se houver despesas excessivas em alguma categoria e dê sugestões realistas para economizar e atingir as metas.
            """.trimIndent()
        } else {
            """
            You are the "Finanças M AI Coach", an intelligent financial advisor.
            Here is the user's current monthly financial summary:
            - Total Incomes: ${String.format("%,.2f", totalIncomes)} MZN
            - Total Expenses: ${String.format("%,.2f", totalExpenses)} MZN
            - Current Available Balance: ${String.format("%,.2f", balance)} MZN
            - Expenses by Category: ${categoryBreakdown.entries.joinToString { "${it.key}: ${String.format("%,.2f", it.value)} MZN" }}
            - Active Financial Goals: $goalsSummary

            Provide practical, personalized, and direct financial advice (maximum 4 paragraphs or bullet points). Be empathetic and encouraging. Highlight any overspending in categories and suggest realistic ways to save and reach their goals.
            """.trimIndent()
        }

        Log.d("GeminiService", "Processing AI request via BackendAiProxyServer")
        // Encaminha requisição ao backend proxy com o token de autenticação do app
        return@withContext BackendAiProxyServer.processAiAdviceRequest(
            authToken = appAuthToken,
            prompt = prompt,
            idioma = idioma
        )
    }
}

