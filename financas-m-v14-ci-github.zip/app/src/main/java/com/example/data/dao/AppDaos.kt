package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserSettingsDao {
    @Query("SELECT * FROM user_settings WHERE id = 1 LIMIT 1")
    fun getUserSettings(): Flow<UserSettings?>

    @Query("SELECT * FROM user_settings WHERE id = 1 LIMIT 1")
    suspend fun getUserSettingsDirect(): UserSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: UserSettings)
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM carteiras ORDER BY ordem ASC, nome ASC")
    fun getAllWallets(): Flow<List<Wallet>>

    @Query("SELECT * FROM carteiras ORDER BY ordem ASC, nome ASC")
    suspend fun getAllWalletsDirect(): List<Wallet>

    @Query("SELECT * FROM carteiras WHERE id = :id")
    suspend fun getWalletById(id: Int): Wallet?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWallet(wallet: Wallet)

    @Update
    suspend fun updateWallet(wallet: Wallet)

    @Update
    suspend fun updateWallets(wallets: List<Wallet>)

    @Delete
    suspend fun deleteWallet(wallet: Wallet)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categorias ORDER BY nome ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Query("SELECT * FROM categorias ORDER BY nome ASC")
    suspend fun getAllCategoriesDirect(): List<Category>

    @Query("SELECT * FROM categorias WHERE id = :id")
    suspend fun getCategoryById(id: Int): Category?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category)

    @Update
    suspend fun updateCategory(category: Category)

    @Delete
    suspend fun deleteCategory(category: Category)
}

data class CategorySum(
    val categoriaId: Int,
    val total: Double
)

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transacoes ORDER BY data DESC")
    fun getAllTransactionsFlow(): Flow<List<FinancialTransaction>>

    @Query("SELECT * FROM transacoes ORDER BY data DESC")
    suspend fun getAllTransactionsDirect(): List<FinancialTransaction>

    @Query("SELECT * FROM transacoes WHERE data >= :start ORDER BY data DESC")
    suspend fun getTransactionsSinceDirect(start: Long): List<FinancialTransaction>

    @Query("SELECT * FROM transacoes WHERE id = :id")
    suspend fun getTransactionById(id: Int): FinancialTransaction?

    @Query("SELECT * FROM transacoes WHERE data >= :start AND data <= :end ORDER BY data DESC")
    fun getTransactionsInRangeFlow(start: Long, end: Long): Flow<List<FinancialTransaction>>

    @Query("SELECT * FROM transacoes WHERE data >= :start AND data <= :end ORDER BY data DESC")
    suspend fun getTransactionsInRange(start: Long, end: Long): List<FinancialTransaction>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FinancialTransaction): Long

    @Update
    suspend fun updateTransaction(transaction: FinancialTransaction)

    @Delete
    suspend fun deleteTransaction(transaction: FinancialTransaction)

    @Query("DELETE FROM transacoes WHERE id = :id")
    suspend fun deleteTransactionById(id: Int)

    @Query("SELECT categoriaId, SUM(valor) as total FROM transacoes WHERE tipo = 'Despesa' AND ajusteCaixa = 0 AND data >= :start AND data <= :end GROUP BY categoriaId")
    fun getMonthlyExpensesByCategory(start: Long, end: Long): Flow<List<CategorySum>>

    @Query("SELECT SUM(valor) FROM transacoes WHERE tipo = 'Despesa' AND ajusteCaixa = 0 AND data >= :start")
    fun getExpensesSumSinceFlow(start: Long): Flow<Double?>
}

@Dao
interface DailyClosureDao {
    @Query("SELECT * FROM fechamentos ORDER BY data DESC")
    fun getAllClosures(): Flow<List<DailyClosure>>

    @Query("SELECT * FROM fechamentos ORDER BY id DESC LIMIT 1")
    suspend fun getLastClosureDirect(): DailyClosure?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClosure(closure: DailyClosure)

    @Delete
    suspend fun deleteClosure(closure: DailyClosure)
}

@Dao
interface FinancialGoalDao {
    @Query("SELECT * FROM metas ORDER BY dataLimite ASC")
    fun getAllGoals(): Flow<List<FinancialGoal>>

    @Query("SELECT * FROM metas WHERE id = :id")
    suspend fun getGoalById(id: Int): FinancialGoal?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: FinancialGoal): Long

    @Delete
    suspend fun deleteGoal(goal: FinancialGoal)
}

@Dao
interface RecycleBinDao {
    @Query("SELECT * FROM lixeira ORDER BY dataExclusao DESC")
    fun getAllTrashItems(): Flow<List<RecycleBin>>

    @Query("SELECT * FROM lixeira")
    suspend fun getAllTrashDirect(): List<RecycleBin>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrash(trash: RecycleBin)

    @Delete
    suspend fun deleteTrash(trash: RecycleBin)

    @Query("DELETE FROM lixeira WHERE id = :id")
    suspend fun deleteTrashById(id: Int)

    @Query("DELETE FROM lixeira WHERE transacaoOriginalId = :transId")
    suspend fun deleteTrashByOriginalId(transId: Int)
}

@Dao
interface SpendingLimitDao {
    @Query("SELECT * FROM spending_limits")
    fun getAllSpendingLimits(): Flow<List<SpendingLimit>>

    @Query("SELECT * FROM spending_limits WHERE categoryId = :categoryId AND month = :month LIMIT 1")
    suspend fun getLimitByCategoryAndMonth(categoryId: Int, month: String): SpendingLimit?

    @Query("SELECT * FROM spending_limits WHERE month = :month")
    fun getLimitsByMonth(month: String): Flow<List<SpendingLimit>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateLimit(limit: SpendingLimit)

    @Delete
    suspend fun deleteLimit(limit: SpendingLimit)
}

@Dao
interface LoanDao {
    @Query("SELECT * FROM loans ORDER BY transactionDate DESC")
    fun getAllLoans(): Flow<List<Loan>>

    @Query("SELECT * FROM loans WHERE id = :id")
    suspend fun getLoanById(id: Int): Loan?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoan(loan: Loan): Long

    @Update
    suspend fun updateLoan(loan: Loan)

    @Delete
    suspend fun deleteLoan(loan: Loan)
}

@Dao
interface InstallmentDao {
    @Query("SELECT * FROM installments ORDER BY dueDate ASC")
    fun getAllInstallments(): Flow<List<Installment>>

    @Query("SELECT * FROM installments WHERE parentId = :parentId ORDER BY dueDate ASC")
    fun getInstallmentsByParentId(parentId: Int): Flow<List<Installment>>

    @Query("SELECT * FROM installments WHERE parentId = :parentId ORDER BY dueDate ASC")
    suspend fun getInstallmentsByParentIdDirect(parentId: Int): List<Installment>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstallment(installment: Installment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstallments(installments: List<Installment>)

    @Update
    suspend fun updateInstallment(installment: Installment)

    @Delete
    suspend fun deleteInstallment(installment: Installment)
}

@Dao
interface ShoppingItemDao {
    @Query("SELECT * FROM itens_compra ORDER BY pago ASC, CASE prioridade WHEN 'ALTA' THEN 1 WHEN 'MEDIA' THEN 2 WHEN 'BAIXA' THEN 3 ELSE 4 END, nome ASC")
    fun getAllShoppingItems(): Flow<List<ShoppingItem>>

    @Query("SELECT * FROM itens_compra WHERE listaId = :listaId ORDER BY pago ASC, CASE prioridade WHEN 'ALTA' THEN 1 WHEN 'MEDIA' THEN 2 WHEN 'BAIXA' THEN 3 ELSE 4 END, nome ASC")
    fun getShoppingItemsForList(listaId: Int): Flow<List<ShoppingItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShoppingItem(item: ShoppingItem): Long

    @Update
    suspend fun updateShoppingItem(item: ShoppingItem)

    @Delete
    suspend fun deleteShoppingItem(item: ShoppingItem)

    @Query("DELETE FROM itens_compra WHERE id = :id")
    suspend fun deleteShoppingItemById(id: Int)

    @Query("DELETE FROM itens_compra WHERE pago = 1")
    suspend fun clearPaidItems()

    @Query("DELETE FROM itens_compra WHERE pago = 1 AND listaId = :listaId")
    suspend fun clearPaidItemsForList(listaId: Int)

    @Query("SELECT DISTINCT nome FROM itens_compra")
    fun getDistinctProductNames(): Flow<List<String>>
}

@Dao
interface ShoppingListDao {
    @Query("SELECT * FROM listas_compra ORDER BY id DESC")
    fun getAllLists(): Flow<List<ShoppingList>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertList(list: ShoppingList): Long

    @Update
    suspend fun updateList(list: ShoppingList)

    @Delete
    suspend fun deleteList(list: ShoppingList)

    @Query("DELETE FROM itens_compra WHERE listaId = :listaId")
    suspend fun deleteItemsByListId(listaId: Int)
}

@Dao
interface ShoppingCategoryDao {
    @Query("SELECT * FROM categorias_compra ORDER BY ordem ASC, nome ASC")
    fun getAllCategories(): Flow<List<ShoppingCategory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: ShoppingCategory): Long

    @Update
    suspend fun updateCategory(category: ShoppingCategory)

    @Delete
    suspend fun deleteCategory(category: ShoppingCategory)

    @Query("UPDATE categorias_compra SET ordem = :ordem WHERE id = :id")
    suspend fun updateCategoryOrder(id: Int, ordem: Int)
}

@Dao
interface ShoppingPriceHistoryDao {
    @Query("SELECT * FROM historico_precos_compra WHERE nomeProduto = :nomeProduto ORDER BY data DESC")
    fun getPriceHistoryForProduct(nomeProduto: String): Flow<List<ShoppingPriceHistory>>

    @Query("SELECT * FROM historico_precos_compra ORDER BY data DESC")
    fun getAllPriceHistory(): Flow<List<ShoppingPriceHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPriceHistory(history: ShoppingPriceHistory)

    @Query("SELECT AVG(preco) FROM historico_precos_compra WHERE nomeProduto = :nomeProduto")
    suspend fun getAveragePriceForProduct(nomeProduto: String): Double?
}

@Dao
interface LoanReceiptDao {
    @Query("SELECT * FROM loan_receipts WHERE loanId = :loanId ORDER BY id DESC")
    fun getReceiptsForLoan(loanId: Int): Flow<List<LoanReceipt>>

    @Query("SELECT * FROM loan_receipts")
    suspend fun getAllReceiptsDirect(): List<LoanReceipt>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: LoanReceipt): Long

    @Delete
    suspend fun deleteReceipt(receipt: LoanReceipt)
}

@Dao
interface SubscriptionDao {
    @Query("SELECT * FROM subscriptions ORDER BY ativa DESC, nome ASC")
    fun getAllSubscriptions(): Flow<List<Subscription>>

    @Query("SELECT * FROM subscriptions ORDER BY ativa DESC, nome ASC")
    suspend fun getAllSubscriptionsDirect(): List<Subscription>

    @Query("SELECT * FROM subscriptions WHERE sourceTransactionId = :txId LIMIT 1")
    suspend fun getSubscriptionBySourceTransactionId(txId: Int): Subscription?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subscription: Subscription): Long

    @Update
    suspend fun update(subscription: Subscription)

    @Delete
    suspend fun delete(subscription: Subscription)

    @Query("DELETE FROM subscriptions WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface CreditCardDao {
    @Query("SELECT * FROM credit_cards ORDER BY ativa DESC, nome ASC")
    fun getAllCreditCards(): Flow<List<CreditCard>>

    @Query("SELECT * FROM credit_cards ORDER BY ativa DESC, nome ASC")
    suspend fun getAllCreditCardsDirect(): List<CreditCard>

    @Query("SELECT * FROM credit_cards WHERE id = :id")
    suspend fun getCreditCardById(id: Int): CreditCard?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCreditCard(card: CreditCard): Long

    @Update
    suspend fun updateCreditCard(card: CreditCard)

    @Delete
    suspend fun deleteCreditCard(card: CreditCard)

    @Query("DELETE FROM credit_cards WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface ExportedReportDao {
    @Query("SELECT * FROM exported_reports ORDER BY timestamp DESC")
    fun getAllExportedReports(): Flow<List<ExportedReport>>

    @Query("SELECT * FROM exported_reports ORDER BY timestamp DESC")
    suspend fun getAllExportedReportsDirect(): List<ExportedReport>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExportedReport(report: ExportedReport)

    @Delete
    suspend fun deleteExportedReport(report: ExportedReport)
}

@Dao
interface ScheduledTransferDao {
    @Query("SELECT * FROM scheduled_transfers ORDER BY dataHora ASC")
    fun getAllScheduledTransfers(): Flow<List<ScheduledTransfer>>

    @Query("SELECT * FROM scheduled_transfers ORDER BY dataHora ASC")
    suspend fun getAllScheduledTransfersDirect(): List<ScheduledTransfer>

    @Query("SELECT * FROM scheduled_transfers WHERE executada = 0 AND dataHora <= :currentTime")
    suspend fun getPendingTransfersDue(currentTime: Long = System.currentTimeMillis()): List<ScheduledTransfer>

    @Query("SELECT * FROM scheduled_transfers WHERE id = :id")
    suspend fun getById(id: Int): ScheduledTransfer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transfer: ScheduledTransfer): Long

    @Update
    suspend fun update(transfer: ScheduledTransfer)

    @Delete
    suspend fun delete(transfer: ScheduledTransfer)

    @Query("DELETE FROM scheduled_transfers WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE status != 'ARCHIVED' ORDER BY createdAt DESC")
    fun getActiveNotifications(): Flow<List<NotificationEntity>>

    @Query("SELECT * FROM notifications ORDER BY createdAt DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>
    
    @Query("SELECT COUNT(*) FROM notifications WHERE status = 'UNREAD'")
    fun getUnreadCount(): Flow<Int>

    @Query("SELECT * FROM notifications WHERE notificationId = :id")
    suspend fun getNotificationById(id: Int): NotificationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Update
    suspend fun updateNotification(notification: NotificationEntity)

    @Delete
    suspend fun deleteNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET status = 'READ', readAt = :time WHERE status = 'UNREAD'")
    suspend fun markAllAsRead(time: Long = System.currentTimeMillis())
    
    @Query("UPDATE notifications SET status = 'READ', readAt = :time WHERE notificationId = :id AND status = 'UNREAD'")
    suspend fun markAsRead(id: Int, time: Long = System.currentTimeMillis())

    @Query("UPDATE notifications SET status = 'RESOLVED' WHERE entityType = :entityType AND entityId = :entityId")
    suspend fun resolveNotificationsForEntity(entityType: String, entityId: Int)
}
