package com.example.util

import java.util.Locale

object MoneyFormatter {
    private fun cleanCurrency(currency: String): String {
        return currency.split(" ").filter { it.isNotBlank() }.distinct().joinToString(" ")
    }

    fun format(amount: Double, currency: String = "MZN"): String {
        val clean = cleanCurrency(currency)
        val formatted = String.format(Locale.US, "%,.0f", amount).replace(',', ' ')
        return "$formatted $clean"
    }

    fun formatWithDecimals(amount: Double, currency: String = "MZN"): String {
        val clean = cleanCurrency(currency)
        val formatted = String.format(Locale.US, "%,.2f", amount).replace(',', ' ')
        return "$formatted $clean"
    }

    fun formatCompact(amount: Double, currency: String = "MZN"): String {
        val clean = cleanCurrency(currency)
        val absVal = kotlin.math.abs(amount)
        val sign = if (amount < 0) "-" else ""
        val formatted = when {
            absVal >= 1_000_000_000 -> String.format(Locale.US, "%.2fB", absVal / 1_000_000_000.0)
            absVal >= 1_000_000 -> String.format(Locale.US, "%.2fM", absVal / 1_000_000.0)
            else -> String.format(Locale.US, "%,.2f", absVal).replace(',', ' ')
        }
        return "$sign$formatted $clean"
    }
}
