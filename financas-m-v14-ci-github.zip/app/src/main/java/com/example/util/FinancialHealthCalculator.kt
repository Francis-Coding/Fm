package com.example.util

import androidx.compose.ui.graphics.Color
import com.example.data.model.*
import java.util.Calendar

data class HealthIndexResult(
    val score: Int,
    val status: String,
    val color: Color,
    val feedback: String,
    val tips: List<String>,
    val savingsRateScore: Int,
    val emergencyFundScore: Int,
    val limitsScore: Int,
    val goalsScore: Int
)

object FinancialHealthCalculator {
    fun calculate(
        transactions: List<FinancialTransaction>,
        wallets: List<Wallet>,
        categories: List<Category>,
        goals: List<FinancialGoal>,
        idioma: String = "PT"
    ): HealthIndexResult {
        val calendar = Calendar.getInstance(java.util.TimeZone.getDefault()).apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfMonth = calendar.timeInMillis

        val incomesThisMonth = transactions
            .filter { it.isReceita() && it.data >= startOfMonth }
            .sumOf { it.valor }

        val expensesThisMonth = transactions
            .filter { it.isDespesa() && it.data >= startOfMonth }
            .sumOf { it.valor }

        val totalBalance = wallets.filter { it.ativa }.sumOf { it.saldoAtual }

        // Average daily expenses over last 30 days
        val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
        val expensesLast30Days = transactions
            .filter { it.isDespesa() && it.data >= thirtyDaysAgo }
            .sumOf { it.valor }
        val avgDailyExpense = if (expensesLast30Days > 0) expensesLast30Days / 30.0 else 0.0
        val survivalDays = if (avgDailyExpense > 0 && !totalBalance.isNaN()) (totalBalance / avgDailyExpense).coerceIn(0.0, 10000.0).toInt() else -1

        // 1. Savings Rate Score (Max 30)
        val savingsRate = if (incomesThisMonth > 0) ((incomesThisMonth - expensesThisMonth) / incomesThisMonth) * 100 else if (expensesThisMonth == 0.0) 0.0 else -100.0
        val savingsRateScore = when {
            incomesThisMonth <= 0.0 && expensesThisMonth > 0.0 -> 0
            incomesThisMonth <= 0.0 && expensesThisMonth == 0.0 -> 15
            savingsRate >= 30.0 -> 30
            savingsRate >= 20.0 -> 25
            savingsRate >= 10.0 -> 15
            savingsRate >= 0.0 -> 10
            else -> 0
        }

        // 2. Emergency Fund Score (Max 35)
        val emergencyFundScore = when {
            survivalDays >= 180 -> 35
            survivalDays >= 90 -> 25
            survivalDays >= 30 -> 15
            survivalDays > 0 -> 5
            survivalDays == -1 -> if (totalBalance > 0) 35 else 0
            else -> 0
        }

        // 3. Spending Limits Score (Max 20)
        val categoriesWithLimits = categories.filter { it.tipo == "Despesa" && it.limiteMensal > 0.0 }
        val categoryExpensesThisMonth = transactions
            .filter { it.isDespesa() && it.data >= startOfMonth }
            .groupBy { it.categoriaId }
            .mapValues { entry -> entry.value.sumOf { it.valor } }
        val overspentCount = categoriesWithLimits.count { cat ->
            (categoryExpensesThisMonth[cat.id] ?: 0.0) > cat.limiteMensal
        }
        val limitsScore = if (categoriesWithLimits.isEmpty()) {
            20
        } else {
            val healthyRatio = (categoriesWithLimits.size - overspentCount).toDouble() / categoriesWithLimits.size
            (healthyRatio * 20).toInt()
        }

        // 4. Goals Progress Score (Max 15)
        val goalsScore = if (goals.isEmpty()) {
            10
        } else {
            val avgProgress = goals.map {
                if (it.valorObjetivo > 0) (it.valorAtual / it.valorObjetivo).coerceIn(0.0, 1.0) else 0.0
            }.average()
            (avgProgress * 15).toInt()
        }

        val totalScore = (savingsRateScore + emergencyFundScore + limitsScore + goalsScore).coerceIn(0, 100)

        val feedbackText = if (idioma == "PT") {
            when {
                totalScore >= 75 -> "Sua saúde financeira está excelente! Continue poupando e mantendo seus custos sob controle."
                totalScore >= 50 -> "Sua saúde financeira é estável, mas há pontos a melhorar. Fique atento aos seus limites de gastos!"
                else -> "Atenção: sua saúde financeira está crítica. É altamente recomendável rever despesas supérfluas urgentemente."
            }
        } else {
            when {
                totalScore >= 75 -> "Your financial health is excellent! Keep saving and managing costs carefully."
                totalScore >= 50 -> "Your financial health is stable, but there is room for improvement. Stay within budget limits!"
                else -> "Warning: your financial health is critical. Reviewing non-essential spending is strongly advised."
            }
        }

        val statusText = if (idioma == "PT") {
            when {
                totalScore >= 75 -> "Excelente"
                totalScore >= 50 -> "Estável"
                else -> "Crítica"
            }
        } else {
            when {
                totalScore >= 75 -> "Excellent"
                totalScore >= 50 -> "Stable"
                else -> "Critical"
            }
        }

        val scoreColor = when {
            totalScore >= 75 -> Color(0xFF2E7D32)
            totalScore >= 50 -> Color(0xFFFBC02D)
            else -> Color(0xFFC62828)
        }

        val tips = mutableListOf<String>()
        if (idioma == "PT") {
            if (savingsRateScore < 15) tips.add("Poupe mais: tente economizar pelo menos 10% da sua receita.")
            if (emergencyFundScore < 15) tips.add("Sua reserva é baixa. Priorize guardar para emergências.")
            if (overspentCount > 0) tips.add("Você ultrapassou o limite em $overspentCount categorias.")
            if (goals.isEmpty()) tips.add("Defina metas para te motivar a poupar.")
        } else {
            if (savingsRateScore < 15) tips.add("Save more: try to set aside at least 10% of your earnings.")
            if (emergencyFundScore < 15) tips.add("Your reserve is low. Focus on building an emergency fund.")
            if (overspentCount > 0) tips.add("You've exceeded limits in $overspentCount budget categories.")
            if (goals.isEmpty()) tips.add("Set a goal to keep yourself motivated.")
        }

        return HealthIndexResult(
            score = totalScore,
            status = statusText,
            color = scoreColor,
            feedback = feedbackText,
            tips = tips,
            savingsRateScore = savingsRateScore,
            emergencyFundScore = emergencyFundScore,
            limitsScore = limitsScore,
            goalsScore = goalsScore
        )
    }
}
