package com.example.util

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.compose.ui.res.painterResource
import com.example.R

data class KnownBrand(
    val key: String,
    val name: String,
    val color: Color
)

object BrandRegistry {
    val KNOWN_BRANDS = mapOf(
        "spotify" to KnownBrand("spotify", "Spotify", Color(0xFF1DB954)),
        "netflix" to KnownBrand("netflix", "Netflix", Color(0xFFE50914)),
        "youtube" to KnownBrand("youtube", "YouTube", Color(0xFFFF0000)),
        "disney" to KnownBrand("disney", "Disney+", Color(0xFF113CCF)),
        "amazon" to KnownBrand("amazon", "Amazon Prime", Color(0xFF00A8E1)),
        "prime" to KnownBrand("prime", "Amazon Prime", Color(0xFF00A8E1)),
        "apple" to KnownBrand("apple", "Apple", Color(0xFF1C1C1E)),
        "hbo" to KnownBrand("hbo", "HBO Max", Color(0xFF5822B4)),
        "max" to KnownBrand("max", "Max", Color(0xFF5822B4)),
        "chatgpt" to KnownBrand("chatgpt", "ChatGPT", Color(0xFF10A37F)),
        "openai" to KnownBrand("openai", "OpenAI", Color(0xFF10A37F)),
        "internet" to KnownBrand("internet", "Internet", Color(0xFF1E66D0)),
        "wifi" to KnownBrand("wifi", "Internet / Wi-Fi", Color(0xFF1E66D0)),
        "energia" to KnownBrand("energia", "Energia", Color(0xFFF59E0B)),
        "electric" to KnownBrand("electric", "Electricity", Color(0xFFF59E0B)),
        "eletricidade" to KnownBrand("eletricidade", "Eletricidade", Color(0xFFF59E0B)),
        "agua" to KnownBrand("agua", "Água", Color(0xFF06B6D4)),
        "água" to KnownBrand("água", "Água", Color(0xFF06B6D4)),
        "gas" to KnownBrand("gas", "Gás", Color(0xFFEF4444)),
        "gás" to KnownBrand("gás", "Gás", Color(0xFFEF4444)),
        "gym" to KnownBrand("gym", "Academia / Gym", Color(0xFFF97316)),
        "fitness" to KnownBrand("fitness", "Fitness", Color(0xFFF97316)),
        "academia" to KnownBrand("academia", "Academia", Color(0xFFF97316)),
        "telemovel" to KnownBrand("telemovel", "Telemóvel", Color(0xFF8B5CF6)),
        "celular" to KnownBrand("celular", "Celular", Color(0xFF8B5CF6)),
        "phone" to KnownBrand("phone", "Phone", Color(0xFF8B5CF6)),
        "seguro" to KnownBrand("seguro", "Seguro", Color(0xFF10B981)),
        "seguros" to KnownBrand("seguros", "Seguros", Color(0xFF10B981))
    )

    fun findBrand(query: String): KnownBrand? {
        val q = query.lowercase().trim()
        if (q.isBlank()) return null
        KNOWN_BRANDS[q]?.let { return it }
        return KNOWN_BRANDS.values.firstOrNull { brand ->
            q.contains(brand.key) || brand.key.contains(q)
        }
    }
}

@Composable
fun BrandIcon(
    nameOrKey: String,
    customColorHex: String? = null,
    modifier: Modifier = Modifier.size(36.dp),
    shape: Shape = RoundedCornerShape(10.dp)
) {
    val brand = remember(nameOrKey) { BrandRegistry.findBrand(nameOrKey) }
    
    val bgColor = remember(brand, customColorHex) {
        if (brand != null) {
            brand.color
        } else if (!customColorHex.isNullOrBlank()) {
            try {
                Color(android.graphics.Color.parseColor(customColorHex))
            } catch (e: Exception) {
                Color(0xFF3B82F6)
            }
        } else {
            Color(0xFF3B82F6)
        }
    }

    val gradientBrush = remember(bgColor) {
        Brush.linearGradient(
            colors = listOf(
                bgColor,
                bgColor.copy(alpha = 0.85f)
            )
        )
    }

    Box(
        modifier = modifier
            .clip(shape)
            .background(gradientBrush)
            .border(1.dp, Color.White.copy(alpha = 0.2f), shape),
        contentAlignment = Alignment.Center
    ) {
        val key = (brand?.key ?: nameOrKey).lowercase().trim()
        when {
            key.contains("spotify") -> Icon(painterResource(R.drawable.ic_brand_spotify), contentDescription = "Spotify", tint = Color.White, modifier = Modifier.size(20.dp))
            key.contains("netflix") -> Icon(painterResource(R.drawable.ic_brand_netflix), contentDescription = "Netflix", tint = Color.White, modifier = Modifier.size(20.dp))
            key.contains("youtube") -> Icon(painterResource(R.drawable.ic_brand_youtube), contentDescription = "YouTube", tint = Color.White, modifier = Modifier.size(20.dp))
            key.contains("apple tv") || key.contains("appletv") -> Icon(painterResource(R.drawable.ic_brand_appletv), contentDescription = "Apple TV", tint = Color.White, modifier = Modifier.size(20.dp))
            key.contains("apple music") || key.contains("applemusic") -> Icon(painterResource(R.drawable.ic_brand_applemusic), contentDescription = "Apple Music", tint = Color.White, modifier = Modifier.size(20.dp))
            key.contains("apple") -> Icon(painterResource(R.drawable.ic_brand_apple), contentDescription = "Apple", tint = Color.White, modifier = Modifier.size(20.dp))
            key.contains("hbo") || key == "max" || key.contains("hbo max") || key.contains("hbomax") -> Icon(painterResource(R.drawable.ic_brand_hbo), contentDescription = "HBO Max", tint = Color.White, modifier = Modifier.size(20.dp))
            key.contains("disney") -> Text("D+", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
            key.contains("chatgpt") || key.contains("openai") -> Icon(Icons.Rounded.AutoAwesome, contentDescription = "ChatGPT", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("internet") || key.contains("wifi") -> Icon(Icons.Rounded.Wifi, contentDescription = "Internet", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("energia") || key.contains("electric") || key.contains("eletricidade") -> Icon(Icons.Rounded.Bolt, contentDescription = "Energia", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("agua") || key.contains("água") -> Icon(Icons.Rounded.WaterDrop, contentDescription = "Água", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("gas") || key.contains("gás") -> Icon(Icons.Rounded.LocalGasStation, contentDescription = "Gás", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("gym") || key.contains("fitness") || key.contains("academia") -> Icon(Icons.Rounded.FitnessCenter, contentDescription = "Academia", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("telemovel") || key.contains("celular") || key.contains("phone") -> Icon(Icons.Rounded.PhoneAndroid, contentDescription = "Celular", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("seguro") -> Icon(Icons.Rounded.Shield, contentDescription = "Seguro", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("tv") || key.contains("streaming") -> Icon(Icons.Rounded.Tv, contentDescription = "TV", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("music") -> Icon(Icons.Rounded.MusicNote, contentDescription = "Música", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("game") || key.contains("gaming") -> Icon(Icons.Rounded.SportsEsports, contentDescription = "Gaming", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("shopping") -> Icon(Icons.Rounded.ShoppingCart, contentDescription = "Shopping", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("cloud") -> Icon(Icons.Rounded.Cloud, contentDescription = "Cloud", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("card") -> Icon(Icons.Rounded.CreditCard, contentDescription = "Cartão", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("car") -> Icon(Icons.Rounded.DirectionsCar, contentDescription = "Veículo", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("home") -> Icon(Icons.Rounded.Home, contentDescription = "Casa", tint = Color.White, modifier = Modifier.size(19.dp))
            key.contains("work") -> Icon(Icons.Rounded.Work, contentDescription = "Trabalho", tint = Color.White, modifier = Modifier.size(19.dp))
            else -> {
                val initial = nameOrKey.trim().takeIf { it.isNotBlank() && it.lowercase() != "custom" }?.firstOrNull()?.uppercase() ?: ""
                if (initial.isNotEmpty()) {
                    Text(text = initial, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                } else {
                    AppIcon(
                        iconKey = nameOrKey,
                        contentDescription = nameOrKey,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SpotifyLogo() {
    Canvas(modifier = Modifier.size(20.dp)) {
        val strokeWidth = 2.dp.toPx()
        drawArc(
            color = Color.White,
            startAngle = 205f,
            sweepAngle = 130f,
            useCenter = false,
            topLeft = Offset(size.width * 0.08f, size.height * 0.12f),
            size = Size(size.width * 0.84f, size.height * 0.76f),
            style = Stroke(width = strokeWidth * 1.25f, cap = StrokeCap.Round)
        )
        drawArc(
            color = Color.White,
            startAngle = 205f,
            sweepAngle = 120f,
            useCenter = false,
            topLeft = Offset(size.width * 0.18f, size.height * 0.34f),
            size = Size(size.width * 0.64f, size.height * 0.60f),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
        drawArc(
            color = Color.White,
            startAngle = 205f,
            sweepAngle = 110f,
            useCenter = false,
            topLeft = Offset(size.width * 0.28f, size.height * 0.54f),
            size = Size(size.width * 0.44f, size.height * 0.44f),
            style = Stroke(width = strokeWidth * 0.8f, cap = StrokeCap.Round)
        )
    }
}
