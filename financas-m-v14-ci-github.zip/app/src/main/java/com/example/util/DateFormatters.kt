package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateFormatters {
    private val dateOnlyFormat = ThreadLocal.withInitial { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }
    private val dateTimeFormat = ThreadLocal.withInitial { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
    private val monthYearFormat = ThreadLocal.withInitial { SimpleDateFormat("MM/yyyy", Locale.getDefault()) }
    private val dayMonthFormat = ThreadLocal.withInitial { SimpleDateFormat("dd/MM", Locale.getDefault()) }
    private val isoDateFormat = ThreadLocal.withInitial { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }

    fun formatDate(timeMillis: Long): String {
        return dateOnlyFormat.get()?.format(Date(timeMillis)) ?: ""
    }

    fun formatDateTime(timeMillis: Long): String {
        return dateTimeFormat.get()?.format(Date(timeMillis)) ?: ""
    }

    fun formatMonthYear(timeMillis: Long): String {
        return monthYearFormat.get()?.format(Date(timeMillis)) ?: ""
    }

    fun formatDayMonth(timeMillis: Long): String {
        return dayMonthFormat.get()?.format(Date(timeMillis)) ?: ""
    }

    fun formatIsoDate(timeMillis: Long): String {
        return isoDateFormat.get()?.format(Date(timeMillis)) ?: ""
    }

    fun parseDate(dateStr: String): Date? {
        return try {
            dateOnlyFormat.get()?.parse(dateStr)
        } catch (e: Exception) {
            null
        }
    }
}
