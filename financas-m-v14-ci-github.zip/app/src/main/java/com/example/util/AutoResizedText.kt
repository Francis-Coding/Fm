package com.example.util

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.isUnspecified

@Composable
fun AutoResizedText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    maxFontSize: TextUnit = TextUnit.Unspecified,
    minFontSize: TextUnit = TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    maxLines: Int = 1,
    softWrap: Boolean = true,
    overflow: TextOverflow = TextOverflow.Clip,
    style: TextStyle = LocalTextStyle.current
) {
    var resizedTextStyle by remember(style, maxFontSize, fontSize) {
        mutableStateOf(style.copy(fontSize = if (maxFontSize.isUnspecified) (if (fontSize.isUnspecified) style.fontSize else fontSize) else maxFontSize))
    }
    var readyToDraw by remember(style, maxFontSize, fontSize, text) { mutableStateOf(false) }

    Text(
        text = text,
        color = color,
        modifier = modifier.drawWithContent {
            if (readyToDraw) {
                drawContent()
            }
        },
        textAlign = textAlign,
        maxLines = maxLines,
        fontWeight = fontWeight,
        style = resizedTextStyle,
        softWrap = softWrap,
        overflow = overflow,
        onTextLayout = { textLayoutResult ->
            if (textLayoutResult.didOverflowWidth || textLayoutResult.didOverflowHeight) {
                if (minFontSize.isUnspecified || resizedTextStyle.fontSize > minFontSize) {
                    val nextFontSize = resizedTextStyle.fontSize * 0.9f
                    resizedTextStyle = resizedTextStyle.copy(fontSize = nextFontSize)
                } else {
                    readyToDraw = true
                }
            } else {
                readyToDraw = true
            }
        }
    )
}
