package com.example.util

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class IconItem(
    val key: String,
    val labelPt: String,
    val labelEn: String,
    val icon: ImageVector
)

object AppIcons {

    // Default Fallbacks
    val DefaultCategoryIcon: ImageVector = Icons.Rounded.Category
    val DefaultWalletIcon: ImageVector = Icons.Rounded.AccountBalanceWallet

    val ALL_ICONS: Map<String, ImageVector> = mapOf(
        "restaurant" to Icons.Rounded.Restaurant,
        "directions_car" to Icons.Rounded.DirectionsCar,
        "directions_bus" to Icons.Rounded.DirectionsBus,
        "home" to Icons.Rounded.Home,
        "movie" to Icons.Rounded.Movie,
        "local_hospital" to Icons.Rounded.LocalHospital,
        "tune" to Icons.Rounded.Tune,
        "payments" to Icons.Rounded.Payments,
        "trending_up" to Icons.AutoMirrored.Rounded.TrendingUp,
        "savings" to Icons.Rounded.Savings,
        "school" to Icons.Rounded.School,
        "checkroom" to Icons.Rounded.Checkroom,
        "label" to Icons.AutoMirrored.Rounded.Label,
        "lunch_dining" to Icons.Rounded.LunchDining,
        "coffee" to Icons.Rounded.Coffee,
        "local_taxi" to Icons.Rounded.LocalTaxi,
        "local_gas_station" to Icons.Rounded.LocalGasStation,
        "lightbulb" to Icons.Rounded.Lightbulb,
        "card_giftcard" to Icons.Rounded.CardGiftcard,
        "pets" to Icons.Rounded.Pets,
        "flight" to Icons.Rounded.Flight,
        "fitness_center" to Icons.Rounded.FitnessCenter,
        "shopping_cart" to Icons.Rounded.ShoppingCart,
        "shopping_bag" to Icons.Rounded.ShoppingBag,
        "receipt" to Icons.AutoMirrored.Rounded.ReceiptLong,
        "work" to Icons.Rounded.Work,
        "person" to Icons.Rounded.Person,
        "smartphone" to Icons.Rounded.Smartphone,
        "wifi" to Icons.Rounded.Wifi,
        "water_drop" to Icons.Rounded.WaterDrop,
        "bolt" to Icons.Rounded.Bolt,
        "build" to Icons.Rounded.Build,
        "child_care" to Icons.Rounded.ChildCare,
        "account_balance_wallet" to Icons.Rounded.AccountBalanceWallet,
        "account_balance" to Icons.Rounded.AccountBalance,
        "credit_card" to Icons.Rounded.CreditCard,
        "currency_exchange" to Icons.Rounded.CurrencyExchange,
        "camera_alt" to Icons.Rounded.CameraAlt,
        "calculate" to Icons.Rounded.Calculate,
        "track_changes" to Icons.Rounded.TrackChanges,
        "analytics" to Icons.Rounded.Analytics,
        "auto_awesome" to Icons.Rounded.AutoAwesome,
        "lock" to Icons.Rounded.Lock,
        "key" to Icons.Rounded.Key,
        "notifications" to Icons.Rounded.Notifications,
        "warning" to Icons.Rounded.Warning,
        "check_circle" to Icons.Rounded.CheckCircle,
        "error" to Icons.Rounded.Error
    )

    val CATEGORY_ICONS: List<IconItem> = listOf(
        IconItem("restaurant", "Alimentação", "Food & Dining", Icons.Rounded.Restaurant),
        IconItem("directions_car", "Transporte", "Transport", Icons.Rounded.DirectionsCar),
        IconItem("home", "Habitação", "Housing", Icons.Rounded.Home),
        IconItem("movie", "Lazer & Cultura", "Entertainment", Icons.Rounded.Movie),
        IconItem("local_hospital", "Saúde & Farmácia", "Health & Pharmacy", Icons.Rounded.LocalHospital),
        IconItem("tune", "Ajustes & Taxas", "Adjustments & Fees", Icons.Rounded.Tune),
        IconItem("payments", "Salário & Renda", "Salary & Income", Icons.Rounded.Payments),
        IconItem("trending_up", "Negócios & Vendas", "Business & Sales", Icons.AutoMirrored.Rounded.TrendingUp),
        IconItem("savings", "Investimentos", "Investments", Icons.Rounded.Savings),
        IconItem("school", "Educação & Cursos", "Education", Icons.Rounded.School),
        IconItem("checkroom", "Vestuário & Moda", "Clothing", Icons.Rounded.Checkroom),
        IconItem("shopping_cart", "Mercado & Compras", "Groceries & Shopping", Icons.Rounded.ShoppingCart),
        IconItem("lightbulb", "Serviços & Utilitários", "Utilities", Icons.Rounded.Lightbulb),
        IconItem("card_giftcard", "Presentes", "Gifts", Icons.Rounded.CardGiftcard),
        IconItem("pets", "Animais de Estimação", "Pets", Icons.Rounded.Pets),
        IconItem("flight", "Viagens & Turismo", "Travel", Icons.Rounded.Flight),
        IconItem("fitness_center", "Desporto & Fitness", "Sports & Fitness", Icons.Rounded.FitnessCenter),
        IconItem("label", "Outros", "Other", Icons.AutoMirrored.Rounded.Label)
    )

    val WALLET_ICONS: List<IconItem> = listOf(
        IconItem("account_balance_wallet", "Carteira", "Wallet", Icons.Rounded.AccountBalanceWallet),
        IconItem("account_balance", "Banco", "Bank Account", Icons.Rounded.AccountBalance),
        IconItem("credit_card", "Cartão de Crédito", "Credit Card", Icons.Rounded.CreditCard),
        IconItem("smartphone", "Carteira Móvel (M-Pesa/e-Mola)", "Mobile Wallet", Icons.Rounded.Smartphone),
        IconItem("payments", "Dinheiro Vivo", "Cash", Icons.Rounded.Payments),
        IconItem("savings", "Conta Poupança", "Savings Account", Icons.Rounded.Savings)
    )

    /**
     * Maps raw icon keys, unicode emojis, and category/wallet names to normalized icon keys.
     * Supports intelligent keyword matching for user-created custom categories.
     */
    fun normalizeIconKey(raw: String?): String {
        if (raw.isNullOrBlank()) return "label"
        val trimmed = raw.trim()
        val lower = trimmed.lowercase()

        // 1. Direct key match
        if (ALL_ICONS.containsKey(trimmed)) return trimmed

        // 2. Unicode Emojis
        when {
            trimmed.contains("🍔") || trimmed.contains("🍕") || trimmed.contains("🍲") || trimmed.contains("🥗") -> return "restaurant"
            trimmed.contains("🚗") || trimmed.contains("🚌") || trimmed.contains("🚕") || trimmed.contains("⛽") || trimmed.contains("🚘") -> return "directions_car"
            trimmed.contains("🏠") || trimmed.contains("🏡") -> return "home"
            trimmed.contains("🎬") || trimmed.contains("🎉") || trimmed.contains("🍿") || trimmed.contains("🎮") -> return "movie"
            trimmed.contains("🏥") || trimmed.contains("💊") || trimmed.contains("🩺") -> return "local_hospital"
            trimmed.contains("⚖️") || trimmed.contains("⚙️") -> return "tune"
            trimmed.contains("💵") || trimmed.contains("💸") || trimmed.contains("💶") -> return "payments"
            trimmed.contains("📈") || trimmed.contains("📊") -> return "trending_up"
            trimmed.contains("💎") || trimmed.contains("💰") || trimmed.contains("🪙") -> return "savings"
            trimmed.contains("📚") || trimmed.contains("🎓") -> return "school"
            trimmed.contains("👕") || trimmed.contains("👗") || trimmed.contains("👟") -> return "checkroom"
            trimmed.contains("🏷️") -> return "label"
            trimmed.contains("👛") || trimmed.contains("📦") -> return "account_balance_wallet"
            trimmed.contains("💳") -> return "credit_card"
            trimmed.contains("📱") -> "smartphone"
            trimmed.contains("💡") -> return "lightbulb"
            trimmed.contains("📷") -> return "camera_alt"
            trimmed.contains("🧮") -> return "calculate"
            trimmed.contains("🎯") -> return "track_changes"
            trimmed.contains("🥖") || trimmed.contains("🛒") -> return "shopping_cart"
            trimmed.contains("⚡") -> return "bolt"
            trimmed.contains("✨") -> return "auto_awesome"
            trimmed.contains("☕") -> return "coffee"
            trimmed.contains("🔒") -> return "lock"
            trimmed.contains("🔑") -> return "key"
            trimmed.contains("🔔") -> return "notifications"
            trimmed.contains("⚠️") -> return "warning"
            trimmed.contains("✅") -> return "check_circle"
            trimmed.contains("❌") -> return "error"
            trimmed.contains("🐶") || trimmed.contains("🐱") -> return "pets"
            trimmed.contains("✈️") -> return "flight"
            trimmed.contains("🏋️") -> return "fitness_center"
        }

        // 3. Keyword Auto-Detection for custom categories / fallback strings
        return when {
            lower.contains("restauran") || lower.contains("alimen") || lower.contains("comida") || lower.contains("jantar") || lower.contains("almoço") || lower.contains("lanche") || lower.contains("food") || lower.contains("dining") -> "restaurant"
            lower.contains("carro") || lower.contains("transpor") || lower.contains("combust") || lower.contains("gasolin") || lower.contains("taxi") || lower.contains("uber") || lower.contains("bus") || lower.contains("autocarro") -> "directions_car"
            lower.contains("casa") || lower.contains("habitac") || lower.contains("aluguer") || lower.contains("aluguel") || lower.contains("renda") || lower.contains("housing") || lower.contains("home") -> "home"
            lower.contains("saude") || lower.contains("saúde") || lower.contains("farmac") || lower.contains("medico") || lower.contains("médico") || lower.contains("hospital") || lower.contains("remedio") || lower.contains("health") -> "local_hospital"
            lower.contains("escola") || lower.contains("educa") || lower.contains("curso") || lower.contains("faculdade") || lower.contains("livro") || lower.contains("estudo") || lower.contains("education") -> "school"
            lower.contains("roupa") || lower.contains("vestuar") || lower.contains("vestuár") || lower.contains("moda") || lower.contains("calcado") || lower.contains("calçado") || lower.contains("clothing") -> "checkroom"
            lower.contains("mercad") || lower.contains("compras") || lower.contains("supermercad") || lower.contains("grocer") -> "shopping_cart"
            lower.contains("luz") || lower.contains("electric") || lower.contains("energ") || lower.contains("utilit") -> "lightbulb"
            lower.contains("agua") || lower.contains("água") -> "water_drop"
            lower.contains("internet") || lower.contains("wifi") || lower.contains("net") -> "wifi"
            lower.contains("telefon") || lower.contains("celular") || lower.contains("movel") || lower.contains("móvel") || lower.contains("m-pesa") || lower.contains("emola") || lower.contains("e-mola") -> "smartphone"
            lower.contains("lazer") || lower.contains("cinem") || lower.contains("filme") || lower.contains("festa") || lower.contains("divers") || lower.contains("entertain") -> "movie"
            lower.contains("pet") || lower.contains("animal") || lower.contains("vete") -> "pets"
            lower.contains("viag") || lower.contains("voo") || lower.contains("feria") || lower.contains("férias") || lower.contains("travel") || lower.contains("hotel") -> "flight"
            lower.contains("ginas") || lower.contains("ginás") || lower.contains("fitness") || lower.contains("desport") || lower.contains("esport") || lower.contains("sport") -> "fitness_center"
            lower.contains("present") || lower.contains("ofert") || lower.contains("gift") -> "card_giftcard"
            lower.contains("salari") || lower.contains("salári") || lower.contains("renda") || lower.contains("ordenad") || lower.contains("remunera") || lower.contains("income") || lower.contains("work") -> "payments"
            lower.contains("invest") || lower.contains("poupanc") || lower.contains("poupanç") || lower.contains("acoes") || lower.contains("ações") || lower.contains("saving") -> "savings"
            lower.contains("banc") || lower.contains("bank") -> "account_balance"
            lower.contains("cartao") || lower.contains("cartão") || lower.contains("credit") -> "credit_card"
            lower.contains("carteira") || lower.contains("wallet") -> "account_balance_wallet"
            lower.contains("impost") || lower.contains("taxa") || lower.contains("ajuste") -> "tune"
            else -> "label"
        }
    }

    private fun String?.isNull_or_blank(): Boolean = this == null || this.isBlank()

    fun getIcon(rawKey: String?): ImageVector {
        val key = normalizeIconKey(rawKey)
        return ALL_ICONS[key] ?: DefaultCategoryIcon
    }
}

@Composable
fun AppIcon(
    iconKey: String?,
    contentDescription: String? = null,
    modifier: Modifier = Modifier,
    tint: Color = Color.Unspecified
) {
    val vector = AppIcons.getIcon(iconKey)
    if (tint == Color.Unspecified) {
        Icon(
            imageVector = vector,
            contentDescription = contentDescription,
            modifier = modifier
        )
    } else {
        Icon(
            imageVector = vector,
            contentDescription = contentDescription,
            modifier = modifier,
            tint = tint
        )
    }
}
