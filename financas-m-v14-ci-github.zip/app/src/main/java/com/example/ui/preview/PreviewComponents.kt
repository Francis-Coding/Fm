package com.example.ui.preview

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

/**
 * Visualizador e pré-visualizador nativo de relatórios PDF, CSV e XLSX (Fase 2, Problemas 10, 11 e 12).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportPreviewModal(
    file: File,
    reportName: String,
    format: String, // "PDF", "CSV", "XLSX", "EXCEL"
    idioma: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top App Bar Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (format.uppercase().contains("PDF")) Icons.Rounded.PictureAsPdf else Icons.Rounded.TableChart,
                            contentDescription = null,
                            tint = if (format.uppercase().contains("PDF")) Color(0xFFDC2626) else Color(0xFF059669),
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = reportName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (idioma == "PT") "Pré-visualização Interna ($format)" else "In-App Preview ($format)",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Fechar"
                        )
                    }
                }

                HorizontalDivider()

                // Content View Dispatcher
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFFF3F4F6))
                ) {
                    when {
                        format.uppercase().contains("PDF") -> {
                            PdfPreviewScreen(file = file, idioma = idioma)
                        }
                        format.uppercase().contains("CSV") -> {
                            CsvPreviewGrid(file = file, idioma = idioma)
                        }
                        format.uppercase().contains("XLS") || format.uppercase().contains("EXCEL") -> {
                            XlsxPreviewGrid(file = file, idioma = idioma)
                        }
                        else -> {
                            CsvPreviewGrid(file = file, idioma = idioma)
                        }
                    }
                }

                HorizontalDivider()

                // Bottom Footer Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (idioma == "PT") "Fechar" else "Close")
                    }
                }
            }
        }
    }
}

/**
 * Renderizador Nativo de PDF utilizando Android PdfRenderer em Bitmaps Compose.
 */
@Composable
fun PdfPreviewScreen(
    file: File,
    idioma: String
) {
    var pageBitmaps by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(file) {
        isLoading = true
        errorMessage = null
        withContext(Dispatchers.IO) {
            try {
                if (!file.exists()) {
                    errorMessage = if (idioma == "PT") "Ficheiro PDF não encontrado." else "PDF file not found."
                    return@withContext
                }

                val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                val pageCount = renderer.pageCount
                val bitmaps = mutableListOf<Bitmap>()

                for (i in 0 until pageCount) {
                    val page = renderer.openPage(i)
                    // Scale for crisp display
                    val width = page.width * 2
                    val height = page.height * 2
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmaps.add(bitmap)
                    page.close()
                }

                renderer.close()
                pfd.close()

                pageBitmaps = bitmaps
            } catch (e: Exception) {
                Log.e("PdfPreviewScreen", "Error rendering PDF", e)
                errorMessage = if (idioma == "PT") "Erro ao renderizar PDF: ${e.localizedMessage}" else "Error rendering PDF: ${e.localizedMessage}"
            } finally {
                isLoading = false
            }
        }
    }

    if (isLoading) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CircularProgressIndicator()
                Text(
                    text = if (idioma == "PT") "A carregar documento PDF..." else "Loading PDF document...",
                    fontSize = 13.sp,
                    color = Color.DarkGray
                )
            }
        }
    } else if (errorMessage != null) {
        Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = errorMessage!!,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center
            )
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            // Zoom Controls Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (idioma == "PT") "Páginas: ${pageBitmaps.size}" else "Pages: ${pageBitmaps.size}",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { scale = (scale - 0.25f).coerceAtLeast(0.75f) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom Out", tint = Color.DarkGray)
                    }
                    Text(
                        text = "${(scale * 100).toInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(
                        onClick = { scale = (scale + 0.25f).coerceAtMost(3.0f) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom In", tint = Color.DarkGray)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(0.75f, 3f)
                            offsetX += pan.x
                            offsetY += pan.y
                        }
                    }
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offsetX,
                            translationY = offsetY
                        ),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    itemsIndexed(pageBitmaps) { index, bmp ->
                        Card(
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                            shape = RoundedCornerShape(4.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "PDF Page ${index + 1}",
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    text = "${index + 1} / ${pageBitmaps.size}",
                                    fontSize = 10.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Pré-visualização de arquivos CSV em formato de Tabela com Parser RFC 4180 real.
 */
@Composable
fun CsvPreviewGrid(
    file: File,
    idioma: String
) {
    var rows by remember { mutableStateOf<List<List<String>>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(file) {
        withContext(Dispatchers.IO) {
            try {
                val content = file.readText(Charsets.UTF_8)
                rows = parseCsvRfc4180(content)
            } catch (e: Exception) {
                Log.e("CsvPreviewGrid", "Error reading CSV", e)
            } finally {
                isLoading = false
            }
        }
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else if (rows.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(if (idioma == "PT") "Ficheiro CSV vazio ou inválido." else "Empty or invalid CSV file.")
        }
    } else {
        SpreadsheetTableView(rows = rows)
    }
}

/**
 * Pré-visualização de arquivos XLSX em formato de Tabela.
 */
@Composable
fun XlsxPreviewGrid(
    file: File,
    idioma: String
) {
    var rows by remember { mutableStateOf<List<List<String>>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(file) {
        withContext(Dispatchers.IO) {
            try {
                rows = parseXlsxRows(file)
            } catch (e: Exception) {
                Log.e("XlsxPreviewGrid", "Error reading XLSX", e)
            } finally {
                isLoading = false
            }
        }
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else if (rows.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(if (idioma == "PT") "Ficheiro Excel (.xlsx) sem dados visualizáveis." else "Excel file (.xlsx) has no readable sheet data.")
        }
    } else {
        SpreadsheetTableView(rows = rows)
    }
}

/**
 * Componente Genérico de Tabela/Spreadsheet com rolagem horizontal e vertical e cabeçalho fixo.
 */
@Composable
fun SpreadsheetTableView(rows: List<List<String>>) {
    val header = rows.firstOrNull() ?: emptyList()
    val dataRows = rows.drop(1)
    val horizontalScrollState = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(horizontalScrollState)
        ) {
            LazyColumn(modifier = Modifier.fillMaxHeight()) {
                // Header Row
                item {
                    Row(
                        modifier = Modifier
                            .background(Color(0xFF1A73E8))
                            .padding(vertical = 4.dp)
                    ) {
                        header.forEachIndexed { colIdx, colName ->
                            Box(
                                modifier = Modifier
                                    .width(130.dp)
                                    .border(0.5.dp, Color.White.copy(alpha = 0.3f))
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = colName,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                // Data Rows
                itemsIndexed(dataRows) { rowIndex, rowData ->
                    val bgColor = if (rowIndex % 2 == 0) Color.White else Color(0xFFF8FAFC)
                    Row(
                        modifier = Modifier
                            .background(bgColor)
                            .padding(vertical = 2.dp)
                    ) {
                        header.indices.forEach { colIdx ->
                            val cellText = rowData.getOrNull(colIdx) ?: ""
                            Box(
                                modifier = Modifier
                                    .width(130.dp)
                                    .border(0.5.dp, Color(0xFFE2E8F0))
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = cellText,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF1E293B),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Parser RFC 4180 para campos CSV com aspas e quebras de linha.
 */
private fun parseCsvRfc4180(csvText: String): List<List<String>> {
    val rows = mutableListOf<List<String>>()
    var currentRow = mutableListOf<String>()
    var currentCell = StringBuilder()
    var inQuotes = false

    var i = 0
    while (i < csvText.length) {
        val c = csvText[i]
        val nextC = if (i + 1 < csvText.length) csvText[i + 1] else ' '

        if (inQuotes) {
            if (c == '"') {
                if (nextC == '"') {
                    currentCell.append('"')
                    i++ // skip double quote
                } else {
                    inQuotes = false
                }
            } else {
                currentCell.append(c)
            }
        } else {
            when (c) {
                '"' -> inQuotes = true
                ',' -> {
                    currentRow.add(currentCell.toString())
                    currentCell = StringBuilder()
                }
                '\r' -> {
                    if (nextC == '\n') i++
                    currentRow.add(currentCell.toString())
                    rows.add(currentRow)
                    currentRow = mutableListOf()
                    currentCell = StringBuilder()
                }
                '\n' -> {
                    currentRow.add(currentCell.toString())
                    rows.add(currentRow)
                    currentRow = mutableListOf()
                    currentCell = StringBuilder()
                }
                else -> currentCell.append(c)
            }
        }
        i++
    }

    if (currentCell.isNotEmpty() || currentRow.isNotEmpty()) {
        currentRow.add(currentCell.toString())
        rows.add(currentRow)
    }

    return rows
}

/**
 * Extração simples de dados de linhas XML do ficheiro XLSX.
 */
private fun parseXlsxRows(file: File): List<List<String>> {
    val rows = mutableListOf<List<String>>()
    try {
        ZipFile(file).use { zip ->
            val entry = zip.getEntry("xl/worksheets/sheet1.xml") ?: return emptyList()
            zip.getInputStream(entry).bufferedReader().use { reader ->
                val xml = reader.readText()
                val rowRegex = Regex("""<row[^>]*>(.*?)</row>""", RegexOption.DOT_MATCHES_ALL)
                val textValueRegex = Regex("""<t[^>]*>(.*?)</t>""")
                val valValueRegex = Regex("""<v[^>]*>(.*?)</v>""")

                for (rowMatch in rowRegex.findAll(xml)) {
                    val rowXml = rowMatch.groupValues[1]
                    val cellRegex = Regex("""<c[^>]*>(.*?)</c>""", RegexOption.DOT_MATCHES_ALL)
                    val cells = mutableListOf<String>()

                    for (cellMatch in cellRegex.findAll(rowXml)) {
                        val cellXml = cellMatch.groupValues[1]
                        val tMatch = textValueRegex.find(cellXml)
                        if (tMatch != null) {
                            cells.add(tMatch.groupValues[1])
                        } else {
                            val vMatch = valValueRegex.find(cellXml)
                            cells.add(vMatch?.groupValues[1] ?: "")
                        }
                    }
                    if (cells.isNotEmpty()) {
                        rows.add(cells)
                    }
                }
            }
        }
    } catch (e: Exception) {
        Log.e("XlsxPreviewGrid", "Failed to parse XLSX zip", e)
    }
    return rows
}
