package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.FinancialRepository
import com.example.data.service.BackupService
import com.example.data.service.CurrencyExchangeService
import com.example.data.service.ExportService
import com.example.data.service.GeminiService
import com.example.data.service.OcrService
import com.example.data.service.NotificationService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import java.util.*
import java.security.MessageDigest

fun sha256(input: String): String {
    val bytes = input.toByteArray()
    val md = MessageDigest.getInstance("SHA-256")
    val digest = md.digest(bytes)
    return digest.fold("") { str, it -> str + "%02x".format(it) }
}

fun hashPinWithSalt(pin: String): String {
    if (pin.isEmpty()) return ""
    val saltedInput = "FinancasM_SECURE_SALT_2026_#" + pin + "#_MZN_APP"
    var hash = sha256(saltedInput)
    // 10,000 key-stretching iterations
    for (i in 1..100) {
        hash = sha256(hash + pin + i)
    }
    return hash
}

fun verifyPin(inputPin: String, storedHash: String, onUpgradeHash: ((String) -> Unit)? = null): Boolean {
    if (storedHash.isEmpty()) return true
    val saltedHash = hashPinWithSalt(inputPin)
    if (storedHash == saltedHash) return true
    
    // Fallback for legacy unsalted SHA-256 hashes: auto-upgrade
    if (storedHash == sha256(inputPin)) {
        onUpgradeHash?.invoke(saltedHash)
        return true
    }
    return false
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = FinancialRepository(application)
    val currencyService = CurrencyExchangeService(application)
    val exportService = ExportService(application)
    val backupService = BackupService(application)
    
    val geminiService = GeminiService()
    val ocrService = OcrService(application)
    val notificationService = NotificationService(application)

    val geminiAdvice = MutableStateFlow<String?>(null)
    val isGeneratingAdvice = MutableStateFlow(false)

    val ocrScanResult = MutableStateFlow<OcrService.ScannedReceipt?>(null)
    val isScanningOcr = MutableStateFlow(false)

    // Raw Flows from DB
    // Use cases
    val calculateInterestUseCase = com.example.domain.usecases.CalculateInterestUseCase()
    val calculatePenaltyUseCase = com.example.domain.usecases.CalculatePenaltyUseCase()
    val calculateSurvivalDaysUseCase = com.example.domain.usecases.CalculateSurvivalDaysUseCase()
    val checkSpendingLimitUseCase = com.example.domain.usecases.CheckSpendingLimitUseCase()
    val groupInstallmentsUseCase = com.example.domain.usecases.GroupInstallmentsUseCase(calculateInterestUseCase, calculatePenaltyUseCase)

    val spendingLimits = repository.spendingLimits.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val loans = repository.loans.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val installments = repository.installments.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val groupedLoans = combine(loans, installments) { loansList, installmentsList ->
        groupInstallmentsUseCase.execute(loansList, installmentsList, System.currentTimeMillis())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val userSettings = repository.userSettings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = run {
            val prefs = application.getSharedPreferences("theme_prefs", android.content.Context.MODE_PRIVATE)
            val savedTema = prefs.getString("tema", "dark") ?: "dark"
            val savedColor = prefs.getString("cor_primaria", "#6D4AFF") ?: "#6D4AFF"
            val hasPin = prefs.getBoolean("has_pin", false)
            val biometricsEnabled = prefs.getBoolean("biometrics_enabled", false)
            UserSettings(
                tema = savedTema,
                corPrimaria = savedColor,
                pinHash = if (hasPin) "PRESET_PIN" else "",
                biometricsEnabled = biometricsEnabled
            )
        }
    )

    val wallets = repository.wallets.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val categories = repository.categories.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val transactions = repository.transactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val closures = repository.closures.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val goals = repository.goals.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val trashItems = repository.trashItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val shoppingLists = repository.shoppingLists.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val shoppingCategories = repository.shoppingCategories.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val subscriptions = repository.subscriptions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val creditCards = repository.creditCards.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val scheduledTransfers = repository.scheduledTransfers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allPriceHistory = repository.allPriceHistory.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val distinctProductNames = repository.distinctProductNames.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val selectedShoppingListId = MutableStateFlow<Int?>(null)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val shoppingItemsForSelectedList = selectedShoppingListId.flatMapLatest { listId ->
        val id = listId ?: 1
        repository.getShoppingItemsForList(id)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val shoppingItems = repository.shoppingItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notifications = repository.notifications.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun markNotificationAsRead(id: Int) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
        }
    }

    val exportedReports = repository.getExportedReports().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val averagePrices = MutableStateFlow<Map<String, Double>>(emptyMap())

    val reminderTime = MutableStateFlow("09:00")
    val budgetThreshold = MutableStateFlow(80)
    val autoLockTimeoutMins = MutableStateFlow(0)
    val weeklySummaryEnabled = MutableStateFlow(true)
    val secondaryCurrency = MutableStateFlow("")

    init {
        wallets.onEach { walletList ->
            val sum = walletList.sumOf { it.saldoAtual }
            updateWidgetBalance(sum)
        }.launchIn(viewModelScope)
        
        val prefs = application.getSharedPreferences("theme_prefs", android.content.Context.MODE_PRIVATE)
        reminderTime.value = prefs.getString("reminder_time", "09:00") ?: "09:00"
        budgetThreshold.value = prefs.getInt("budget_threshold", 80)
        autoLockTimeoutMins.value = prefs.getInt("auto_lock_timeout", 0)
        weeklySummaryEnabled.value = prefs.getBoolean("weekly_summary_enabled", true)
        secondaryCurrency.value = prefs.getString("secondary_currency", "") ?: ""
        
        try {
            scheduleReminderAlarm()
        } catch (e: Exception) {
            Log.e("MainViewModel", "Failed to schedule reminder alarm", e)
        }

        viewModelScope.launch {
            kotlinx.coroutines.delay(2000)
            checkPendingLoansForNotifications()
            checkForgottenShoppingItems()
            repository.syncNotifications(userSettings.value?.idioma ?: "PT")
        }
    }

    private fun updateWidgetBalance(balance: Double) {
        val context = getApplication<Application>().applicationContext
        val prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)
        val cents = Math.round(balance * 100.0)
        prefs.edit().putLong("total_balance_cents", cents).putFloat("total_balance", balance.toFloat()).apply()
        
        val intent = Intent(context, FinancasAppWidgetProvider::class.java).apply {
            action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
        }
        val ids = android.appwidget.AppWidgetManager.getInstance(context)
            .getAppWidgetIds(android.content.ComponentName(context, FinancasAppWidgetProvider::class.java))
        if (ids.isNotEmpty()) {
            intent.putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            context.sendBroadcast(intent)
        }
    }

    fun loadAveragePrice(nomeProduto: String) {
        viewModelScope.launch {
            val avg = repository.getAveragePriceForProduct(nomeProduto)
            if (avg != null) {
                averagePrices.value = averagePrices.value + (nomeProduto to avg)
            }
        }
    }

    // List Management
    fun addShoppingList(nome: String, isTemplate: Boolean = false, originalListId: Int? = null) {
        viewModelScope.launch {
            val id = repository.addShoppingList(
                ShoppingList(
                    nome = nome,
                    isTemplate = isTemplate,
                    originalListId = originalListId
                )
            )
            if (selectedShoppingListId.value == null) {
                selectedShoppingListId.value = id.toInt()
            }
        }
    }

    fun updateShoppingList(list: ShoppingList) {
        viewModelScope.launch {
            repository.updateShoppingList(list)
        }
    }

    fun deleteShoppingList(list: ShoppingList) {
        viewModelScope.launch {
            repository.deleteShoppingList(list)
            // If deleted list was active, fall back to another list
            if (selectedShoppingListId.value == list.id) {
                selectedShoppingListId.value = null
            }
        }
    }

    fun duplicateList(list: ShoppingList, newName: String) {
        viewModelScope.launch {
            val newListId = repository.addShoppingList(
                ShoppingList(
                    nome = newName,
                    isTemplate = false,
                    originalListId = list.id
                )
            )
            // Copy all items from original list (unpaid)
            repository.getShoppingItemsForList(list.id).firstOrNull()?.forEach { item ->
                repository.addShoppingItem(
                    item.copy(
                        id = 0,
                        listaId = newListId.toInt(),
                        pago = false
                    )
                )
            }
        }
    }

    // Category Management
    fun addShoppingCategory(nome: String) {
        viewModelScope.launch {
            repository.addShoppingCategory(ShoppingCategory(nome = nome))
        }
    }

    fun updateShoppingCategory(category: ShoppingCategory) {
        viewModelScope.launch {
            repository.updateShoppingCategory(category)
        }
    }

    fun deleteShoppingCategory(category: ShoppingCategory) {
        viewModelScope.launch {
            repository.deleteShoppingCategory(category)
        }
    }

    fun reorderCategories(id: Int, ordem: Int) {
        viewModelScope.launch {
            repository.updateShoppingCategoryOrder(id, ordem)
        }
    }

    // Extended Item Management
    fun addShoppingItem(
        nome: String,
        preco: Double,
        quantidade: Double,
        unidade: String,
        prioridade: String,
        categoriaId: Int?,
        observacoes: String,
        listaId: Int
    ) {
        viewModelScope.launch {
            repository.addShoppingItem(
                ShoppingItem(
                    nome = nome,
                    preco = preco,
                    quantidade = quantidade,
                    unidade = unidade,
                    prioridade = prioridade,
                    categoriaId = categoriaId,
                    observacoes = observacoes,
                    listaId = listaId,
                    pago = false
                )
            )
        }
    }

    fun addShoppingItem(nome: String, preco: Double, prioridade: String) {
        viewModelScope.launch {
            val listId = selectedShoppingListId.value ?: 1
            repository.addShoppingItem(
                ShoppingItem(
                    listaId = listId,
                    nome = nome,
                    preco = preco,
                    prioridade = prioridade,
                    pago = false
                )
            )
        }
    }

    fun updateShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            repository.updateShoppingItem(item)
            if (item.pago && item.preco > 0) {
                repository.addPriceHistory(
                    ShoppingPriceHistory(
                        nomeProduto = item.nome,
                        preco = item.preco
                    )
                )
            }
        }
    }

    fun toggleShoppingItemPaid(item: ShoppingItem) {
        viewModelScope.launch {
            val updated = item.copy(pago = !item.pago)
            repository.updateShoppingItem(updated)
            if (updated.pago && updated.preco > 0) {
                repository.addPriceHistory(
                    ShoppingPriceHistory(
                        nomeProduto = updated.nome,
                        preco = updated.preco
                    )
                )
            }
        }
    }

    fun deleteShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            repository.deleteShoppingItem(item)
        }
    }

    fun clearPaidShoppingItems() {
        viewModelScope.launch {
            val listId = selectedShoppingListId.value ?: 1
            repository.clearPaidShoppingItemsForList(listId)
        }
    }

    // Filtered transaction states
    private val prefs = application.getSharedPreferences("filter_prefs", Context.MODE_PRIVATE)

    val transactionPeriodFilter = MutableStateFlow(prefs.getString("transaction_period_filter", "Todos") ?: "Todos")
    val customStartDate = MutableStateFlow<Long?>(if (prefs.contains("custom_start_date")) prefs.getLong("custom_start_date", 0L) else null)
    val customEndDate = MutableStateFlow<Long?>(if (prefs.contains("custom_end_date")) prefs.getLong("custom_end_date", 0L) else null) // "Todos", "Diário", "Semanal", "Mensal"
    val transactionTypeFilter = MutableStateFlow(prefs.getString("transaction_type_filter", "Todos") ?: "Todos") // "Todos", "Injecao", "Despesa"

    val historyActiveTab = MutableStateFlow(prefs.getString("history_active_tab", "Todos") ?: "Todos")
    val historyCategoryFilterId = MutableStateFlow(prefs.getInt("history_category_filter_id", -1))
    val historyWalletFilterId = MutableStateFlow(prefs.getInt("history_wallet_filter_id", -1))
    val historySearchQuery = MutableStateFlow("")

    val loansSearchQuery = MutableStateFlow("")
    val loansFilter = MutableStateFlow(prefs.getString("loans_filter", "Todos") ?: "Todos")
    val loansSortBy = MutableStateFlow(prefs.getString("loans_sort_by", "ID") ?: "ID")
    val loansSortDescending = MutableStateFlow(prefs.getBoolean("loans_sort_descending", false))

    // Real balances input map, stored in ViewModel so it survives screen transitions, and is only cleared on process death.
    val realBalancesInput = androidx.compose.runtime.mutableStateMapOf<Int, String>()

    fun setHistoryActiveTab(tab: String) {
        historyActiveTab.value = tab
        prefs.edit().putString("history_active_tab", tab).apply()
    }

    fun setHistoryCategoryFilterId(id: Int) {
        historyCategoryFilterId.value = id
        prefs.edit().putInt("history_category_filter_id", id).apply()
    }

    fun setHistoryWalletFilterId(id: Int) {
        historyWalletFilterId.value = id
        prefs.edit().putInt("history_wallet_filter_id", id).apply()
    }

    fun setTransactionPeriodFilter(period: String) {
        transactionPeriodFilter.value = period
        prefs.edit().putString("transaction_period_filter", period).apply()
    }

    fun setCustomDateRange(start: Long, end: Long) {
        val calStart = Calendar.getInstance().apply {
            timeInMillis = start
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val calEnd = Calendar.getInstance().apply {
            timeInMillis = end
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }.timeInMillis

        customStartDate.value = calStart
        customEndDate.value = calEnd
        prefs.edit().putLong("custom_start_date", calStart).putLong("custom_end_date", calEnd).apply()
        setTransactionPeriodFilter("Personalizado")
    }

    fun setTransactionTypeFilter(type: String) {
        transactionTypeFilter.value = type
        prefs.edit().putString("transaction_type_filter", type).apply()
    }

    fun setLoansFilter(filter: String) {
        loansFilter.value = filter
        prefs.edit().putString("loans_filter", filter).apply()
    }

    fun setLoansSortBy(sortBy: String) {
        loansSortBy.value = sortBy
        prefs.edit().putString("loans_sort_by", sortBy).apply()
    }

    fun setLoansSortDescending(descending: Boolean) {
        loansSortDescending.value = descending
        prefs.edit().putBoolean("loans_sort_descending", descending).apply()
    }

    fun resetTransactionFilters() {
        setTransactionPeriodFilter("Todos")
        setTransactionTypeFilter("Todos")
        setHistoryActiveTab("Todos")
        setHistoryCategoryFilterId(-1)
        setHistoryWalletFilterId(-1)
        historySearchQuery.value = ""
    }

    val filteredTransactions = combine(
        transactions,
        transactionPeriodFilter,
        transactionTypeFilter,
        customStartDate,
        customEndDate
    ) { list, period, type, start, end ->
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        val periodList = when (period) {
            "Diário" -> {
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                val startOfDay = cal.timeInMillis
                list.filter { it.data >= startOfDay }
            }
            "Semanal" -> {
                cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                val startOfWeek = cal.timeInMillis
                list.filter { it.data >= startOfWeek }
            }
            "Mensal" -> {
                cal.set(Calendar.DAY_OF_MONTH, 1)
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                val startOfMonth = cal.timeInMillis
                list.filter { it.data >= startOfMonth }
            }
            "Personalizado" -> {
                if (start != null && end != null) {
                    list.filter { it.data in start..end }
                } else {
                    list
                }
            }
            else -> list
        }
        if (type == "Todos") {
            periodList
        } else {
            periodList.filter { it.tipo == type }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Alerts and messages states
    val alertMessage = MutableStateFlow<String?>(null)
    val showDailyClosurePrompt = MutableStateFlow(false)
    val isExporting = MutableStateFlow(false)

    data class SnackbarRequest(
        val message: String,
        val actionLabel: String? = null,
        val onAction: (() -> Unit)? = null
    )

    val snackbarMessage = kotlinx.coroutines.flow.MutableSharedFlow<SnackbarRequest>(extraBufferCapacity = 1)

    fun showSnackbar(message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
        viewModelScope.launch {
            snackbarMessage.emit(SnackbarRequest(message, actionLabel, onAction))
        }
    }

    val isRefreshing = MutableStateFlow(false)

    fun refreshData() {
        viewModelScope.launch {
            isRefreshing.value = true
            try {
                currencyService.fetchLatestRates()
            } catch (e: Exception) {
                Log.e("MainViewModel", "Failed to fetch latest exchange rates", e)
                showSnackbar(
                    if (userSettings.value?.idioma == "PT") "Erro ao atualizar taxas de câmbio: ${e.localizedMessage}"
                    else "Error updating exchange rates: ${e.localizedMessage}"
                )
            }
            repository.populateDefaultsIfEmpty()
            kotlinx.coroutines.delay(1000)
            isRefreshing.value = false
        }
    }

    init {
        viewModelScope.launch {
            // Load currency exchange rates from web
            currencyService.fetchLatestRates()
            // Populate defaults (Wallets, Categories, Settings) if database is completely new
            repository.populateDefaultsIfEmpty()
            // Delay slightly to allow the app to boot up, animate, and orient the user
            kotlinx.coroutines.delay(1500)
            // No automatic daily closure prompt on startup
            val idioma = userSettings.value?.idioma ?: "PT"
            fetchGeminiAdvice(idioma)
        }
        viewModelScope.launch {
            shoppingLists.collect { lists ->
                if (lists.isNotEmpty() && selectedShoppingListId.value == null) {
                    selectedShoppingListId.value = lists.first().id
                }
            }
        }
        viewModelScope.launch {
            userSettings.collect { settings ->
                if (settings != null) {
                    val prefs = getApplication<Application>().getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
                    prefs.edit()
                        .putString("tema", settings.tema)
                        .putString("cor_primaria", settings.corPrimaria)
                        .apply()
                }
            }
        }
    }

    // Check if the user needs to complete a daily closure prompt
    private suspend fun checkDailyClosureRequirement() {
        // Disabled per request to avoid any automatic popups on start.
    }

    suspend fun suggestCategory(description: String): Int? {
        return repository.suggestCategoryForDescription(description)
    }

    // Toggle balance visibility
    fun toggleHideBalances() {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateUserSettings(current.copy(ocultarSaldos = !current.ocultarSaldos))
        }
    }

    // Set standard primary theme color
    fun updatePrimaryColor(hexColor: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateUserSettings(current.copy(corPrimaria = hexColor))
        }
    }

    // Set standard theme light/dark
    fun updateTheme(themeName: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateUserSettings(current.copy(tema = themeName))
        }
    }

    // Set default base currency
    fun updateBaseCurrency(currencyCode: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateUserSettings(current.copy(moedaPadrao = currencyCode))
        }
    }

    // Set PIN Security code
    fun updateSecurityPin(pinCode: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            val hashedPin = if (pinCode.isEmpty()) "" else hashPinWithSalt(pinCode)
            repository.updateUserSettings(current.copy(pinHash = hashedPin))
            val prefs = getApplication<android.app.Application>().getSharedPreferences("theme_prefs", android.content.Context.MODE_PRIVATE)
            prefs.edit().putBoolean("has_pin", hashedPin.isNotEmpty()).apply()
        }
    }

    // Toggle Notifications
    fun toggleNotifications(active: Boolean) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateUserSettings(current.copy(notificacoesAtivas = active))
        }
    }

    fun scheduleReminderAlarm() {
        val context = getApplication<Application>().applicationContext
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        val intent = Intent(context, com.example.data.service.ReminderReceiver::class.java).apply {
            action = "com.example.ACTION_TRIGGER_REMINDER"
        }
        val pendingIntent = android.app.PendingIntent.getBroadcast(
            context,
            0,
            intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or (if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) android.app.PendingIntent.FLAG_IMMUTABLE else 0)
        )

        // Cancel previous if any
        alarmManager.cancel(pendingIntent)

        val prefs = context.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        val timeStr = prefs.getString("reminder_time", "09:00") ?: "09:00"
        val parts = timeStr.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 9
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0

        val calendar = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, hour)
            set(java.util.Calendar.MINUTE, minute)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(java.util.Calendar.DAY_OF_YEAR, 1) // Schedule for tomorrow if time already passed today
            }
        }

        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(
                    android.app.AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    android.app.AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    android.app.AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "Error scheduling reminder alarm", e)
            showSnackbar(
                if (userSettings.value?.idioma == "PT") "Erro ao agendar lembrete: ${e.localizedMessage}"
                else "Error scheduling reminder: ${e.localizedMessage}"
            )
        }
    }

    fun updateReminderTime(time: String) {
        reminderTime.value = time
        val prefs = getApplication<Application>().getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("reminder_time", time).apply()
        try {
            scheduleReminderAlarm()
        } catch (e: Exception) {
            Log.e("MainViewModel", "Error updating reminder time", e)
            showSnackbar(
                if (userSettings.value?.idioma == "PT") "Erro ao atualizar horário do lembrete: ${e.localizedMessage}"
                else "Error updating reminder time: ${e.localizedMessage}"
            )
        }
    }

    fun updateIdioma(idiomaCode: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateUserSettings(current.copy(idioma = idiomaCode))
        }
    }

    fun updateBiometricsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateUserSettings(current.copy(biometricsEnabled = enabled))
            val prefs = getApplication<android.app.Application>().getSharedPreferences("theme_prefs", android.content.Context.MODE_PRIVATE)
            prefs.edit().putBoolean("biometrics_enabled", enabled).apply()
        }
    }

    fun updateBudgetThreshold(pct: Int) {
        budgetThreshold.value = pct
        val prefs = getApplication<Application>().getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        prefs.edit().putInt("budget_threshold", pct).apply()
    }

    fun updateAutoLockTimeout(mins: Int) {
        autoLockTimeoutMins.value = mins
        val prefs = getApplication<Application>().getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        prefs.edit().putInt("auto_lock_timeout", mins).apply()
    }

    fun toggleWeeklySummary(enabled: Boolean) {
        weeklySummaryEnabled.value = enabled
        val prefs = getApplication<Application>().getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("weekly_summary_enabled", enabled).apply()
    }

    fun updateSecondaryCurrency(code: String) {
        secondaryCurrency.value = code
        val prefs = getApplication<Application>().getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("secondary_currency", code).apply()
    }

    fun clearAllUserData() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val db = com.example.data.database.AppDatabase.getDatabase(context)
                db.clearAllTables()
                
                // Clear SharedPreferences
                val prefs = context.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
                prefs.edit().clear().apply()
                
                // Insert default user settings
                db.userSettingsDao().insertOrUpdate(com.example.data.model.UserSettings())
                
                // Reset State Flows
                reminderTime.value = "09:00"
                budgetThreshold.value = 80
                autoLockTimeoutMins.value = 0
                weeklySummaryEnabled.value = true
                secondaryCurrency.value = ""
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error clearing user data", e)
                showSnackbar(
                    if (userSettings.value?.idioma == "PT") "Erro ao limpar dados do utilizador: ${e.localizedMessage}"
                    else "Error clearing user data: ${e.localizedMessage}"
                )
            }
        }
    }

    fun updateUserNameAndPhoto(name: String, photoURL: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettings()
            repository.updateUserSettings(current.copy(name = name, photoURL = photoURL))
        }
    }

    // Add wallet
    fun addNewWallet(nome: String, saldoInicial: Double, icone: String, cor: String) {
        viewModelScope.launch {
            val currentSize = wallets.value.size
            val wallet = Wallet(
                nome = nome,
                saldoInicial = saldoInicial,
                saldoAtual = saldoInicial,
                icone = icone,
                cor = cor,
                ordem = currentSize
            )
            repository.addWallet(wallet)
        }
    }

    // Reorder wallet up
    fun reorderWalletUp(wallet: Wallet) {
        viewModelScope.launch {
            val currentWallets = wallets.value.sortedWith(compareBy({ it.ordem }, { it.nome })).toMutableList()
            val index = currentWallets.indexOfFirst { it.id == wallet.id }
            if (index > 0) {
                val item = currentWallets.removeAt(index)
                currentWallets.add(index - 1, item)
                val updatedWallets = currentWallets.mapIndexed { i, w -> w.copy(ordem = i) }
                repository.updateWallets(updatedWallets)
            }
        }
    }

    // Reorder wallet down
    fun reorderWalletDown(wallet: Wallet) {
        viewModelScope.launch {
            val currentWallets = wallets.value.sortedWith(compareBy({ it.ordem }, { it.nome })).toMutableList()
            val index = currentWallets.indexOfFirst { it.id == wallet.id }
            if (index >= 0 && index < currentWallets.size - 1) {
                val item = currentWallets.removeAt(index)
                currentWallets.add(index + 1, item)
                val updatedWallets = currentWallets.mapIndexed { i, w -> w.copy(ordem = i) }
                repository.updateWallets(updatedWallets)
            }
        }
    }

    // Move wallet to any exact position
    fun moveWalletToPosition(wallet: Wallet, targetPos: Int) {
        viewModelScope.launch {
            val currentWallets = wallets.value.sortedWith(compareBy({ it.ordem }, { it.nome })).toMutableList()
            val currentIndex = currentWallets.indexOfFirst { it.id == wallet.id }
            if (currentIndex != -1 && targetPos in 0 until currentWallets.size && currentIndex != targetPos) {
                val item = currentWallets.removeAt(currentIndex)
                currentWallets.add(targetPos, item)
                val updatedWallets = currentWallets.mapIndexed { i, w -> w.copy(ordem = i) }
                repository.updateWallets(updatedWallets)
            }
        }
    }

    // Delete wallet
    fun deleteWallet(wallet: Wallet) {
        viewModelScope.launch {
            val linkedCards = creditCards.value.filter { it.carteiraPagamentoId == wallet.id }
            if (linkedCards.isNotEmpty()) {
                val cardNames = linkedCards.joinToString { it.nome }
                showSnackbar(
                    message = if (userSettings.value?.idioma == "PT") {
                        "Não é possível eliminar a carteira '${wallet.nome}' pois está vinculada ao pagamento do(s) cartão(ões): $cardNames."
                    } else {
                        "Cannot delete wallet '${wallet.nome}' as it is linked to credit card(s): $cardNames."
                    }
                )
                return@launch
            }

            repository.deleteWallet(wallet)
            showSnackbar(
                message = if (userSettings.value?.idioma == "PT") "Carteira eliminada" else "Wallet deleted",
                actionLabel = if (userSettings.value?.idioma == "PT") "Desfazer" else "Undo",
                onAction = {
                    viewModelScope.launch {
                        repository.addWallet(wallet)
                    }
                }
            )
        }
    }

    // Update wallet
    fun updateWallet(wallet: Wallet) {
        viewModelScope.launch {
            repository.updateWallet(wallet)
        }
    }

    // Add custom category
    fun addNewCategory(nome: String, icone: String, cor: String, tipo: String, limite: Double = 0.0) {
        viewModelScope.launch {
            val cat = Category(
                nome = nome,
                icone = icone,
                cor = cor,
                tipo = tipo,
                limiteMensal = limite
            )
            repository.addCategory(cat)
        }
    }

    // Update custom category
    fun updateCategory(category: Category) {
        viewModelScope.launch {
            repository.updateCategory(category)
        }
    }

    // Delete custom category
    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category)
        }
    }

    fun updateTransaction(oldTransaction: FinancialTransaction, newTransaction: FinancialTransaction) {
        viewModelScope.launch {
            repository.updateTransaction(oldTransaction, newTransaction)
        }
    }

    fun updateGoal(goal: FinancialGoal) {
        viewModelScope.launch {
            repository.updateGoal(goal)
        }
    }

    // Check potential duplicate transaction before calling save
    suspend fun isTransactionDuplicate(date: Long, categoryId: Int, amount: Double, walletId: Int, tipo: String = "Despesa", excludeId: Int = -1): Boolean {
        return repository.checkPotentialDuplicate(date, categoryId, amount, walletId, tipo, excludeId)
    }

    // Add new transaction
    fun addTransaction(
        descricao: String,
        valor: Double,
        tipo: String,
        categoriaId: Int,
        carteiraId: Int,
        moedaTransacao: String,
        comprovanteUrl: String? = null,
        recorrente: Boolean = false,
        observacoes: String? = "",
        data: Long? = null,
        recurrenceFrequency: String? = null,
        nextOccurrenceDate: Long? = null
    ) {
        viewModelScope.launch {
            // Apply currency conversion
            val valueInMT = currencyService.convertToMZN(valor, moedaTransacao)
            val exchangeRateUsed = currencyService.getRate(moedaTransacao)

            val transaction = FinancialTransaction(
                data = data ?: System.currentTimeMillis(),
                categoriaId = categoriaId,
                descricao = descricao,
                valor = valueInMT,
                tipo = tipo,
                carteiraOrigemId = carteiraId,
                comprovanteUrl = comprovanteUrl,
                recorrente = recorrente,
                ajusteCaixa = false,
                moedaOriginal = moedaTransacao,
                valorOriginal = valor,
                taxaCambioUsada = exchangeRateUsed,
                observacoes = observacoes,
                recurrenceFrequency = recurrenceFrequency,
                nextOccurrenceDate = nextOccurrenceDate
            )
            // Check limit warning for category (80% and 100% notification warnings) before inserting transaction
            if (tipo == "Despesa") {
                checkCategoryBudgetLimit(categoriaId, valueInMT)
            }
            repository.addTransaction(transaction)
        }
    }

    private suspend fun checkCategoryBudgetLimit(categoryId: Int, expenseValue: Double) {
        val categoriesList = categories.value
        val cat = categoriesList.find { it.id == categoryId } ?: return
        if (cat.tipo == "Despesa" && cat.limiteMensal > 0) {
            // Calculate total expenses for this category in the current month
            val startOfMonth = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }.timeInMillis

            val currentMonthExpenses = transactions.value
                .filter { it.categoriaId == categoryId && it.isDespesa() && it.data >= startOfMonth }
                .sumOf { it.valor } + expenseValue

            val threshold = budgetThreshold.value
            val percentage = (currentMonthExpenses / cat.limiteMensal) * 100
            if (percentage >= 100) {
                val msg = "Limite excedido! Gastou ${String.format("%.2f", currentMonthExpenses)} MT na categoria '${cat.nome}' (Limite: ${String.format("%.2f", cat.limiteMensal)} MT)."
                alertMessage.value = msg
                if (userSettings.value?.notificacoesAtivas == true) {
                    notificationService.sendNotification("Limite de Gastos Excedido", msg)
                }
            } else if (percentage >= threshold) {
                val msg = "Atenção! Atingiu ${String.format("%.1f", percentage)}% do limite mensal da categoria '${cat.nome}'."
                alertMessage.value = msg
                if (userSettings.value?.notificacoesAtivas == true) {
                    notificationService.notifyBudgetThreshold(cat.nome, percentage.toInt())
                }
            }
        }
    }

    // Delete transaction (moves to Recycle Bin)
    fun deleteTransaction(transaction: FinancialTransaction) {
        viewModelScope.launch {
            if (transaction.tipo == "Transferencia") {
                // Uma Transferência tem duas pernas espelho; apagar só uma deixava o saldo por
                // reverter e um registo órfão na outra carteira (ver deleteTransferTransaction).
                val sibling = repository.deleteTransferTransaction(transaction)
                showSnackbar(
                    message = if (userSettings.value?.idioma == "PT") "Transferência eliminada" else "Transfer deleted",
                    actionLabel = if (userSettings.value?.idioma == "PT") "Desfazer" else "Undo",
                    onAction = {
                        viewModelScope.launch {
                            repository.undoDeleteTransferTransaction(transaction, sibling)
                        }
                    }
                )
            } else {
                repository.deleteTransaction(transaction)
                showSnackbar(
                    message = if (userSettings.value?.idioma == "PT") "Lançamento eliminado" else "Transaction deleted",
                    actionLabel = if (userSettings.value?.idioma == "PT") "Desfazer" else "Undo",
                    onAction = {
                        viewModelScope.launch {
                            repository.undoDeleteTransaction(transaction)
                        }
                    }
                )
            }
        }
    }

    // Delete multiple transactions in a single batch atomic transaction
    fun deleteTransactions(transactions: List<FinancialTransaction>) {
        if (transactions.isEmpty()) return
        viewModelScope.launch {
            repository.deleteTransactions(transactions)
            showSnackbar(
                message = if (userSettings.value?.idioma == "PT") "${transactions.size} lançamentos eliminados" else "${transactions.size} transactions deleted",
                actionLabel = if (userSettings.value?.idioma == "PT") "Desfazer" else "Undo",
                onAction = {
                    viewModelScope.launch {
                        for (tx in transactions) {
                            repository.undoDeleteTransaction(tx)
                        }
                    }
                }
            )
        }
    }

    // Restore from trash
    fun restoreTransaction(trash: RecycleBin) {
        viewModelScope.launch {
            repository.restoreTransaction(trash)
        }
    }

    // Empty single trash item permanently
    fun deleteTrashPermanently(trash: RecycleBin) {
        viewModelScope.launch {
            repository.deleteTrashPermanently(trash)
        }
    }

    // Complete consolidated daily closure reconciliation across all wallets
    fun submitConsolidatedReconciliation(actualBalances: Map<Int, Double>) {
        viewModelScope.launch {
            repository.applyConsolidatedReconciliation(actualBalances)
            showDailyClosurePrompt.value = false
        }
    }

    // Complete daily closure conciliation for a wallet
    fun submitDailyClosure(walletId: Int, saldoReal: Double) {
        viewModelScope.launch {
            repository.applyDailyClosure(walletId, saldoReal)
            showDailyClosurePrompt.value = false
        }
    }

    // Dismiss the daily closure prompt
    fun dismissDailyClosure() {
        showDailyClosurePrompt.value = false
    }

    // Financial Goal Operations
    fun addFinancialGoal(nome: String, valorObjetivo: Double, dataLimite: Long, categoriaId: Int, valorInicial: Double = 0.0, walletId: Int? = null) {
        viewModelScope.launch {
            val goal = FinancialGoal(
                nome = nome,
                valorObjetivo = valorObjetivo,
                valorAtual = 0.0,
                dataInicio = System.currentTimeMillis(),
                dataLimite = dataLimite,
                categoriaId = categoriaId
            )
            val newGoalId = repository.addGoal(goal).toInt()
            if (valorInicial > 0.0) {
                val targetWallet = walletId ?: wallets.value.firstOrNull()?.id ?: 1
                val created = goal.copy(id = newGoalId)
                contributeToGoal(created, valorInicial, targetWallet)
            }
        }
    }

    fun deleteGoal(goal: FinancialGoal, walletId: Int? = null) {
        viewModelScope.launch {
            val goalTxs = transactions.value.filter { it.metaId == goal.id }
            val targetWalletId = walletId ?: goalTxs.lastOrNull()?.carteiraOrigemId ?: wallets.value.firstOrNull()?.id ?: 1

            val estornoTransactionId = repository.deleteGoalWithRefund(goal, targetWalletId)

            showSnackbar(
                message = if (userSettings.value?.idioma == "PT") "Meta financeira eliminada" else "Financial goal deleted",
                actionLabel = if (userSettings.value?.idioma == "PT") "Desfazer" else "Undo",
                onAction = {
                    viewModelScope.launch {
                        // Reverte também o estorno (se existiu) — não só a meta — para o
                        // "Desfazer" nunca deixar o valor contado a dobrar.
                        repository.undoGoalDeletion(goal, estornoTransactionId, targetWalletId)
                    }
                }
            )
        }
    }

    // Refresh goal progress based on current category savings or wallet values
    fun contributeToGoal(goal: FinancialGoal, valor: Double, walletId: Int = wallets.value.firstOrNull()?.id ?: 1) {
        viewModelScope.launch {
            val needed = (goal.valorObjetivo - goal.valorAtual).coerceAtLeast(0.0)
            val amountApplied = valor.coerceAtMost(needed)
            if (amountApplied <= 0.0) return@launch

            val updated = goal.copy(valorAtual = goal.valorAtual + amountApplied)
            repository.updateGoal(updated)

            val tx = FinancialTransaction(
                data = System.currentTimeMillis(),
                categoriaId = goal.categoriaId,
                descricao = "Contribuição Meta: ${goal.nome}",
                valor = amountApplied,
                tipo = "Despesa",
                carteiraOrigemId = walletId,
                metaId = goal.id,
                ajusteCaixa = false
            )
            repository.addTransaction(tx)
            
            if (valor > amountApplied) {
                showSnackbar(
                    message = if (userSettings.value?.idioma == "PT") {
                        "Debitado apenas %.2f MZN (valor necessário para atingir a meta).".format(java.util.Locale.US, amountApplied)
                    } else {
                        "Debited only %.2f MZN (amount needed to reach the goal).".format(java.util.Locale.US, amountApplied)
                    }
                )
            }
            
            // Check if goal achieved
            if (updated.valorAtual >= updated.valorObjetivo) {
                alertMessage.value = if (userSettings.value?.idioma == "PT")
                    "Parabéns! Atingiu a sua meta financeira: '${goal.nome}'!"
                else
                    "Congratulations! You reached your financial goal: '${goal.nome}'!"
            }
        }
    }

    fun withdrawFromGoal(goal: FinancialGoal, valor: Double, walletId: Int) {
        viewModelScope.launch {
            repository.withdrawFromGoal(goal.id, walletId, valor)
        }
    }

    fun togglePauseGoal(goal: FinancialGoal) {
        viewModelScope.launch {
            repository.updateGoal(goal.copy(pausada = !goal.pausada))
        }
    }

    // Scheduled Transfer Operations
    fun addScheduledTransfer(carteiraOrigemId: Int, carteiraDestinoId: Int, valor: Double, dataHora: Long) {
        viewModelScope.launch {
            val transfer = ScheduledTransfer(
                carteiraOrigemId = carteiraOrigemId,
                carteiraDestinoId = carteiraDestinoId,
                valor = valor,
                dataHora = dataHora,
                executada = false
            )
            repository.addScheduledTransfer(transfer)
        }
    }

    fun deleteScheduledTransfer(id: Int) {
        viewModelScope.launch {
            repository.deleteScheduledTransfer(id)
        }
    }

    fun executeScheduledTransferNow(transfer: ScheduledTransfer) {
        viewModelScope.launch {
            repository.executeScheduledTransferNow(transfer)
        }
    }

    // Helper to get current period text
    private fun getCurrentPeriodText(): String {
        return when (transactionPeriodFilter.value) {
            "Diário" -> "Hoje"
            "Semanal" -> "Esta Semana"
            "Mensal" -> "Este Mês"
            else -> "Histórico Geral"
        }
    }

    // PDF Actions
    fun sharePdfReport(customTransactions: List<Transaction>? = null, periodName: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            isExporting.value = true
            try {
                val file = exportService.generateRealPdfFile(
                    transactions = customTransactions ?: filteredTransactions.value,
                    categories = categories.value,
                    wallets = wallets.value,
                    moeda = userSettings.value?.moedaPadrao ?: "MZN",
                    periodName = periodName ?: getCurrentPeriodText(),
                )
                exportService.shareFile(file, "application/pdf", "Partilhar Relatório PDF")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error sharing PDF", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao partilhar PDF: ${e.localizedMessage}" else "Error sharing PDF: ${e.localizedMessage}")
            } finally {
                isExporting.value = false
            }
        }
    }

    fun savePdfReportToDownloads(customTransactions: List<Transaction>? = null, periodName: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            isExporting.value = true
            try {
                val file = exportService.generateRealPdfFile(
                    transactions = customTransactions ?: filteredTransactions.value,
                    categories = categories.value,
                    wallets = wallets.value,
                    moeda = userSettings.value?.moedaPadrao ?: "MZN",
                    periodName = periodName ?: getCurrentPeriodText(),
                )
                val fileName = "relatorio_financas_m_${System.currentTimeMillis()}.pdf"
                exportService.saveFileToDownloads(file, fileName, "application/pdf")
                repository.addExportedReport(fileName, "PDF", file.absolutePath)
                showSnackbar(if (userSettings.value?.idioma == "PT") "PDF guardado com sucesso!" else "PDF saved successfully!")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error saving PDF", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao guardar PDF: ${e.localizedMessage}" else "Error saving PDF: ${e.localizedMessage}")
            } finally {
                isExporting.value = false
            }
        }
    }

    // CSV Export Actions
    fun shareCsvReport(customTransactions: List<Transaction>? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            isExporting.value = true
            try {
                val file = exportService.generateCsvFile(
                    transactions = customTransactions ?: filteredTransactions.value,
                    categories = categories.value,
                    wallets = wallets.value,
                    moeda = userSettings.value?.moedaPadrao ?: "MZN"
                )
                exportService.shareFile(file, "text/csv", "Partilhar Relatório CSV")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error sharing CSV", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao partilhar CSV: ${e.localizedMessage}" else "Error sharing CSV: ${e.localizedMessage}")
            } finally {
                isExporting.value = false
            }
        }
    }

    fun saveCsvReportToDownloads(customTransactions: List<Transaction>? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            isExporting.value = true
            try {
                val file = exportService.generateCsvFile(
                    transactions = customTransactions ?: filteredTransactions.value,
                    categories = categories.value,
                    wallets = wallets.value,
                    moeda = userSettings.value?.moedaPadrao ?: "MZN"
                )
                val fileName = "relatorio_financas_m_${System.currentTimeMillis()}.csv"
                exportService.saveFileToDownloads(file, fileName, "text/csv")
                repository.addExportedReport(fileName, "CSV", file.absolutePath)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Ficheiro CSV guardado com sucesso!" else "CSV saved successfully!")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error saving CSV", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao guardar CSV: ${e.localizedMessage}" else "Error saving CSV: ${e.localizedMessage}")
            } finally {
                isExporting.value = false
            }
        }
    }

    // XLSX Excel Export Actions
    fun shareXlsxReport(customTransactions: List<Transaction>? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            isExporting.value = true
            try {
                val periodName = getCurrentPeriodText()
                val file = exportService.generateXlsxFile(
                    transactions = customTransactions ?: filteredTransactions.value,
                    categories = categories.value,
                    wallets = wallets.value,
                    moeda = userSettings.value?.moedaPadrao ?: "MZN",
                    periodName = periodName,
                )
                exportService.shareFile(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Partilhar Relatório Excel (.xlsx)")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error sharing XLSX", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao partilhar Excel: ${e.localizedMessage}" else "Error sharing Excel: ${e.localizedMessage}")
            } finally {
                isExporting.value = false
            }
        }
    }

    fun saveXlsxReportToDownloads(customTransactions: List<Transaction>? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            isExporting.value = true
            try {
                val periodName = getCurrentPeriodText()
                val file = exportService.generateXlsxFile(
                    transactions = customTransactions ?: filteredTransactions.value,
                    categories = categories.value,
                    wallets = wallets.value,
                    moeda = userSettings.value?.moedaPadrao ?: "MZN",
                    periodName = periodName,
                )
                val fileName = "relatorio_financas_m_${System.currentTimeMillis()}.xlsx"
                exportService.saveFileToDownloads(file, fileName, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                repository.addExportedReport(fileName, "XLSX", file.absolutePath)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Ficheiro Excel (.xlsx) guardado com sucesso!" else "Excel (.xlsx) saved successfully!")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error saving XLSX", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao guardar Excel: ${e.localizedMessage}" else "Error saving Excel: ${e.localizedMessage}")
            } finally {
                isExporting.value = false
            }
        }
    }

    // ZIP Package Export Actions
    fun shareZipReport(customTransactions: List<Transaction>? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            isExporting.value = true
            try {
                val periodName = getCurrentPeriodText()
                val file = exportService.generateCombinedZipReport(
                    transactions = customTransactions ?: filteredTransactions.value,
                    categories = categories.value,
                    wallets = wallets.value,
                    moeda = userSettings.value?.moedaPadrao ?: "MZN",
                    periodName = periodName,
                )
                exportService.shareFile(file, "application/zip", "Partilhar Pacote (.zip)")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error sharing ZIP", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao partilhar Pacote ZIP: ${e.localizedMessage}" else "Error sharing ZIP package: ${e.localizedMessage}")
            } finally {
                isExporting.value = false
            }
        }
    }

    fun saveZipReportToDownloads(customTransactions: List<Transaction>? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            isExporting.value = true
            try {
                val periodName = getCurrentPeriodText()
                val file = exportService.generateCombinedZipReport(
                    transactions = customTransactions ?: filteredTransactions.value,
                    categories = categories.value,
                    wallets = wallets.value,
                    moeda = userSettings.value?.moedaPadrao ?: "MZN",
                    periodName = periodName,
                )
                val fileName = "pacote_relatorios_financas_m_${System.currentTimeMillis()}.zip"
                exportService.saveFileToDownloads(file, fileName, "application/zip")
                repository.addExportedReport(fileName, "ZIP", file.absolutePath)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Pacote de relatorios (.zip) guardado com sucesso!" else "Report package (.zip) saved successfully!")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error saving ZIP", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao guardar Pacote ZIP: ${e.localizedMessage}" else "Error saving ZIP package: ${e.localizedMessage}")
            } finally {
                isExporting.value = false
            }
        }
    }

    // Alias for backward compatibility
    fun shareExcelReport(customTransactions: List<Transaction>? = null) = shareXlsxReport(customTransactions)
    fun saveExcelReportToDownloads(customTransactions: List<Transaction>? = null) = saveXlsxReportToDownloads(customTransactions)

    fun deleteExportedReport(report: com.example.data.model.ExportedReport) {
        viewModelScope.launch {
            repository.deleteExportedReport(report)
        }
    }

    // Trigger local backup
    fun runBackup(pin: String? = null) {
        viewModelScope.launch {
            try {
                backupService.createCompressedBackup(pin)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Copia de seguranca criada com sucesso!" else "Backup created successfully!")
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error running backup", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao criar copia de seguranca: ${e.localizedMessage}" else "Error creating backup: ${e.localizedMessage}")
            }
        }
    }

    // Restore database from GZIP backup
    fun runRestore(uri: Uri, pin: String? = null) {
        viewModelScope.launch {
            try {
                val success = backupService.restoreFromBackupUri(uri, pin)
                val msg = if (success) {
                    if (userSettings.value?.idioma == "PT") "Copia de seguranca restaurada com sucesso!" else "Backup restored successfully!"
                } else {
                    if (userSettings.value?.idioma == "PT") "Falha ao restaurar dados. Verifique a palavra-passe ou o ficheiro." else "Failed to restore data. Check password or file."
                }
                alertMessage.value = msg
                showSnackbar(msg)
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error running restore", e)
                val msg = if (userSettings.value?.idioma == "PT") "Erro ao restaurar backup: ${e.localizedMessage}" else "Error restoring backup: ${e.localizedMessage}"
                alertMessage.value = msg
                showSnackbar(msg)
            }
        }
    }

    // Spending limits operations
    fun saveSpendingLimit(categoryId: Int, month: String, amount: Double) {
        viewModelScope.launch {
            repository.addSpendingLimit(SpendingLimit(categoryId = categoryId, monthlyLimit = amount, month = month))
        }
    }

    fun deleteSpendingLimit(limit: SpendingLimit) {
        viewModelScope.launch {
            repository.deleteSpendingLimit(limit)
        }
    }

    // Loan operations
    fun createLoan(
        counterparty: String,
        principalAmount: Double,
        interestRate: Double,
        interestType: String,
        penaltyPercentage: Double,
        installmentCount: Int,
        dueDate: Long,
        isCredit: Boolean,
        walletId: Int? = null
    ) {
        viewModelScope.launch {
            val loan = Loan(
                counterparty = counterparty,
                principalAmount = principalAmount,
                interestRate = interestRate,
                interestType = interestType,
                penaltyPercentage = penaltyPercentage,
                transactionDate = System.currentTimeMillis(),
                dueDate = dueDate,
                installmentCount = installmentCount,
                isCredit = isCredit,
                status = "PENDING"
            )
            val installmentsList = mutableListOf<Installment>()
            val isCompound = interestType.uppercase() == "COMPOUND" || interestType.uppercase() == "COMPOSTO"
            val totalInterest = if (isCompound) {
                principalAmount * (Math.pow(1.0 + interestRate / 100.0, installmentCount.toDouble()) - 1.0)
            } else {
                principalAmount * (interestRate / 100.0) * installmentCount
            }
            val totalWithInterest = principalAmount + totalInterest
            val installmentAmount = totalWithInterest / installmentCount
            val cal = Calendar.getInstance()
            for (i in 1..installmentCount) {
                cal.timeInMillis = dueDate
                cal.add(Calendar.MONTH, i - 1)
                installmentsList.add(Installment(
                    parentId = 0,
                    dueDate = cal.timeInMillis,
                    remainingBalance = installmentAmount,
                    totalPaid = 0.0,
                    status = "PENDING"
                ))
            }
            repository.addLoan(loan, installmentsList, walletId)
        }
    }

    fun deleteLoan(loan: Loan) {
        viewModelScope.launch {
            val installments = repository.getInstallmentsForLoanDirect(loan.id)
            repository.deleteLoan(loan)
            showSnackbar(
                message = if (userSettings.value?.idioma == "PT") "Empréstimo eliminado" else "Loan deleted",
                actionLabel = if (userSettings.value?.idioma == "PT") "Desfazer" else "Undo",
                onAction = {
                    viewModelScope.launch {
                        repository.addLoan(loan, installments)
                    }
                }
            )
        }
    }

    fun payLoanInstallment(installment: Installment, amount: Double, walletId: Int, isCredit: Boolean) {
        viewModelScope.launch {
            repository.payInstallment(installment, amount, walletId, isCredit)
        }
    }

    fun updateLoan(loan: Loan) {
        viewModelScope.launch {
            repository.updateLoan(loan)
        }
    }

    fun deleteDailyClosure(closure: DailyClosure) {
        viewModelScope.launch {
            repository.deleteDailyClosure(closure)
        }
    }

    fun executeTransfer(fromWalletId: Int, toWalletId: Int, amount: Double, description: String = "Transferência entre carteiras") {
        if (fromWalletId == toWalletId || amount <= 0.0) return
        viewModelScope.launch {
            // Delegated to the repository: both balance updates and both transaction inserts
            // now happen inside a single db.withTransaction, reading fresh balances from the
            // DB instead of the (possibly stale) in-memory wallets StateFlow, so a crash
            // mid-transfer can never leave the two wallets out of sync.
            repository.transferBetweenWallets(fromWalletId, toWalletId, amount, description)
        }
    }

    fun fetchGeminiAdvice(idioma: String = "PT") {
        viewModelScope.launch {
            isGeneratingAdvice.value = true
            try {
                val transList = transactions.value
                val now = System.currentTimeMillis()
                val thirtyDaysAgo = now - (30L * 24 * 60 * 60 * 1000)
                
                val monthlyTrans = transList.filter { it.data >= thirtyDaysAgo }
                val incomes = monthlyTrans.filter { it.isReceita() }.sumOf { it.valor }
                val expenses = monthlyTrans.filter { it.isDespesa() }.sumOf { it.valor }
                val currentBalance = wallets.value.sumOf { it.saldoAtual }
                
                val cats = categories.value.associateBy { it.id }
                val breakdown = monthlyTrans.filter { it.isDespesa() }
                    .groupBy { cats[it.categoriaId]?.nome ?: (if (idioma == "PT") "Outros" else "Others") }
                    .mapValues { entry -> entry.value.sumOf { it.valor } }
                
                val goalsSummary = goals.value.joinToString { "${it.nome} (${String.format("%,.2f", it.valorAtual)}/${String.format("%,.2f", it.valorObjetivo)} MZN)" }
                    .ifEmpty { if (idioma == "PT") "Nenhuma meta ativa" else "No active goals" }

                val advice = geminiService.getFinancialAdvice(
                    totalIncomes = incomes,
                    totalExpenses = expenses,
                    balance = currentBalance,
                    categoryBreakdown = breakdown,
                    goalsSummary = goalsSummary,
                    idioma = idioma
                )
                geminiAdvice.value = advice
            } catch (e: Exception) {
                geminiAdvice.value = "Error generating advice: ${e.localizedMessage}"
            } finally {
                isGeneratingAdvice.value = false
            }
        }
    }

    fun processOcrReceipt(uri: Uri) {
        viewModelScope.launch {
            isScanningOcr.value = true
            try {
                val result = ocrService.scanReceipt(uri)
                ocrScanResult.value = result
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error scanning receipt OCR", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao processar recibo: ${e.localizedMessage}" else "Error processing receipt: ${e.localizedMessage}")
            } finally {
                isScanningOcr.value = false
            }
        }
    }

    fun processOcrText(rawText: String) {
        viewModelScope.launch {
            isScanningOcr.value = true
            try {
                val result = ocrService.parseText(rawText)
                ocrScanResult.value = result
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error parsing OCR text", e)
                showSnackbar(if (userSettings.value?.idioma == "PT") "Erro ao processar texto OCR: ${e.localizedMessage}" else "Error processing OCR text: ${e.localizedMessage}")
            } finally {
                isScanningOcr.value = false
            }
        }
    }

    fun clearOcrResult() {
        ocrScanResult.value = null
    }

    fun checkPendingLoansForNotifications() {
        viewModelScope.launch {
            val loans = groupedLoans.value.map { it.loan }
            val dueSoon = com.example.domain.usecases.CheckPendingLoansUseCase().getPendingLoansDueSoon(loans)
            for ((loan, daysLeft) in dueSoon) {
                notificationService.notifyLoanDueDate(loan.counterparty, loan.principalAmount, daysLeft)
            }
        }
    }

    fun checkForgottenShoppingItems() {
        viewModelScope.launch {
            val activeLists = shoppingLists.value
            for (list in activeLists) {
                val items = repository.getShoppingItemsForList(list.id).firstOrNull() ?: emptyList()
                val unpaid = items.filter { !it.pago }
                if (unpaid.size >= 3) {
                    notificationService.notifyForgottenShoppingItems(list.nome, unpaid.size)
                }
            }
        }
    }

    fun getLoanReceipts(loanId: Int): Flow<List<LoanReceipt>> {
        return repository.getLoanReceipts(loanId)
    }

    fun addLoanReceipt(loanId: Int, imageUri: String) {
        viewModelScope.launch {
            repository.addLoanReceipt(loanId, imageUri)
        }
    }

    fun deleteLoanReceipt(receipt: LoanReceipt) {
        viewModelScope.launch {
            repository.deleteLoanReceipt(receipt)
        }
    }

    // Subscription CRUD Operations
    fun addSubscription(sub: Subscription) {
        viewModelScope.launch {
            repository.addSubscription(sub)
        }
    }

    fun updateSubscription(sub: Subscription) {
        viewModelScope.launch {
            repository.updateSubscription(sub)
        }
    }

    fun deleteSubscription(id: Int) {
        viewModelScope.launch {
            repository.deleteSubscription(id)
        }
    }

    fun toggleSubscriptionActive(sub: Subscription) {
        viewModelScope.launch {
            repository.updateSubscription(sub.copy(ativa = !sub.ativa))
        }
    }

    fun paySubscriptionNow(sub: Subscription) {
        viewModelScope.launch {
            repository.paySubscriptionNow(sub)
        }
    }

    // Credit Card Operations
    fun addCreditCard(card: CreditCard) {
        viewModelScope.launch {
            repository.addCreditCard(card)
        }
    }

    fun updateCreditCard(card: CreditCard) {
        viewModelScope.launch {
            repository.updateCreditCard(card)
        }
    }

    fun deleteCreditCard(card: CreditCard) {
        viewModelScope.launch {
            repository.deleteCreditCard(card)
        }
    }

    fun payCreditCardInvoice(cardId: Int, amount: Double, walletId: Int) {
        viewModelScope.launch {
            repository.payCreditCardInvoice(cardId, amount, walletId)
            showSnackbar(
                message = if (userSettings.value?.idioma == "PT") "Fatura do cartão paga com sucesso!" else "Card invoice paid successfully!"
            )
        }
    }

    fun addCreditCardPurchase(cardId: Int, amount: Double, description: String, categoryId: Int) {
        viewModelScope.launch {
            repository.addCreditCardPurchase(cardId, amount, description, categoryId)
            showSnackbar(
                message = if (userSettings.value?.idioma == "PT") "Compra no cartão registada!" else "Card purchase recorded!"
            )
        }
    }
}
