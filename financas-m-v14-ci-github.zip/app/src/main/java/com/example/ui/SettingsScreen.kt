@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File


// ------------------- TELA 6: CONFIGURAÇÕES E PERSONALIZAÇÃO -------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    settings: UserSettings,
    categories: List<Category>,
    trashItems: List<RecycleBin>,
    onNavigate: (String) -> Unit
) {
    // Verified match successfully
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var showCategoryCRUD by remember { mutableStateOf(false) }
    var showLixeiraDialog by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var showOnboardingTutorial by remember { mutableStateOf(false) }
    var showCustomColorDialog by remember { mutableStateOf(false) }
    
    // Profile Editor states
    var showProfileEditor by remember { mutableStateOf(false) }
    var profileNameInput by remember { mutableStateOf(settings.name) }
    var profilePhotoUriInput by remember { mutableStateOf(settings.photoURL) }
    var showLogoutSessionsDialog by remember { mutableStateOf(false) }

    // Sync state with settings updates
    LaunchedEffect(settings.name, settings.photoURL) {
        profileNameInput = settings.name
        profilePhotoUriInput = settings.photoURL
    }

    // Backup system file launcher
    val fileRestoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.runRestore(uri)
        }
    }

    // Photo selection launcher
    val profilePhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            profilePhotoUriInput = uri.toString()
        }
    }

    val themeColor = try {
        Color(android.graphics.Color.parseColor(settings.corPrimaria))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    val baseBackgroundColor = if (settings.tema == "dark") {
        MaterialTheme.colorScheme.background
    } else {
        Color(0xFFF8F9FC)
    }

    val coroutineScope = rememberCoroutineScope()
    var selectedSection by remember { mutableStateOf("aparência") }
    var activeMobileSection by remember { mutableStateOf<String?>(null) }
    val rightListState = androidx.compose.foundation.lazy.rememberLazyListState()

    // Encapsulate typed helper data structures locally
    data class SecurityConfigItem(
        val title: String,
        val desc: String,
        val checked: Boolean,
        val onToggle: (Boolean) -> Unit
    )

    data class QuickActionConfig(
        val title: String,
        val desc: String,
        val bg: Color,
        val tint: Color,
        val icon: androidx.compose.ui.graphics.vector.ImageVector,
        val action: () -> Unit
    )

    data class MobileSectionOption(
        val id: String,
        val label: String,
        val desc: String,
        val icon: androidx.compose.ui.graphics.vector.ImageVector
    )

    // Local lambdas to reuse same custom cards on both mobile and tablet
    val aparenciaCard = @Composable {
        val PT = settings.idioma == "PT"
        Card(
            modifier = Modifier.fillMaxWidth().testTag("aparencia_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(32.dp).background(themeColor.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Palette, null, tint = themeColor, modifier = Modifier.size(18.dp))
                    }
                    Text(if (PT) "Aparência" else "Appearance", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (PT) "Tema do aplicativo" else "App theme", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth().background(if (settings.tema == "dark") Color(0xFF2A2A2A) else Color(0xFFF1F3F9), RoundedCornerShape(12.dp)).padding(4.dp)) {
                        listOf("light" to if (PT) "Claro" else "Light", "dark" to if (PT) "Escuro" else "Dark").forEach { (theme, label) ->
                            val isSel = settings.tema == theme
                            Box(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (isSel) (if (theme == "dark") themeColor else Color.White) else Color.Transparent).clickable { viewModel.updateTheme(theme) }.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(if (theme == "light") Icons.Rounded.WbSunny else Icons.Rounded.Brightness2, null, tint = if (isSel) (if (theme == "dark") Color.White else themeColor) else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                                    Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isSel) (if (theme == "dark") Color.White else Color.Black) else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (PT) "Cor primária" else "Primary color", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        val hexList = listOf("#1A73E8", "#2E7D32", "#7B1FA2", "#FF5722", "#C62828")
                        hexList.forEach { hex ->
                            val isSel = settings.corPrimaria.lowercase() == hex.lowercase()
                            Box(Modifier.size(48.dp).clickable { viewModel.updatePrimaryColor(hex) }, contentAlignment = Alignment.Center) {
                                Box(Modifier.size(32.dp).clip(CircleShape).background(Color(android.graphics.Color.parseColor(hex))).border(if (isSel) 3.dp else 1.dp, if (isSel) MaterialTheme.colorScheme.onSurface else Color.Transparent, CircleShape), contentAlignment = Alignment.Center) {
                                    if (isSel) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                        val isGradSel = !hexList.any { settings.corPrimaria.lowercase() == it.lowercase() }
                        Box(Modifier.size(48.dp).clickable { showCustomColorDialog = true }, contentAlignment = Alignment.Center) {
                            Box(Modifier.size(32.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red))).border(if (isGradSel) 3.dp else 1.dp, if (isGradSel) MaterialTheme.colorScheme.onSurface else Color.Transparent, CircleShape), contentAlignment = Alignment.Center) {
                                if (isGradSel) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (PT) "Moeda padrão de exibição" else "Default currency", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("MZN", "USD", "ZAR").forEach { code ->
                            val isSel = settings.moedaPadrao == code
                            FilterChip(selected = isSel, onClick = { viewModel.updateBaseCurrency(code) }, label = { Text(code, fontSize = 10.sp, fontWeight = FontWeight.Bold) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = themeColor, selectedLabelColor = Color.White))
                        }
                    }
                }
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(if (PT) "Moeda Secundária (Duplo Câmbio)" else "Secondary Currency (Dual Rate)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(if (PT) "Exibe conversão estimada no saldo principal" else "Displays estimated conversion under main balance", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    }
                    val secCurrency by viewModel.secondaryCurrency.collectAsState()
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("" to if (PT) "Nenhum" else "None", "USD" to "USD", "EUR" to "EUR", "BRL" to "BRL").forEach { (code, label) ->
                            val isSel = secCurrency == code
                            FilterChip(
                                selected = isSel,
                                onClick = { viewModel.updateSecondaryCurrency(code) },
                                label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = themeColor, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(if (PT) "Idioma do sistema" else "System language", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(if (PT) "Escolha o idioma do aplicativo" else "Choose the application language", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    }
                    Button(onClick = { viewModel.updateIdioma(if (PT) "EN" else "PT") }, colors = ButtonDefaults.buttonColors(containerColor = themeColor.copy(alpha = 0.1f), contentColor = themeColor), shape = RoundedCornerShape(8.dp)) {
                        Text(if (PT) "Português 🇵🇹" else "English 🇬🇧", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    val segurancaCard = @Composable {
        val PT = settings.idioma == "PT"
        val reminderTime by viewModel.reminderTime.collectAsState()
        val budgetThresh by viewModel.budgetThreshold.collectAsState()
        val autoLockMins by viewModel.autoLockTimeoutMins.collectAsState()
        val weeklySummary by viewModel.weeklySummaryEnabled.collectAsState()
        Card(
            modifier = Modifier.fillMaxWidth().testTag("seguranca_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(32.dp).background(Color(0xFFE8F5E9), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Shield, null, tint = Color(0xFF2E7D32), modifier = Modifier.size(18.dp))
                    }
                    Text(if (PT) "Segurança e privacidade" else "Security & privacy", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
                listOf(
                    SecurityConfigItem(if (PT) "Notificações inteligentes" else "Smart notifications", if (PT) "Receba alertas personalizados" else "Receive personalized alerts", settings.notificacoesAtivas) { b: Boolean -> viewModel.toggleNotifications(b) },
                    SecurityConfigItem(if (PT) "Autenticação biométrica" else "Biometric authentication", if (PT) "Use impressão digital ou reconhecimento facial" else "Use fingerprint or facial recognition", settings.biometricsEnabled) { b: Boolean -> viewModel.updateBiometricsEnabled(b) }
                ).forEach { item ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(item.desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                        }
                        Switch(checked = item.checked, onCheckedChange = item.onToggle, colors = SwitchDefaults.colors(checkedThumbColor = themeColor, checkedTrackColor = themeColor.copy(alpha = 0.4f)))
                    }
                }

                if (settings.notificacoesAtivas) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    var showTimeDialog by remember { mutableStateOf(false) }
                    Row(
                        Modifier.fillMaxWidth().clickable { showTimeDialog = true },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (PT) "Horário do Lembrete Diário" else "Daily Reminder Time",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = if (PT) "Defina o horário para receber alertas ($reminderTime)" else "Set schedule for daily alerts ($reminderTime)",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                        Box(
                            Modifier
                                .background(themeColor.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(reminderTime, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = themeColor)
                        }
                    }

                    if (showTimeDialog) {
                        var hourInput by remember { mutableStateOf(reminderTime.substringBefore(":")) }
                        var minInput by remember { mutableStateOf(reminderTime.substringAfter(":")) }
                        AlertDialog(
                            onDismissRequest = { showTimeDialog = false },
                            title = { Text(if (PT) "Definir Horário" else "Set Reminder Time", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(if (PT) "Selecione o horário para as notificações:" else "Select the hour for notifications:", fontSize = 12.sp)
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        OutlinedTextField(
                                            value = hourInput,
                                            onValueChange = { if (it.length <= 2 && it.all { c -> c.isDigit() }) hourInput = it },
                                            label = { Text("HH") },
                                            modifier = Modifier.weight(1f),
                                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        )
                                        Text(":", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(
                                            value = minInput,
                                            onValueChange = { if (it.length <= 2 && it.all { c -> c.isDigit() }) minInput = it },
                                            label = { Text("MM") },
                                            modifier = Modifier.weight(1f),
                                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        )
                                    }
                                }
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        val h = hourInput.toIntOrNull() ?: 9
                                        val m = minInput.toIntOrNull() ?: 0
                                        val formattedH = String.format("%02d", h.coerceIn(0, 23))
                                        val formattedM = String.format("%02d", m.coerceIn(0, 59))
                                        viewModel.updateReminderTime("$formattedH:$formattedM")
                                        showTimeDialog = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = themeColor)
                                ) {
                                    Text(if (PT) "Salvar" else "Save")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showTimeDialog = false }) {
                                    Text(if (PT) "Cancelar" else "Cancel", color = themeColor)
                                }
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(if (PT) "Limite de Alerta de Orçamento" else "Budget Alert Threshold", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("$budgetThresh%", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = themeColor)
                        }
                        Text(if (PT) "Notificar quando uma categoria atingir esta percentagem do limite mensal" else "Notify when a category reaches this percentage of monthly limit", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                        Slider(
                            value = budgetThresh.toFloat(),
                            onValueChange = { viewModel.updateBudgetThreshold(it.toInt()) },
                            valueRange = 50f..100f,
                            steps = 9,
                            colors = SliderDefaults.colors(thumbColor = themeColor, activeTrackColor = themeColor, inactiveTrackColor = themeColor.copy(alpha = 0.2f))
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (PT) "Resumo Semanal Automático" else "Automatic Weekly Summary", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(if (PT) "Receber resumo de receitas e despesas aos domingos" else "Receive summary of income and expenses on Sundays", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                        }
                        Switch(
                            checked = weeklySummary,
                            onCheckedChange = { viewModel.toggleWeeklySummary(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = themeColor, checkedTrackColor = themeColor.copy(alpha = 0.4f))
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (PT) "Tempo de Bloqueio Automático" else "Auto-Lock Timeout", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(if (PT) "Exigir PIN de segurança após ficar em segundo plano" else "Require security PIN after being in background", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 4.dp)) {
                        listOf(0 to if (PT) "Imediato" else "Immediate", 1 to "1 Min", 5 to "5 Min", 15 to "15 Min").forEach { (mins, label) ->
                            val isSel = autoLockMins == mins
                            FilterChip(
                                selected = isSel,
                                onClick = { viewModel.updateAutoLockTimeout(mins) },
                                label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = themeColor, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }

                Card(modifier = Modifier.fillMaxWidth().clickable { showSecurityDialog = true }, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF2E7D32))) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(32.dp).background(Color.White.copy(alpha = 0.2f), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Lock, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (settings.pinHash.isNotEmpty()) (if (PT) "PIN de Segurança Ativado" else "Security PIN Enabled") else (if (PT) "Ativar PIN de segurança" else "Enable security PIN"), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                            Text(if (PT) "Proteja seu acesso ao aplicativo" else "Secure access to your application", fontSize = 10.sp, color = Color(0xFFE8F5E9))
                        }
                        Icon(Icons.Rounded.ChevronRight, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }

    val acoesRapidasCard = @Composable {
        val PT = settings.idioma == "PT"
        Card(
            modifier = Modifier.fillMaxWidth().testTag("acoes_rapidas_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(32.dp).background(Color(0xFFFFF9C4), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Bolt, null, tint = Color(0xFFFBC02D), modifier = Modifier.size(18.dp))
                    }
                    Text(if (PT) "Ações rápidas" else "Quick actions", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        QuickActionConfig(if (PT) "Alterar PIN" else "Change PIN", if (PT) "Bloqueio" else "Lock", Color(0xFFF3E8FF), Color(0xFF7B1FA2), Icons.Rounded.Lock) { showSecurityDialog = true },
                        QuickActionConfig(if (PT) "Gerir categorias" else "Categories", if (PT) "Adicionar" else "Add or edit", Color(0xFFDCFCE7), Color(0xFF2E7D32), Icons.Rounded.Category) { showCategoryCRUD = true }
                    ).forEach { item ->
                        Card(modifier = Modifier.weight(1f).clickable { item.action() }, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") Color(0xFF26213A) else item.bg)) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(Modifier.size(32.dp).background(if (settings.tema == "dark") Color(0xFF4A148C) else item.bg.copy(alpha = 0.5f), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(item.icon, null, tint = if (settings.tema == "dark") Color(0xFFE040FB) else item.tint, modifier = Modifier.size(16.dp))
                                }
                                Column {
                                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(item.desc, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                }
                            }
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        QuickActionConfig(if (PT) "Sair sessões" else "Sessions", if (PT) "Desconectar" else "Sign out", Color(0xFFFFD8D8), Color(0xFFC62828), Icons.AutoMirrored.Rounded.ExitToApp) { showLogoutSessionsDialog = true },
                        QuickActionConfig(if (PT) "Atividades" else "Activities", if (PT) "Ver histórico" else "History", Color(0xFFE0F2FE), Color(0xFF0288D1), Icons.Rounded.History) { onNavigate("lancamentos") },
                        QuickActionConfig(if (PT) "Guia Rápido" else "Quick Guide", if (PT) "Aprender" else "Learn", Color(0xFFE0F7FA), Color(0xFF00ACC1), Icons.Rounded.Info) { showOnboardingTutorial = true }
                    ).forEach { item ->
                        Card(
                            modifier = Modifier.weight(1f).clickable { item.action() },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else item.bg)
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier.size(32.dp).background(if (settings.tema == "dark") item.tint.copy(alpha = 0.2f) else item.bg.copy(alpha = 0.5f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(item.icon, null, tint = item.tint, modifier = Modifier.size(16.dp))
                                }
                                Column {
                                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(item.desc, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val backupCard = @Composable {
        val PT = settings.idioma == "PT"
        Card(
            modifier = Modifier.fillMaxWidth().testTag("backup_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(32.dp).background(themeColor.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.CloudUpload, null, tint = themeColor, modifier = Modifier.size(18.dp))
                    }
                    Text(if (PT) "Backup e dados" else "Backup & data", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
                Row(modifier = Modifier.fillMaxWidth().background(Color(0xFFE8F5E9), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(18.dp).background(Color(0xFF2E7D32), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(10.dp))
                    }
                    Text(if (PT) "Último backup: 12 de mai. de 2024 • 08:30" else "Last backup: May 12, 2024 • 08:30", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.runBackup() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)), shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Rounded.CloudUpload, null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (PT) "Backup agora" else "Backup now", fontSize = 11.sp)
                    }
                    OutlinedButton(onClick = { fileRestoreLauncher.launch("application/gzip") }, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, Color(0xFF2E7D32)), shape = RoundedCornerShape(10.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF2E7D32))) {
                        Icon(Icons.Rounded.CloudDownload, null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (PT) "Restaurar" else "Restore", fontSize = 11.sp)
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (PT) "Limpeza Completa e Purga de Segurança" else "Full Purge & Security Clean", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                    Text(if (PT) "Elimina permanentemente todas as carteiras, transações, metas e configurações do aplicativo. Esta operação não pode ser desfeita!" else "Permanently deletes all wallets, transactions, goals and settings. This operation is irreversible!", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    
                    var showPurgeConfirm by remember { mutableStateOf(false) }
                    
                    Button(
                        onClick = { showPurgeConfirm = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f), contentColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp).testTag("purge_data_button")
                    ) {
                        Icon(Icons.Rounded.DeleteForever, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (PT) "Purgar Todos os Dados do Utilizador" else "Purge All User Data", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    
                    if (showPurgeConfirm) {
                        AlertDialog(
                            onDismissRequest = { showPurgeConfirm = false },
                            title = { Text(if (PT) "Purga Definitiva de Dados?" else "Confirm Permanent Purge?", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
                            text = { Text(if (PT) "Tem a certeza absoluta? Todos os seus registos financeiros, contas, compras e configurações serão eliminados de forma definitiva e o aplicativo será reiniciado." else "Are you absolutely sure? All your financial records, wallets, lists and configurations will be permanently destroyed and the app will reset.", fontSize = 13.sp) },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        viewModel.clearAllUserData()
                                        showPurgeConfirm = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Text(if (PT) "Sim, Eliminar Tudo" else "Yes, Delete Everything")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showPurgeConfirm = false }) {
                                    Text(if (PT) "Cancelar" else "Cancel", color = themeColor)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    val sobreCard = @Composable {
        val PT = settings.idioma == "PT"
        Card(
            modifier = Modifier.fillMaxWidth().testTag("sobre_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(32.dp).background(themeColor.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Info, null, tint = themeColor, modifier = Modifier.size(18.dp))
                    }
                    Text(if (PT) "Sobre o app" else "About app", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(if (PT) "Lixeira e excluídos" else "Trash & deleted", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(if (PT) "Restaurar itens apagados" else "Restore deleted items", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    }
                    Button(onClick = { showLixeiraDialog = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer), shape = RoundedCornerShape(8.dp)) {
                        Icon(Icons.Rounded.DeleteSweep, null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (PT) "Lixeira (${trashItems.size})" else "Trash (${trashItems.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(
                        (if (PT) "Nome" else "Name") to (if (PT) "Finanças Pessoais" else "Personal Finances"),
                        "Versão" to "1.5.0",
                        "Developer" to "MozDevel"
                    ).forEach { (lbl, valStr) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(lbl, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                            Text(valStr, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(baseBackgroundColor)
    ) {
        val isWideScreen = maxWidth >= 720.dp

        if (isWideScreen) {
            // Tablet Side-by-Side Split View Layout
            Row(modifier = Modifier.fillMaxSize()) {
                // Left Sidebar (pinned 300dp)
                Column(
                    modifier = Modifier
                        .width(300.dp)
                        .fillMaxHeight()
                        .background(if (settings.tema == "dark") MaterialTheme.colorScheme.surface.copy(alpha = 0.5f) else Color(0xFFF0F2FA))
                        .border(1.dp, if (settings.tema == "dark") Color.White.copy(alpha = 0.05f) else Color.Black.copy(alpha = 0.05f))
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Olá, João card (replicates image 100% copy)
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { showProfileEditor = true },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF5E35B1))
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(36.dp).background(Color.White.copy(alpha = 0.2f), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Star, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                Text(if (settings.idioma == "PT") "Olá, ${settings.name}!" else "Hello, ${settings.name}!", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(if (settings.idioma == "PT") "Aqui você personaliza tudo do seu jeito." else "Here you customize everything your way.", fontSize = 10.sp, color = Color(0xFFE1BEE7))
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Menu Options
                    val menus = listOf(
                        Triple("aparência", if (settings.idioma == "PT") "Aparência" else "Appearance", Icons.Rounded.Palette),
                        Triple("segurança", if (settings.idioma == "PT") "Segurança" else "Security", Icons.Rounded.Shield),
                        Triple("categorias", if (settings.idioma == "PT") "Gerenciar categorias" else "Manage categories", Icons.Rounded.Category),
                        Triple("backup", if (settings.idioma == "PT") "Backup e dados" else "Backup & data", Icons.Rounded.CloudUpload),
                        Triple("ações_rápidas", if (settings.idioma == "PT") "Ações rápidas" else "Quick Actions", Icons.Rounded.Bolt),
                        Triple("sobre", if (settings.idioma == "PT") "Sobre o app" else "About app", Icons.Rounded.Info)
                    )

                    menus.forEach { (id, label, icon) ->
                        val isSel = selectedSection == id
                        val bgBrush = if (isSel) (if (settings.tema == "dark") themeColor.copy(alpha = 0.2f) else Color(0xFFF3E5F5)) else Color.Transparent
                        val textClr = if (isSel) (if (settings.tema == "dark") themeColor else Color(0xFF7B1FA2)) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(bgBrush)
                                .clickable {
                                    selectedSection = id
                                    if (id == "categorias") {
                                        showCategoryCRUD = true
                                    } else {
                                        val idx = when (id) {
                                            "aparência" -> 1
                                            "segurança" -> 2
                                            "backup" -> 4
                                            "ações_rápidas" -> 3
                                            "sobre" -> 5
                                            else -> 1
                                        }
                                        coroutineScope.launch { rightListState.animateScrollToItem(idx) }
                                    }
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(icon, null, tint = textClr, modifier = Modifier.size(18.dp))
                            Text(label, fontSize = 13.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium, color = textClr, modifier = Modifier.weight(1f))
                        }
                    }

                    Spacer(Modifier.weight(1f))

                    // Premium Experience promo card (replicates image 100% copy)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") Color(0xFF2E1C38) else Color(0xFFF3E5F5)),
                        border = BorderStroke(1.dp, if (settings.tema == "dark") Color(0xFF7B1FA2).copy(alpha = 0.2f) else Color(0xFFE1BEE7))
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(Modifier.size(28.dp).background(if (settings.tema == "dark") Color(0xFF4A148C) else Color(0xFFE1BEE7), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.Star, null, tint = if (settings.tema == "dark") Color(0xFFEA80FC) else Color(0xFF7B1FA2), modifier = Modifier.size(14.dp))
                                }
                                Text(if (settings.idioma == "PT") "Experiência Premium" else "Premium Experience", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (settings.tema == "dark") Color(0xFFE1BEE7) else Color(0xFF4A148C))
                            }
                            Text(if (settings.idioma == "PT") "Recursos avançados para você ter ainda mais controle." else "Advanced features for you to have even more control.", fontSize = 9.sp, color = if (settings.tema == "dark") Color(0xFFB39DDB) else Color(0xFF7B1FA2))
                            Button(onClick = { Toast.makeText(context, if (settings.idioma == "PT") "Planos Premium em Breve!" else "Premium Plans Coming Soon!", Toast.LENGTH_SHORT).show() }, colors = ButtonDefaults.buttonColors(containerColor = if (settings.tema == "dark") Color(0xFF673AB7) else Color(0xFF7B1FA2)), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = 4.dp)) {
                                Text(if (settings.idioma == "PT") "Conhecer planos" else "Explore plans", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }

                // Right content panel (Smooth scrollable list of elements)
                androidx.compose.foundation.lazy.LazyColumn(
                    state = rightListState,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    contentPadding = PaddingValues(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    IconButton(
                                        onClick = { onNavigate("dashboard") },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                            contentDescription = "Voltar",
                                            tint = themeColor
                                        )
                                    }
                                    Text(if (settings.idioma == "PT") "Configurações" else "Settings", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
                                    Box(Modifier.size(28.dp).background(themeColor.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Rounded.Settings, null, tint = themeColor, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Text(if (settings.idioma == "PT") "Personalize sua experiência e tenha mais controle." else "Personalize your experience and have more control.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                            }
                            // Avatar on top right with active green status dot
                            Box(Modifier.size(52.dp).clip(CircleShape).clickable { showProfileEditor = true }.background(themeColor.copy(alpha = 0.15f)).border(2.dp, themeColor, CircleShape)) {
                                if (profilePhotoUriInput.isNotEmpty()) {
                                    AsyncImage(model = profilePhotoUriInput, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                } else {
                                    Text(if (settings.name.isNotEmpty()) settings.name.take(1).uppercase() else "U", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = themeColor, modifier = Modifier.align(Alignment.Center))
                                }
                                Box(Modifier.size(11.dp).clip(CircleShape).background(Color(0xFF4CAF50)).border(1.5.dp, Color.White, CircleShape).align(Alignment.BottomEnd))
                            }
                        }
                    }
                    item { aparenciaCard() }
                    item { segurancaCard() }
                    item { acoesRapidasCard() }
                    item { backupCard() }
                    item { sobreCard() }
                }
            }
        } else {
            // Mobile Adaptability Master-Detail Navigator
            if (activeMobileSection == null) {
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(
                                onClick = { onNavigate("dashboard") },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = "Voltar",
                                    tint = themeColor
                                )
                            }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(if (settings.idioma == "PT") "Configurações" else "Settings", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
                                    Box(Modifier.size(24.dp).background(themeColor.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Rounded.Settings, null, tint = themeColor, modifier = Modifier.size(14.dp))
                                    }
                                }
                                Text(if (settings.idioma == "PT") "Toque para configurar tudo" else "Tap to configure", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                            }
                        }
                        Box(Modifier.size(44.dp).clip(CircleShape).clickable { showProfileEditor = true }.background(themeColor.copy(alpha = 0.15f)).border(2.dp, themeColor, CircleShape)) {
                            if (profilePhotoUriInput.isNotEmpty()) {
                                AsyncImage(model = profilePhotoUriInput, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                            } else {
                                Text(if (settings.name.isNotEmpty()) settings.name.take(1).uppercase() else "U", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = themeColor, modifier = Modifier.align(Alignment.Center))
                            }
                            Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF4CAF50)).border(1.5.dp, Color.White, CircleShape).align(Alignment.BottomEnd))
                        }
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { showProfileEditor = true },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF5E35B1))
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(36.dp).background(Color.White.copy(alpha = 0.2f), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Star, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                Text(if (settings.idioma == "PT") "Olá, ${settings.name}!" else "Hello, ${settings.name}!", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(if (settings.idioma == "PT") "Aqui você personaliza tudo do seu jeito." else "Here you customize everything your way.", fontSize = 10.sp, color = Color(0xFFE1BEE7))
                            }
                        }
                    }

                    val options = listOf(
                        MobileSectionOption("aparência", if (settings.idioma == "PT") "Aparência" else "Appearance", if (settings.idioma == "PT") "Tema, cores e moedas" else "Theme, colors & coins", Icons.Rounded.Palette),
                        MobileSectionOption("segurança", if (settings.idioma == "PT") "Segurança e privacidade" else "Security & privacy", if (settings.idioma == "PT") "PIN e biometria" else "PIN & biometrics", Icons.Rounded.Shield),
                        MobileSectionOption("ações_rápidas", if (settings.idioma == "PT") "Ações rápida" else "Quick actions", if (settings.idioma == "PT") "Atalhos rápidos" else "Quick shortcuts", Icons.Rounded.Bolt),
                        MobileSectionOption("backup", if (settings.idioma == "PT") "Backup e dados" else "Backup & recovery", if (settings.idioma == "PT") "Cópias de segurança" else "Restore and copy", Icons.Rounded.CloudUpload),
                        MobileSectionOption("sobre", if (settings.idioma == "PT") "Sobre o app" else "About app", if (settings.idioma == "PT") "Versão e lixeira" else "Version & trash", Icons.Rounded.Info)
                    )

                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        options.forEach { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { activeMobileSection = item.id },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.White),
                                border = BorderStroke(1.dp, if (settings.tema == "dark") Color.White.copy(alpha = 0.05f) else Color.Black.copy(alpha = 0.05f))
                            ) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(Modifier.size(36.dp).background(themeColor.copy(alpha = 0.1f), CircleShape), contentAlignment = Alignment.Center) {
                                        Icon(item.icon, null, tint = themeColor, modifier = Modifier.size(18.dp))
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(item.label, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(item.desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                    }
                                    Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = if (settings.tema == "dark") Color(0xFF2E1C38) else Color(0xFFF3E5F5)),
                        border = BorderStroke(1.dp, if (settings.tema == "dark") Color(0xFF7B1FA2).copy(alpha = 0.2f) else Color(0xFFE1BEE7))
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(Modifier.size(28.dp).background(if (settings.tema == "dark") Color(0xFF4A148C) else Color(0xFFE1BEE7), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.Star, null, tint = if (settings.tema == "dark") Color(0xFFEA80FC) else Color(0xFF7B1FA2), modifier = Modifier.size(14.dp))
                                }
                                Text(if (settings.idioma == "PT") "Experiência Premium" else "Premium Experience", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (settings.tema == "dark") Color(0xFFE1BEE7) else Color(0xFF4A148C))
                            }
                            Text(if (settings.idioma == "PT") "Recursos avançados para você ter ainda mais controle." else "Advanced features for you to have even more control.", fontSize = 10.sp, color = if (settings.tema == "dark") Color(0xFFB39DDB) else Color(0xFF7B1FA2))
                            Button(onClick = { Toast.makeText(context, if (settings.idioma == "PT") "Planos Premium em Breve!" else "Premium Plans Coming Soon!", Toast.LENGTH_SHORT).show() }, colors = ButtonDefaults.buttonColors(containerColor = if (settings.tema == "dark") Color(0xFF673AB7) else Color(0xFF7B1FA2)), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(if (settings.idioma == "PT") "Conhecer planos" else "Explore plans", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().background(if (settings.tema == "dark") MaterialTheme.colorScheme.surface else Color.White).padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { activeMobileSection = null }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = themeColor)
                        }
                        Text(
                            text = when (activeMobileSection) {
                                "aparência" -> if (settings.idioma == "PT") "Aparência" else "Appearance"
                                "segurança" -> if (settings.idioma == "PT") "Segurança e privacidade" else "Security & privacy"
                                "ações_rápidas" -> if (settings.idioma == "PT") "Ações rápidas" else "Quick actions"
                                "backup" -> if (settings.idioma == "PT") "Backup e dados" else "Backup & recovery"
                                "sobre" -> if (settings.idioma == "PT") "Sobre o app" else "About app"
                                else -> ""
                            },
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        when (activeMobileSection) {
                            "aparência" -> aparenciaCard()
                            "segurança" -> segurancaCard()
                            "ações_rápidas" -> acoesRapidasCard()
                            "backup" -> backupCard()
                            "sobre" -> sobreCard()
                        }
                    }
                }
            }
        }
    }


    // Modal logout all other sessions dialog
    if (showLogoutSessionsDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutSessionsDialog = false },
            title = {
                Text(
                    text = if (settings.idioma == "PT") "Encerrar Outras Sessões?" else "End Other Sessions?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = if (settings.idioma == "PT") 
                        "Deseja desconectar com segurança todos os outros dispositivos e navegadores que têm acesso à sua conta?" 
                        else "Do you want to securely disconnect all other devices and browsers that have access to your account?",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutSessionsDialog = false
                        Toast.makeText(
                            context,
                            if (settings.idioma == "PT") "Todas as outras sessões foram encerradas com sucesso!" else "All other sessions signed out successfully!",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (settings.idioma == "PT") "Sim, Encerrar" else "Yes, Sign Out",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutSessionsDialog = false }) {
                    Text(if (settings.idioma == "PT") "Cancelar" else "Cancel")
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    // Modal Edit Profile Dialog
    if (showProfileEditor) {
        Dialog(onDismissRequest = { showProfileEditor = false }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = if (settings.idioma == "PT") "Editar Perfil" else "Edit Profile",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Profile avatar interaction inside Dialog
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(themeColor.copy(alpha = 0.12f))
                            .border(2.dp, themeColor, CircleShape)
                            .clickable { profilePhotoLauncher.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        if (profilePhotoUriInput.isNotEmpty()) {
                            AsyncImage(
                                model = profilePhotoUriInput,
                                contentDescription = "Profile Photo",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Person,
                                contentDescription = null,
                                tint = themeColor,
                                modifier = Modifier.size(48.dp)
                            )
                        }

                        // Icon badge to select image
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.3f))
                        )
                        Icon(
                            imageVector = Icons.Rounded.CameraAlt,
                            contentDescription = "Edit photo",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Text(
                        text = if (settings.idioma == "PT") "Toque na imagem para escolher uma foto" else "Tap image to select a custom photo",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )

                    // Name input
                    OutlinedTextField(
                        value = profileNameInput,
                        onValueChange = { profileNameInput = it },
                        label = { Text(if (settings.idioma == "PT") "Nome" else "Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = themeColor,
                            focusedLabelColor = themeColor
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
                    ) {
                        TextButton(
                            onClick = {
                                profileNameInput = settings.name
                                profilePhotoUriInput = settings.photoURL
                                showProfileEditor = false
                            }
                        ) {
                            Text(if (settings.idioma == "PT") "Cancelar" else "Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Button(
                            onClick = {
                                viewModel.updateUserNameAndPhoto(profileNameInput, profilePhotoUriInput)
                                showProfileEditor = false
                                Toast.makeText(context, if (settings.idioma == "PT") "Perfil atualizado!" else "Profile updated!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (settings.idioma == "PT") "Guardar" else "Save", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Custom Color Dialog Picker
    if (showCustomColorDialog) {
        var hexInput by remember { mutableStateOf(settings.corPrimaria) }
        var redVal by remember { mutableStateOf(109) }
        var greenVal by remember { mutableStateOf(74) }
        var blueVal by remember { mutableStateOf(255) }

        LaunchedEffect(Unit) {
            try {
                val parsed = android.graphics.Color.parseColor(settings.corPrimaria)
                redVal = android.graphics.Color.red(parsed)
                greenVal = android.graphics.Color.green(parsed)
                blueVal = android.graphics.Color.blue(parsed)
                hexInput = settings.corPrimaria
            } catch (e: Exception) {
                // keep default
            }
        }

        Dialog(onDismissRequest = { showCustomColorDialog = false }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("custom_color_picker_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = if (settings.idioma == "PT") "Criar Cor Personalizada" else "Create Custom Color",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val previewColor = Color(redVal, greenVal, blueVal)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = previewColor)
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = String.format("#%02X%02X%02X", redVal, greenVal, blueVal),
                                color = if ((redVal * 0.299 + greenVal * 0.587 + blueVal * 0.114) > 186) Color.Black else Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (settings.idioma == "PT") "Vermelho (R)" else "Red (R)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Red
                                )
                                Text(text = redVal.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = redVal.toFloat(),
                                onValueChange = {
                                    redVal = it.toInt()
                                    hexInput = String.format("#%02X%02X%02X", redVal, greenVal, blueVal)
                                },
                                valueRange = 0f..255f,
                                colors = SliderDefaults.colors(
                                    thumbColor = Color.Red,
                                    activeTrackColor = Color.Red
                                )
                            )
                        }

                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (settings.idioma == "PT") "Verde (G)" else "Green (G)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                                Text(text = greenVal.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = greenVal.toFloat(),
                                onValueChange = {
                                    greenVal = it.toInt()
                                    hexInput = String.format("#%02X%02X%02X", redVal, greenVal, blueVal)
                                },
                                valueRange = 0f..255f,
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFF2E7D32),
                                    activeTrackColor = Color(0xFF2E7D32)
                                )
                            )
                        }

                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (settings.idioma == "PT") "Azul (B)" else "Blue (B)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Blue
                                )
                                Text(text = blueVal.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = blueVal.toFloat(),
                                onValueChange = {
                                    blueVal = it.toInt()
                                    hexInput = String.format("#%02X%02X%02X", redVal, greenVal, blueVal)
                                },
                                valueRange = 0f..255f,
                                colors = SliderDefaults.colors(
                                    thumbColor = Color.Blue,
                                    activeTrackColor = Color.Blue
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = hexInput,
                        onValueChange = { input ->
                            hexInput = input
                            try {
                                val cleanInput = if (input.startsWith("#")) input else "#$input"
                                if (cleanInput.length == 7) {
                                    val parsed = android.graphics.Color.parseColor(cleanInput)
                                    redVal = android.graphics.Color.red(parsed)
                                    greenVal = android.graphics.Color.green(parsed)
                                    blueVal = android.graphics.Color.blue(parsed)
                                }
                            } catch (e: Exception) {
                                // silent fail
                            }
                        },
                        label = { Text(if (settings.idioma == "PT") "Código Hexadecimal" else "Hexadecimal Code") },
                        placeholder = { Text("#RRGGBB") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showCustomColorDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (settings.idioma == "PT") "Cancelar" else "Cancel")
                        }

                        Button(
                            onClick = {
                                val cleanHex = if (hexInput.startsWith("#")) hexInput else "#$hexInput"
                                try {
                                    android.graphics.Color.parseColor(cleanHex)
                                    viewModel.updatePrimaryColor(cleanHex)
                                    showCustomColorDialog = false
                                } catch (e: Exception) {
                                    val errorMsg = if (settings.idioma == "PT") "Código hexadecimal inválido!" else "Invalid hexadecimal code!"
                                    Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1.5f),
                            colors = ButtonDefaults.buttonColors(containerColor = previewColor)
                        ) {
                            Text(
                                text = if (settings.idioma == "PT") "Aplicar Cor" else "Apply Color",
                                color = if ((redVal * 0.299 + greenVal * 0.587 + blueVal * 0.114) > 186) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal PIN setup Dialog
    if (showSecurityDialog) {
        var pin1 by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showSecurityDialog = false }) {
            Card(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (settings.idioma == "PT") "Configurar PIN de Segurança" else "Setup Security PIN", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(if (settings.idioma == "PT") "Digite 4 números para proteger o aplicativo no início:" else "Enter 4 numbers to protect the application on startup:", fontSize = 11.sp)
                    
                    OutlinedTextField(
                        value = pin1,
                        onValueChange = { if (it.length <= 4) pin1 = it },
                        label = { Text(if (settings.idioma == "PT") "Novo PIN (4 dígitos)" else "New PIN (4 digits)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (settings.pinHash.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    viewModel.updateSecurityPin("")
                                    showSecurityDialog = false
                                }
                            ) {
                                Text(if (settings.idioma == "PT") "Remover PIN" else "Remove PIN", color = MaterialTheme.colorScheme.error)
                            }
                        }
                        TextButton(onClick = { showSecurityDialog = false }) {
                            Text(if (settings.idioma == "PT") "Cancelar" else "Cancel")
                        }
                        Button(
                            onClick = {
                                if (pin1.length == 4) {
                                    viewModel.updateSecurityPin(pin1)
                                    showSecurityDialog = false
                                } else {
                                    val msg = if (settings.idioma == "PT") "O PIN deve conter exatamente 4 dígitos!" else "PIN must contain exactly 4 digits!"
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Text(if (settings.idioma == "PT") "Configurar" else "Setup")
                        }
                    }
                }
            }
        }
    }

    // Modal Category CRUD
    if (showCategoryCRUD) {
        Dialog(onDismissRequest = { showCategoryCRUD = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxHeight(0.85f).fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (settings.idioma == "PT") "Gerir Categorias" else "Manage Categories", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        IconButton(onClick = { showCategoryCRUD = false }) {
                            Icon(Icons.Rounded.Close, null)
                        }
                    }

                    // Adding new category Form
                    var nameCat by remember { mutableStateOf("") }
                    var selectedIconKey by remember { mutableStateOf("restaurant") }
                    var corCat by remember { mutableStateOf("#FF5722") }
                    var tipoCat by remember { mutableStateOf("Despesa") }
                    var limiteCat by remember { mutableStateOf("") }

                    // Auto-suggest icon based on name input
                    val effectiveIconKey = remember(nameCat, selectedIconKey) {
                        if (nameCat.isNotBlank() && selectedIconKey == "restaurant") {
                            com.example.util.AppIcons.normalizeIconKey(nameCat)
                        } else {
                            selectedIconKey
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (settings.idioma == "PT") "Adicionar Nova Categoria" else "Add New Category", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = nameCat,
                                    onValueChange = { nameCat = it },
                                    placeholder = { Text(if (settings.idioma == "PT") "Nome da categoria" else "Category name") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    com.example.util.AppIcon(
                                        iconKey = effectiveIconKey,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            Text(if (settings.idioma == "PT") "Escolha um Ícone:" else "Pick an Icon:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                            ) {
                                items(com.example.util.AppIcons.CATEGORY_ICONS) { iconItem ->
                                    val isSelected = selectedIconKey == iconItem.key || (selectedIconKey == "restaurant" && effectiveIconKey == iconItem.key)
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                                            .clickable { selectedIconKey = iconItem.key },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        com.example.util.AppIcon(
                                            iconKey = iconItem.key,
                                            contentDescription = iconItem.labelPt,
                                            tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(
                                        selected = tipoCat == "Despesa",
                                        onClick = { tipoCat = "Despesa" },
                                        label = { Text(if (settings.idioma == "PT") "Despesa" else "Expense") }
                                    )
                                    FilterChip(
                                        selected = tipoCat == "Injecao",
                                        onClick = { tipoCat = "Injecao" },
                                        label = { Text(if (settings.idioma == "PT") "Injeção" else "Inflow") }
                                    )
                                }

                                Button(
                                    onClick = {
                                        if (nameCat.isNotBlank()) {
                                            viewModel.addNewCategory(
                                                nome = nameCat,
                                                icone = effectiveIconKey,
                                                cor = corCat,
                                                tipo = tipoCat,
                                                limite = limiteCat.toDoubleOrNull() ?: 0.0
                                            )
                                            nameCat = ""
                                            selectedIconKey = "restaurant"
                                            limiteCat = ""
                                        }
                                    }
                                ) {
                                    Text(if (settings.idioma == "PT") "Guardar" else "Save", fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    var showActionDialogForCategory by remember { mutableStateOf<Category?>(null) }
                    var showEditCategoryDialog by remember { mutableStateOf<Category?>(null) }
                    var categoryToDeleteConfirm by remember { mutableStateOf<Category?>(null) }

                    // Categories lists
                    LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        items(categories, key = { it.id }) { cat ->
                            SwipeToDeleteContainer(
                                item = cat,
                                onDelete = { viewModel.deleteCategory(it) },
                                requireConfirmation = true,
                                modifier = Modifier.animateItem()
                            ) { category ->
                                Column {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .combinedClickable(
                                                onClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    showActionDialogForCategory = category
                                                },
                                                onLongClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    showActionDialogForCategory = category
                                                }
                                            )
                                            .testTag("category_item_${category.id}"),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                            com.example.util.AppIcon(
                                                iconKey = if (category.icone.isNotBlank()) category.icone else category.nome,
                                                contentDescription = category.nome,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Column {
                                                Text(category.nome, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text(
                                                    text = if (settings.idioma == "PT") category.tipo else (if (category.tipo == "Despesa") "Expense" else "Inflow"),
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                                )
                                            }
                                        }
     
                                        IconButton(onClick = { categoryToDeleteConfirm = category }) {
                                            Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                    Divider()
                                }
                            }
                        }
                    }

                    if (categoryToDeleteConfirm != null) {
                        val cat = categoryToDeleteConfirm!!
                        AlertDialog(
                            onDismissRequest = { categoryToDeleteConfirm = null },
                            title = { Text(if (settings.idioma == "PT") "Eliminar Categoria" else "Delete Category") },
                            text = { Text(if (settings.idioma == "PT") "Tem a certeza que deseja eliminar a categoria \"${cat.nome}\"? Os lançamentos associados passarão a ficar sem categoria definida." else "Are you sure you want to delete the category \"${cat.nome}\"? Associated transactions will no longer have a category.") },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        viewModel.deleteCategory(cat)
                                        categoryToDeleteConfirm = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Text(if (settings.idioma == "PT") "Eliminar" else "Delete")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { categoryToDeleteConfirm = null }) {
                                    Text(if (settings.idioma == "PT") "Cancelar" else "Cancel")
                                }
                            }
                        )
                    }

                    if (showActionDialogForCategory != null) {
                        val c = showActionDialogForCategory!!
                        Dialog(onDismissRequest = { showActionDialogForCategory = null }) {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(if (settings.idioma == "PT") "Opções da Categoria" else "Category Options", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text(c.nome, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                    
                                    Divider()

                                    Button(
                                        onClick = {
                                            showEditCategoryDialog = c
                                            showActionDialogForCategory = null
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Rounded.Edit, null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(if (settings.idioma == "PT") "Editar" else "Edit")
                                    }

                                    Button(
                                        onClick = {
                                            categoryToDeleteConfirm = c
                                            showActionDialogForCategory = null
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Rounded.Delete, null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(if (settings.idioma == "PT") "Eliminar" else "Delete")
                                    }
                                }
                            }
                        }
                    }

                    if (showEditCategoryDialog != null) {
                        EditCategoryDialog(
                            category = showEditCategoryDialog!!,
                            settings = settings,
                            onDismiss = { showEditCategoryDialog = null },
                            onConfirm = { viewModel.updateCategory(it) }
                        )
                    }
                }
            }
        }
    }

    // Modal Recycle Bin (Lixeira) list
    if (showLixeiraDialog) {
        Dialog(onDismissRequest = { showLixeiraDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxHeight(0.8f).fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (settings.idioma == "PT") "Recipientes Excluídos (Lixeira)" else "Deleted Items (Recycle Bin)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        IconButton(onClick = { showLixeiraDialog = false }) {
                            Icon(Icons.Rounded.Close, null)
                        }
                    }

                    Text(
                        text = if (settings.idioma == "PT") "Todos os lançamentos abaixo foram movidos para a lixeira. Pode restaurá-los com facilidade para a sua carteira, mantendo os saldos actualizados." else "All transactions below have been moved to the recycle bin. You can easily restore them to your wallet, keeping balances updated.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        if (trashItems.isEmpty()) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text(if (settings.idioma == "PT") "Lixeira vazia." else "Recycle Bin is empty.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                }
                            }
                        } else {
                            items(trashItems, key = { it.id }) { item ->
                                val dateDel = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(item.dataExclusao))
                                
                                SwipeToDeleteContainer(
                                    item = item,
                                    onDelete = { viewModel.deleteTrashPermanently(it) },
                                    requireConfirmation = true,
                                    modifier = Modifier.animateItem()
                                ) { trashItem ->
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text((if (settings.idioma == "PT") "Lançamento ID: " else "Transaction ID: ") + "${trashItem.transacaoOriginalId}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text((if (settings.idioma == "PT") "Excluído em: " else "Deleted on: ") + "$dateDel", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                            }
    
                                            Row {
                                                IconButton(onClick = { viewModel.restoreTransaction(trashItem) }) {
                                                    Icon(Icons.Rounded.Restore, if (settings.idioma == "PT") "Restaurar" else "Restore", tint = Color(0xFF2E7D32))
                                                }
                                                IconButton(onClick = { viewModel.deleteTrashPermanently(trashItem) }) {
                                                    Icon(Icons.Rounded.Delete, if (settings.idioma == "PT") "Eliminar" else "Delete", tint = MaterialTheme.colorScheme.error)
                                                }
                                            }
                                        }
                                        Divider()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showOnboardingTutorial) {
        Dialog(onDismissRequest = { showOnboardingTutorial = false }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("onboarding_tutorial_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (settings.idioma == "PT") "Guia Rápido de Utilização" else "Quick Onboarding Guide",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("1", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                            }
                            Column {
                                Text(if (settings.idioma == "PT") "Adicionar Lançamentos" else "Add Transactions", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(if (settings.idioma == "PT") "Use o botão '+' no menu para registar despesas e receitas instantaneamente com feedback tátil." else "Use the '+' button on the menu to record expenses and incomes instantly with haptic feedback.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("2", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                            }
                            Column {
                                Text(if (settings.idioma == "PT") "Gerir Contas & Limites" else "Manage Accounts & Limits", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(if (settings.idioma == "PT") "Configure carteiras e defina limites para o seu orçamento mensal de forma simples." else "Configure wallets and define simple monthly budget limits to safeguard your goals.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("3", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                            }
                            Column {
                                Text(if (settings.idioma == "PT") "Relatórios & Simulador" else "Reports & Simulator", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(if (settings.idioma == "PT") "Exporte em PDF/Planilha ou use o novo Simulador de Juros para projetar o futuro." else "Export to PDF/Spreadsheet or use the new Interest Simulator to project your future growth.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { showOnboardingTutorial = false },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("onboarding_tutorial_close_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (settings.idioma == "PT") "Entendido!" else "Got it!", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditCategoryDialog(
    category: Category,
    settings: UserSettings,
    onDismiss: () -> Unit,
    onConfirm: (Category) -> Unit
) {
    var nome by remember { mutableStateOf(category.nome) }
    var icone by remember { mutableStateOf(category.icone) }
    var cor by remember { mutableStateOf(category.cor) }
    var tipo by remember { mutableStateOf(category.tipo) }
    var limiteStr by remember { mutableStateOf(category.limiteMensal.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(if (settings.idioma == "PT") "Editar Categoria" else "Edit Category", fontWeight = FontWeight.Bold, fontSize = 18.sp)

                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text(if (settings.idioma == "PT") "Nome da Categoria" else "Category Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = icone,
                    onValueChange = { icone = it },
                    label = { Text(if (settings.idioma == "PT") "Emoji Ícone" else "Emoji Icon") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = cor,
                    onValueChange = { cor = it },
                    label = { Text(if (settings.idioma == "PT") "Cor Hex" else "Hex Color") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = tipo == "Despesa",
                        onClick = { tipo = "Despesa" },
                        label = { Text(if (settings.idioma == "PT") "Despesa" else "Expense") }
                    )
                    FilterChip(
                        selected = tipo == "Injecao",
                        onClick = { tipo = "Injecao" },
                        label = { Text(if (settings.idioma == "PT") "Injeção" else "Inflow") }
                    )
                }

                OutlinedTextField(
                    value = limiteStr,
                    onValueChange = { limiteStr = it },
                    label = { Text(if (settings.idioma == "PT") "Limite Mensal (MZN)" else "Monthly Limit (MZN)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(if (settings.idioma == "PT") "Cancelar" else "Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val lim = limiteStr.toDoubleOrNull() ?: category.limiteMensal
                            if (nome.isNotBlank()) {
                                val updated = category.copy(
                                    nome = nome,
                                    icone = icone,
                                    cor = cor,
                                    tipo = tipo,
                                    limiteMensal = lim
                                )
                                onConfirm(updated)
                                onDismiss()
                            }
                        }
                    ) {
                        Text(if (settings.idioma == "PT") "Guardar" else "Save")
                    }
                }
            }
        }
    }
}
