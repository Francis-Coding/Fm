package com.example.ui

import com.example.data.model.ExportedReport

import android.widget.Toast
import java.io.File
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class PeriodMode {
    MENSAL, SEMANAL, TRIMESTRAL, ANO_PASSADO, COMPLETO, PERSONALIZADO
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RelatoriosDashboardScreen(
    viewModel: MainViewModel,
    transactions: List<Transaction>,
    categories: List<Category>,
    wallets: List<Wallet>,
    settings: UserSettings,
    initialTab: Int = 0
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val idioma = settings.idioma
    val mo = settings.moedaPadrao

    val goals by viewModel.goals.collectAsState()
    val subscriptions by viewModel.subscriptions.collectAsState()

    // Period Mode State
    var periodMode by remember { mutableStateOf(PeriodMode.MENSAL) }

    // Month / Year state for Mensal mode
    val calendar = remember { Calendar.getInstance() }
    var selectedYear by remember { mutableIntStateOf(calendar.get(Calendar.YEAR)) }
    var selectedMonth by remember { mutableIntStateOf(calendar.get(Calendar.MONTH)) } // 0-indexed
    var showMonthPickerModal by remember { mutableStateOf(false) }

    // Custom Date Range state
    var customStartDate by remember {
        mutableLongStateOf(
            Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, -30)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }.timeInMillis
        )
    }
    var customEndDate by remember {
        mutableLongStateOf(
            Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23)
                set(Calendar.MINUTE, 59)
                set(Calendar.SECOND, 59)
            }.timeInMillis
        )
    }
    var showCustomRangePickerModal by remember { mutableStateOf(false) }

    // Tab Index for scrolling
    var selectedTabIndex by remember(initialTab) { mutableIntStateOf(initialTab) }

    // Interactive Modals State
    var showHealthAnalysisModal by remember { mutableStateOf(false) }
    var showCategoryDetailsModal by remember { mutableStateOf(false) }
    var showSubscriptionsModal by remember { mutableStateOf(false) }
    var subscriptionModalInitialEditId by remember { mutableStateOf<Int?>(null) }
    var showExportHistoryModal by remember { mutableStateOf(false) }
    var showIncomeDetailsModal by remember { mutableStateOf(false) }
    var showExpenseDetailsModal by remember { mutableStateOf(false) }
    var showBalanceDetailsModal by remember { mutableStateOf(false) }
    var showSavingsInfoModal by remember { mutableStateOf(false) }
    var showExportModal by remember { mutableStateOf(false) }

    // Start/End timestamps for Selected Month
    val selectedMonthStart = remember(selectedYear, selectedMonth) {
        Calendar.getInstance().apply {
            set(Calendar.YEAR, selectedYear)
            set(Calendar.MONTH, selectedMonth)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val selectedMonthEnd = remember(selectedYear, selectedMonth) {
        Calendar.getInstance().apply {
            set(Calendar.YEAR, selectedYear)
            set(Calendar.MONTH, selectedMonth)
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }.timeInMillis
    }

    // Filtered Transactions based on Selected Period Mode
    val periodTransactions = remember(transactions, periodMode, selectedYear, selectedMonth, customStartDate, customEndDate) {
        when (periodMode) {
            PeriodMode.COMPLETO -> transactions.filter { !it.ajusteCaixa }
            PeriodMode.SEMANAL -> {
                val start = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -6)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                transactions.filter { it.data >= start && !it.ajusteCaixa }
            }
            PeriodMode.MENSAL -> {
                transactions.filter { it.data in selectedMonthStart..selectedMonthEnd && !it.ajusteCaixa }
            }
            PeriodMode.TRIMESTRAL -> {
                val start = Calendar.getInstance().apply {
                    add(Calendar.MONTH, -3)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                transactions.filter { it.data >= start && !it.ajusteCaixa }
            }
            PeriodMode.ANO_PASSADO -> {
                val prevYear = Calendar.getInstance().get(Calendar.YEAR) - 1
                val start = Calendar.getInstance().apply {
                    set(Calendar.YEAR, prevYear)
                    set(Calendar.MONTH, Calendar.JANUARY)
                    set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val end = Calendar.getInstance().apply {
                    set(Calendar.YEAR, prevYear)
                    set(Calendar.MONTH, Calendar.DECEMBER)
                    set(Calendar.DAY_OF_MONTH, 31)
                    set(Calendar.HOUR_OF_DAY, 23)
                    set(Calendar.MINUTE, 59)
                    set(Calendar.SECOND, 59)
                    set(Calendar.MILLISECOND, 999)
                }.timeInMillis
                transactions.filter { it.data in start..end && !it.ajusteCaixa }
            }
            PeriodMode.PERSONALIZADO -> {
                transactions.filter { it.data in customStartDate..customEndDate && !it.ajusteCaixa }
            }
        }
    }

    // Previous Period Transactions for Trend Comparisons
    val lastPeriodTransactions = remember(transactions, periodMode, selectedMonthStart, customStartDate, customEndDate) {
        when (periodMode) {
            PeriodMode.MENSAL -> {
                val lastMonthStart = Calendar.getInstance().apply {
                    set(Calendar.YEAR, selectedYear)
                    set(Calendar.MONTH, selectedMonth)
                    add(Calendar.MONTH, -1)
                    set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                }.timeInMillis
                transactions.filter { it.data in lastMonthStart until selectedMonthStart && !it.ajusteCaixa }
            }
            PeriodMode.SEMANAL -> {
                // O período atual começa em "hoje 00:00 − 6 dias" (ver periodTransactions
                // acima). O período anterior tem de terminar exatamente nesse instante —
                // caso contrário fica um dia "órfão" que não entra em nenhum dos dois
                // períodos, distorcendo a comparação percentual.
                val end = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, -6)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val start = end - (7L * 24 * 60 * 60 * 1000)
                transactions.filter { it.data in start until end && !it.ajusteCaixa }
            }
            PeriodMode.PERSONALIZADO -> {
                val duration = (customEndDate - customStartDate).coerceAtLeast(1L)
                val start = customStartDate - duration
                transactions.filter { it.data in start until customStartDate && !it.ajusteCaixa }
            }
            PeriodMode.TRIMESTRAL -> {
                // Mesma lógica: o anterior termina exatamente onde o atual começa.
                val end = Calendar.getInstance().apply {
                    add(Calendar.MONTH, -3)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val start = Calendar.getInstance().apply {
                    add(Calendar.MONTH, -6)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                transactions.filter { it.data in start until end && !it.ajusteCaixa }
            }
            PeriodMode.ANO_PASSADO -> {
                val yearBeforeLast = Calendar.getInstance().get(Calendar.YEAR) - 2
                val start = Calendar.getInstance().apply {
                    set(Calendar.YEAR, yearBeforeLast)
                    set(Calendar.MONTH, Calendar.JANUARY)
                    set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                }.timeInMillis
                val end = Calendar.getInstance().apply {
                    set(Calendar.YEAR, yearBeforeLast)
                    set(Calendar.MONTH, Calendar.DECEMBER)
                    set(Calendar.DAY_OF_MONTH, 31)
                    set(Calendar.HOUR_OF_DAY, 23)
                    set(Calendar.MINUTE, 59)
                }.timeInMillis
                transactions.filter { it.data in start..end && !it.ajusteCaixa }
            }
            PeriodMode.COMPLETO -> emptyList()
        }
    }

    // Dynamic Calculations
    val periodStart = remember(periodMode, selectedMonthStart, customStartDate, periodTransactions) {
        when (periodMode) {
            PeriodMode.MENSAL -> selectedMonthStart
            PeriodMode.PERSONALIZADO -> customStartDate
            PeriodMode.SEMANAL -> System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
            PeriodMode.TRIMESTRAL -> System.currentTimeMillis() - 90L * 24 * 60 * 60 * 1000
            PeriodMode.ANO_PASSADO -> {
                val prevYear = Calendar.getInstance().get(Calendar.YEAR) - 1
                Calendar.getInstance().apply {
                    set(Calendar.YEAR, prevYear)
                    set(Calendar.MONTH, Calendar.JANUARY)
                    set(Calendar.DAY_OF_MONTH, 1)
                }.timeInMillis
            }
            PeriodMode.COMPLETO -> if (periodTransactions.isNotEmpty()) periodTransactions.minOf { it.data } else System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
        }
    }
    val periodEnd = remember(periodMode, selectedMonthEnd, customEndDate, periodTransactions) {
        when (periodMode) {
            PeriodMode.MENSAL -> selectedMonthEnd
            PeriodMode.PERSONALIZADO -> customEndDate
            PeriodMode.SEMANAL -> System.currentTimeMillis()
            PeriodMode.TRIMESTRAL -> System.currentTimeMillis()
            PeriodMode.ANO_PASSADO -> {
                val prevYear = Calendar.getInstance().get(Calendar.YEAR) - 1
                Calendar.getInstance().apply {
                    set(Calendar.YEAR, prevYear)
                    set(Calendar.MONTH, Calendar.DECEMBER)
                    set(Calendar.DAY_OF_MONTH, 31)
                    set(Calendar.HOUR_OF_DAY, 23)
                    set(Calendar.MINUTE, 59)
                }.timeInMillis
            }
            PeriodMode.COMPLETO -> if (periodTransactions.isNotEmpty()) periodTransactions.maxOf { it.data } else System.currentTimeMillis()
        }
    }

    // Arredondado ao cêntimo já na agregação (não apenas na exibição), para que Saldo =
    // Receita − Despesa nunca divirja do que é mostrado nos três cartões por causa de
    // arredondamentos independentes a jusante (cada valor sendo arredondado separadamente
    // a partir do Double bruto na hora de formatar).
    val receitas = remember(periodTransactions) {
        Math.round(periodTransactions.filter { it.isReceita() }.sumOf { it.valor } * 100) / 100.0
    }
    val despesas = remember(periodTransactions) {
        Math.round(periodTransactions.filter { it.isDespesa() }.sumOf { it.valor } * 100) / 100.0
    }
    val saldoWallets = remember(wallets) { wallets.sumOf { it.saldoAtual } }
    val saldoPeriodo = receitas - despesas

    val receitasAnteriores = remember(lastPeriodTransactions) {
        Math.round(lastPeriodTransactions.filter { it.isReceita() }.sumOf { it.valor } * 100) / 100.0
    }
    val despesasAnteriores = remember(lastPeriodTransactions) {
        Math.round(lastPeriodTransactions.filter { it.isDespesa() }.sumOf { it.valor } * 100) / 100.0
    }
    val saldoAnterior = receitasAnteriores - despesasAnteriores

    // Quando o valor anterior é 0 mas agora há movimento, isso é uma variação real (não
    // "sem variação") — tratamos como +100% em vez de mascarar com 0%.
    val varReceitas = when {
        receitasAnteriores > 0 -> ((receitas - receitasAnteriores) / receitasAnteriores) * 100
        receitas > 0 -> 100.0
        else -> 0.0
    }
    val varDespesas = when {
        despesasAnteriores > 0 -> ((despesas - despesasAnteriores) / despesasAnteriores) * 100
        despesas > 0 -> 100.0
        else -> 0.0
    }
    val varSaldo = if (saldoAnterior != 0.0) ((saldoPeriodo - saldoAnterior) / Math.abs(saldoAnterior)) * 100.0 else if (saldoPeriodo > 0) 100.0 else 0.0

    // Défice (despesas > receitas) tem de aparecer como poupança negativa, não ficar
    // escondido em 0% — coerceIn(0,100) anterior mascarava esse cenário por completo.
    val poupanca = if (receitas > 0) (((receitas - despesas) / receitas) * 100).toInt().coerceIn(-100, 100) else 0

    // Format numbers
    val formatNumber = remember {
        { num: Double ->
            String.format(Locale.getDefault(), "%,.2f", num)
                .replace(",", "X")
                .replace(".", ",")
                .replace("X", ".")
        }
    }

    val formatVar = { vari: Double -> if (vari >= 0) "↑ +${vari.toInt()}% (vs. ant.)" else "↓ -${(-vari).toInt()}% (vs. ant.)" }
    val colorVar = { vari: Double, invert: Boolean ->
        if ((vari >= 0) xor invert) Color(0xFF10B981) else Color(0xFFEF4444)
    }

    // Display string for active period
    val periodLabelText = remember(periodMode, selectedYear, selectedMonth, customStartDate, customEndDate, idioma) {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        when (periodMode) {
            PeriodMode.COMPLETO -> if (idioma == "PT") "Todo o Período" else "All Time"
            PeriodMode.SEMANAL -> if (idioma == "PT") "Últimos 7 dias" else "Last 7 days"
            PeriodMode.TRIMESTRAL -> if (idioma == "PT") "Últimos 3 meses" else "Last 3 months"
            PeriodMode.ANO_PASSADO -> {
                val prevYear = Calendar.getInstance().get(Calendar.YEAR) - 1
                if (idioma == "PT") "Ano de $prevYear" else "Year $prevYear"
            }
            PeriodMode.MENSAL -> {
                val cal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, selectedYear)
                    set(Calendar.MONTH, selectedMonth)
                }
                val fmt = SimpleDateFormat(if (idioma == "PT") "MMMM 'de' yyyy" else "MMMM yyyy", Locale.forLanguageTag(if (idioma == "PT") "pt" else "en"))
                fmt.format(cal.time).replaceFirstChar { it.uppercase() }
            }
            PeriodMode.PERSONALIZADO -> "${dateFormat.format(Date(customStartDate))} - ${dateFormat.format(Date(customEndDate))}"
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Header
        item {
            HeaderSection(
                idioma = idioma,
                periodText = periodLabelText,
                onPeriodClick = {
                    if (periodMode == PeriodMode.MENSAL) showMonthPickerModal = true
                    else if (periodMode == PeriodMode.PERSONALIZADO) showCustomRangePickerModal = true
                    else {
                        // Semanal/Trimestral/Ano Passado/Completo têm um intervalo fixo (não há o
                        // que escolher), mas o chip parece clicável — em vez de não reagir, mostra
                        // as datas exatas do período atual.
                        val df = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        val rangeText = "${df.format(Date(periodStart))} - ${df.format(Date(periodEnd))}"
                        Toast.makeText(context, rangeText, Toast.LENGTH_SHORT).show()
                    }
                },
                onExportClick = { showExportModal = true }
            )
        }

        // Period Selector Bar
        item {
            PeriodSelectorBar(
                idioma = idioma,
                activeMode = periodMode,
                onSelectMode = { mode ->
                    periodMode = mode
                    if (mode == PeriodMode.MENSAL) showMonthPickerModal = true
                    if (mode == PeriodMode.PERSONALIZADO) showCustomRangePickerModal = true
                }
            )
        }

        // Category/Section Navigation Tabs
        item {
            SegmentedButtons(
                idioma = idioma,
                selectedIndex = selectedTabIndex,
                onSelectIndex = { index ->
                    selectedTabIndex = index
                    coroutineScope.launch {
                        listState.animateScrollToItem(0)
                    }
                }
            )
        }

        when (selectedTabIndex) {
            0 -> {
                // Tab 0: Visão Geral (Summary, Cashflow, Expenses Donut, Simulator)
                item {
                    SummaryGrid(
                        idioma = idioma,
                        receitasStr = formatNumber(receitas),
                        despesasStr = formatNumber(despesas),
                        saldoPeriodoStr = formatNumber(saldoPeriodo),
                        saldoWalletsStr = formatNumber(saldoWallets),
                        saldoPeriodoVal = saldoPeriodo,
                        poupanca = poupanca,
                        mo = mo,
                        varRecText = formatVar(varReceitas),
                        varRecColor = colorVar(varReceitas, false),
                        varDesText = formatVar(varDespesas),
                        varDesColor = colorVar(varDespesas, true),
                        varSalText = formatVar(varSaldo),
                        varSalColor = colorVar(varSaldo, false),
                        onIncomeClick = { showIncomeDetailsModal = true },
                        onExpenseClick = { showExpenseDetailsModal = true },
                        onBalanceClick = { showBalanceDetailsModal = true },
                        onSavingsClick = { showSavingsInfoModal = true }
                    )
                }

                item {
                    CashFlowCard(
                        idioma = idioma,
                        transactions = periodTransactions,
                        mo = mo,
                        startDate = periodStart,
                        endDate = periodEnd
                    )
                }

                item {
                    ExpenseDistributionCard(
                        idioma = idioma,
                        transactions = periodTransactions,
                        categories = categories,
                        mo = mo,
                        onViewDetails = { showCategoryDetailsModal = true }
                    )
                }

                item {
                    SimulatorCard(idioma = idioma, mo = mo)
                }
            }

            1 -> {
                // Tab 1: Saúde Financeira
                item {
                    HealthCard(
                        idioma = idioma,
                        transactions = transactions,
                        wallets = wallets,
                        categories = categories,
                        goals = goals,
                        onViewFullAnalysis = { showHealthAnalysisModal = true }
                    )
                }
            }

            2 -> {
                // Tab 2: Recorrentes (Subscrições e Contas Recorrentes)
                item {
                    SubscriptionsCard(
                        idioma = idioma,
                        mo = mo,
                        subscriptions = subscriptions,
                        onManageSubscriptions = { showSubscriptionsModal = true },
                        onSubscriptionClick = { sub ->
                            subscriptionModalInitialEditId = sub.id
                            showSubscriptionsModal = true
                        }
                    )
                }
            }
        }
    }

    // Modal Month Picker
    if (showMonthPickerModal) {
        MonthPickerModal(
            idioma = idioma,
            currentYear = selectedYear,
            currentMonth = selectedMonth,
            onDismiss = { showMonthPickerModal = false },
            onSelect = { year, month ->
                selectedYear = year
                selectedMonth = month
                showMonthPickerModal = false
            }
        )
    }

    // Modal Custom Range Picker
    if (showCustomRangePickerModal) {
        CustomRangePickerModal(
            idioma = idioma,
            startDate = customStartDate,
            endDate = customEndDate,
            onDismiss = { showCustomRangePickerModal = false },
            onConfirm = { start, end ->
                customStartDate = start
                customEndDate = end
                showCustomRangePickerModal = false
            }
        )
    }

    // Modal Health Analysis
    if (showHealthAnalysisModal) {
        HealthAnalysisModal(
            idioma = idioma,
            mo = mo,
            transactions = transactions,
            wallets = wallets,
            categories = categories,
            goals = goals,
            onDismiss = { showHealthAnalysisModal = false }
        )
    }

    // Modal Category Details
    if (showCategoryDetailsModal) {
        CategoryDetailsModal(
            idioma = idioma,
            mo = mo,
            transactions = periodTransactions,
            categories = categories,
            onDismiss = { showCategoryDetailsModal = false }
        )
    }

    // Modal Subscriptions Manager
    if (showSubscriptionsModal) {
        SubscriptionsManagerModal(
            idioma = idioma,
            mo = mo,
            subscriptions = subscriptions,
            viewModel = viewModel,
            initialEditSubscriptionId = subscriptionModalInitialEditId,
            onDismiss = {
                showSubscriptionsModal = false
                subscriptionModalInitialEditId = null
            }
        )
    }

    // Modal Export History
    if (showExportHistoryModal) {
        val exportedReports by viewModel.exportedReports.collectAsState()
        ExportHistoryModal(
            idioma = idioma,
            reports = exportedReports,
            onDeleteReport = { viewModel.deleteExportedReport(it) },
            onDismiss = { showExportHistoryModal = false }
        )
    }

    // Income Transactions Modal
    if (showIncomeDetailsModal) {
        TransactionsListModal(
            title = if (idioma == "PT") "Detalhamento de Receitas" else "Income Breakdown",
            idioma = idioma,
            mo = mo,
            transactions = periodTransactions.filter { it.isReceita() },
            categories = categories,
            onDismiss = { showIncomeDetailsModal = false }
        )
    }

    // Expense Transactions Modal
    if (showExpenseDetailsModal) {
        TransactionsListModal(
            title = if (idioma == "PT") "Detalhamento de Despesas" else "Expense Breakdown",
            idioma = idioma,
            mo = mo,
            transactions = periodTransactions.filter { it.isDespesa() },
            categories = categories,
            onDismiss = { showExpenseDetailsModal = false }
        )
    }

    // Balance/Wallets Modal
    if (showBalanceDetailsModal) {
        WalletsListModal(
            idioma = idioma,
            mo = mo,
            wallets = wallets,
            onDismiss = { showBalanceDetailsModal = false }
        )
    }

    // Savings Info Modal
    if (showSavingsInfoModal) {
        SavingsInfoModal(
            idioma = idioma,
            mo = mo,
            receitas = receitas,
            despesas = despesas,
            poupanca = poupanca,
            onDismiss = { showSavingsInfoModal = false }
        )
    }

    // Export Modal
    if (showExportModal) {
        AlertDialog(
            onDismissRequest = { showExportModal = false },
            title = {
                Text(
                    text = if (idioma == "PT") "Exportar Relatório" else "Export Report",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (idioma == "PT") "Escolha o formato para exportar $periodLabelText:" else "Choose format to export $periodLabelText:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.savePdfReportToDownloads(customTransactions = periodTransactions, periodName = periodLabelText)
                                showExportModal = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Outlined.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PDF", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                viewModel.saveXlsxReportToDownloads(customTransactions = periodTransactions)
                                showExportModal = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Outlined.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("XLSX", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                viewModel.saveCsvReportToDownloads(customTransactions = periodTransactions)
                                showExportModal = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Outlined.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("CSV", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                viewModel.saveZipReportToDownloads(customTransactions = periodTransactions)
                                showExportModal = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Outlined.FolderZip, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ZIP", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = {
                            showExportModal = false
                            showExportHistoryModal = true
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(
                            text = if (idioma == "PT") "Histórico de relatórios >" else "Report history >",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showExportModal = false }) {
                    Text(if (idioma == "PT") "Fechar" else "Close")
                }
            }
        )
    }
}

@Composable
fun HeaderSection(
    idioma: String,
    periodText: String,
    onPeriodClick: () -> Unit,
    onExportClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (idioma == "PT") "Relatórios" else "Reports",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (idioma == "PT") "Análise interativa e controle total do seu patrimônio" else "Interactive analysis and total control of your assets",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onExportClick)
            ) {
                Box(
                    modifier = Modifier.size(38.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FileDownload,
                        contentDescription = if (idioma == "PT") "Exportar" else "Export",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onPeriodClick)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DateRange,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = periodText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PeriodSelectorBar(
    idioma: String,
    activeMode: PeriodMode,
    onSelectMode: (PeriodMode) -> Unit
) {
    val modes = remember(idioma) {
        listOf(
            Pair(PeriodMode.MENSAL, if (idioma == "PT") "Mensal" else "Monthly"),
            Pair(PeriodMode.SEMANAL, if (idioma == "PT") "Semanal" else "Weekly"),
            Pair(PeriodMode.TRIMESTRAL, if (idioma == "PT") "Trimestre" else "Quarter"),
            Pair(PeriodMode.ANO_PASSADO, if (idioma == "PT") "Ano Pas." else "Last Year"),
            Pair(PeriodMode.COMPLETO, if (idioma == "PT") "Completo" else "All Time"),
            Pair(PeriodMode.PERSONALIZADO, if (idioma == "PT") "Custom" else "Custom")
        )
    }

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(modes.size) { index ->
            val (mode, label) = modes[index]
            val isSelected = activeMode == mode

            val bgColor by animateColorAsState(
                targetValue = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                animationSpec = tween(200), label = "periodBg"
            )
            val textColor by animateColorAsState(
                targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                animationSpec = tween(200), label = "periodText"
            )

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = bgColor,
                border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelectMode(mode) }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = textColor,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun SegmentedButtons(idioma: String, selectedIndex: Int, onSelectIndex: (Int) -> Unit) {
    val options = remember(idioma) {
        listOf(
            Pair(if (idioma == "PT") "Visão Geral" else "Overview", Icons.Rounded.Home),
            Pair(if (idioma == "PT") "Saúde Financeira" else "Financial Health", Icons.Rounded.FavoriteBorder),
            Pair(if (idioma == "PT") "Recorrentes" else "Recurring", Icons.Rounded.Subscriptions)
        )
    }

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(options.size) { index ->
            val (label, icon) = options[index]
            val isSelected = index == selectedIndex

            val bgColor by animateColorAsState(
                targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                animationSpec = tween(200), label = "segmentBg"
            )

            val contentColor by animateColorAsState(
                targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                animationSpec = tween(200), label = "segmentContent"
            )

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = bgColor,
                border = if (!isSelected) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelectIndex(index) }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = contentColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = contentColor
                    )
                }
            }
        }
    }
}

@Composable
fun SummaryGrid(
    idioma: String,
    receitasStr: String,
    despesasStr: String,
    saldoPeriodoStr: String,
    saldoWalletsStr: String,
    saldoPeriodoVal: Double,
    poupanca: Int,
    mo: String,
    varRecText: String,
    varRecColor: Color,
    varDesText: String,
    varDesColor: Color,
    varSalText: String,
    varSalColor: Color,
    onIncomeClick: () -> Unit,
    onExpenseClick: () -> Unit,
    onBalanceClick: () -> Unit,
    onSavingsClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SummaryCard(
                title = if (idioma == "PT") "Receitas" else "Income",
                value = receitasStr,
                currency = mo,
                valueColor = Color(0xFF10B981),
                trendText = varRecText,
                trendColor = varRecColor,
                subtitle = if (idioma == "PT") "Toque para ver lista" else "Tap to view list",
                onClick = onIncomeClick
            )
            SummaryCard(
                title = if (idioma == "PT") "Resultado do Período" else "Net Cash Flow",
                value = saldoPeriodoStr,
                currency = mo,
                valueColor = if (saldoPeriodoVal >= 0) Color(0xFF10B981) else Color(0xFFEF4444),
                trendText = varSalText,
                trendColor = varSalColor,
                subtitle = if (idioma == "PT") "Saldo Carteiras: $mo $saldoWalletsStr" else "Wallet Total: $mo $saldoWalletsStr",
                onClick = onBalanceClick
            )
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SummaryCard(
                title = if (idioma == "PT") "Despesas" else "Expenses",
                value = despesasStr,
                currency = mo,
                valueColor = Color(0xFFEF4444),
                trendText = varDesText,
                trendColor = varDesColor,
                subtitle = if (idioma == "PT") "Toque para ver lista" else "Tap to view list",
                onClick = onExpenseClick
            )
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onSavingsClick),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (idioma == "PT") "Poupança" else "Savings",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Icon(
                            Icons.Rounded.Info,
                            contentDescription = null,
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    val poupancaColor = if (poupanca < 0) Color(0xFFEF4444) else Color(0xFFF59E0B)
                    Text(
                        text = "$poupanca%",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = poupancaColor
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (poupanca < 0) {
                            if (idioma == "PT") "Défice: despesas acima das receitas" else "Deficit: expenses above income"
                        } else {
                            if (idioma == "PT") "Meta ideal: 30%" else "Target: 30%"
                        },
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { (poupanca / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = poupancaColor,
                        trackColor = if (poupanca < 0) Color(0xFFFEE2E2) else Color(0xFFFEF3C7)
                    )
                }
            }
        }
    }
}

@Composable
fun SummaryCard(
    title: String,
    value: String,
    currency: String,
    valueColor: Color,
    trendText: String,
    trendColor: Color,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(
                    Icons.Rounded.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = valueColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = currency,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = valueColor,
                    modifier = Modifier.padding(bottom = 3.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = trendText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = trendColor
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun HealthCard(
    idioma: String,
    transactions: List<Transaction>,
    wallets: List<Wallet>,
    categories: List<Category>,
    goals: List<FinancialGoal>,
    onViewFullAnalysis: () -> Unit
) {
    val healthData = remember(transactions, wallets, categories, goals, idioma) {
        com.example.util.FinancialHealthCalculator.calculate(transactions, wallets, categories, goals, idioma)
    }

    val healthScore = healthData.score
    val scoreStatusText = healthData.status
    val scoreColor = healthData.color

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onViewFullAnalysis),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (idioma == "PT") "Saúde Financeira" else "Financial Health",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(20.dp))

            // Gauge Chart — dividido nos 4 fatores que compõem a pontuação (Poupança/Reserva/
            // Limites/Metas, que somam 30+35+20+15=100 pts), em vez de um arco de cor única. Assim
            // dá para ver de relance qual fator está a puxar a nota para baixo, sem precisar tocar.
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(180.dp)
            ) {
                val savingsColor = Color(0xFF10B981)
                val emergencyColor = Color(0xFF3B82F6)
                val limitsColor = Color(0xFFF59E0B)
                val goalsColor = Color(0xFF8B5CF6)

                val animatedSavings by animateFloatAsState(180f * (healthData.savingsRateScore / 100f), tween(1000), label = "s1")
                val animatedEmergency by animateFloatAsState(180f * (healthData.emergencyFundScore / 100f), tween(1000), label = "s2")
                val animatedLimits by animateFloatAsState(180f * (healthData.limitsScore / 100f), tween(1000), label = "s3")
                val animatedGoals by animateFloatAsState(180f * (healthData.goalsScore / 100f), tween(1000), label = "s4")

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 14.dp.toPx()
                    val radius = size.minDimension / 2 - strokeWidth
                    val center = Offset(size.width / 2, size.height / 2 + size.height / 4)
                    val topLeft = Offset(center.x - radius, center.y - radius)
                    val arcSize = Size(radius * 2, radius * 2)

                    // Track (fundo)
                    drawArc(
                        color = Color(0xFFF1F5F9),
                        startAngle = 180f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                    )

                    if (healthScore > 0) {
                        // Cada fator ocupa o seu próprio segmento do semicírculo (na mesma ordem
                        // do modal de detalhe), com um pequeno espaço entre eles.
                        var angleCursor = 180f
                        val gap = 1.5f
                        listOf(
                            animatedSavings to savingsColor,
                            animatedEmergency to emergencyColor,
                            animatedLimits to limitsColor,
                            animatedGoals to goalsColor
                        ).forEach { (sweep, color) ->
                            if (sweep > gap) {
                                drawArc(
                                    color = color,
                                    startAngle = angleCursor,
                                    sweepAngle = sweep - gap,
                                    useCenter = false,
                                    topLeft = topLeft,
                                    size = arcSize,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                )
                            }
                            angleCursor += sweep
                        }
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.offset(y = 20.dp)
                ) {
                    Text(
                        text = if (healthScore > 0) "$healthScore" else "--",
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        color = scoreColor
                    )
                    Text(
                        text = scoreStatusText,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = scoreColor
                    )
                }
            }

            if (healthScore > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                // Legenda compacta dos 4 fatores do gauge, para saber qual cor é qual sem ter de tocar.
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    listOf(
                        (if (idioma == "PT") "Poupança" else "Savings") to Color(0xFF10B981),
                        (if (idioma == "PT") "Reserva" else "Reserve") to Color(0xFF3B82F6),
                        (if (idioma == "PT") "Limites" else "Limits") to Color(0xFFF59E0B),
                        (if (idioma == "PT") "Metas" else "Goals") to Color(0xFF8B5CF6)
                    ).forEach { (label, color) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (healthScore >= 75) {
                    if (idioma == "PT") "Sua saúde financeira está excelente!\nContinue mantendo os bons hábitos." else "Your financial health is excellent!\nKeep up the good habits."
                } else if (healthScore >= 50) {
                    if (idioma == "PT") "Sua saúde financeira está boa.\nHá espaço para otimizar poupanças." else "Your financial health is good.\nThere is room to optimize savings."
                } else if (healthScore > 0) {
                    if (idioma == "PT") "Sua saúde financeira precisa de atenção.\nVeja o que pode melhorar." else "Your financial health needs attention.\nSee what you can improve."
                } else {
                    if (idioma == "PT") "Registre suas primeiras transações para calcular seu índice de saúde." else "Register your first transactions to calculate your health index."
                },
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(18.dp))
            OutlinedButton(
                onClick = onViewFullAnalysis,
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = scoreColor),
                border = BorderStroke(1.dp, scoreColor.copy(alpha = 0.5f))
            ) {
                Text(
                    text = if (idioma == "PT") "Ver análise completa >" else "View full analysis >",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun CashFlowCard(
    idioma: String,
    transactions: List<Transaction>,
    mo: String,
    startDate: Long = 0L,
    endDate: Long = 0L
) {
    var selectedBarIndex by remember { mutableIntStateOf(-1) }

    val daysList = remember { mutableStateListOf<String>() }
    val daysRangeList = remember { mutableStateListOf<String>() }
    val incomeList = remember { mutableStateListOf<Double>() }
    val expenseList = remember { mutableStateListOf<Double>() }
    val incomeRatios = remember { mutableStateListOf<Float>() }
    val expenseRatios = remember { mutableStateListOf<Float>() }
    var isAggregatedPeriod by remember { mutableStateOf(false) }
    var maxBarValue by remember { mutableStateOf(1.0) }

    LaunchedEffect(transactions, startDate, endDate) {
        daysList.clear()
        daysRangeList.clear()
        incomeList.clear()
        expenseList.clear()
        incomeRatios.clear()
        expenseRatios.clear()

        val actualStart = if (startDate <= 0L) {
            if (transactions.isNotEmpty()) transactions.minOf { it.data }
            else System.currentTimeMillis() - 6L * 24 * 60 * 60 * 1000
        } else startDate

        val actualEnd = if (endDate <= actualStart) {
            if (transactions.isNotEmpty()) transactions.maxOf { it.data }
            else System.currentTimeMillis()
        } else endDate

        val totalDays = ((actualEnd - actualStart) / (24L * 60 * 60 * 1000)).toInt().coerceAtLeast(1)
        isAggregatedPeriod = totalDays > 10

        val incomeMap = mutableMapOf<String, Double>()
        val expenseMap = mutableMapOf<String, Double>()

        if (totalDays <= 10) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = actualStart
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val numBars = totalDays.coerceIn(1, 10)
            for (i in 0 until numBars) {
                val dayStr = SimpleDateFormat("dd/MM", Locale.getDefault()).format(cal.time)
                daysList.add(dayStr)
                daysRangeList.add(dayStr)

                val dayStart = cal.timeInMillis
                val dayEnd = dayStart + (24L * 60 * 60 * 1000) - 1

                val dayTxs = transactions.filter { it.data in dayStart..dayEnd }
                val inc = dayTxs.filter { it.isReceita() }.sumOf { it.valor }
                val exp = dayTxs.filter { it.isDespesa() }.sumOf { it.valor }

                incomeMap[dayStr] = inc
                expenseMap[dayStr] = exp

                incomeList.add(inc)
                expenseList.add(exp)

                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
        } else {
            val bucketCount = 7
            val totalSpan = (actualEnd - actualStart).coerceAtLeast(1L)
            val bucketSize = totalSpan / bucketCount

            for (i in 0 until bucketCount) {
                val bStart = actualStart + (i * bucketSize)
                val bEnd = if (i == bucketCount - 1) actualEnd else (bStart + bucketSize - 1)

                val startCal = Calendar.getInstance().apply { timeInMillis = bStart }
                val endCal = Calendar.getInstance().apply { timeInMillis = bEnd }
                val sameMonth = startCal.get(Calendar.MONTH) == endCal.get(Calendar.MONTH) &&
                    startCal.get(Calendar.YEAR) == endCal.get(Calendar.YEAR)

                // Rótulo do eixo: compacto (o espaço por barra é estreito). Quando o bloco cai no
                // mesmo mês, mostra só "dia-dia/mês" (ex.: "23-29/08"); só quando cruza mês é que
                // usa o formato completo dos dois lados.
                val axisLabel = if (sameMonth) {
                    "${SimpleDateFormat("dd", Locale.getDefault()).format(Date(bStart))}-${SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(bEnd))}"
                } else {
                    "${SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(bStart))}-${SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(bEnd))}"
                }
                // Intervalo completo para o banner ao tocar na barra, onde há espaço de sobra.
                val rangeLabel = "${SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(bStart))} - ${SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(bEnd))}"

                val dayStr = axisLabel
                daysList.add(dayStr)
                daysRangeList.add(rangeLabel)

                val dayTxs = transactions.filter { it.data in bStart..bEnd }
                val inc = dayTxs.filter { it.isReceita() }.sumOf { it.valor }
                val exp = dayTxs.filter { it.isDespesa() }.sumOf { it.valor }

                incomeMap[dayStr] = inc
                expenseMap[dayStr] = exp

                incomeList.add(inc)
                expenseList.add(exp)
            }
        }

        val maxInc = incomeList.maxOrNull() ?: 0.0
        val maxExp = expenseList.maxOrNull() ?: 0.0
        val maxVal = maxOf(maxInc, maxExp, 1.0)
        maxBarValue = maxVal

        incomeList.forEachIndexed { i, inc ->
            val exp = expenseList.getOrElse(i) { 0.0 }
            incomeRatios.add((inc / maxVal).toFloat())
            expenseRatios.add((-(exp) / maxVal).toFloat())
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (idioma == "PT") "Fluxo de Caixa Interativo" else "Interactive Cash Flow",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (idioma == "PT") "Toque nas barras para ver detalhes" else "Tap bars to view details",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(Icons.Outlined.BarChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tooltip Banner when a bar is selected
            AnimatedVisibility(visible = selectedBarIndex in 0 until daysList.size) {
                if (selectedBarIndex in 0 until daysList.size) {
                    val dayLabel = daysRangeList.getOrElse(selectedBarIndex) { daysList[selectedBarIndex] }
                    val inc = incomeList[selectedBarIndex]
                    val exp = expenseList[selectedBarIndex]
                    val saldo = inc - exp

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${if (isAggregatedPeriod) (if (idioma == "PT") "Período" else "Period") else (if (idioma == "PT") "Dia" else "Day")} $dayLabel",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text(
                                        text = "+${String.format(Locale.getDefault(), "%,.0f $mo", inc)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF10B981)
                                    )
                                    Text(
                                        text = "-${String.format(Locale.getDefault(), "%,.0f $mo", exp)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFEF4444)
                                    )
                                }
                                // Saldo líquido do dia/bloco — o que realmente importa para saber
                                // se aquele período foi positivo ou negativo, sem ter de calcular.
                                Text(
                                    text = "${if (idioma == "PT") "Saldo" else "Net"}: ${if (saldo >= 0) "+" else ""}${String.format(Locale.getDefault(), "%,.0f $mo", saldo)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (saldo >= 0) Color(0xFF10B981) else Color(0xFFEF4444)
                                )
                            }
                            IconButton(onClick = { selectedBarIndex = -1 }) {
                                Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            val hasAnyData = incomeList.any { it > 0.0 } || expenseList.any { it > 0.0 }

            // Interactive Bar Chart Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                if (!hasAnyData) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Outlined.BarChart,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (idioma == "PT") "Sem movimentos neste período" else "No activity in this period",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures { offset ->
                                val w = size.width
                                val barCount = daysList.size.coerceIn(1, 10)
                                val spacing = (w - 40.dp.toPx()) / barCount
                                val tappedIndex = ((offset.x - 40.dp.toPx()) / spacing).toInt()
                                if (tappedIndex in 0 until barCount) {
                                    selectedBarIndex = tappedIndex
                                }
                            }
                        }
                ) {
                    val w = size.width
                    val h = size.height
                    val barCount = daysList.size.coerceIn(1, 10)

                    // Rótulos do eixo Y com o valor real em moeda (em vez de frações "2/3", "1/3"
                    // sem escala), para dar para ler a grandeza do gráfico sem ter de tocar em nada.
                    fun fmtAxis(v: Double): String {
                        val abs = Math.abs(v)
                        return when {
                            abs >= 1_000_000 -> String.format(Locale.getDefault(), "%.1fM", v / 1_000_000)
                            abs >= 1_000 -> String.format(Locale.getDefault(), "%.0fk", v / 1_000)
                            else -> String.format(Locale.getDefault(), "%.0f", v)
                        }
                    }
                    val lines = listOf(1f, 0.66f, 0.33f, 0f)
                    val labels = listOf(fmtAxis(maxBarValue), fmtAxis(maxBarValue * 0.66), fmtAxis(maxBarValue * 0.33), "0")

                    val textPaint = android.graphics.Paint().apply {
                        color = android.graphics.Color.GRAY
                        textSize = 26f
                        isAntiAlias = true
                    }

                    val chartTop = 20.dp.toPx()
                    val chartBottom = h - 30.dp.toPx()
                    val chartH = chartBottom - chartTop

                    lines.forEachIndexed { i, factor ->
                        val y = chartTop + chartH * (1 - factor)
                        drawLine(
                            color = Color(0xFFE2E8F0),
                            start = Offset(40.dp.toPx(), y),
                            end = Offset(w, y),
                            strokeWidth = 2f,
                            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                        drawContext.canvas.nativeCanvas.drawText(
                            labels[i],
                            0f,
                            y + 10f,
                            textPaint
                        )
                    }

                    val zeroY = chartTop + chartH * 0.50f
                    val spacing = (w - 40.dp.toPx()) / barCount
                    val barWidth = (spacing * 0.55f).coerceAtMost(16.dp.toPx())

                    for (i in 0 until barCount) {
                        val x = 40.dp.toPx() + spacing * i + (spacing - barWidth) / 2
                        val isSelected = i == selectedBarIndex

                        drawContext.canvas.nativeCanvas.drawText(
                            daysList[i],
                            x + barWidth / 2,
                            chartBottom + 25.dp.toPx(),
                            textPaint.apply { textAlign = android.graphics.Paint.Align.CENTER }
                        )

                        // Highlight background if selected
                        if (isSelected) {
                            drawRoundRect(
                                color = Color(0xFF3B82F6).copy(alpha = 0.12f),
                                topLeft = Offset(x - 4.dp.toPx(), chartTop),
                                size = Size(barWidth + 8.dp.toPx(), chartH),
                                cornerRadius = CornerRadius(6.dp.toPx())
                            )
                        }

                        if (i < incomeRatios.size && incomeRatios[i] > 0) {
                            val barH = incomeRatios[i] * (zeroY - chartTop)
                            drawRoundRect(
                                color = if (isSelected) Color(0xFF059669) else Color(0xFF10B981),
                                topLeft = Offset(x, zeroY - barH),
                                size = Size(barWidth, barH),
                                cornerRadius = CornerRadius(4.dp.toPx())
                            )
                        }

                        if (i < expenseRatios.size && expenseRatios[i] < 0) {
                            val barH = -expenseRatios[i] * (chartBottom - zeroY)
                            drawRoundRect(
                                color = if (isSelected) Color(0xFFDC2626) else Color(0xFFEF4444),
                                topLeft = Offset(x, zeroY),
                                size = Size(barWidth, barH),
                                cornerRadius = CornerRadius(4.dp.toPx())
                            )
                        }
                    }

                    // Overlay Net Balance Line
                    val points = mutableListOf<Offset>()
                    val maxValForLine = maxOf((incomeList.zip(expenseList).map { (inc, exp) -> Math.abs(inc - exp) }.maxOrNull() ?: 1.0), 1.0)
                    for (i in 0 until barCount) {
                        val cx = 40.dp.toPx() + spacing * i + spacing / 2
                        val inc = if (i < incomeList.size) incomeList[i] else 0.0
                        val exp = if (i < expenseList.size) expenseList[i] else 0.0
                        val net = inc - exp
                        val ratio = (net / maxValForLine).toFloat()
                        val ny = zeroY - (ratio * (zeroY - chartTop) * 0.8f)
                        points.add(Offset(cx, ny))
                    }

                    if (points.size > 1) {
                        val path = androidx.compose.ui.graphics.Path()
                        path.moveTo(points[0].x, points[0].y)
                        for (i in 1 until points.size) {
                            path.lineTo(points[i].x, points[i].y)
                        }
                        drawPath(
                            path = path,
                            color = Color(0xFF2563EB),
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    points.forEach { pt ->
                        drawCircle(
                            color = Color.White,
                            radius = 5.dp.toPx(),
                            center = pt
                        )
                        drawCircle(
                            color = Color(0xFF2563EB),
                            radius = 3.5.dp.toPx(),
                            center = pt
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF10B981)))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = if (idioma == "PT") "Entradas" else "Income", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(16.dp))
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFEF4444)))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = if (idioma == "PT") "Saídas" else "Expenses", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(16.dp))
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF2563EB)))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = if (idioma == "PT") "Saldo Líquido" else "Net Balance", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ExpenseDistributionCard(
    idioma: String,
    transactions: List<Transaction>,
    categories: List<Category>,
    mo: String,
    spendingLimits: List<SpendingLimit> = emptyList(),
    onViewDetails: () -> Unit
) {
    var selectedCategoryIndex by remember { mutableIntStateOf(-1) }

    val currentExpenses = remember(transactions) {
        transactions.filter { it.isDespesa() }
    }
    val totalExpenses = remember(currentExpenses) { currentExpenses.sumOf { it.valor } }

    val categoryTotals = remember(currentExpenses, categories) {
        currentExpenses.groupBy { it.categoriaId }
            .map { (catId, txs) ->
                val cat = categories.find { it.id == catId }
                Triple(catId, cat?.nome ?: (if (idioma == "PT") "Outros" else "Others"), txs.sumOf { it.valor })
            }
            .sortedByDescending { it.third }
            .take(5)
    }

    val totalTop5 = remember(categoryTotals) { categoryTotals.sumOf { it.third } }
    val others = totalExpenses - totalTop5
    val finalCategories = remember(categoryTotals, others, idioma) {
        if (others > 0) categoryTotals + Triple(null, if (idioma == "PT") "Outros" else "Others", others) else categoryTotals
    }
    // Nº de transações por categoria, para mostrar no detalhe expandido ao selecionar uma fatia.
    // "Outros" soma as transações de todas as categorias fora do top 5.
    val categoryCounts = remember(currentExpenses, categoryTotals) {
        val top5Ids = categoryTotals.map { it.first }.toSet()
        val counts = currentExpenses.groupBy { it.categoriaId }.mapValues { it.value.size }
        val othersCount = currentExpenses.count { it.categoriaId !in top5Ids }
        counts + (null to othersCount)
    }

    val defaultColors = remember {
        listOf(
            Color(0xFF3B82F6),
            Color(0xFF10B981),
            Color(0xFF8B5CF6),
            Color(0xFFF59E0B),
            Color(0xFF94A3B8),
            Color(0xFFEC4899)
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (idioma == "PT") "Distribuição de Despesas" else "Expense Distribution",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(onClick = onViewDetails) {
                    Text(
                        text = if (idioma == "PT") "Ver detalhes >" else "Details >",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(130.dp)
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(finalCategories, totalExpenses) {
                                detectTapGestures { offset ->
                                    if (totalExpenses <= 0 || finalCategories.isEmpty()) return@detectTapGestures
                                    val center = Offset(size.width / 2f, size.height / 2f)
                                    val dx = offset.x - center.x
                                    val dy = offset.y - center.y
                                    val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                                    val strokeWPx = 16.dp.toPx()
                                    val outerRadius = size.width / 2f
                                    val innerRadius = outerRadius - strokeWPx
                                    // Só regista o toque se cair dentro do anel do gráfico (não no
                                    // texto central nem fora do círculo)
                                    if (distance < innerRadius - 8.dp.toPx() || distance > outerRadius + 8.dp.toPx()) {
                                        return@detectTapGestures
                                    }
                                    // drawArc começa em -90° (topo) e avança no sentido horário
                                    var angleDeg = Math.toDegrees(kotlin.math.atan2(dy, dx).toDouble()).toFloat()
                                    angleDeg = (angleDeg + 90f + 360f) % 360f
                                    var cursor = 0f
                                    for ((idx, triple) in finalCategories.withIndex()) {
                                        val sweep = ((triple.third / totalExpenses) * 360f).toFloat()
                                        if (angleDeg >= cursor && angleDeg < cursor + sweep) {
                                            selectedCategoryIndex = if (selectedCategoryIndex == idx) -1 else idx
                                            break
                                        }
                                        cursor += sweep
                                    }
                                }
                            }
                    ) {
                        val strokeW = 16.dp.toPx()
                        var startAngle = -90f

                        if (totalExpenses > 0) {
                            finalCategories.forEachIndexed { index, triple ->
                                val sweepAngle = ((triple.third / totalExpenses) * 360f).toFloat()
                                val isSelected = index == selectedCategoryIndex
                                drawArc(
                                    color = if (isSelected) defaultColors[index % defaultColors.size].copy(alpha = 0.7f) else defaultColors[index % defaultColors.size],
                                    startAngle = startAngle,
                                    sweepAngle = sweepAngle,
                                    useCenter = false,
                                    style = Stroke(if (isSelected) strokeW + 6f else strokeW)
                                )
                                startAngle += sweepAngle
                            }
                        } else {
                            drawArc(
                                color = Color(0xFFE2E8F0),
                                startAngle = -90f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(strokeW)
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = String.format(Locale.getDefault(), "%,.0f", totalExpenses)
                                .replace(",", "X").replace(".", ",").replace("X", "."),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(mo, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    if (totalExpenses > 0) {
                        finalCategories.forEachIndexed { index, triple ->
                            val perc = ((triple.third / totalExpenses) * 100).toInt()
                            val isSelected = index == selectedCategoryIndex

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else Color.Transparent,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedCategoryIndex = if (selectedCategoryIndex == index) -1 else index
                                    }
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(defaultColors[index % defaultColors.size])
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        val catId = triple.first
                                        val hasExceededLimit = catId != null && spendingLimits.any { it.categoryId == catId && it.monthlyLimit > 0 && triple.third > it.monthlyLimit }

                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = triple.second,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (hasExceededLimit) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .clip(CircleShape)
                                                        .background(com.example.ui.theme.AppTheme.SemanticColors.dangerText)
                                                )
                                            }
                                        }
                                        Text("$perc%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                    }
                                    // Detalhe explicativo: só aparece ao selecionar esta categoria —
                                    // mostra o valor exato e quantas transações compõem a fatia,
                                    // que o "%" sozinho não diz.
                                    if (isSelected) {
                                        val txCount = categoryCounts[triple.first] ?: 0
                                        Text(
                                            text = "${String.format(Locale.getDefault(), "%,.2f $mo", triple.third).replace(",", "X").replace(".", ",").replace("X", ".")} • " +
                                                "$txCount ${if (idioma == "PT") (if (txCount == 1) "transação" else "transações") else (if (txCount == 1) "transaction" else "transactions")}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(start = 14.dp, top = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            if (idioma == "PT") "Sem despesas registradas" else "No expenses recorded",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text(
                    text = if (idioma == "PT") "Ver detalhes completos >" else "View complete details >",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun SimulatorCard(idioma: String, mo: String) {
    val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
    var selectedType by remember { mutableStateOf("COMPOSTOS") } // "COMPOSTOS" or "SIMPLES"
    var valorInicialText by remember { mutableStateOf("") }
    var aporteMensalText by remember { mutableStateOf("") }
    var taxaAnualText by remember { mutableStateOf("") }
    var mesesText by remember { mutableStateOf("") }

    val valorInicial = valorInicialText.toDoubleOrNull() ?: 0.0
    val aporteMensal = aporteMensalText.toDoubleOrNull() ?: 0.0
    val taxaAnual = taxaAnualText.toDoubleOrNull() ?: 0.0
    val meses = mesesText.toIntOrNull() ?: 0

    // Interest calculation (Compound or Simple)
    val (montanteFinal, totalInvestido, lucro) = remember(selectedType, valorInicial, aporteMensal, taxaAnual, meses) {
        if (meses <= 0) {
            Triple(valorInicial, valorInicial, 0.0)
        } else {
            val i = (taxaAnual / 100.0) / 12.0
            val investidoTotal = valorInicial + (aporteMensal * meses)
            if (selectedType == "SIMPLES") {
                val jurosInicial = valorInicial * i * meses
                val jurosAportes = aporteMensal * i * (meses * (meses + 1) / 2.0)
                val totalJuros = jurosInicial + jurosAportes
                val montante = investidoTotal + totalJuros
                // Sem coerceAtLeast(0.0): se a taxa anual introduzida for negativa, o "lucro"
                // deve poder mostrar um valor negativo real, coerente com o montante final
                // (o mesmo padrão de inconsistência já corrigido no cartão "Patrimônio").
                Triple(montante, investidoTotal, totalJuros)
            } else {
                var montante = valorInicial
                var investido = valorInicial
                for (m in 1..meses) {
                    montante = (montante + aporteMensal) * (1 + i)
                    investido += aporteMensal
                }
                val gain = montante - investido
                Triple(montante, investido, gain)
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = if (idioma == "PT") "Simulador Financeiro" else "Financial Simulator",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(14.dp))

            // Interest Type Selection Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Pair("COMPOSTOS", if (idioma == "PT") "Juros Compostos" else "Compound Interest"),
                    Pair("SIMPLES", if (idioma == "PT") "Juros Simples" else "Simple Interest")
                ).forEach { (typeKey, label) ->
                    val isSelected = selectedType == typeKey
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { selectedType = typeKey }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))

            // 2x2 Inputs Grid (A.1)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = valorInicialText,
                    onValueChange = { valorInicialText = it.filter { char -> char.isDigit() } },
                    label = { Text(if (idioma == "PT") "Valor Inicial" else "Initial Value", fontSize = 11.sp) },
                    trailingIcon = { Text(mo, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                    value = aporteMensalText,
                    onValueChange = { aporteMensalText = it.filter { char -> char.isDigit() } },
                    label = { Text(if (idioma == "PT") "Aporte Mensal" else "Monthly Deposit", fontSize = 11.sp) },
                    trailingIcon = { Text(mo, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(10.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = taxaAnualText,
                    onValueChange = { taxaAnualText = it.filter { char -> char.isDigit() || char == '.' } },
                    label = { Text(if (idioma == "PT") "Taxa Anual (%)" else "Annual Rate (%)", fontSize = 11.sp) },
                    trailingIcon = { Text("%", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                    value = mesesText,
                    onValueChange = { mesesText = it.filter { char -> char.isDigit() } },
                    label = { Text(if (idioma == "PT") "Meses" else "Months", fontSize = 11.sp) },
                    trailingIcon = { Text(if (idioma == "PT") "meses" else "months", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(10.dp)
                )
            }

            // Quick Month Chips (B.10)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(6, 12, 24, 36).forEach { chipMonths ->
                    val isChipSelected = mesesText == chipMonths.toString()
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isChipSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .border(
                                width = 1.dp,
                                color = if (isChipSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { mesesText = chipMonths.toString() }
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$chipMonths m",
                            fontSize = 11.sp,
                            fontWeight = if (isChipSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isChipSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Botão para fechar o teclado — o cálculo já é automático a cada tecla digitada
            // (ver `remember(selectedType, valorInicial, ...)` acima), por isso o botão não
            // "calcula" nada; o rótulo reflete isso para não parecer que falta clicar aqui.
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedButton(
                onClick = { focusManager.clearFocus() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (idioma == "PT") "Fechar Teclado" else "Close Keyboard",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Result Green Card (A.1)
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.AppTheme.SemanticColors.successBackground),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                if (idioma == "PT") "Montante Final" else "Final Amount",
                                fontSize = 11.sp,
                                color = com.example.ui.theme.AppTheme.SemanticColors.successText
                            )
                            Text(
                                com.example.util.MoneyFormatter.format(montanteFinal, mo),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = com.example.ui.theme.AppTheme.SemanticColors.successText
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                if (idioma == "PT") "Lucro" else "Profit",
                                fontSize = 11.sp,
                                color = com.example.ui.theme.AppTheme.SemanticColors.successText
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    com.example.util.MoneyFormatter.format(lucro, mo),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = com.example.ui.theme.AppTheme.SemanticColors.successText
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.Rounded.ChevronRight,
                                    contentDescription = null,
                                    tint = com.example.ui.theme.AppTheme.SemanticColors.successText,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (idioma == "PT") "Total Investido: ${com.example.util.MoneyFormatter.format(totalInvestido, mo)}"
                        else "Total Invested: ${com.example.util.MoneyFormatter.format(totalInvestido, mo)}",
                        fontSize = 11.sp,
                        color = com.example.ui.theme.AppTheme.SemanticColors.successText.copy(alpha = 0.85f)
                    )
                }
            }
        }
    }
}

@Composable
fun ServiceLogoIcon(
    nome: String,
    iconeKey: String,
    corHex: String,
    modifier: Modifier = Modifier.size(36.dp)
) {
    com.example.util.BrandIcon(
        nameOrKey = if (iconeKey.isNotBlank()) iconeKey else nome,
        customColorHex = corHex,
        modifier = modifier
    )
}

@Composable
fun SubscriptionsCard(
    idioma: String,
    mo: String,
    subscriptions: List<Subscription>,
    onManageSubscriptions: () -> Unit,
    onSubscriptionClick: (Subscription) -> Unit = {}
) {
    val activeSubs = remember(subscriptions) { subscriptions.filter { it.ativa } }
    val activeCount = activeSubs.size
    val totalSubsValue = remember(activeSubs) {
        activeSubs.sumOf { it.valorMensalEquivalente() }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onManageSubscriptions),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = if (idioma == "PT") "Subscrições e Serviços" else "Subscriptions & Services",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(16.dp))

            if (activeSubs.isEmpty()) {
                Text(
                    text = if (idioma == "PT") "Nenhuma subscrição ativa." else "No active subscriptions.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                activeSubs.take(3).forEach { sub ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onSubscriptionClick(sub) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ServiceLogoIcon(
                            nome = sub.nome,
                            iconeKey = sub.icone,
                            corHex = sub.corHex,
                            modifier = Modifier.size(34.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                sub.nome,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "${com.example.util.MoneyFormatter.format(sub.valor, mo)} / ${sub.cicloCobranca.lowercase().take(3)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(com.example.ui.theme.AppTheme.SemanticColors.successBackground)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                if (idioma == "PT") "Ativa" else "Active",
                                fontSize = 10.sp,
                                color = com.example.ui.theme.AppTheme.SemanticColors.successText
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (idioma == "PT") "$activeCount subscrições ativas" else "$activeCount active subscriptions",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    String.format(Locale.getDefault(), "%,.0f $mo / mês", totalSubsValue).replace(",", "X").replace(".", ",").replace("X", "."),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text(
                    text = if (idioma == "PT") "Gerenciar subscrições >" else "Manage subscriptions >",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable(onClick = onManageSubscriptions)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

// ---------------- DIALOGS AND MODALS ----------------

@Composable
fun CustomRangePickerModal(
    idioma: String,
    startDate: Long,
    endDate: Long,
    onDismiss: () -> Unit,
    onConfirm: (Long, Long) -> Unit
) {
    val context = LocalContext.current
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    var tempStart by remember { mutableLongStateOf(startDate) }
    var tempEnd by remember { mutableLongStateOf(endDate) }

    val startPicker = remember(tempStart) {
        val cal = Calendar.getInstance().apply { timeInMillis = tempStart }
        android.app.DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val newCal = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth, 0, 0, 0)
                }
                tempStart = newCal.timeInMillis
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    val endPicker = remember(tempEnd) {
        val cal = Calendar.getInstance().apply { timeInMillis = tempEnd }
        android.app.DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val newCal = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth, 23, 59, 59)
                }
                tempEnd = newCal.timeInMillis
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (idioma == "PT") "Escolher Período Personalizado" else "Choose Custom Period",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                    if (idioma == "PT") "Selecione o intervalo de datas para gerar os relatórios:" else "Select the date range to generate reports:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { startPicker.show() }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(if (idioma == "PT") "Data Inicial 📅" else "Start Date 📅", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(dateFormat.format(Date(tempStart)), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { endPicker.show() }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(if (idioma == "PT") "Data Final 📅" else "End Date 📅", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(dateFormat.format(Date(tempEnd)), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Text(
                    if (idioma == "PT") "Atalhos rápidos:" else "Quick shortcuts:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            tempEnd = cal.timeInMillis
                            cal.add(Calendar.DAY_OF_MONTH, -30)
                            tempStart = cal.timeInMillis
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (idioma == "PT") "Últimos 30d" else "Last 30d", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            val cal = Calendar.getInstance()
                            tempEnd = cal.timeInMillis
                            cal.add(Calendar.DAY_OF_MONTH, -90)
                            tempStart = cal.timeInMillis
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (idioma == "PT") "Últimos 90d" else "Last 90d", fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(tempStart, tempEnd) },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(if (idioma == "PT") "Aplicar" else "Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Cancelar" else "Cancel")
            }
        }
    )
}

@Composable
fun MonthPickerModal(
    idioma: String,
    currentYear: Int,
    currentMonth: Int,
    onDismiss: () -> Unit,
    onSelect: (Int, Int) -> Unit
) {
    var tempYear by remember { mutableIntStateOf(currentYear) }
    val months = remember(idioma) {
        if (idioma == "PT") listOf("Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez")
        else listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    }

    val nowCal = Calendar.getInstance()
    val realCurrentYear = nowCal.get(Calendar.YEAR)
    val realCurrentMonth = nowCal.get(Calendar.MONTH)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { tempYear-- }) {
                    Icon(Icons.Rounded.KeyboardArrowLeft, contentDescription = null)
                }
                Text("$tempYear", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                IconButton(
                    onClick = { tempYear++ },
                    enabled = tempYear < realCurrentYear
                ) {
                    Icon(Icons.Rounded.KeyboardArrowRight, contentDescription = null)
                }
            }
        },
        text = {
            Column {
                val rows = months.chunked(3)
                rows.forEachIndexed { rowIndex, rowMonths ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowMonths.forEachIndexed { colIndex, m ->
                            val monthIdx = rowIndex * 3 + colIndex
                            val isSelected = tempYear == currentYear && monthIdx == currentMonth
                            val isFuture = tempYear > realCurrentYear || (tempYear == realCurrentYear && monthIdx > realCurrentMonth)
                            Button(
                                onClick = { onSelect(tempYear, monthIdx) },
                                enabled = !isFuture,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(vertical = 4.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(m, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Cancelar" else "Cancel")
            }
        }
    )
}

@Composable
fun HealthAnalysisModal(
    idioma: String,
    mo: String,
    transactions: List<Transaction>,
    wallets: List<Wallet>,
    categories: List<Category>,
    goals: List<FinancialGoal>,
    onDismiss: () -> Unit
) {
    val healthData = remember(transactions, wallets, categories, goals, idioma) {
        com.example.util.FinancialHealthCalculator.calculate(transactions, wallets, categories, goals, idioma)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (idioma == "PT") "Saúde Financeira" else "Financial Health Analysis",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = healthData.color.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${healthData.score}/100",
                        color = healthData.color,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = healthData.feedback,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 18.sp
                )

                HorizontalDivider()

                MetricRow(
                    label = if (idioma == "PT") "Taxa de Poupança" else "Savings Rate",
                    value = "${healthData.savingsRateScore} / 30 pts",
                    status = if (healthData.savingsRateScore >= 20) (if (idioma == "PT") "Ótima taxa de poupança" else "Great savings rate") else (if (idioma == "PT") "Poupe mais da sua receita" else "Save more of your income"),
                    color = if (healthData.savingsRateScore >= 20) Color(0xFF10B981) else Color(0xFFF97316)
                )

                HorizontalDivider()

                MetricRow(
                    label = if (idioma == "PT") "Fundo de Emergência" else "Emergency Reserve",
                    value = "${healthData.emergencyFundScore} / 35 pts",
                    status = if (healthData.emergencyFundScore >= 25) (if (idioma == "PT") "Reserva sólida" else "Solid reserve") else (if (idioma == "PT") "Construa sua reserva" else "Build your reserve"),
                    color = if (healthData.emergencyFundScore >= 25) Color(0xFF10B981) else Color(0xFF3B82F6)
                )

                HorizontalDivider()

                MetricRow(
                    label = if (idioma == "PT") "Limites de Gastos" else "Budget Limits",
                    value = "${healthData.limitsScore} / 20 pts",
                    status = if (healthData.limitsScore == 20) (if (idioma == "PT") "Dentro do orçamento" else "Within budget") else (if (idioma == "PT") "Categorias estouradas" else "Exceeded categories"),
                    color = if (healthData.limitsScore == 20) Color(0xFF10B981) else Color(0xFFEF4444)
                )

                HorizontalDivider()

                MetricRow(
                    label = if (idioma == "PT") "Progresso das Metas" else "Goals Progress",
                    value = "${healthData.goalsScore} / 15 pts",
                    status = if (healthData.goalsScore >= 10) (if (idioma == "PT") "Bons avanços" else "Good progress") else (if (idioma == "PT") "Avançar metas" else "Advance goals"),
                    color = Color(0xFF8B5CF6)
                )

                if (healthData.tips.isNotEmpty()) {
                    HorizontalDivider()
                    Text(
                        if (idioma == "PT") "Dicas de Melhoria:" else "Improvement Tips:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    healthData.tips.forEach { tip ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("• ", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(tip, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, shape = RoundedCornerShape(8.dp)) {
                Text(if (idioma == "PT") "Entendido" else "Got it")
            }
        }
    )
}

@Composable
fun MetricRow(label: String, value: String, status: String, color: Color) {
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(status, fontSize = 11.sp, color = color)
    }
}

@Composable
fun CategoryDetailsModal(
    idioma: String,
    mo: String,
    transactions: List<Transaction>,
    categories: List<Category>,
    onDismiss: () -> Unit
) {
    val expenses = remember(transactions) { transactions.filter { it.isDespesa() } }
    val total = remember(expenses) { expenses.sumOf { it.valor } }
    val grouped = remember(expenses, categories) {
        expenses.groupBy { it.categoriaId }
            .map { (catId, txs) ->
                val cat = categories.find { it.id == catId }
                Triple(cat?.nome ?: (if (idioma == "PT") "Sem Categoria" else "Uncategorized"), txs.sumOf { it.valor }, txs.size)
            }
            .sortedByDescending { it.second }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (idioma == "PT") "Detalhamento por Categoria" else "Category Breakdown",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (grouped.isEmpty()) {
                    Text(
                        if (idioma == "PT") "Sem despesas registradas neste período." else "No expenses recorded in this period.",
                        fontSize = 13.sp
                    )
                } else {
                    grouped.forEach { (catName, catVal, count) ->
                        val perc = if (total > 0) ((catVal / total) * 100).toInt() else 0
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(catName, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("$count ${if (idioma == "PT") "transações" else "transactions"} ($perc%)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                String.format(Locale.getDefault(), "%,.2f $mo", catVal).replace(",", "X").replace(".", ",").replace("X", "."),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEF4444)
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, shape = RoundedCornerShape(8.dp)) {
                Text(if (idioma == "PT") "Fechar" else "Close")
            }
        }
    )
}

@Composable
fun TransactionsListModal(
    title: String,
    idioma: String,
    mo: String,
    transactions: List<Transaction>,
    categories: List<Category>,
    onDismiss: () -> Unit
) {
    val total = remember(transactions) { transactions.sumOf { it.valor } }
    val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    text = "${if (idioma == "PT") "Total:" else "Total:"} ${String.format(Locale.getDefault(), "%,.2f $mo", total).replace(",", "X").replace(".", ",").replace("X", ".")}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        text = {
            Box(modifier = Modifier.heightIn(max = 350.dp)) {
                if (transactions.isEmpty()) {
                    Text(if (idioma == "PT") "Nenhuma transação encontrada para este filtro." else "No transactions found for this filter.", fontSize = 13.sp)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(transactions) { tx ->
                            val cat = categories.find { it.id == tx.categoriaId }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tx.descricao, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Text("${cat?.nome ?: ""} • ${dateFormat.format(Date(tx.data))}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(
                                    String.format(Locale.getDefault(), "%,.2f $mo", tx.valor).replace(",", "X").replace(".", ",").replace("X", "."),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (tx.isReceita()) Color(0xFF10B981) else Color(0xFFEF4444)
                                )
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, shape = RoundedCornerShape(8.dp)) {
                Text(if (idioma == "PT") "Fechar" else "Close")
            }
        }
    )
}

@Composable
fun WalletsListModal(
    idioma: String,
    mo: String,
    wallets: List<Wallet>,
    onDismiss: () -> Unit
) {
    val totalSaldo = remember(wallets) { wallets.sumOf { it.saldoAtual } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(if (idioma == "PT") "Sua Carteiras e Contas" else "Your Wallets & Accounts", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    text = "${if (idioma == "PT") "Saldo Total:" else "Total Balance:"} ${String.format(Locale.getDefault(), "%,.2f $mo", totalSaldo).replace(",", "X").replace(".", ",").replace("X", ".")}",
                    fontSize = 13.sp,
                    color = Color(0xFF3B82F6),
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (wallets.isEmpty()) {
                    Text(if (idioma == "PT") "Nenhuma carteira cadastrada." else "No wallets registered.", fontSize = 13.sp)
                } else {
                    wallets.forEach { wallet ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(wallet.nome, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text(if (wallet.ativa) (if (idioma == "PT") "Conta Ativa" else "Active Account") else (if (idioma == "PT") "Inativa" else "Inactive"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Text(
                                String.format(Locale.getDefault(), "%,.2f $mo", wallet.saldoAtual).replace(",", "X").replace(".", ",").replace("X", "."),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, shape = RoundedCornerShape(8.dp)) {
                Text(if (idioma == "PT") "Fechar" else "Close")
            }
        }
    )
}

@Composable
fun SavingsInfoModal(
    idioma: String,
    mo: String,
    receitas: Double,
    despesas: Double,
    poupanca: Int,
    onDismiss: () -> Unit
) {
    // Sem coerceAtLeast(0.0): se despesas > receitas, isto é um défice real e deve
    // aparecer como valor negativo, não como "0,00 poupado".
    val economizado = receitas - despesas
    val economizadoFormatted = String.format(Locale.getDefault(), "%,.2f", economizado)
        .replace(",", "X")
        .replace(".", ",")
        .replace("X", ".")
    val economizadoPrefix = if (economizado > 0) "+" else ""

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (idioma == "PT") "Análise da Poupança" else "Savings Analysis", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = if (idioma == "PT") "Sua taxa de poupança representa a porcentagem das suas receitas que não foi gasta." else "Your savings rate is the percentage of income that was not spent.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val isDeficit = economizado < 0
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isDeficit) Color(0xFFFEE2E2) else Color(0xFFFEF3C7),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isDeficit) {
                                if (idioma == "PT") "Défice no Período:" else "Deficit in Period:"
                            } else {
                                if (idioma == "PT") "Economizado no Período:" else "Saved in Period:"
                            },
                            fontSize = 11.sp,
                            color = if (isDeficit) Color(0xFFB91C1C) else Color(0xFF92400E)
                        )
                        Text(
                            "$economizadoPrefix$economizadoFormatted $mo ($poupanca%)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDeficit) Color(0xFFB91C1C) else Color(0xFF92400E)
                        )
                    }
                }
                Text(
                    text = if (idioma == "PT") "Dica: Especialistas recomendam poupar pelo menos 20% a 30% da renda mensal para investimentos e fundo de emergência." else "Tip: Experts recommend saving at least 20% to 30% of monthly income for investments and emergency fund.",
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, shape = RoundedCornerShape(8.dp)) {
                Text(if (idioma == "PT") "Entendido" else "Got it")
            }
        }
    )
}

@Composable
fun SubscriptionsManagerModal(
    idioma: String,
    mo: String,
    subscriptions: List<Subscription>,
    viewModel: MainViewModel,
    initialEditSubscriptionId: Int? = null,
    onDismiss: () -> Unit
) {
    var showEditDialog by remember { mutableStateOf(false) }
    var subscriptionToEdit by remember { mutableStateOf<Subscription?>(null) }
    var subscriptionToDelete by remember { mutableStateOf<Subscription?>(null) }

    // Se veio de um toque direto numa subscrição específica no cartão de Relatórios, abre
    // já a edição dela em vez de mostrar primeiro a lista completa.
    LaunchedEffect(initialEditSubscriptionId) {
        if (initialEditSubscriptionId != null) {
            val match = subscriptions.find { it.id == initialEditSubscriptionId }
            if (match != null) {
                subscriptionToEdit = match
                showEditDialog = true
            }
        }
    }

    val activeSubs = remember(subscriptions) { subscriptions.filter { it.ativa } }
    val totalMensal = remember(activeSubs) {
        activeSubs.sumOf { it.valorMensalEquivalente() }
    }

    if (subscriptionToDelete != null) {
        AlertDialog(
            onDismissRequest = { subscriptionToDelete = null },
            title = { Text(if (idioma == "PT") "Excluir Subscrição?" else "Delete Subscription?") },
            text = {
                Text(
                    if (idioma == "PT") "Tem certeza que deseja excluir '${subscriptionToDelete?.nome}'?"
                    else "Are you sure you want to delete '${subscriptionToDelete?.nome}'?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        subscriptionToDelete?.id?.let { viewModel.deleteSubscription(it) }
                        subscriptionToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(if (idioma == "PT") "Excluir" else "Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { subscriptionToDelete = null }) {
                    Text(if (idioma == "PT") "Cancelar" else "Cancel")
                }
            }
        )
    }

    if (showEditDialog) {
        SubscriptionEditDialog(
            idioma = idioma,
            mo = mo,
            subscription = subscriptionToEdit,
            onSave = { sub ->
                if (sub.id == 0) {
                    viewModel.addSubscription(sub)
                } else {
                    viewModel.updateSubscription(sub)
                }
                showEditDialog = false
            },
            onDelete = { sub ->
                viewModel.deleteSubscription(sub.id)
                showEditDialog = false
            },
            onDismiss = { showEditDialog = false }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (idioma == "PT") "Gerenciar Subscrições" else "Manage Subscriptions",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = null)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header summary banner
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                if (idioma == "PT") "Total Estimado / Mês" else "Estimated Total / Month",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                String.format(Locale.getDefault(), "%,.2f $mo", totalMensal).replace(",", "X").replace(".", ",").replace("X", "."),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                "${activeSubs.size} ${if (idioma == "PT") "ativas" else "active"}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Add button
                Button(
                    onClick = {
                        subscriptionToEdit = null
                        showEditDialog = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (idioma == "PT") "+ Nova Subscrição" else "+ New Subscription", fontWeight = FontWeight.Bold)
                }

                HorizontalDivider()

                if (subscriptions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (idioma == "PT") "Nenhuma subscrição cadastrada ainda." else "No subscriptions registered yet.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(subscriptions, key = { it.id }) { sub ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (sub.ativa) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ServiceLogoIcon(
                                        nome = sub.nome,
                                        iconeKey = sub.icone,
                                        corHex = sub.corHex,
                                        modifier = Modifier.size(40.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sub.nome, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(
                                            String.format(Locale.getDefault(), "%,.2f $mo / %s", sub.valor, sub.cicloCobranca.lowercase()).replace(",", "X").replace(".", ",").replace("X", "."),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        val daysRemaining = calculateDaysUntilDayOfMonth(sub.diaCobranca)
                                        val daysStr = if (daysRemaining == 0) (if (idioma == "PT") "hoje" else "today") else (if (idioma == "PT") "em $daysRemaining dias" else "in $daysRemaining days")
                                        Text(
                                            if (idioma == "PT") "Cobrança dia ${sub.diaCobranca} · $daysStr" else "Billed on day ${sub.diaCobranca} · $daysStr",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Switch(
                                            checked = sub.ativa,
                                            onCheckedChange = { viewModel.toggleSubscriptionActive(sub) },
                                            modifier = Modifier.scale(0.8f)
                                        )
                                        Row {
                                            IconButton(
                                                onClick = {
                                                    subscriptionToEdit = sub
                                                    showEditDialog = true
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                            }
                                            IconButton(
                                                onClick = { subscriptionToDelete = sub },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFFEF4444))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Concluir" else "Done")
            }
        }
    )
}

@Composable
fun SubscriptionEditDialog(
    idioma: String,
    mo: String,
    subscription: Subscription?,
    onSave: (Subscription) -> Unit,
    onDelete: (Subscription) -> Unit,
    onDismiss: () -> Unit
) {
    var nome by remember { mutableStateOf(subscription?.nome ?: "") }
    var valorText by remember { mutableStateOf(subscription?.valor?.let { if (it == 0.0) "" else it.toInt().toString() } ?: "") }
    var ciclo by remember { mutableStateOf(subscription?.cicloCobranca ?: "MENSAL") }
    var diaCobranca by remember { mutableIntStateOf(subscription?.diaCobranca ?: 1) }
    var icone by remember { mutableStateOf(subscription?.icone ?: "custom") }
    var corHex by remember { mutableStateOf(subscription?.corHex ?: "#3B82F6") }
    var ativa by remember { mutableStateOf(subscription?.ativa ?: true) }

    val presets = remember {
        listOf(
            Triple("Netflix", "netflix", "#E50914"),
            Triple("Spotify", "spotify", "#1DB954"),
            Triple("YouTube Premium", "youtube", "#FF0000"),
            Triple("Disney+", "disney", "#113CCF"),
            Triple("Amazon Prime", "amazon", "#00A8E1"),
            Triple("Apple Music", "apple", "#333333"),
            Triple("ChatGPT Plus", "chatgpt", "#10A37F"),
            Triple("Internet Casa", "internet", "#3B82F6"),
            Triple("Gym / Academia", "gym", "#F97316")
        )
    }

    val iconOptions = remember {
        listOf(
            Pair("tv", if (idioma == "PT") "TV / Streaming" else "TV / Streaming"),
            Pair("music", if (idioma == "PT") "Música" else "Music"),
            Pair("game", if (idioma == "PT") "Jogos" else "Gaming"),
            Pair("shopping", if (idioma == "PT") "Compras" else "Shopping"),
            Pair("cloud", if (idioma == "PT") "Nuvem" else "Cloud"),
            Pair("phone", if (idioma == "PT") "Mobile" else "Mobile"),
            Pair("electric", if (idioma == "PT") "Energia" else "Energy"),
            Pair("gym", if (idioma == "PT") "Academia" else "Gym"),
            Pair("star", if (idioma == "PT") "Especial" else "Special"),
            Pair("card", if (idioma == "PT") "Cartão" else "Card"),
            Pair("car", if (idioma == "PT") "Veículo" else "Vehicle"),
            Pair("home", if (idioma == "PT") "Casa" else "Home"),
            Pair("work", if (idioma == "PT") "Trabalho" else "Work"),
            Pair("custom", if (idioma == "PT") "Inicial" else "Initial Letter")
        )
    }

    val colorPalette = remember {
        listOf(
            "#3B82F6", "#EF4444", "#10B981", "#8B5CF6",
            "#EC4899", "#F97316", "#06B6D4", "#6366F1",
            "#14B8A6", "#EAB308", "#1E293B", "#000000"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (subscription == null) (if (idioma == "PT") "Nova Subscrição" else "New Subscription")
                else (if (idioma == "PT") "Editar Subscrição" else "Edit Subscription"),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Live Preview Header
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ServiceLogoIcon(
                            nome = nome.ifBlank { "S" },
                            iconeKey = icone,
                            corHex = corHex,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                if (nome.isNotBlank()) nome else (if (idioma == "PT") "Nome do Serviço" else "Service Name"),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                if (idioma == "PT") "Pré-visualização do Ícone" else "Icon Live Preview",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Preset Quick Choice Chips
                Text(if (idioma == "PT") "Atalhos de Marcas:" else "Brand Presets:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(presets) { (pName, pIcon, pColor) ->
                        FilterChip(
                            selected = nome == pName,
                            onClick = {
                                nome = pName
                                icone = pIcon
                                corHex = pColor
                            },
                            label = { Text(pName, fontSize = 11.sp) }
                        )
                    }
                }

                // Name field
                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text(if (idioma == "PT") "Nome do Serviço" else "Service Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Price field
                OutlinedTextField(
                    value = valorText,
                    onValueChange = { valorText = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                    label = { Text(if (idioma == "PT") "Valor ($mo)" else "Price ($mo)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Icon Picker
                Text(if (idioma == "PT") "Escolher Ícone:" else "Choose Icon:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(iconOptions) { (key, label) ->
                        FilterChip(
                            selected = icone == key,
                            onClick = { icone = key },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }

                // Color Palette Picker
                Text(if (idioma == "PT") "Cor do Ícone:" else "Icon Color:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(colorPalette) { hex ->
                        val parsedColor = remember(hex) {
                            try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { Color.Gray }
                        }
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(parsedColor)
                                .border(
                                    width = if (corHex.equals(hex, ignoreCase = true)) 2.5.dp else 0.dp,
                                    color = if (corHex.equals(hex, ignoreCase = true)) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { corHex = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (corHex.equals(hex, ignoreCase = true)) {
                                Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }

                // Cycle selector
                Text(if (idioma == "PT") "Ciclo de Cobrança:" else "Billing Cycle:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("MENSAL", "ANUAL", "SEMANAL").forEach { c ->
                        FilterChip(
                            selected = ciclo == c,
                            onClick = { ciclo = c },
                            label = {
                                Text(
                                    when (c) {
                                        "MENSAL" -> if (idioma == "PT") "Mensal" else "Monthly"
                                        "ANUAL" -> if (idioma == "PT") "Anual" else "Yearly"
                                        else -> if (idioma == "PT") "Semanal" else "Weekly"
                                    },
                                    fontSize = 12.sp
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Billing Day / Payment Date Picker
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (idioma == "PT") "Data / Dia do Pagamento (Mês):" else "Payment Date / Day of Month:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = if (diaCobranca == 0) "" else "$diaCobranca",
                            onValueChange = { input ->
                                val dayNum = input.filter { it.isDigit() }.toIntOrNull()
                                if (dayNum != null) {
                                    diaCobranca = dayNum.coerceIn(1, 31)
                                } else if (input.isEmpty()) {
                                    diaCobranca = 1
                                }
                            },
                            label = { Text(if (idioma == "PT") "Dia (1 a 31)" else "Day (1 to 31)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.width(130.dp)
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { if (diaCobranca > 1) diaCobranca-- },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Icon(Icons.Rounded.Remove, contentDescription = "Diminuir dia", modifier = Modifier.size(18.dp))
                            }
                            Text(
                                text = " Dia $diaCobranca ",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            IconButton(
                                onClick = { if (diaCobranca < 31) diaCobranca++ },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = "Aumentar dia", modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    // Quick Day Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        items(listOf(1, 5, 10, 15, 20, 25, 28, 30, 31)) { day ->
                            FilterChip(
                                selected = diaCobranca == day,
                                onClick = { diaCobranca = day },
                                label = { Text("Dia $day", fontSize = 10.sp) }
                            )
                        }
                    }
                }

                // Active toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (idioma == "PT") "Subscrição Ativa" else "Active Subscription", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Switch(checked = ativa, onCheckedChange = { ativa = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val priceVal = valorText.replace(",", ".").toDoubleOrNull() ?: 0.0
                    if (nome.isNotBlank()) {
                        val sub = Subscription(
                            id = subscription?.id ?: 0,
                            nome = nome.trim(),
                            valor = priceVal,
                            cicloCobranca = ciclo,
                            diaCobranca = diaCobranca,
                            icone = icone,
                            corHex = corHex,
                            ativa = ativa
                        )
                        onSave(sub)
                    }
                },
                enabled = nome.isNotBlank()
            ) {
                Text(if (idioma == "PT") "Salvar" else "Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Cancelar" else "Cancel")
            }
        }
    )
}

@Composable
fun ExportHistoryModal(
    idioma: String,
    reports: List<ExportedReport>,
    onDeleteReport: (ExportedReport) -> Unit = {},
    onDismiss: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
    var selectedReportForPreview by remember { mutableStateOf<ExportedReport?>(null) }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (idioma == "PT") "Histórico de Relatórios Exportados" else "Exported Reports History",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            if (reports.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (idioma == "PT") "Nenhum relatório exportado ainda." else "No exported reports yet.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(reports) { report ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedReportForPreview = report },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = report.fileName,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = if (report.format.uppercase() == "PDF") Color(0xFFEF4444).copy(alpha = 0.15f) else Color(0xFF10B981).copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = report.format.uppercase(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (report.format.uppercase() == "PDF") Color(0xFFDC2626) else Color(0xFF059669),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                    Text(
                                        text = dateFormat.format(Date(report.timestamp)),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (idioma == "PT") "• Toque para ler" else "• Tap to read",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = { selectedReportForPreview = report },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Visibility,
                                        contentDescription = "Visualizar",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteReport(report) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFEF4444),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, shape = RoundedCornerShape(8.dp)) {
                Text(if (idioma == "PT") "Fechar" else "Close")
            }
        }
    )

    if (selectedReportForPreview != null) {
        val r = selectedReportForPreview!!
        val fileToRead = remember(r) {
            val f = if (r.filePath.isNotEmpty()) File(r.filePath) else null
            if (f != null && f.exists()) f
            else {
                val cacheFile = File(context.cacheDir, r.fileName)
                if (cacheFile.exists()) cacheFile else null
            }
        }

        if (fileToRead != null && fileToRead.exists()) {
            com.example.ui.preview.ReportPreviewModal(
                file = fileToRead,
                reportName = r.fileName,
                format = r.format,
                idioma = idioma,
                onDismiss = { selectedReportForPreview = null }
            )
        } else {
            AlertDialog(
                onDismissRequest = { selectedReportForPreview = null },
                title = { Text(r.fileName) },
                text = { Text(if (idioma == "PT") "O ficheiro do relatório não se encontra no armazenamento local." else "Report file not found in local storage.") },
                confirmButton = {
                    TextButton(onClick = { selectedReportForPreview = null }) {
                        Text(if (idioma == "PT") "Fechar" else "Close")
                    }
                }
            )
        }
    }
}
