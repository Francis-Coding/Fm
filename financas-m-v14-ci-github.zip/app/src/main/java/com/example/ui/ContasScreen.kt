@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import com.example.util.AutoResizedText
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File


// ------------------- TELA 4: CARTEIRAS / CONTAS -------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ContasScreen(
    viewModel: MainViewModel,
    wallets: List<Wallet>,
    settings: UserSettings,
    onLoansClick: () -> Unit,
    lazyListState: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState()
) {
    var showAddWalletModal by remember { mutableStateOf(false) }
    var nomeWallet by remember { mutableStateOf("") }
    var saldoWallet by remember { mutableStateOf("") }
    var showSaldoCalculator by remember { mutableStateOf(false) }
    var iconeWallet by remember { mutableStateOf("account_balance_wallet") }
    var corWallet by remember { mutableStateOf("#1A73E8") }
    var showActionDialogForWallet by remember { mutableStateOf<Wallet?>(null) }
    var showEditWalletDialog by remember { mutableStateOf<Wallet?>(null) }
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    val idioma = settings.idioma

    val realBalancesInput = viewModel.realBalancesInput
    var activeCalculatorWalletId by remember { mutableStateOf<Int?>(null) }

    // Lifted state collections to top level of Composable context
    val closuresList by viewModel.closures.collectAsStateWithLifecycle(emptyList())
    val loansList by viewModel.loans.collectAsStateWithLifecycle(emptyList())

    var showAllWallets by remember { mutableStateOf(false) }
    var selectedAccountTypeFilter by remember { mutableStateOf("Todas") }
    var isOrganizingMode by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    var showRecurringTransfersModal by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf("CARTEIRAS") }
    val scheduledTransfersList by viewModel.scheduledTransfers.collectAsStateWithLifecycle(emptyList())

    val isDark = settings.tema == "dark"
    val themePrimary = if (isDark) Color(0xFF35D07F) else Color(0xFF087A35)
    val backgroundColor = if (isDark) Color(0xFF090B11) else Color(0xFFF8FAF9)
    val cardBg = if (isDark) Color(0xFF141B2D) else Color(0xFFFFFFFF)
    val textPrimary = if (isDark) Color(0xFFFFFFFF) else Color(0xFF172033)
    val textSecondary = if (isDark) Color(0xFF98A2B3) else Color(0xFF667085)
    val borderCol = if (isDark) Color(0x0DFFFFFF) else Color(0xFFEEF2EE)
    val dividerCol = if (isDark) Color(0x0DFFFFFF) else Color(0xFFEEF2EE)
    val surfaceVariantColor = if (isDark) Color(0xFF141B2D) else Color(0xFFF1F5F9)

    // Helper formatter for MZN/Currency with space thousands separator
    fun formatVal(value: Double): String {
        if (settings.ocultarSaldos) return "••••• ${settings.moedaPadrao}"
        return com.example.util.MoneyFormatter.formatWithDecimals(value, settings.moedaPadrao)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- HEADER ---
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Title and Top Quick Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (idioma == "PT") "Minhas Contas" else "My Accounts",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = textPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(imageVector = Icons.Rounded.Paid, contentDescription = null, tint = Color(0xFF00E676), modifier = Modifier.size(20.dp))
                }

                // Compact Quick Actions Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Agendamentos Button (Compact Pill)
                    OutlinedButton(
                        onClick = { showRecurringTransfersModal = true },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isDark) themePrimary.copy(alpha = 0.08f) else themePrimary.copy(alpha = 0.04f),
                            contentColor = themePrimary
                        ),
                        border = BorderStroke(1.dp, themePrimary.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Schedule,
                            contentDescription = null,
                            tint = themePrimary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (idioma == "PT") "Agendas" else "Scheduled",
                            color = themePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    // Nova Conta Button (Compact Primary Pill)
                    Button(
                        onClick = { showAddWalletModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = themePrimary),
                        shape = RoundedCornerShape(20.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 1.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("add_wallet_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (idioma == "PT") "Nova" else "New",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Compact Sub-Tabs Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(surfaceVariantColor)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeTab = "CARTEIRAS" },
                    shape = RoundedCornerShape(8.dp),
                    color = if (activeTab == "CARTEIRAS") themePrimary else Color.Transparent
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Wallet,
                            contentDescription = null,
                            tint = if (activeTab == "CARTEIRAS") Color.White else textSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (idioma == "PT") "Carteiras" else "Accounts",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeTab == "CARTEIRAS") Color.White else textSecondary
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeTab = "CARTOES" },
                    shape = RoundedCornerShape(8.dp),
                    color = if (activeTab == "CARTOES") themePrimary else Color.Transparent
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CreditCard,
                            contentDescription = null,
                            tint = if (activeTab == "CARTOES") Color.White else textSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (idioma == "PT") "Cartões de Crédito" else "Credit Cards",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeTab == "CARTOES") Color.White else textSecondary
                        )
                    }
                }
            }

            if (activeTab == "CARTOES") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    CreditCardsModuleSection(
                        viewModel = viewModel,
                        wallets = wallets,
                        settings = settings
                    )
                }
            }
        }

        if (activeTab == "CARTEIRAS") {
        // --- SCROLLABLE CONTENT ---
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            
            // --- 1. CONSOLIDATED KPI BADGES CARD ---
            item {
                val totalBalance = remember(wallets) { wallets.sumOf { it.saldoAtual } }
                val totalBalanceConverted = remember(totalBalance, settings.moedaPadrao) {
                    viewModel.currencyService.convertFromMZN(totalBalance, settings.moedaPadrao)
                }

                val latestClosure = remember(closuresList) {
                    closuresList.sortedByDescending { it.data }.firstOrNull { it.carteiraId == 0 }
                }
                
                val diffReconciliation = remember(latestClosure, settings.moedaPadrao) {
                    if (latestClosure != null) {
                        val espConv = viewModel.currencyService.convertFromMT(latestClosure.saldoEsperado, settings.moedaPadrao)
                        val realConv = viewModel.currencyService.convertFromMT(latestClosure.saldoReal, settings.moedaPadrao)
                        realConv - espConv
                    } else {
                        0.0
                    }
                }

                val statsData = remember(closuresList, wallets) {
                    // Every reconciliation this app performs is consolidated (carteiraId == 0)
                    // and covers ALL wallets at once — there is no per-wallet closure record.
                    // A wallet counts as reconciled iff a consolidated closure happened recently.
                    val twentyFourHoursAgo = System.currentTimeMillis() - 24 * 60 * 60 * 1000
                    val hasRecentConsolidatedClosure = closuresList.any { it.carteiraId == 0 && it.data > twentyFourHoursAgo }
                    val pendenciasCount = if (hasRecentConsolidatedClosure) 0 else wallets.size
                    Pair(hasRecentConsolidatedClosure, pendenciasCount)
                }
                val pendenciasCount = statsData.second

                val lastReconciliationText = remember(latestClosure, idioma) {
                    if (latestClosure != null) {
                        val closureDate = java.util.Date(latestClosure.data)
                        val today = java.util.Calendar.getInstance()
                        val closureCal = java.util.Calendar.getInstance().apply { time = closureDate }
                        val isToday = today.get(java.util.Calendar.YEAR) == closureCal.get(java.util.Calendar.YEAR) &&
                                      today.get(java.util.Calendar.DAY_OF_YEAR) == closureCal.get(java.util.Calendar.DAY_OF_YEAR)
                        
                        val isYesterday = today.get(java.util.Calendar.YEAR) == closureCal.get(java.util.Calendar.YEAR) &&
                                          today.get(java.util.Calendar.DAY_OF_YEAR) - closureCal.get(java.util.Calendar.DAY_OF_YEAR) == 1
                        
                        val timeFormat = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(closureDate)
                        when {
                            isToday -> if (idioma == "PT") "Hoje, $timeFormat" else "Today, $timeFormat"
                            isYesterday -> if (idioma == "PT") "Ontem, $timeFormat" else "Yesterday, $timeFormat"
                            else -> java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.getDefault()).format(closureDate)
                        }
                    } else {
                        if (idioma == "PT") "Nunca" else "Never"
                    }
                }

                val lastReconciliationDateText = remember(latestClosure) {
                    if (latestClosure != null) {
                        java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(latestClosure.data))
                    } else {
                        "---"
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF1E2F21) else Color(0xFFF1F8F1)), // Exquisite very light sage tint
                    border = BorderStroke(1.dp, if (isDark) Color(0xFF2E4D34) else Color(0xFFE1EBE1))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Section 1: Saldo Total Consolidado
                        Column(
                            modifier = Modifier.weight(1.1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (idioma == "PT") "Saldo Total Consolidado" else "Consolidated Total Balance",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFF9CCC9C) else Color(0xFF556B55)
                            )
                            AutoResizedText(
                                text = formatVal(totalBalanceConverted),
                                maxFontSize = 17.sp,
                                minFontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isDark) Color(0xFF81C784) else Color(0xFF1B5E20),
                                maxLines = 1,
                                softWrap = false,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, tint = textSecondary, modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = if (idioma == "PT") "${wallets.size} contas ativas" else "${wallets.size} active accounts",
                                    fontSize = 11.sp,
                                    color = textSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Divider 1
                        Box(
                            modifier = Modifier
                                .height(56.dp)
                                .width(1.dp)
                                .background(if (isDark) Color(0xFF2E4D34) else Color(0xFFE1EBE1))
                                .padding(horizontal = 4.dp)
                        )

                        // Section 2: Diferença da Reconciliação
                        Column(
                            modifier = Modifier.weight(1.0f).padding(horizontal = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (idioma == "PT") "Diferença da Reconciliação" else "Reconciliation Difference",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFF9CCC9C) else Color(0xFF556B55)
                            )
                            val diffColor = if (diffReconciliation < -0.005) (if (isDark) Color(0xFFE57373) else Color(0xFFC62828)) else if (diffReconciliation > 0.005) (if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)) else (if (isDark) Color(0xFF81C784) else Color(0xFF1B5E20))
                            val diffPrefix = if (diffReconciliation > 0.005) "+" else ""
                            Text(
                                text = if (settings.ocultarSaldos) "•••••" else "$diffPrefix${String.format(java.util.Locale.GERMAN, "%,.2f", diffReconciliation).replace('.', ' ')} ${settings.moedaPadrao}",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = diffColor
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (pendenciasCount > 0) Color.Red else Color.Green))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (idioma == "PT") "$pendenciasCount pendências" else "$pendenciasCount pending",
                                    fontSize = 11.sp,
                                    color = textSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Divider 2
                        Box(
                            modifier = Modifier
                                .height(56.dp)
                                .width(1.dp)
                                .background(if (isDark) Color(0xFF2E4D34) else Color(0xFFE1EBE1))
                        )

                        // Section 3: Última Reconciliação
                        Column(
                            modifier = Modifier.weight(1.0f).padding(start = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (idioma == "PT") "Última Reconciliação" else "Last Reconciliation",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFF9CCC9C) else Color(0xFF556B55)
                            )
                            Text(
                                text = lastReconciliationText,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.CalendarToday, contentDescription = null, tint = textSecondary, modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = lastReconciliationDateText,
                                    fontSize = 11.sp,
                                    color = textSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // --- 2. LOANS CARD ---
            item {
                val activeLoansCount = loansList.count { it.status == "PENDING" }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onLoansClick() }
                        .testTag("loans_redirection_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF281E2C) else Color(0xFFFDF7FF)), // Ultra elegant soft lavender background
                    border = BorderStroke(1.dp, if (isDark) Color(0xFF402E48) else Color(0xFFF3E5F5))
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF7B1FA2)), // Deep Purple icon square
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Handshake,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = Translator.t("loans", idioma),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isDark) Color(0xFFE1BEE7) else Color(0xFF4A148C)
                                )
                                Text(
                                    text = if (idioma == "PT") "$activeLoansCount empréstimos ativos" else "$activeLoansCount active loans",
                                    fontSize = 12.sp,
                                    color = if (isDark) Color(0xFFCE93D8) else Color(0xFF7B1FA2).copy(alpha = 0.8f),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint = if (isDark) Color(0xFFE1BEE7) else Color(0xFF4A148C),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // --- 3. CONTAS HEADER ---
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (idioma == "PT") "Contas" else "Accounts",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        )
                        if (isOrganizingMode) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(themePrimary.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Modo Reordenar" else "Reorder Mode",
                                    color = themePrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Toggle Organizing Mode Button
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { 
                                    isOrganizingMode = !isOrganizingMode 
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    val toastMsg = if (isOrganizingMode) {
                                        if (idioma == "PT") "Modo de ordenação ativo. Use as setas para mover as contas." else "Reorder mode active. Use the arrows to prioritize accounts."
                                    } else {
                                        if (idioma == "PT") "Ordenação salva!" else "Ordering saved!"
                                    }
                                    Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isOrganizingMode) Icons.Rounded.Check else Icons.AutoMirrored.Rounded.Sort,
                                contentDescription = "Organizar",
                                tint = themePrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (isOrganizingMode) {
                                    if (idioma == "PT") "Pronto" else "Done"
                                } else {
                                    if (idioma == "PT") "Organizar" else "Organize"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = themePrimary
                            )
                        }

                        if (wallets.size > 4 && !isOrganizingMode) {
                            Text(
                                text = if (showAllWallets) {
                                    if (idioma == "PT") "Ver menos" else "View less"
                                } else {
                                    if (idioma == "PT") "Ver todas" else "View all"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = themePrimary,
                                modifier = Modifier
                                    .clickable {
                                        showAllWallets = !showAllWallets
                                        val msg = if (showAllWallets) {
                                            if (idioma == "PT") "Exibindo todas as contas ativas" else "Showing all active accounts"
                                        } else {
                                            if (idioma == "PT") "Exibindo as principais contas" else "Showing main accounts"
                                        }
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    }
                                    .bounceClick()
                            )
                        }
                    }
                }
            }

            // --- 4. CONTAS LIST ---
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val filters = listOf("Todas", "Mobile Money", "Bancos", "Dinheiro")
                    filters.forEach { filter ->
                        val isSelected = selectedAccountTypeFilter == filter
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) themePrimary else cardBg,
                            border = if (!isSelected) BorderStroke(1.dp, borderCol) else null,
                            modifier = Modifier.clickable { selectedAccountTypeFilter = filter }
                        ) {
                            Text(
                                text = filter,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else textPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            item {
                val filtered = wallets.filter { w ->
                    val name = w.nome.lowercase()
                    when (selectedAccountTypeFilter) {
                        "Mobile Money" -> name.contains("m-pesa") || name.contains("mpesa") || name.contains("e-mola") || name.contains("emola") || name.contains("mobile")
                        "Bancos" -> name.contains("banco") || name.contains("bank") || name.contains("bci") || name.contains("millennium") || name.contains("standard") || name.contains("absa")
                        "Dinheiro" -> name.contains("carteira") || name.contains("dinheiro") || name.contains("cash") || name.contains("principal")
                        else -> true
                    }
                }
                val displayedWallets = if (showAllWallets || isOrganizingMode) filtered else filtered.take(4)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp) // Sleek closer spacing between account cards!
                ) {
                    displayedWallets.forEach { w ->
                        val converted = viewModel.currencyService.convertFromMT(w.saldoAtual, settings.moedaPadrao)
                        val cardColor = try {
                            Color(android.graphics.Color.parseColor(w.cor))
                        } catch (e: Exception) {
                            MaterialTheme.colorScheme.surface
                        }

                        var dragOffsetY by remember(w.id) { mutableStateOf(0f) }
                        var isDragging by remember(w.id) { mutableStateOf(false) }

                        @Composable
                        fun WalletCardContent(wallet: Wallet) {
                            val isPrincipal = wallet.nome.lowercase().contains("principal") || wallet.nome.lowercase().contains("carteira")
                            val isEMola = wallet.nome.lowercase().contains("e-mola") || wallet.nome.lowercase().contains("emola")
                            val isMPesa = wallet.nome.lowercase().contains("pesa")
                            val isRecargarki = wallet.nome.lowercase().contains("recargarki")

                            val circleBgColor = when {
                                isEMola -> Color(0xFFE8F5E9)       // Soft green
                                isMPesa -> Color(0xFFFCE4EC)       // Soft pink
                                isPrincipal -> Color(0xFFE3F2FD)   // Soft blue
                                isRecargarki -> Color(0xFFFFF8E1)  // Soft yellow
                                else -> cardColor.copy(alpha = 0.12f)
                            }

                            val iconKey = when {
                                isEMola -> "payments"
                                isMPesa -> "smartphone"
                                isPrincipal -> "account_balance_wallet"
                                isRecargarki -> "receipt_long"
                                else -> wallet.icone
                            }

                            // Dynamic update status line
                            val transactionsFlow = viewModel.transactions.value
                            val lastTx = transactionsFlow.filter { it.carteiraOrigemId == wallet.id }.maxByOrNull { it.data }
                            val timeDiffText = if (lastTx != null) {
                                val diffMs = System.currentTimeMillis() - lastTx.data
                                val diffMins = (diffMs / (60 * 1000)).toInt()
                                when {
                                    diffMins < 1 -> if (idioma == "PT") "Atualizado agora" else "Updated just now"
                                    diffMins < 60 -> if (idioma == "PT") "Atualizado há $diffMins min" else "Updated $diffMins min ago"
                                    diffMins < 1440 -> {
                                        val hours = diffMins / 60
                                        if (idioma == "PT") "Atualizado há $hours h" else "Updated $hours h ago"
                                    }
                                    else -> {
                                        val days = diffMins / 1440
                                        if (idioma == "PT") "Atualizado há $days d" else "Updated $days d ago"
                                    }
                                }
                            } else {
                                val minutes = (wallet.id * 2) % 6
                                if (minutes == 0) {
                                    if (idioma == "PT") "Atualizado agora" else "Updated just now"
                                } else {
                                    if (idioma == "PT") "Atualizado há $minutes min" else "Updated $minutes min ago"
                                }
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (!isOrganizingMode) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            showActionDialogForWallet = wallet
                                        }
                                    }
                                    .pointerInput(wallet.id) {
                                        if (isOrganizingMode) {
                                            detectDragGestures(
                                                onDragStart = { _ ->
                                                    isDragging = true
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                },
                                                onDragEnd = {
                                                    isDragging = false
                                                    dragOffsetY = 0f
                                                },
                                                onDragCancel = {
                                                    isDragging = false
                                                    dragOffsetY = 0f
                                                },
                                                onDrag = { change, dragAmount ->
                                                    change.consume()
                                                    dragOffsetY += dragAmount.y
                                                    val threshold = 70f
                                                    if (dragOffsetY > threshold) {
                                                        viewModel.reorderWalletDown(wallet)
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                        dragOffsetY = 0f
                                                    } else if (dragOffsetY < -threshold) {
                                                        viewModel.reorderWalletUp(wallet)
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                        dragOffsetY = 0f
                                                    }
                                                }
                                            )
                                        }
                                    }
                                    .offset { androidx.compose.ui.unit.IntOffset(0, dragOffsetY.roundToInt()) }
                                    .graphicsLayer {
                                        if (isDragging) {
                                            scaleX = 1.04f
                                            scaleY = 1.04f
                                            shadowElevation = 8.dp.toPx()
                                        }
                                    }
                                    .testTag("wallet_item_${wallet.id}"),
                                colors = CardDefaults.cardColors(containerColor = cardBg),
                                border = if (isOrganizingMode) BorderStroke(1.5.dp, themePrimary.copy(alpha = 0.5f)) else BorderStroke(1.dp, borderCol),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 12.dp, vertical = 6.dp) // Sleeker padding!
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp) // Sleeker spacing!
                                ) {
                                    if (isOrganizingMode) {
                                        Icon(
                                            imageVector = Icons.Rounded.DragHandle,
                                            contentDescription = "Drag Handle",
                                            tint = textSecondary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    // Perfect Avatar Icon Circle (reduced size for sleekness)
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp) // Sleeker avatar size!
                                            .clip(CircleShape)
                                            .background(circleBgColor),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        AppIcon(iconKey = iconKey, modifier = Modifier.size(20.dp), tint = themePrimary)
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = wallet.nome,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp, // Sleeker font!
                                                color = textPrimary,
                                                maxLines = 1,
                                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                            if (!isOrganizingMode) {
                                                // "Ativa" Pill Badge
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(50))
                                                        .background(if (isDark) Color(0xFF1E3822) else Color(0xFFE8F5E9))
                                                        .padding(horizontal = 6.dp, vertical = 1.dp)
                                                ) {
                                                    Text(
                                                        text = if (idioma == "PT") "Ativa" else "Active",
                                                        color = if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32),
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 8.sp // Sleeker badge!
                                                    )
                                                }
                                            }
                                        }

                                        // Subtype badges rendering
                                        if (!isOrganizingMode) {
                                            val subTypeInfo = remember(wallet.nome) {
                                                val name = wallet.nome.lowercase()
                                                when {
                                                    name.contains("m-pesa") || name.contains("mpesa") || name.contains("e-mola") || name.contains("emola") -> {
                                                        "Mobile Money" to "Taxa: 1.5%"
                                                    }
                                                    name.contains("poupança") || name.contains("savings") || name.contains("invest") -> {
                                                        "Poupança" to "5% a.a."
                                                    }
                                                    name.contains("crédito") || name.contains("credit") || name.contains("cartão") -> {
                                                        "Crédito" to "Limite"
                                                    }
                                                    else -> {
                                                        "Dinheiro" to "Grátis"
                                                    }
                                                }
                                            }
                                            val totalNetWorth = remember(wallets) { wallets.sumOf { it.saldoAtual }.coerceAtLeast(1.0) }
                                            val walletSharePct = remember(wallet.saldoAtual, totalNetWorth) {
                                                val pct = (wallet.saldoAtual / totalNetWorth) * 100
                                                String.format(java.util.Locale.US, "%.1f%%", pct)
                                            }

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier.padding(vertical = 2.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f, fill = false)
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(themePrimary.copy(alpha = 0.08f))
                                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                                ) {
                                                    Text(
                                                        text = "${subTypeInfo.first} • ${subTypeInfo.second}",
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = themePrimary,
                                                        maxLines = 1,
                                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                                    )
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(if (isDark) Color(0xFF2A2238) else Color(0xFFF3E5F5))
                                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                                ) {
                                                    Text(
                                                        text = walletSharePct,
                                                        maxLines = 1,
                                                        softWrap = false,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isDark) Color(0xFFCE93D8) else Color(0xFF7B1FA2)
                                                    )
                                                }
                                            }
                                        }

                                        if (!isOrganizingMode) {
                                            Spacer(modifier = Modifier.height(1.dp))
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp) // Sleeker dot!
                                                        .clip(CircleShape)
                                                        .background(Color(0xFF4CAF50))
                                                )
                                                Text(
                                                    text = timeDiffText,
                                                    maxLines = 1,
                                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                                    fontSize = 10.sp, // Sleeker status font!
                                                    color = textSecondary,
                                                    fontWeight = FontWeight.Medium
                                                )
                                                 val twentyFourHoursAgo = System.currentTimeMillis() - 24 * 60 * 60 * 1000L
                                                // Consolidated reconciliations (carteiraId == 0) cover every wallet at
                                                // once — there's no per-wallet closure record to match against.
                                                val isReconciled = closuresList.any { it.carteiraId == 0 && it.data > twentyFourHoursAgo }
                                                if (!isReconciled) {
                                                    Box(
                                                        modifier = Modifier
                                                            .padding(start = 2.dp)
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(com.example.ui.theme.AppTheme.SemanticColors.warningBackground)
                                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = if (idioma == "PT") "Reconciliação pendente" else "Pending reconciliation",
                                                            fontSize = 8.sp,
                                                            maxLines = 1,
                                                            softWrap = false,
                                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                                            fontWeight = FontWeight.Bold,
                                                            color = com.example.ui.theme.AppTheme.SemanticColors.warningText
                                                        )
                                                    }
                                                }
                                            }
                                        } else {
                                            var posPickerExpanded by remember { mutableStateOf(false) }
                                            Box {
                                                Surface(
                                                    onClick = { posPickerExpanded = true },
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = themePrimary.copy(alpha = 0.1f),
                                                    border = BorderStroke(1.dp, themePrimary.copy(alpha = 0.3f))
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Text(
                                                            text = if (idioma == "PT") "Posição: ${wallet.ordem + 1} ▾" else "Position: ${wallet.ordem + 1} ▾",
                                                            fontSize = 11.sp,
                                                            color = themePrimary,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                                DropdownMenu(
                                                    expanded = posPickerExpanded,
                                                    onDismissRequest = { posPickerExpanded = false }
                                                ) {
                                                    wallets.indices.forEach { targetIdx ->
                                                        DropdownMenuItem(
                                                            text = { Text(if (idioma == "PT") "Mover para ${targetIdx + 1}º lugar" else "Move to position ${targetIdx + 1}") },
                                                            onClick = {
                                                                posPickerExpanded = false
                                                                viewModel.moveWalletToPosition(wallet, targetIdx)
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (isOrganizingMode) {
                                        // Up/Down reorder controls
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            IconButton(
                                                onClick = { 
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    viewModel.reorderWalletUp(wallet) 
                                                },
                                                modifier = Modifier.size(28.dp).testTag("wallet_up_${wallet.id}")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.KeyboardArrowUp,
                                                    contentDescription = "Move Up",
                                                    tint = themePrimary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                            IconButton(
                                                onClick = { 
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    viewModel.reorderWalletDown(wallet) 
                                                },
                                                modifier = Modifier.size(28.dp).testTag("wallet_down_${wallet.id}")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.KeyboardArrowDown,
                                                    contentDescription = "Move Down",
                                                    tint = themePrimary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    } else {
                                        Column(
                                            horizontalAlignment = Alignment.End,
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                AutoResizedText(
                                                    text = formatVal(converted),
                                                    maxFontSize = 15.sp,
                                                    minFontSize = 9.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = textPrimary,
                                                    maxLines = 1,
                                                    softWrap = false,
                                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                                )
                                                Icon(
                                                    imageVector = Icons.Rounded.ChevronRight,
                                                    contentDescription = null,
                                                    tint = textSecondary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }

                                            val walletTxs = remember(transactionsFlow, wallet.id) {
                                                transactionsFlow.filter { it.carteiraOrigemId == wallet.id }
                                            }
                                            val wIn = remember(walletTxs) { walletTxs.filter { it.isReceita() }.sumOf { it.valor } }
                                            val wOut = remember(walletTxs) { walletTxs.filter { it.isDespesa() }.sumOf { it.valor } }
                                            val wInConv = viewModel.currencyService.convertFromMT(wIn, settings.moedaPadrao)
                                            val wOutConv = viewModel.currencyService.convertFromMT(wOut, settings.moedaPadrao)

                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                val formattedIn = if (settings.ocultarSaldos) "••••" else String.format(java.util.Locale.GERMAN, "%,.0f", wInConv).replace('.', ' ')
                                                val formattedOut = if (settings.ocultarSaldos) "••••" else String.format(java.util.Locale.GERMAN, "%,.0f", wOutConv).replace('.', ' ')
                                                Text("↑ +$formattedIn", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32), maxLines = 1)
                                                Text("↓ -$formattedOut", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color(0xFFE57373) else Color(0xFFC62828), maxLines = 1)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (isOrganizingMode) {
                            WalletCardContent(w)
                        } else {
                            SwipeToDeleteContainer(
                                item = w,
                                onDelete = { viewModel.deleteWallet(it) },
                                requireConfirmation = true
                            ) { wallet ->
                                WalletCardContent(wallet)
                            }
                        }
                    }
                }
            }

            // --- 5. RECONCILIAÇÃO DIÁRIA HEADER ---
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (idioma == "PT") "Reconciliação Diária" else "Daily Reconciliation",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Rounded.Analytics, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = if (idioma == "PT") "Ver detalhes" else "View details",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier
                            .clickable {
                                coroutineScope.launch {
                                    lazyListState.animateScrollToItem(6)
                                }
                            }
                            .bounceClick()
                    )
                }
            }

            // --- 6. RECONCILIAÇÃO DIÁRIA CARD TABLE ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = BorderStroke(1.dp, borderCol)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (wallets.isEmpty()) {
                            Text(
                                text = if (idioma == "PT") "Adicione uma conta primeiro." else "Add an account first.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(8.dp)
                            )
                        } else {
                            // Table Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                 Text(
                                    text = if (idioma == "PT") "Conta" else "Account",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textSecondary,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = if (idioma == "PT") "Esperado" else "Expected",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color(0xFF64B5F6) else Color(0xFF1E88E5), // Blue exactly
                                    modifier = Modifier.weight(1.35f),
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = if (idioma == "PT") "Seu Saldo" else "Your Balance",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textSecondary,
                                    modifier = Modifier.weight(1.1f),
                                    textAlign = TextAlign.End
                                )
                            }

                            HorizontalDivider(color = dividerCol)

                            // Table Rows
                            for (wallet in wallets) {
                                val expectedConverted = viewModel.currencyService.convertFromMT(wallet.saldoAtual, settings.moedaPadrao)
                                val currentInput = realBalancesInput[wallet.id] ?: ""

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Column 1: Account Info
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        com.example.util.AppIcon(
                                            iconKey = if (wallet.icone.isNotBlank()) wallet.icone else wallet.nome,
                                            contentDescription = wallet.nome,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = wallet.nome,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    // Column 2: Expected (Sistema)
                                    Text(
                                        text = formatVal(expectedConverted),
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = textPrimary,
                                        modifier = Modifier.weight(1.35f),
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    // Column 3: Text Field Input
                                    Box(
                                        modifier = Modifier.weight(1.1f),
                                        contentAlignment = Alignment.CenterEnd
                                    ) {
                                        var isFocused by remember { mutableStateOf(false) }
                                        BasicTextField(
                                            value = currentInput,
                                            onValueChange = { newValue ->
                                                realBalancesInput[wallet.id] = sanitizeDoubleInput(currentInput, newValue)
                                            },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            textStyle = androidx.compose.ui.text.TextStyle(
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textPrimary,
                                                textAlign = TextAlign.End
                                            ),
                                            modifier = Modifier
                                                .width(110.dp)
                                                .height(32.dp)
                                                .onFocusChanged { focusState ->
                                                    isFocused = focusState.isFocused
                                                },
                                            decorationBox = { innerTextField ->
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .background(if (isFocused) cardBg else backgroundColor, RoundedCornerShape(6.dp))
                                                        .border(
                                                            1.dp,
                                                            if (isFocused) themePrimary else borderCol,
                                                            RoundedCornerShape(6.dp)
                                                        )
                                                        .padding(horizontal = 6.dp),
                                                    contentAlignment = Alignment.CenterEnd
                                                ) {
                                                    Row(
                                                        modifier = Modifier.fillMaxSize(),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        IconButton(
                                                            onClick = { activeCalculatorWalletId = wallet.id },
                                                            modifier = Modifier.size(20.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Rounded.Calculate,
                                                                contentDescription = "Calculadora",
                                                                tint = themePrimary,
                                                                modifier = Modifier.size(14.dp)
                                                            )
                                                        }
                                                        Box(
                                                            modifier = Modifier.weight(1f),
                                                            contentAlignment = Alignment.CenterEnd
                                                        ) {
                                                            if (currentInput.isEmpty()) {
                                                                Text(
                                                                    text = if (idioma == "PT") "Saldo..." else "Balance...",
                                                                    fontSize = 11.sp,
                                                                    color = textSecondary,
                                                                    textAlign = TextAlign.End,
                                                                    modifier = Modifier.fillMaxWidth()
                                                                )
                                                            }
                                                            innerTextField()
                                                        }
                                                    }
                                                }
                                            }
                                        )
                                    }

                                    if (activeCalculatorWalletId == wallet.id) {
                                        CalculatorDialog(
                                            initialValue = currentInput,
                                            idioma = idioma,
                                            onDismiss = { activeCalculatorWalletId = null },
                                            onConfirm = { result ->
                                                realBalancesInput[wallet.id] = result
                                                activeCalculatorWalletId = null
                                            }
                                        )
                                    }
                                }
                            }

                            HorizontalDivider(color = dividerCol)

                            // Calculate live consolidated totals
                            var totalActualConverted = 0.0
                            var anyInputEntered = false
                            for (wallet in wallets) {
                                val expectedConverted = viewModel.currencyService.convertFromMT(wallet.saldoAtual, settings.moedaPadrao)
                                val enteredVal = realBalancesInput[wallet.id]?.toDoubleOrNull()
                                if (enteredVal != null) {
                                    totalActualConverted += enteredVal
                                    anyInputEntered = true
                                } else {
                                    totalActualConverted += expectedConverted
                                }
                            }

                            val totalExpectedMT = wallets.sumOf { it.saldoAtual }
                            val totalExpectedConverted = viewModel.currencyService.convertFromMT(totalExpectedMT, settings.moedaPadrao)
                            val consolidatedDiff = totalActualConverted - totalExpectedConverted

                            val realTotalText = if (anyInputEntered) formatVal(totalActualConverted) else "---"
                            val diffText = if (anyInputEntered) {
                                val prefix = if (consolidatedDiff > 0.005) "+" else ""
                                "$prefix${com.example.util.MoneyFormatter.formatWithDecimals(consolidatedDiff, settings.moedaPadrao)}"
                            } else {
                                "---"
                            }

                            val diffColor = when {
                                !anyInputEntered -> textSecondary
                                consolidatedDiff > 0.005 -> if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)
                                consolidatedDiff < -0.005 -> if (isDark) Color(0xFFE57373) else Color(0xFFD32F2F)
                                else -> themePrimary
                            }

                            // Footer Summary with Dividers (Stacked vertically to prevent translining)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Part 1: Saldo Real Total
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Saldo Real Total" else "Total Actual Balance",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color(0xFF9CCC9C) else Color(0xFF556B55)
                                    )
                                    Text(
                                        text = realTotalText,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = textPrimary
                                    )
                                }

                                // Subtle horizontal divider separating the two rows
                                androidx.compose.material3.HorizontalDivider(
                                    color = dividerCol.copy(alpha = 0.5f),
                                    thickness = 1.dp
                                )

                                // Part 2: Diferença Consolidada
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Diferença Consolidada" else "Consolidated Difference",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color(0xFF9CCC9C) else Color(0xFF556B55)
                                    )
                                    Text(
                                        text = diffText,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = diffColor
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            val contextForToast = LocalContext.current
                            var showClosureConfirmDialog by remember { mutableStateOf(false) }
                            var pendingBalancesMap by remember { mutableStateOf<Map<Int, Double>?>(null) }

                            if (showClosureConfirmDialog && pendingBalancesMap != null) {
                                AlertDialog(
                                    onDismissRequest = { showClosureConfirmDialog = false },
                                    title = { Text(if (idioma == "PT") "Confirmar Fechamento de Caixa" else "Confirm Cash Closure") },
                                    text = {
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(if (idioma == "PT") "Deseja registar o fechamento de caixa para todas as contas?" else "Do you want to record cash closure for all accounts?")
                                            Text(
                                                if (idioma == "PT") "Isto criará lançamentos de ajuste caso haja divergências." else "This will generate adjustment entries if there are discrepancies.",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    },
                                    confirmButton = {
                                        Button(onClick = {
                                            viewModel.submitConsolidatedReconciliation(pendingBalancesMap!!)
                                            realBalancesInput.clear()
                                            showClosureConfirmDialog = false
                                            pendingBalancesMap = null
                                            Toast.makeText(contextForToast, if (idioma == "PT") "Fechamento consolidado realizado!" else "Consolidated closure recorded!", Toast.LENGTH_SHORT).show()
                                        }) {
                                            Text(if (idioma == "PT") "Confirmar" else "Confirm")
                                        }
                                    },
                                    dismissButton = {
                                        OutlinedButton(onClick = {
                                            showClosureConfirmDialog = false
                                            pendingBalancesMap = null
                                        }) {
                                            Text(if (idioma == "PT") "Cancelar" else "Cancel")
                                        }
                                    }
                                )
                            }

                            Button(
                                onClick = {
                                    val actualBalancesMT = mutableMapOf<Int, Double>()
                                    for (wallet in wallets) {
                                        val expectedMT = wallet.saldoAtual
                                        val expectedConverted = viewModel.currencyService.convertFromMT(expectedMT, settings.moedaPadrao)
                                        val enteredValConverted = realBalancesInput[wallet.id]?.toDoubleOrNull() ?: expectedConverted
                                        val enteredValMT = viewModel.currencyService.convertToMT(enteredValConverted, settings.moedaPadrao)
                                        actualBalancesMT[wallet.id] = enteredValMT
                                    }

                                    pendingBalancesMap = actualBalancesMT
                                    showClosureConfirmDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = themePrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Rounded.Save, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (idioma == "PT") "Confirmar Fechamento de Caixa" else "Confirm Cash Closure",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            // --- 7. HISTÓRICO DE RECONCILIAÇÕES HEADER ---
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (idioma == "PT") "Histórico de Reconciliações" else "Reconciliation History",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = textPrimary
                    )
                    Text(
                        text = if (idioma == "PT") "Ver tudo" else "View all",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = themePrimary,
                        modifier = Modifier
                            .clickable {
                                Toast.makeText(context, if (idioma == "PT") "Exibindo histórico completo" else "Showing entire history", Toast.LENGTH_SHORT).show()
                            }
                            .bounceClick()
                    )
                }
            }

            // --- 8. HISTÓRICO LIST ---
            val filteredClosuresList = closuresList.filter { it.carteiraId == 0 }
            
            if (filteredClosuresList.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = cardBg),
                        border = BorderStroke(1.dp, borderCol),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(24.dp)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (idioma == "PT") "Nenhuma reconciliação registada." else "No reconciliation records found.",
                                fontSize = 13.sp,
                                color = textSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            } else {
                items(filteredClosuresList.sortedByDescending { it.data }, key = { it.id }) { closure ->
                    val wName = if (idioma == "PT") "Diferença do Saldo Total" else "Total Balance Difference"
                    val dateStr = remember(closure.data) { java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(closure.data)) }

                    val espConv = remember(closure.saldoEsperado, settings.moedaPadrao) { viewModel.currencyService.convertFromMT(closure.saldoEsperado, settings.moedaPadrao) }
                    val realConv = remember(closure.saldoReal, settings.moedaPadrao) { viewModel.currencyService.convertFromMT(closure.saldoReal, settings.moedaPadrao) }
                    val difConv = realConv - espConv

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = cardBg),
                        border = BorderStroke(1.dp, borderCol),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Light red circular container with descending zigzag chart icon
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(if (isDark) Color(0xFF4A1F1F) else Color(0xFFFFEBEE)), // Adaptive background
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.TrendingDown,
                                        contentDescription = null,
                                        tint = if (isDark) Color(0xFFEF9A9A) else Color(0xFFD32F2F),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Column {
                                    Text(
                                        text = dateStr,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = textPrimary
                                    )
                                    Text(
                                        text = wName,
                                        fontSize = 12.sp,
                                        color = textSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${if (idioma == "PT") "Esp" else "Exp"}: ${String.format(java.util.Locale.GERMAN, "%,.2f", espConv).replace('.', ' ')} | Real: ${String.format(java.util.Locale.GERMAN, "%,.2f", realConv).replace('.', ' ')}",
                                        fontSize = 11.sp,
                                        color = textSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val difColor = if (difConv < -0.005) (if (isDark) Color(0xFFE57373) else Color(0xFFD32F2F)) else if (difConv > 0.005) (if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)) else textPrimary
                                val difPrefix = if (difConv > 0.005) "+" else ""
                                Text(
                                    text = "$difPrefix${String.format(java.util.Locale.GERMAN, "%,.2f", difConv).replace('.', ' ')} ${settings.moedaPadrao}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = difColor
                                )

                                // Delete Trash / Garbage icon button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(if (isDark) Color(0xFF333333) else Color(0xFFF5F5F5))
                                        .clickable { viewModel.deleteDailyClosure(closure) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFD32F2F),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        }
    }

    // Modal to Add Account
    if (showAddWalletModal) {
        Dialog(onDismissRequest = { showAddWalletModal = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(if (idioma == "PT") "Nova Conta / Carteira" else "New Account / Wallet", fontSize = 18.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = nomeWallet,
                        onValueChange = { nomeWallet = it },
                        label = { Text(if (idioma == "PT") "Nome da Conta" else "Account Name") },
                        placeholder = { Text(if (idioma == "PT") "Ex: M-Pesa Principal" else "e.g. Primary Bank") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_wallet_nome")
                    )

                    OutlinedTextField(
                        value = saldoWallet,
                        onValueChange = { saldoWallet = sanitizeDoubleInput(saldoWallet, it) },
                        label = { Text(if (idioma == "PT") "Saldo Inicial (${settings.moedaPadrao})" else "Initial Balance (${settings.moedaPadrao})") },
                        placeholder = { Text("0.00") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_wallet_saldo"),
                        trailingIcon = {
                            IconButton(onClick = { showSaldoCalculator = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.Calculate,
                                    contentDescription = "Calculadora",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    )

                    if (showSaldoCalculator) {
                        CalculatorDialog(
                            initialValue = saldoWallet,
                            idioma = idioma,
                            onDismiss = { showSaldoCalculator = false },
                            onConfirm = { result ->
                                saldoWallet = result
                                showSaldoCalculator = false
                            }
                        )
                    }

                    // Simple Emoji selection
                    Text(if (idioma == "PT") "Escolha o Ícone:" else "Choose Icon:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("account_balance_wallet", "smartphone", "credit_card", "payments", "account_balance").forEach { key ->
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (iconeWallet == key) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable { iconeWallet = key },
                                contentAlignment = Alignment.Center
                            ) {
                                AppIcon(iconKey = key, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // Simple Color choice
                    Text(if (idioma == "PT") "Escolha a Cor:" else "Choose Color:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("#1A73E8", "#2E7D32", "#7B1FA2", "#E53935", "#FFB300").forEach { hex ->
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clickable { corWallet = hex },
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(Color(android.graphics.Color.parseColor(hex)))
                                        .border(2.dp, if (corWallet == hex) (if (isDark) Color.White else Color.Black) else Color.Transparent, CircleShape)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(onClick = { showAddWalletModal = false }) {
                            Text(if (idioma == "PT") "Cancelar" else "Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val trimmed = nomeWallet.trim()
                                val initial = saldoWallet.toDoubleOrNull() ?: 0.0
                                val isDup = wallets.any { it.nome.equals(trimmed, ignoreCase = true) }
                                if (isDup) {
                                    Toast.makeText(context, if (idioma == "PT") "Já existe uma conta com o mesmo nome!" else "An account with this name already exists!", Toast.LENGTH_SHORT).show()
                                } else if (trimmed.isNotBlank() && initial >= 0.0) {
                                    viewModel.addNewWallet(trimmed, initial, iconeWallet, corWallet)
                                    showAddWalletModal = false
                                    nomeWallet = ""
                                    saldoWallet = ""
                                }
                            },
                            modifier = Modifier.testTag("submit_wallet_button")
                        ) {
                            Text(if (idioma == "PT") "Adicionar" else "Add")
                        }
                    }
                }
            }
        }
    }

    // Wallet Options bottom sheet (triggered by long-press)
    showActionDialogForWallet?.let { wal ->
        ModalBottomSheet(
            onDismissRequest = { showActionDialogForWallet = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Opções da Conta",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = wal.nome,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                // Beautiful interactive balance evolution chart (Cubic Bezier curve)
                WalletBalanceHistoryChart(
                    walletId = wal.id,
                    currentBalance = wal.saldoAtual,
                    isDark = isDark,
                    isAmountVisible = !settings.ocultarSaldos,
                    themePrimary = themePrimary,
                    currency = settings.moedaPadrao,
                    transactions = viewModel.transactions.value
                )

                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                Button(
                    onClick = {
                        showEditWalletDialog = wal
                        showActionDialogForWallet = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Edit, null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (idioma == "PT") "Editar" else "Edit")
                }

                Button(
                    onClick = {
                        viewModel.deleteWallet(wal)
                        showActionDialogForWallet = null
                        Toast.makeText(context, if (idioma == "PT") "Conta excluída!" else "Account deleted!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Delete, null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (idioma == "PT") "Eliminar" else "Delete")
                }
            }
        }
    }

    showEditWalletDialog?.let { walletToEdit ->
        EditWalletDialog(
            wallet = walletToEdit,
            idioma = idioma,
            existingWallets = wallets,
            onDismiss = { showEditWalletDialog = null },
            onConfirm = { viewModel.updateWallet(it) }
        )
    }

    if (showRecurringTransfersModal) {
        val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
        var selectedSrcWallet by remember { mutableStateOf(wallets.firstOrNull()) }
        var selectedDestWallet by remember { mutableStateOf(wallets.getOrNull(1) ?: wallets.firstOrNull()) }
        var transferAmountStr by remember { mutableStateOf("") }

        val initialCalendar = remember { Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) } }
        var scheduledTimestamp by remember { mutableLongStateOf(initialCalendar.timeInMillis) }

        Dialog(onDismissRequest = { showRecurringTransfersModal = false }) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") "Transferências Agendadas" else "Scheduled Transfers",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = themePrimary
                    )
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    // List of existing recurring transfers
                    if (scheduledTransfersList.isEmpty()) {
                        Text(
                            text = if (idioma == "PT") "Nenhum agendamento registado." else "No scheduled transfers found.",
                            fontSize = 12.sp,
                            color = textSecondary
                        )
                    } else {
                        scheduledTransfersList.forEach { transfer ->
                            val src = wallets.find { it.id == transfer.carteiraOrigemId }
                            val dest = wallets.find { it.id == transfer.carteiraDestinoId }
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${src?.nome ?: "Conta"} -> ${dest?.nome ?: "Conta"}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = textPrimary
                                        )
                                        Text(
                                            text = if (transfer.executada) {
                                                if (idioma == "PT") "Status: Executada" else "Status: Executed"
                                            } else {
                                                if (idioma == "PT") "Agendada: ${dateFormat.format(Date(transfer.dataHora))}" else "Scheduled: ${dateFormat.format(Date(transfer.dataHora))}"
                                            },
                                            fontSize = 11.sp,
                                            color = textSecondary
                                        )
                                        Text(
                                            text = "Valor: ${String.format("%,.2f", transfer.valor)} ${settings.moedaPadrao}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = themePrimary
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (!transfer.executada) {
                                            IconButton(
                                                onClick = {
                                                    viewModel.executeScheduledTransferNow(transfer)
                                                    Toast.makeText(context, if (idioma == "PT") "Transferência Executada!" else "Transfer Executed!", Toast.LENGTH_SHORT).show()
                                                }
                                            ) {
                                                Icon(Icons.Rounded.PlayArrow, "Executar agora", tint = Color(0xFF35D07F))
                                            }
                                        }
                                        IconButton(
                                            onClick = {
                                                viewModel.deleteScheduledTransfer(transfer.id)
                                                Toast.makeText(context, if (idioma == "PT") "Agendamento removido" else "Transfer deleted", Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Icon(Icons.Rounded.Delete, "Remover", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    // Adding Form
                    Text(
                        text = if (idioma == "PT") "Novo Agendamento" else "New Scheduled Transfer",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = textPrimary
                    )

                    // Source Account Dropdown
                    var srcExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { srcExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isDark) Color(0xFF141B2D) else Color(0xFFF8FAFC),
                                contentColor = textPrimary
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Origem: ${selectedSrcWallet?.nome ?: ""}" else "Source: ${selectedSrcWallet?.nome ?: ""}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = textPrimary
                                )
                                Icon(
                                    imageVector = Icons.Rounded.ArrowDropDown,
                                    contentDescription = null,
                                    tint = textSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        DropdownMenu(expanded = srcExpanded, onDismissRequest = { srcExpanded = false }) {
                            wallets.forEach { w ->
                                DropdownMenuItem(
                                    text = { Text(w.nome, fontWeight = FontWeight.Medium) },
                                    onClick = {
                                        selectedSrcWallet = w
                                        srcExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Destination Account Dropdown
                    var destExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { destExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isDark) Color(0xFF141B2D) else Color(0xFFF8FAFC),
                                contentColor = textPrimary
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Destino: ${selectedDestWallet?.nome ?: ""}" else "Destination: ${selectedDestWallet?.nome ?: ""}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = textPrimary
                                )
                                Icon(
                                    imageVector = Icons.Rounded.ArrowDropDown,
                                    contentDescription = null,
                                    tint = textSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        DropdownMenu(expanded = destExpanded, onDismissRequest = { destExpanded = false }) {
                            wallets.forEach { w ->
                                DropdownMenuItem(
                                    text = { Text(w.nome, fontWeight = FontWeight.Medium) },
                                    onClick = {
                                        selectedDestWallet = w
                                        destExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Amount Text Field
                    OutlinedTextField(
                        value = transferAmountStr,
                        onValueChange = { transferAmountStr = it },
                        label = { Text(if (idioma == "PT") "Valor" else "Amount") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Date/Time Selection Button
                    OutlinedButton(
                        onClick = {
                            val c = Calendar.getInstance().apply { timeInMillis = scheduledTimestamp }
                            android.app.DatePickerDialog(
                                context,
                                { _, year, month, dayOfMonth ->
                                    val tC = Calendar.getInstance().apply { timeInMillis = scheduledTimestamp }
                                    android.app.TimePickerDialog(
                                        context,
                                        { _, hourOfDay, minute ->
                                            val newC = Calendar.getInstance().apply {
                                                set(Calendar.YEAR, year)
                                                set(Calendar.MONTH, month)
                                                set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                                set(Calendar.HOUR_OF_DAY, hourOfDay)
                                                set(Calendar.MINUTE, minute)
                                                set(Calendar.SECOND, 0)
                                                set(Calendar.MILLISECOND, 0)
                                            }
                                            scheduledTimestamp = newC.timeInMillis
                                        },
                                        tC.get(Calendar.HOUR_OF_DAY),
                                        tC.get(Calendar.MINUTE),
                                        true
                                    ).show()
                                },
                                c.get(Calendar.YEAR),
                                c.get(Calendar.MONTH),
                                c.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (idioma == "PT") "Data/Hora: ${dateFormat.format(Date(scheduledTimestamp))}" else "Date/Time: ${dateFormat.format(Date(scheduledTimestamp))}",
                            fontSize = 13.sp
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showRecurringTransfersModal = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Fechar")
                        }
                        Button(
                            onClick = {
                                val amt = transferAmountStr.toDoubleOrNull() ?: 0.0
                                val srcId = selectedSrcWallet?.id
                                val destId = selectedDestWallet?.id

                                if (srcId == null || destId == null) {
                                    Toast.makeText(context, if (idioma == "PT") "Selecione as contas de origem e destino" else "Select source and destination accounts", Toast.LENGTH_SHORT).show()
                                } else if (srcId == destId) {
                                    Toast.makeText(context, if (idioma == "PT") "A conta de origem e destino devem ser diferentes" else "Source and destination accounts must be different", Toast.LENGTH_SHORT).show()
                                } else if (amt <= 0.0) {
                                    Toast.makeText(context, if (idioma == "PT") "Introduza um valor válido" else "Enter a valid amount", Toast.LENGTH_SHORT).show()
                                } else if (scheduledTimestamp <= System.currentTimeMillis()) {
                                    Toast.makeText(context, if (idioma == "PT") "A data e hora do agendamento deve ser no futuro!" else "Scheduled date and time must be in the future!", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.addScheduledTransfer(srcId, destId, amt, scheduledTimestamp)
                                    transferAmountStr = ""
                                    Toast.makeText(context, if (idioma == "PT") "Transferência Agendada com Sucesso!" else "Transfer Scheduled Successfully!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = themePrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (idioma == "PT") "Agendar" else "Schedule")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WalletBalanceHistoryChart(
    walletId: Int,
    currentBalance: Double,
    isDark: Boolean,
    isAmountVisible: Boolean,
    themePrimary: Color,
    currency: String,
    transactions: List<com.example.data.model.FinancialTransaction> = emptyList()
) {
    // Calculate real balance history points for the last 7 days based on actual transactions
    val points = remember(walletId, currentBalance, transactions) {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 23)
        cal.set(java.util.Calendar.MINUTE, 59)
        cal.set(java.util.Calendar.SECOND, 59)
        cal.set(java.util.Calendar.MILLISECOND, 999)
        val todayEnd = cal.timeInMillis

        val dayInMillis = 24 * 60 * 60 * 1000L
        val dayBalances = DoubleArray(7)
        var running = currentBalance
        val walletTxs = transactions.filter { it.carteiraOrigemId == walletId }.sortedByDescending { it.data }
        var txIdx = 0
        for (i in 6 downTo 0) {
            val dayEnd = todayEnd - (6 - i) * dayInMillis
            while (txIdx < walletTxs.size && walletTxs[txIdx].data > dayEnd) {
                val tx = walletTxs[txIdx]
                val isIncomingTransferLeg = tx.tipo == "Transferencia" &&
                    (tx.descricao.endsWith(" (Entrada)") || tx.descricao.endsWith(" (In)"))
                val isOutgoingTransferLeg = tx.tipo == "Transferencia" && !isIncomingTransferLeg
                if (tx.tipo == "Injecao" || tx.tipo == "Receita" || isIncomingTransferLeg) {
                    running -= tx.valor
                } else if (tx.tipo == "Despesa" || tx.tipo == "PagamentoEmprestimo" || isOutgoingTransferLeg) {
                    // Cada perna de Transferencia tem carteiraOrigemId igual à sua própria
                    // carteira (ver FinancialRepository.transferBetweenWallets) e também
                    // altera saldoAtual dessa carteira; sem as distinguir por direção, o
                    // histórico de 7 dias ficava desalinhado do saldo real sempre que havia
                    // transferências.
                    running += tx.valor
                }
                txIdx++
            }
            dayBalances[i] = running
        }
        dayBalances.toList()
    }

    val maxVal = points.maxOrNull() ?: 1.0
    val minVal = points.minOrNull() ?: 0.0
    val delta = if (maxVal == minVal) 1.0 else (maxVal - minVal)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Evolução do Saldo (Últimos 7 dias)",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )

        androidx.compose.foundation.Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .background(
                    color = if (isDark) Color(0xFF141B2D) else Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(14.dp)
        ) {
            val width = size.width
            val height = size.height
            val stepX = width / (points.size - 1)

            val path = androidx.compose.ui.graphics.Path()
            points.forEachIndexed { index, balance ->
                val x = index * stepX
                val ratio = (balance - minVal) / delta
                val y = height - (ratio.toFloat() * height)
                if (index == 0) {
                    path.moveTo(x, y)
                } else {
                    val prevX = (index - 1) * stepX
                    val prevRatio = (points[index - 1] - minVal) / delta
                    val prevY = height - (prevRatio.toFloat() * height)
                    path.cubicTo(
                        (prevX + x) / 2f, prevY,
                        (prevX + x) / 2f, y,
                        x, y
                    )
                }
            }

            drawPath(
                path = path,
                color = themePrimary,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 3.dp.toPx(),
                    cap = androidx.compose.ui.graphics.StrokeCap.Round,
                    join = androidx.compose.ui.graphics.StrokeJoin.Round
                )
            )

            points.forEachIndexed { index, balance ->
                val x = index * stepX
                val ratio = (balance - minVal) / delta
                val y = height - (ratio.toFloat() * height)
                drawCircle(
                    color = themePrimary,
                    radius = 4.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(x, y)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (isAmountVisible) "Mín: ${String.format("%,.0f", minVal)} $currency" else "•••• MZN",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
            Text(
                text = if (isAmountVisible) "Máx: ${String.format("%,.0f", maxVal)} $currency" else "•••• MZN",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

// ------------------- TELA 5: RELATÓRIOS -------------------
@Composable
fun RelatoriosScreen(
    viewModel: MainViewModel,
    transactions: List<Transaction>,
    categories: List<Category>,
    wallets: List<Wallet>,
    settings: UserSettings,
    initialTab: Int = 0
) {
    RelatoriosDashboardScreen(viewModel, transactions, categories, wallets, settings, initialTab)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditWalletDialog(
    wallet: Wallet,
    idioma: String = "PT",
    existingWallets: List<Wallet> = emptyList(),
    onDismiss: () -> Unit,
    onConfirm: (Wallet) -> Unit
) {
    val context = LocalContext.current
    var nome by remember { mutableStateOf(wallet.nome) }
    var saldoInicialStr by remember { mutableStateOf(String.format(java.util.Locale.US, "%.2f", wallet.saldoInicial)) }
    var icone by remember { mutableStateOf(wallet.icone) }
    var cor by remember { mutableStateOf(wallet.cor) }
    var showCalculator by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(if (idioma == "PT") "Editar Conta" else "Edit Account", fontWeight = FontWeight.Bold, fontSize = 18.sp)

                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text(if (idioma == "PT") "Nome da Conta" else "Account Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = saldoInicialStr,
                    onValueChange = { saldoInicialStr = it },
                    label = { Text(if (idioma == "PT") "Saldo Inicial (MZN)" else "Initial Balance (MZN)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { showCalculator = true }) {
                            Icon(
                                imageVector = Icons.Rounded.Calculate,
                                contentDescription = if (idioma == "PT") "Calculadora" else "Calculator",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                )

                if (showCalculator) {
                    CalculatorDialog(
                        initialValue = saldoInicialStr,
                        idioma = idioma,
                        onDismiss = { showCalculator = false },
                        onConfirm = { result ->
                            saldoInicialStr = result
                            showCalculator = false
                        }
                    )
                }

                Text(if (idioma == "PT") "Ícone da Conta" else "Account Icon", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(com.example.util.AppIcons.WALLET_ICONS) { iconItem ->
                        val isSelected = icone == iconItem.key
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .border(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent, CircleShape)
                                .clickable { icone = iconItem.key },
                            contentAlignment = Alignment.Center
                        ) {
                            AppIcon(iconKey = iconItem.key, modifier = Modifier.size(20.dp), tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }

                Text(if (idioma == "PT") "Cor da Conta" else "Account Color", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                val colorPalette = listOf("#1A73E8", "#00E676", "#FFB300", "#FF5252", "#9C27B0", "#00BCD4", "#FF9800", "#607D8B", "#3F51B5", "#E91E63")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(colorPalette) { hex ->
                        val isSelected = cor.equals(hex, ignoreCase = true)
                        val swatchColor = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { Color.Gray }
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(swatchColor)
                                .border(2.dp, if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent, CircleShape)
                                .clickable { cor = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(if (idioma == "PT") "Cancelar" else "Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val trimmed = nome.trim()
                            val isDup = existingWallets.any { it.id != wallet.id && it.nome.equals(trimmed, ignoreCase = true) }
                            if (isDup) {
                                Toast.makeText(
                                    context,
                                    if (idioma == "PT") "Já existe outra conta com este nome!" else "Another account already has this name!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else if (trimmed.isNotBlank()) {
                                val saldo = saldoInicialStr.toDoubleOrNull() ?: wallet.saldoInicial
                                val diff = saldo - wallet.saldoInicial
                                val updated = wallet.copy(
                                    nome = trimmed,
                                    saldoInicial = saldo,
                                    saldoAtual = wallet.saldoAtual + diff,
                                    icone = icone,
                                    cor = cor
                                )
                                onConfirm(updated)
                                onDismiss()
                            }
                        }
                    ) {
                        Text(if (idioma == "PT") "Guardar" else "Save")
                    }
                }
            }
        }
    }
}
