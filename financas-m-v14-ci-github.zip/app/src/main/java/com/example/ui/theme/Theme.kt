package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object AppTheme {
    object Spacing {
        val extraSmall = 4.dp
        val small = 8.dp
        val medium = 16.dp
        val large = 24.dp
        val extraLarge = 32.dp
    }

    object CornerRadius {
        val small = 8.dp
        val medium = 12.dp
        val large = 16.dp
        val extraLarge = 24.dp
    }

    object SemanticColors {
        val successBackground = Color(0xFFDCFCE7)
        val successText = Color(0xFF166534)
        val dangerBackground = Color(0xFFFFE2E2)
        val dangerText = Color(0xFFD32F2F)
        val warningBackground = Color(0xFFFEF3C7)
        val warningText = Color(0xFFD97706)
        val infoBackground = Color(0xFFE0F2FE)
        val infoText = Color(0xFF0369A1)
    }
}

@Composable
fun FinancasMTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    primaryHexColor: String = "#1A73E8",
    content: @Composable () -> Unit
) {
    val primaryColor = try {
        Color(android.graphics.Color.parseColor(primaryHexColor))
    } catch (e: Exception) {
        Color(0xFF6D4AFF) // Fallback Default Roxo Premium
    }

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = primaryColor,
            onPrimary = Color.White,
            primaryContainer = primaryColor.copy(alpha = 0.25f),
            onPrimaryContainer = Color.White,
            secondary = Color(0xFF8B5CF6),
            onSecondary = Color.White,
            background = Color(0xFF090B11),
            onBackground = Color(0xFFFFFFFF),
            surface = Color(0xFF111827),
            onSurface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFF141B2D),
            onSurfaceVariant = Color(0xFF98A2B3),
            outline = Color(0x14FFFFFF)
        )
    } else {
        lightColorScheme(
            primary = primaryColor,
            onPrimary = Color.White,
            primaryContainer = primaryColor.copy(alpha = 0.12f),
            onPrimaryContainer = primaryColor,
            secondary = Color(0xFF8B5CF6),
            onSecondary = Color.White,
            background = Color(0xFFF8FAFC),
            onBackground = Color(0xFF0F172A),
            surface = Color.White,
            onSurface = Color(0xFF0F172A),
            surfaceVariant = Color(0xFFF1F5F9),
            onSurfaceVariant = Color(0xFF64748B),
            outline = Color(0xFFE2E8F0)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
