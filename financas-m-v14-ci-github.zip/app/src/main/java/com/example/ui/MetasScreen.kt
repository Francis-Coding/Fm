@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File

@Composable
fun MetasScreen(
    viewModel: MainViewModel,
    goals: List<FinancialGoal>,
    categories: List<Category>,
    settings: UserSettings,
    deepLinkGoalId: Int? = null,
    lazyListState: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val wallets by viewModel.wallets.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    var showAddGoalModal by remember { mutableStateOf(false) }
    var nomeGoal by remember { mutableStateOf("") }
    var objectiveGoal by remember { mutableStateOf("") }
    var initialDepositGoal by remember { mutableStateOf("") }
    var daysToSave by remember { mutableStateOf("30") }
    var selectedCategory by remember { mutableStateOf<Category?>(null) }
    var showActionDialogForGoal by remember { mutableStateOf<FinancialGoal?>(null) }
    var showEditGoalDialog by remember { mutableStateOf<FinancialGoal?>(null) }
    var showWithdrawGoalDialog by remember { mutableStateOf<FinancialGoal?>(null) }
    val haptic = LocalHapticFeedback.current
    var tactileState by remember { mutableStateOf(TactileSuccessState()) }

    var showGoalSimulatorModal by remember { mutableStateOf(false) }
    var goalFilter by remember { mutableStateOf("all") } // "all", "progress", "completed"

    LaunchedEffect(deepLinkGoalId, goals) {
        if (deepLinkGoalId != null) {
            val goal = goals.find { it.id == deepLinkGoalId }
            if (goal != null) {
                showActionDialogForGoal = goal
            }
        }
    }

    // In-memory simulation states for advanced features
    var associatedWalletsMap by remember {
        mutableStateOf(
            mapOf(
                1 to listOf("Carteira Principal", "Conta Poupança"),
                2 to listOf("e-Mola", "M-Pesa")
            )
        )
    }

    var goalMilestonesMap by remember {
        mutableStateOf(
            mapOf(
                1 to listOf("Definir Orçamento" to true, "Primeiro Depósito" to true, "Metade do Caminho" to false),
                2 to listOf("Reserva Inicial" to true, "Alcançar 80%" to false)
            )
        )
    }

    var goalTimelineMap by remember {
        mutableStateOf(
            mapOf(
                1 to listOf("18/07" to "Aporte de 500,00 MZN via e-Mola", "12/07" to "Aporte de 200,00 MZN via Dinheiro"),
                2 to listOf("15/07" to "Depósito inicial de 1.000,00 MZN via M-Pesa")
            )
        )
    }

    LaunchedEffect(categories) {
        selectedCategory = categories.firstOrNull()
    }

    val isDark = settings.tema == "dark"
    val currency = settings.moedaPadrao

    // Total metrics calculations
    val totalSaved = goals.sumOf { it.valorAtual }
    val totalTarget = goals.sumOf { it.valorObjetivo }
    val totalSavedConv = viewModel.currencyService.convertFromMT(totalSaved, currency)
    val totalTargetConv = viewModel.currencyService.convertFromMT(totalTarget, currency)
    val overallProgress = if (totalTarget > 0) (totalSaved / totalTarget).coerceIn(0.0, 1.0).toFloat() else 0f
    val completedCount = goals.count { it.valorObjetivo > 0 && it.valorAtual >= it.valorObjetivo }
    val inProgressCount = goals.size - completedCount

    val filteredGoals = when (goalFilter) {
        "progress" -> goals.filter { it.valorObjetivo > 0 && it.valorAtual < it.valorObjetivo }
        "completed" -> goals.filter { it.valorObjetivo > 0 && it.valorAtual >= it.valorObjetivo }
        else -> goals
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // --- TOP APP BAR HEADER ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (settings.idioma == "PT") "Minhas Metas" else "My Goals",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color.White else Color(0xFF1E293B)
                    )
                    Icon(imageVector = Icons.Rounded.TrackChanges, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (settings.idioma == "PT") "Planeie e alcance os seus objetivos" else "Plan and achieve your goals",
                    fontSize = 12.sp,
                    color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B)
                )
            }
            
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // "Simular" Button
                OutlinedButton(
                    onClick = { showGoalSimulatorModal = true },
                    border = BorderStroke(1.dp, Color(0xFF1B5E20)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1B5E20)),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.Calculate, null, tint = Color(0xFF1B5E20), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (settings.idioma == "PT") "Simular" else "Simulate",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // "Nova Meta" Button
                Button(
                    onClick = { showAddGoalModal = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1B5E20),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_goal_button")
                ) {
                    Icon(Icons.Rounded.Add, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (settings.idioma == "PT") "Nova Meta" else "New Goal",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        LazyColumn(
            state = lazyListState,
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            // --- ITEM 1: SUMMARY KPI BANNER CARD ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else Color(0xFFF1F5F9)
                    ),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (settings.idioma == "PT") "Progresso Geral de Metas" else "Overall Goals Progress",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = String.format("%,.2f %s", totalSavedConv, currency),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1B5E20)
                                    )
                                    Text(
                                        text = String.format("/ %,.2f %s", totalTargetConv, currency),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF94A3B8),
                                        modifier = Modifier.padding(bottom = 2.dp)
                                    )
                                }
                            }

                            // Completion Badge Pill
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF1B5E20).copy(alpha = 0.12f),
                                contentColor = Color(0xFF1B5E20)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Rounded.CheckCircle, null, modifier = Modifier.size(14.dp), tint = Color(0xFF1B5E20))
                                    Text(
                                        text = "$completedCount/${goals.size} " + (if (settings.idioma == "PT") "concluídas" else "done"),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Progress Indicator
                        val animatedOverallProgress by animateFloatAsState(
                            targetValue = overallProgress,
                            animationSpec = spring(stiffness = Spring.StiffnessLow)
                        )
                        LinearProgressIndicator(
                            progress = animatedOverallProgress,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = Color(0xFF1B5E20),
                            trackColor = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFCBD5E1)
                        )

                        // Filter Chips Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = goalFilter == "all",
                                onClick = { goalFilter = "all" },
                                label = { Text(if (settings.idioma == "PT") "Todas (${goals.size})" else "All (${goals.size})", fontSize = 11.sp) },
                                shape = RoundedCornerShape(12.dp)
                            )
                            FilterChip(
                                selected = goalFilter == "progress",
                                onClick = { goalFilter = "progress" },
                                label = { Text(if (settings.idioma == "PT") "Em Progresso ($inProgressCount)" else "In Progress ($inProgressCount)", fontSize = 11.sp) },
                                shape = RoundedCornerShape(12.dp)
                            )
                            FilterChip(
                                selected = goalFilter == "completed",
                                onClick = { goalFilter = "completed" },
                                label = { Text(if (settings.idioma == "PT") "Concluídas ($completedCount)" else "Completed ($completedCount)", fontSize = 11.sp) },
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }
            }

            // --- EMPTY STATE ---
            if (filteredGoals.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFF8FAFC)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp).fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Rounded.TrackChanges, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                            Text(
                                text = if (settings.idioma == "PT") "Nenhuma meta encontrada neste filtro." else "No goals found in this filter.",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF64748B)
                            )
                            Button(
                                onClick = { showAddGoalModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20))
                            ) {
                                Text(if (settings.idioma == "PT") "Criar Primeira Meta" else "Create First Goal")
                            }
                        }
                    }
                }
            } else {
                // --- GOAL ITEMS ---
                items(filteredGoals, key = { it.id }) { g ->
                    val progress = if (g.valorObjetivo > 0) (g.valorAtual / g.valorObjetivo).toFloat() else 0f
                    val percentage = (progress * 100).toInt()
                    val remaining = (g.valorObjetivo - g.valorAtual).coerceAtLeast(0.0)

                    val msRemaining = g.dataLimite - System.currentTimeMillis()
                    val isOverdue = msRemaining < 0 && g.valorAtual < g.valorObjetivo
                    val daysRemaining = if (isOverdue) 1L else (msRemaining / (1000 * 60 * 60 * 24)).coerceAtLeast(1L)
                    val toSaveDaily = remaining / daysRemaining
                    val toSaveWeekly = toSaveDaily * 7
                    val toSaveMonthly = toSaveDaily * 30

                    val cat = categories.find { it.id == g.categoriaId }
                    val categoryColorString = cat?.cor ?: "#4CAF50"
                    val parsedCategoryColor = try {
                        Color(android.graphics.Color.parseColor(categoryColorString))
                    } catch (e: Exception) {
                        MaterialTheme.colorScheme.primary
                    }

                    val dynamicProgressColor = when {
                        progress >= 1.0f -> Color(0xFF10B981) // Green
                        progress >= 0.7f -> Color(0xFF059669) // Emerald
                        progress >= 0.3f -> Color(0xFF2563EB) // Blue
                        else -> Color(0xFFD97706) // Amber/Orange
                    }

                    var showContributionDialog by remember { mutableStateOf(false) }
                    var contributionStr by remember { mutableStateOf("") }
                    var selectedContributionWalletId by remember(wallets) { mutableStateOf(wallets.firstOrNull()?.id ?: 1) }
                    var showDetails by remember { mutableStateOf(false) }

                    SwipeToDeleteContainer(
                        item = g,
                        onDelete = { viewModel.deleteGoal(it) },
                        modifier = Modifier.animateItem()
                    ) { goal ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        showActionDialogForGoal = goal
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        showActionDialogForGoal = goal
                                    }
                                ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White
                            ),
                            shape = RoundedCornerShape(20.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Min)
                            ) {
                                // Left category color strip
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .width(6.dp)
                                        .background(parsedCategoryColor)
                                )

                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // HEADER ROW: Category Icon Badge + Title + Days Badge + Action Button
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(42.dp)
                                                    .clip(CircleShape)
                                                    .background(parsedCategoryColor.copy(alpha = 0.15f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                AppIcon(
                                                    iconKey = cat?.icone ?: "track_changes",
                                                    modifier = Modifier.size(20.dp),
                                                    tint = parsedCategoryColor
                                                )
                                            }

                                            Column {
                                                Text(
                                                    text = goal.nome,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 15.sp,
                                                    maxLines = 1,
                                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                                    color = if (isDark) Color.White else Color(0xFF1E293B)
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = parsedCategoryColor.copy(alpha = 0.12f)
                                                    ) {
                                                        Text(
                                                            text = cat?.nome ?: "Geral",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = parsedCategoryColor,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }

                                                    if (goal.pausada) {
                                                        Surface(
                                                            shape = RoundedCornerShape(8.dp),
                                                            color = Color(0xFFFFB300).copy(alpha = 0.2f)
                                                        ) {
                                                            Text(
                                                                text = if (settings.idioma == "PT") "Pausada" else "Paused",
                                                                fontSize = 10.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color(0xFFFF8F00),
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }

                                                    Text(
                                                        text = "• $daysRemaining " + (if (settings.idioma == "PT") "dias restantes" else "days left"),
                                                        fontSize = 11.sp,
                                                        color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B)
                                                    )
                                                }
                                            }
                                        }

                                        // 3-Dots Options Button
                                        IconButton(
                                            onClick = { showActionDialogForGoal = goal },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.MoreVert,
                                                contentDescription = "Options",
                                                tint = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B)
                                            )
                                        }
                                    }

                                    // AMOUNTS & PROGRESS ROW
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        val savedAmountConv = viewModel.currencyService.convertFromMT(goal.valorAtual, currency)
                                        val targetAmountConv = viewModel.currencyService.convertFromMT(goal.valorObjetivo, currency)

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = if (settings.idioma == "PT") "Valor Poupado" else "Saved Amount",
                                                    fontSize = 10.sp,
                                                    color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B)
                                                )
                                                Text(
                                                    text = String.format("%,.2f %s", savedAmountConv, currency),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 15.sp,
                                                    color = dynamicProgressColor
                                                )
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = if (settings.idioma == "PT") "Objetivo" else "Target",
                                                    fontSize = 10.sp,
                                                    color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B)
                                                )
                                                Text(
                                                    text = String.format("%,.2f %s", targetAmountConv, currency),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = if (isDark) Color.White else Color(0xFF1E293B)
                                                )
                                            }

                                            // Percentage pill
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = dynamicProgressColor.copy(alpha = 0.12f)
                                            ) {
                                                Text(
                                                    text = "$percentage%",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = dynamicProgressColor,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        // Progress Bar
                                        val animatedGoalProgress by animateFloatAsState(
                                            targetValue = progress.coerceIn(0f, 1f),
                                            animationSpec = spring(stiffness = Spring.StiffnessLow)
                                        )
                                        LinearProgressIndicator(
                                            progress = animatedGoalProgress,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(8.dp)
                                                .clip(CircleShape)
                                                .testTag("goal_progress_bar_${goal.id}"),
                                            color = dynamicProgressColor,
                                            trackColor = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFE2E8F0)
                                        )
                                    }

                                    // ACTION BUTTONS ROW: Contribuir + Detalhes Toggle
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = { showContributionDialog = true },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color(0xFF1B5E20),
                                                contentColor = Color.White
                                            ),
                                            shape = RoundedCornerShape(12.dp),
                                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(40.dp)
                                                .testTag("contribute_button_${g.id}")
                                        ) {
                                            Icon(Icons.Rounded.Savings, null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (settings.idioma == "PT") "Contribuir" else "Contribute",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = { showDetails = !showDetails },
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.2f) else Color(0xFFCBD5E1)),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                            modifier = Modifier.height(40.dp)
                                        ) {
                                            Text(
                                                text = if (showDetails) (if (settings.idioma == "PT") "Ocultar" else "Hide") else (if (settings.idioma == "PT") "Plano & Marcos" else "Plan & Milestones"),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = if (isDark) Color.White.copy(alpha = 0.8f) else Color(0xFF475569)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                imageVector = if (showDetails) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                                contentDescription = null,
                                                tint = if (isDark) Color.White.copy(alpha = 0.8f) else Color(0xFF475569),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }

                                    // COLLAPSIBLE DETAILS SECTION
                                    androidx.compose.animation.AnimatedVisibility(
                                        visible = showDetails,
                                        enter = androidx.compose.animation.fadeIn() + androidx.compose.animation.expandVertically(),
                                        exit = androidx.compose.animation.fadeOut() + androidx.compose.animation.shrinkVertically()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(top = 4.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Divider(color = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFE2E8F0))

                                            // Completion Celebration Banner
                                            if (progress >= 1.0f) {
                                                Surface(
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = Color(0xFFFEF3C7),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Icon(Icons.Rounded.EmojiEvents, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
                                                        Text(
                                                            text = if (settings.idioma == "PT") "Meta 100% Alcançada! Excelente!" else "Goal 100% Achieved! Excellent!",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF92400E)
                                                        )
                                                    }
                                                }
                                            }

                                            // Savings Plan Columns (Diária, Semanal, Mensal)
                                            if (remaining > 0) {
                                                if (isOverdue) {
                                                    Surface(
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = Color(0xFFFEE2E2),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                        ) {
                                                            Icon(Icons.Rounded.Warning, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                                            Text(
                                                                text = if (settings.idioma == "PT") "Meta Expirada! Edite a data limite para reajustar o plano." else "Goal Overdue! Edit target date to reset plan.",
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color(0xFF991B1B)
                                                            )
                                                        }
                                                    }
                                                } else {
                                                    Card(
                                                        colors = CardDefaults.cardColors(
                                                            containerColor = parsedCategoryColor.copy(alpha = 0.06f)
                                                        ),
                                                        shape = RoundedCornerShape(14.dp),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Column(
                                                            modifier = Modifier.padding(12.dp),
                                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                                        ) {
                                                            Text(
                                                                text = if (settings.idioma == "PT") "Plano de Poupança Sugerido:" else "Suggested Savings Plan:",
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 12.sp,
                                                                color = parsedCategoryColor
                                                            )

                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                val toSaveDailyConv = viewModel.currencyService.convertFromMT(toSaveDaily, currency)
                                                                val toSaveWeeklyConv = viewModel.currencyService.convertFromMT(toSaveWeekly, currency)
                                                                val toSaveMonthlyConv = viewModel.currencyService.convertFromMT(toSaveMonthly, currency)

                                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                                    Text(if (settings.idioma == "PT") "Diária" else "Daily", fontSize = 10.sp, color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B))
                                                                    Text(String.format("%,.0f %s", toSaveDailyConv, currency), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                                }
                                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                                    Text(if (settings.idioma == "PT") "Semanal" else "Weekly", fontSize = 10.sp, color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B))
                                                                    Text(String.format("%,.0f %s", toSaveWeeklyConv, currency), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                                }
                                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                                    Text(if (settings.idioma == "PT") "Mensal" else "Monthly", fontSize = 10.sp, color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B))
                                                                    Text(String.format("%,.0f %s", toSaveMonthlyConv, currency), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            // Subgoals / Milestones Checklist
                                            val defaultMilestones = listOf(
                                                (if (settings.idioma == "PT") "Definir Orçamento" else "Set Budget") to true,
                                                (if (settings.idioma == "PT") "Primeiro Aporte (25%)" else "First Deposit (25%)") to (progress >= 0.25f),
                                                (if (settings.idioma == "PT") "Metade do Caminho (50%)" else "Halfway (50%)") to (progress >= 0.50f),
                                                (if (settings.idioma == "PT") "Reta Final (75%)" else "Final Stretch (75%)") to (progress >= 0.75f),
                                                (if (settings.idioma == "PT") "Meta Concluída (100%)" else "Goal Completed (100%)") to (progress >= 1.0f)
                                            )
                                            val milestones = goalMilestonesMap[goal.id] ?: defaultMilestones
                                            if (milestones.isNotEmpty()) {
                                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text(
                                                        text = if (settings.idioma == "PT") "Marcos & Sub-objetivos:" else "Milestones:",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = parsedCategoryColor
                                                    )
                                                    milestones.forEachIndexed { mIdx, milestone ->
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .clickable {
                                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                                    val currentList = milestones.toMutableList()
                                                                    currentList[mIdx] = milestone.first to !milestone.second
                                                                    goalMilestonesMap = goalMilestonesMap + (goal.id to currentList)
                                                                }
                                                                .padding(vertical = 2.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = if (milestone.second) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                                                contentDescription = null,
                                                                tint = if (milestone.second) Color(0xFF1B5E20) else Color.Gray,
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Text(
                                                                text = milestone.first,
                                                                fontSize = 11.sp,
                                                                textDecoration = if (milestone.second) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
                                                                color = if (isDark) Color.White.copy(alpha = 0.8f) else Color(0xFF1E293B)
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            // Associated Wallets
                                            val goalTxs = transactions.filter { it.metaId == goal.id }
                                            val walletNames = goalTxs.mapNotNull { tx -> wallets.find { it.id == tx.carteiraOrigemId }?.nome }.distinct()
                                            val associatedWallets = if (walletNames.isNotEmpty()) walletNames else (associatedWalletsMap[goal.id] ?: emptyList())
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(11.dp))
                                                Text(
                                                    text = if (associatedWallets.isNotEmpty())
                                                        "${if (settings.idioma == "PT") "Fontes" else "Sources"}: ${associatedWallets.joinToString(", ")}"
                                                    else
                                                        (if (settings.idioma == "PT") "Sem carteiras vinculadas" else "No linked wallets"),
                                                    fontSize = 11.sp,
                                                    color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B),
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }

                                    // CONTRIBUTION MODAL
                                    if (showContributionDialog) {
                                        Dialog(onDismissRequest = { showContributionDialog = false }) {
                                            Card(
                                                shape = RoundedCornerShape(20.dp),
                                                colors = CardDefaults.cardColors(containerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White),
                                                modifier = Modifier.padding(16.dp)
                                            ) {
                                                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                                    Text(
                                                        text = if (settings.idioma == "PT") "Adicionar Poupança" else "Add Savings",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 17.sp,
                                                        color = if (isDark) Color.White else Color(0xFF1E293B)
                                                    )
                                                    OutlinedTextField(
                                                        value = contributionStr,
                                                        onValueChange = { contributionStr = sanitizeDoubleInput(contributionStr, it) },
                                                        label = { Text(if (settings.idioma == "PT") "Valor a Guardar ($currency)" else "Amount to Save ($currency)") },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(12.dp)
                                                    )

                                                    // Quick preset chips
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        val presets = listOf(100.0, 500.0, 1000.0, 5000.0)
                                                        presets.forEach { preset ->
                                                            AssistChip(
                                                                onClick = { contributionStr = preset.toInt().toString() },
                                                                label = { Text("+${preset.toInt()}", fontSize = 11.sp) },
                                                                shape = RoundedCornerShape(8.dp)
                                                            )
                                                        }
                                                    }

                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.End,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        TextButton(onClick = { showContributionDialog = false }) {
                                                            Text(if (settings.idioma == "PT") "Cancelar" else "Cancel", color = Color(0xFF64748B))
                                                        }
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Button(
                                                            onClick = {
                                                                val valCont = contributionStr.toDoubleOrNull() ?: 0.0
                                                                if (valCont > 0) {
                                                                    viewModel.contributeToGoal(g, valCont, selectedContributionWalletId)
                                                                    showContributionDialog = false
                                                                    contributionStr = ""
                                                                }
                                                            },
                                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20))
                                                        ) {
                                                            Text(if (settings.idioma == "PT") "Salvar" else "Save")
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }

            // --- BOTTOM TIP CARD ---
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) Color(0xFF1E1B4B) else Color(0xFFF1F0FF)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(if (isDark) Color(0xFF6366F1) else Color(0xFFECEBFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.TrendingUp,
                                contentDescription = null,
                                tint = if (isDark) Color.White else Color(0xFF4F46E5),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        
                        Text(
                            text = if (settings.idioma == "PT") {
                                "Dica: Mantenha aportes periódicos e utilize o simulador para projetar metas de longo prazo!"
                            } else {
                                "Tip: Keep making regular contributions and use the simulator for long-term targets!"
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isDark) Color(0xFFE0E0FF) else Color(0xFF4F46E5),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

    // --- MODAL: CRIAR NOVA META (TELA CHEIA & ALTA DENSIDADE) ---
    if (showAddGoalModal) {
        var selectedGoalDateMs by remember { mutableStateOf<Long?>(System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000)) }
        var selectedDepositWalletId by remember(wallets) { mutableIntStateOf(wallets.firstOrNull()?.id ?: 1) }

        val submitGoal = {
            val parseVal: (String) -> Double = { text ->
                text.replace(",", ".").toDoubleOrNull() ?: 0.0
            }
            val objVal = parseVal(objectiveGoal)
            val initVal = parseVal(initialDepositGoal)
            val cat = selectedCategory ?: categories.firstOrNull()

            if (nomeGoal.isBlank()) {
                android.widget.Toast.makeText(
                    context,
                    if (settings.idioma == "PT") "Por favor, digite o nome do objetivo!" else "Please enter a goal name!",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            } else if (objVal <= 0.0) {
                android.widget.Toast.makeText(
                    context,
                    if (settings.idioma == "PT") "Insira um valor objetivo válido maior que zero!" else "Please enter a valid target amount greater than zero!",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            } else {
                val catId = cat?.id ?: 1
                val limitDate = selectedGoalDateMs ?: (System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000))
                viewModel.addFinancialGoal(nomeGoal, objVal, limitDate, catId, initVal, selectedDepositWalletId)

                TactileFeedbackHelper.triggerSuccessHaptic(haptic, context, scope)
                tactileState = TactileSuccessState(
                    visible = true,
                    title = if (settings.idioma == "PT") "Meta Criada com Sucesso" else "Goal Created Successfully",
                    detail = nomeGoal,
                    amount = "$currency ${String.format(java.util.Locale.getDefault(), "%,.2f", objVal)}",
                    color = Color(0xFF10B981),
                    icon = Icons.Rounded.Savings
                )

                showAddGoalModal = false
                nomeGoal = ""
                objectiveGoal = ""
                initialDepositGoal = ""
                daysToSave = "30"
            }
        }

        Dialog(
            onDismissRequest = { showAddGoalModal = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false
            )
        ) {
            val isPt = settings.idioma == "PT"
            val pickerLocale = if (isPt) java.util.Locale("pt", "PT") else java.util.Locale.US
            java.util.Locale.setDefault(pickerLocale)
            val pickerConfig = android.content.res.Configuration(context.resources.configuration).apply {
                setLocale(pickerLocale)
            }
            val calendar = java.util.Calendar.getInstance()
            val datePickerDialog = android.app.DatePickerDialog(
                context,
                { _, year, month, dayOfMonth ->
                    val selectedCal = java.util.Calendar.getInstance().apply {
                        set(java.util.Calendar.YEAR, year)
                        set(java.util.Calendar.MONTH, month)
                        set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth)
                        set(java.util.Calendar.HOUR_OF_DAY, 23)
                        set(java.util.Calendar.MINUTE, 59)
                        set(java.util.Calendar.SECOND, 59)
                    }
                    val ms = selectedCal.timeInMillis
                    val diffMs = ms - System.currentTimeMillis()
                    val calculatedDays = (diffMs / 86400000L).coerceAtLeast(1L)
                    daysToSave = calculatedDays.toString()
                    selectedGoalDateMs = ms
                },
                calendar.get(java.util.Calendar.YEAR),
                calendar.get(java.util.Calendar.MONTH),
                calendar.get(java.util.Calendar.DAY_OF_MONTH)
            )

            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Text(
                                        text = if (settings.idioma == "PT") "Criar Nova Meta" else "Create New Goal",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Text(
                                        text = if (settings.idioma == "PT") "Planeje e acompanhe seus objetivos" else "Plan & track financial targets",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            navigationIcon = {
                                IconButton(onClick = { showAddGoalModal = false }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = if (settings.idioma == "PT") "Fechar" else "Close"
                                    )
                                }
                            },
                            actions = {
                                Button(
                                    onClick = submitGoal,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .testTag("submit_goal_button")
                                ) {
                                    Text(if (settings.idioma == "PT") "Salvar Meta" else "Save Goal", fontWeight = FontWeight.Bold)
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                    }
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Goal Name
                        OutlinedTextField(
                            value = nomeGoal,
                            onValueChange = { nomeGoal = it },
                            label = { Text(if (settings.idioma == "PT") "Nome do Objetivo" else "Goal Name") },
                            placeholder = { Text(if (settings.idioma == "PT") "Ex: Comprar Casa, Carro, Viagem" else "e.g. House, Car, Trip") },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                            modifier = Modifier.fillMaxWidth().testTag("input_goal_nome")
                        )

                        // 2-Column Row: Target Value & Initial Deposit
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedTextField(
                                    value = objectiveGoal,
                                    onValueChange = { objectiveGoal = sanitizeDoubleInput(objectiveGoal, it) },
                                    label = { Text(if (settings.idioma == "PT") "Valor Meta ($currency)" else "Target ($currency)") },
                                    placeholder = { Text("0.00") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    leadingIcon = { Icon(Icons.Rounded.AttachMoney, null) },
                                    modifier = Modifier.fillMaxWidth().testTag("input_goal_valor")
                                )
                                // Quick Presets inline
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val presets = listOf(1000.0, 5000.0, 10000.0, 50000.0)
                                    presets.forEach { preset ->
                                        SuggestionChip(
                                            onClick = {
                                                val currentVal = objectiveGoal.replace(",", ".").toDoubleOrNull() ?: 0.0
                                                objectiveGoal = (currentVal + preset).toInt().toString()
                                            },
                                            label = { Text("+${preset.toInt()}", fontSize = 9.sp) },
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(26.dp)
                                        )
                                    }
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                OutlinedTextField(
                                    value = initialDepositGoal,
                                    onValueChange = { initialDepositGoal = sanitizeDoubleInput(initialDepositGoal, it) },
                                    label = { Text(if (settings.idioma == "PT") "Aporte Inicial ($currency)" else "Initial Saved ($currency)") },
                                    placeholder = { Text("0.00 (opcional)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    leadingIcon = { Icon(Icons.Rounded.Savings, null) },
                                    modifier = Modifier.fillMaxWidth().testTag("input_goal_initial_deposit")
                                )
                            }
                        }

                        // Wallet selection for initial deposit if > 0
                        val initDepositVal = initialDepositGoal.replace(",", ".").toDoubleOrNull() ?: 0.0
                        if (initDepositVal > 0.0) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = if (settings.idioma == "PT") "Debitar Aporte Inicial de:" else "Debit Initial Deposit From:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(wallets.size) { wIdx ->
                                        val w = wallets[wIdx]
                                        FilterChip(
                                            selected = selectedDepositWalletId == w.id,
                                            onClick = { selectedDepositWalletId = w.id },
                                            leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(14.dp)) },
                                            label = { Text(w.nome, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                        }

                        // Category Selection Chips
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (settings.idioma == "PT") "Categoria Associada" else "Associated Category",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            androidx.compose.foundation.lazy.LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth().testTag("dropdown_goal_category")
                            ) {
                                items(categories.size) { idx ->
                                    val cat = categories[idx]
                                    val isSelected = (selectedCategory?.id ?: categories.firstOrNull()?.id) == cat.id
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { selectedCategory = cat },
                                        label = {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                AppIcon(iconKey = cat.icone, modifier = Modifier.size(14.dp))
                                                Text(cat.nome, fontSize = 11.sp)
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            }
                        }

                        // Target Date & Duration Presets
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            val displayDateStr = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(selectedGoalDateMs ?: System.currentTimeMillis()))
                            Box(modifier = Modifier.fillMaxWidth().clickable { datePickerDialog.show() }) {
                                OutlinedTextField(
                                    value = "$displayDateStr ($daysToSave " + (if (settings.idioma == "PT") "dias" else "days") + ")",
                                    onValueChange = {},
                                    label = { Text(if (settings.idioma == "PT") "Prazo Final (Toque p/ alterar data)" else "Target Date (Tap to pick date)") },
                                    readOnly = true,
                                    enabled = false,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    trailingIcon = { Icon(Icons.Rounded.DateRange, null) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            // Duration Preset Chips
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val durationPresets = listOf(
                                    "30d (1 Mês)" to 30L,
                                    "90d (3m)" to 90L,
                                    "180d (6m)" to 180L,
                                    "365d (1 Ano)" to 365L
                                )
                                durationPresets.forEach { (label, days) ->
                                    SuggestionChip(
                                        onClick = {
                                            daysToSave = days.toString()
                                            selectedGoalDateMs = System.currentTimeMillis() + (days * 24 * 60 * 60 * 1000)
                                        },
                                        label = { Text(label, fontSize = 10.sp) },
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }
                            }
                        }

                        // Live Savings Simulation Card
                        val targetVal = objectiveGoal.replace(",", ".").toDoubleOrNull() ?: 0.0
                        val initVal = initialDepositGoal.replace(",", ".").toDoubleOrNull() ?: 0.0
                        val days = daysToSave.toLongOrNull()?.coerceAtLeast(1L) ?: 30L
                        if (targetVal > 0.0) {
                            val netTarget = (targetVal - initVal).coerceAtLeast(0.0)
                            val dailyNeeded = netTarget / days
                            val monthlyNeeded = dailyNeeded * 30

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.AutoMirrored.Rounded.TrendingUp, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                        Text(
                                            text = if (settings.idioma == "PT") "Simulação de Economia Sugerida:" else "Suggested Savings Projection:",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        val saveLabel = if (settings.idioma == "PT") "Guardar" else "Save"
                                        val dayLabel = if (settings.idioma == "PT") "/ dia" else "/ day"
                                        val monthLabel = if (settings.idioma == "PT") "/ mês" else "/ month"

                                        Text(
                                            text = String.format("• %s ~%,.2f %s %s", saveLabel, dailyNeeded, currency, dayLabel),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = String.format("• %s ~%,.2f %s %s", saveLabel, monthlyNeeded, currency, monthLabel),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = submitGoal,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("submit_goal_button_bottom")
                        ) {
                            Icon(Icons.Rounded.Check, null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (settings.idioma == "PT") "Criar Meta Financeira" else "Create Financial Goal",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    // --- MODAL: OPÇÕES DA META ---
    showActionDialogForGoal?.let { gl ->
        Dialog(onDismissRequest = { showActionDialogForGoal = null }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(if (settings.idioma == "PT") "Opções da Meta" else "Goal Options", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(gl.nome, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    
                    Divider()

                    OutlinedButton(
                        onClick = {
                            viewModel.togglePauseGoal(gl)
                            showActionDialogForGoal = null
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(if (gl.pausada) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (gl.pausada) {
                                if (settings.idioma == "PT") "Retomar Meta" else "Resume Goal"
                            } else {
                                if (settings.idioma == "PT") "Pausar Meta" else "Pause Goal"
                            }
                        )
                    }

                    if (gl.valorAtual > 0) {
                        Button(
                            onClick = {
                                showWithdrawGoalDialog = gl
                                showActionDialogForGoal = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.CallMade, null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (settings.idioma == "PT") "Resgatar / Retirar Fundos" else "Withdraw Funds")
                        }
                    }

                    Button(
                        onClick = {
                            showEditGoalDialog = gl
                            showActionDialogForGoal = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Edit, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (settings.idioma == "PT") "Editar Meta" else "Edit Goal")
                    }

                    Button(
                        onClick = {
                            viewModel.deleteGoal(gl)
                            showActionDialogForGoal = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Delete, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (settings.idioma == "PT") "Eliminar Meta" else "Delete Goal")
                    }
                }
            }
        }
    }

    showEditGoalDialog?.let { goalToEdit ->
        EditGoalDialog(
            goal = goalToEdit,
            categories = categories,
            settings = settings,
            onDismiss = { showEditGoalDialog = null },
            onConfirm = { viewModel.updateGoal(it) }
        )
    }

    showWithdrawGoalDialog?.let { goalToWithdraw ->
        var withdrawAmountStr by remember { mutableStateOf(goalToWithdraw.valorAtual.toString()) }
        var selectedWalletId by remember(wallets) { mutableStateOf(wallets.firstOrNull()?.id ?: 1) }

        AlertDialog(
            onDismissRequest = { showWithdrawGoalDialog = null },
            title = {
                Text(
                    if (settings.idioma == "PT") "Resgatar Fundos da Meta" else "Withdraw Funds from Goal",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "${goalToWithdraw.nome} (${String.format("%,.2f", goalToWithdraw.valorAtual)} ${settings.moedaPadrao})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = withdrawAmountStr,
                        onValueChange = { withdrawAmountStr = it },
                        label = { Text(if (settings.idioma == "PT") "Valor a Resgatar" else "Withdrawal Amount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = if (settings.idioma == "PT") "Depositar na Carteira:" else "Deposit to Wallet:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(wallets.filter { it.ativa }) { w ->
                            FilterChip(
                                selected = selectedWalletId == w.id,
                                onClick = { selectedWalletId = w.id },
                                leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(16.dp)) },
                                label = { Text(w.nome, fontSize = 11.sp, maxLines = 1) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = withdrawAmountStr.toDoubleOrNull() ?: 0.0
                        if (amt > 0 && amt <= goalToWithdraw.valorAtual) {
                            viewModel.withdrawFromGoal(goalToWithdraw, amt, selectedWalletId)
                            showWithdrawGoalDialog = null
                            android.widget.Toast.makeText(
                                context,
                                if (settings.idioma == "PT") "Resgate efetuado com sucesso!" else "Withdrawal successful!",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            android.widget.Toast.makeText(
                                context,
                                if (settings.idioma == "PT") "Valor inválido ou superior ao saldo da meta!" else "Invalid amount or exceeds goal balance!",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                ) {
                    Text(if (settings.idioma == "PT") "Confirmar Resgate" else "Confirm Withdrawal")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWithdrawGoalDialog = null }) {
                    Text(if (settings.idioma == "PT") "Cancelar" else "Cancel")
                }
            }
        )
    }

    // --- MODAL: SIMULADOR DE APORTES ---
    if (showGoalSimulatorModal) {
        Dialog(onDismissRequest = { showGoalSimulatorModal = false }) {
            Card(
                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.85f).padding(12.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (settings.idioma == "PT") "Simulador de Aportes" else "Savings Planner",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF1B5E20)
                        )
                        IconButton(onClick = { showGoalSimulatorModal = false }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Rounded.Close, null)
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    var targetValStr by remember { mutableStateOf("50000") }
                    var periodMonthsStr by remember { mutableStateOf("12") }
                    var expectedYieldStr by remember { mutableStateOf("8") }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = targetValStr,
                            onValueChange = { targetValStr = it },
                            label = { Text("Meta ($currency)", fontSize = 10.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.2f)
                        )
                        OutlinedTextField(
                            value = periodMonthsStr,
                            onValueChange = { periodMonthsStr = it },
                            label = { Text("Meses", fontSize = 10.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(0.8f)
                        )
                        OutlinedTextField(
                            value = expectedYieldStr,
                            onValueChange = { expectedYieldStr = it },
                            label = { Text("Rendimento (% a.a.)", fontSize = 10.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    val targetVal = targetValStr.toDoubleOrNull() ?: 0.0
                    val period = periodMonthsStr.toIntOrNull() ?: 1
                    val yieldYear = expectedYieldStr.toDoubleOrNull() ?: 0.0
                    val yieldMonth = (yieldYear / 12.0) / 100.0

                    val monthlyContribution = remember(targetVal, period, yieldMonth) {
                        if (targetVal > 0.0 && period > 0) {
                            if (yieldMonth == 0.0) {
                                targetVal / period
                            } else {
                                targetVal * (yieldMonth / (Math.pow(1.0 + yieldMonth, period.toDouble()) - 1.0))
                            }
                        } else {
                            0.0
                        }
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (settings.idioma == "PT") "Aporte Mensal Requerido:" else "Required Monthly Savings:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B5E20)
                            )
                            Text(
                                text = String.format("%,.2f %s", monthlyContribution, currency),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF1B5E20)
                            )
                            val totalDeposited = monthlyContribution * period
                            val totalInterest = Math.max(0.0, targetVal - totalDeposited)
                            Text(
                                text = if (settings.idioma == "PT") "Total Depositado: ${String.format("%,.0f", totalDeposited)} $currency | Juros Ganhos: ${String.format("%,.0f", totalInterest)} $currency" else "Total Deposited: ${String.format("%,.0f", totalDeposited)} $currency | Interest: ${String.format("%,.0f", totalInterest)} $currency",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF2E7D32)
                            )
                        }
                    }

                    Text(
                        text = if (settings.idioma == "PT") "Cronograma de Crescimento Mensal:" else "Monthly Growth Schedule:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    val schedule = remember(monthlyContribution, period, yieldMonth) {
                        val list = mutableListOf<Pair<Int, Double>>()
                        var bal = 0.0
                        for (i in 1..period) {
                            val interest = bal * yieldMonth
                            bal += monthlyContribution + interest
                            list.add(i to bal)
                        }
                        list
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    ) {
                        LazyColumn(
                            modifier = Modifier.padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Mês", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("Aporte", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("Saldo Acumulado", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Divider(modifier = Modifier.padding(vertical = 2.dp))
                            }

                            items(schedule) { (i, finalBalance) ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("#$i", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                    Text(String.format("%,.2f %s", monthlyContribution, currency), fontSize = 11.sp, color = Color(0xFF1B5E20))
                                    Text(String.format("%,.2f %s", finalBalance, currency), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { showGoalSimulatorModal = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Fechar")
                        }
                    }
                }
            }
        }
    }

    TactileSuccessBannerOverlay(
        state = tactileState,
        onDismiss = { tactileState = tactileState.copy(visible = false) }
    )
}


