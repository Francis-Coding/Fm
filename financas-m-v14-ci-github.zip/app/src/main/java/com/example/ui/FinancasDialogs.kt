@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class
)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import java.io.File


// ------------------- MODAL: CONCILIAÇÃO DIÁRIA OBRIGATÓRIA (CONSOLIDADA) -------------------
@Composable
fun DailyClosureModal(
    wallets: List<Wallet>,
    settings: UserSettings,
    onIgnore: () -> Unit,
    onSubmit: (Int, Double) -> Unit
) {
    var realBalanceStr by remember { mutableStateOf("") }
    var showClosureCalculator by remember { mutableStateOf(false) }
    val idioma = settings.idioma
    val totalExpected = wallets.sumOf { it.saldoAtual }

    var showDenominationCounter by remember { mutableStateOf(false) }
    var count1000 by remember { mutableStateOf("") }
    var count500 by remember { mutableStateOf("") }
    var count200 by remember { mutableStateOf("") }
    var count100 by remember { mutableStateOf("") }
    var count50 by remember { mutableStateOf("") }
    var count20 by remember { mutableStateOf("") }
    var countCoins by remember { mutableStateOf("") }
    var discrepancyNote by remember { mutableStateOf("") }

    val totalFromDenominations = remember(count1000, count500, count200, count100, count50, count20, countCoins) {
        (count1000.toIntOrNull() ?: 0) * 1000.0 +
        (count500.toIntOrNull() ?: 0) * 500.0 +
        (count200.toIntOrNull() ?: 0) * 200.0 +
        (count100.toIntOrNull() ?: 0) * 100.0 +
        (count50.toIntOrNull() ?: 0) * 50.0 +
        (count20.toIntOrNull() ?: 0) * 20.0 +
        (countCoins.toDoubleOrNull() ?: 0.0)
    }

    Dialog(onDismissRequest = onIgnore) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (idioma == "PT") "Conciliação Consolidada" else "Consolidated Reconciliation",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = if (idioma == "PT") 
                        "Confirme o saldo real somado de todas as suas contas para conciliação diária:"
                        else 
                        "Confirm the total actual combined balance across all accounts for daily reconciliation:",
                    textAlign = TextAlign.Center,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Consolidated Details Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Rounded.AttachMoney, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                        Text(
                            text = if (idioma == "PT") "Total de Todas as Contas" else "Total of All Accounts",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (idioma == "PT") 
                                "Saldo Esperado: ${String.format("%,.2f", totalExpected)} MZN"
                                else 
                                "Expected Balance: ${String.format("%,.2f", totalExpected)} MZN",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Denomination Counter Toggle Button
                OutlinedButton(
                    onClick = { showDenominationCounter = !showDenominationCounter },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (showDenominationCounter) 
                            (if (idioma == "PT") "Fechar Contador de Notas ▲" else "Hide Note Counter ▲")
                        else 
                            (if (idioma == "PT") "Contar Cédulas e Moedas ▼" else "Count Notes & Coins ▼"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (showDenominationCounter) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                if (settings.idioma == "PT") "Contagem Física de Cédulas:" else "Physical Notes Count:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(
                                    value = count1000,
                                    onValueChange = { count1000 = it.filter { c -> c.isDigit() } },
                                    label = { Text("1000 ${settings.moedaPadrao}") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = count500,
                                    onValueChange = { count500 = it.filter { c -> c.isDigit() } },
                                    label = { Text("500 ${settings.moedaPadrao}") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(
                                    value = count200,
                                    onValueChange = { count200 = it.filter { c -> c.isDigit() } },
                                    label = { Text("200 ${settings.moedaPadrao}") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = count100,
                                    onValueChange = { count100 = it.filter { c -> c.isDigit() } },
                                    label = { Text("100 ${settings.moedaPadrao}") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(
                                    value = count50,
                                    onValueChange = { count50 = it.filter { c -> c.isDigit() } },
                                    label = { Text("50 ${settings.moedaPadrao}") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = count20,
                                    onValueChange = { count20 = it.filter { c -> c.isDigit() } },
                                    label = { Text("20 ${settings.moedaPadrao}") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                            OutlinedTextField(
                                value = countCoins,
                                onValueChange = { countCoins = sanitizeDoubleInput(countCoins, it) },
                                label = { Text(if (idioma == "PT") "Moedas e Trocos (MZN)" else "Coins & Small Change (MZN)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            Button(
                                onClick = {
                                    realBalanceStr = String.format(java.util.Locale.US, "%.2f", totalFromDenominations)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    if (idioma == "PT") "Aplicar Total das Cédulas (${String.format("%,.2f", totalFromDenominations)} MZN)" else "Apply Total Notes (${String.format("%,.2f", totalFromDenominations)} MZN)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = realBalanceStr,
                    onValueChange = { realBalanceStr = sanitizeDoubleInput(realBalanceStr, it) },
                    label = { Text(if (idioma == "PT") "Saldo Real Total (MZN)" else "Total Actual Balance (MZN)") },
                    placeholder = { Text("0.00") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("closure_real_input"),
                    trailingIcon = {
                        IconButton(onClick = { showClosureCalculator = true }) {
                            Icon(
                                imageVector = Icons.Rounded.Calculate,
                                contentDescription = if (idioma == "PT") "Calculadora" else "Calculator",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                )

                // Motivos Frequentes de Discrepância / Quebra de Caixa
                val calculatedDiff = (realBalanceStr.toDoubleOrNull() ?: 0.0) - totalExpected
                if (Math.abs(calculatedDiff) > 0.01) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (idioma == "PT") "Justificação da Discrepância (${String.format("%+,.2f", calculatedDiff)} MZN):" else "Discrepancy Justification (${String.format("%+,.2f", calculatedDiff)} MZN):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(listOf("Taxa Agente M-Pesa", "Troco Esquecido", "Tarifa de Levantamento", "Diferença Arredondamento", "Sem Discrepância")) { reason ->
                                FilterChip(
                                    selected = discrepancyNote == reason,
                                    onClick = { discrepancyNote = reason },
                                    label = { Text(reason, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }

                if (showClosureCalculator) {
                    CalculatorDialog(
                        initialValue = realBalanceStr,
                        idioma = idioma,
                        onDismiss = { showClosureCalculator = false },
                        onConfirm = { result ->
                            realBalanceStr = result
                            showClosureCalculator = false
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onIgnore,
                        modifier = Modifier.weight(1f).testTag("closure_ignore_button")
                    ) {
                        Text(if (idioma == "PT") "Ignorar" else "Ignore")
                    }
                    Button(
                        onClick = {
                            val realVal = realBalanceStr.toDoubleOrNull() ?: 0.0
                            onSubmit(0, realVal) // 0 signals consolidated sum closure
                        },
                        modifier = Modifier.weight(1f).testTag("closure_submit_button")
                    ) {
                        Text(if (idioma == "PT") "Confirmar" else "Confirm")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditGoalDialog(
    goal: FinancialGoal,
    categories: List<Category>,
    settings: UserSettings,
    onDismiss: () -> Unit,
    onConfirm: (FinancialGoal) -> Unit
) {
    var nome by remember { mutableStateOf(goal.nome) }
    var valorObjetivoStr by remember { mutableStateOf(goal.valorObjetivo.toString()) }
    var selectedCategory by remember { mutableStateOf(categories.find { it.id == goal.categoriaId }) }
    var categoryDropdownOpen by remember { mutableStateOf(false) }
    var selectedGoalDateMs by remember { mutableStateOf(goal.dataLimite) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(if (settings.idioma == "PT") "Editar Meta" else "Edit Goal", fontWeight = FontWeight.Bold, fontSize = 18.sp)

                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text(if (settings.idioma == "PT") "Nome da Meta" else "Goal Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = valorObjetivoStr,
                    onValueChange = { valorObjetivoStr = it },
                    label = { Text(if (settings.idioma == "PT") "Valor Objetivo" else "Target Value") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selector
                Box {
                    OutlinedButton(
                        onClick = { categoryDropdownOpen = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(selectedCategory?.let { Translator.getLocalizedCategoryName(it.nome, settings.idioma) } ?: (if (settings.idioma == "PT") "Selecionar Categoria" else "Select Category"))
                    }
                    DropdownMenu(
                        expanded = categoryDropdownOpen,
                        onDismissRequest = { categoryDropdownOpen = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        AppIcon(iconKey = cat.icone, modifier = Modifier.size(16.dp))
                                        Text(Translator.getLocalizedCategoryName(cat.nome, settings.idioma))
                                    }
                                },
                                onClick = {
                                    selectedCategory = cat
                                    categoryDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                // Date Picker for goal limit
                val context = LocalContext.current
                val isPt = settings.idioma == "PT"
                val pickerLocale = if (isPt) java.util.Locale.forLanguageTag("pt-PT") else java.util.Locale.US
                val pickerConfig = android.content.res.Configuration(context.resources.configuration).apply {
                    setLocale(pickerLocale)
                }
                val localizedContext = context.createConfigurationContext(pickerConfig)
                val calendar = java.util.Calendar.getInstance().apply {
                    timeInMillis = selectedGoalDateMs
                }
                val datePickerDialog = android.app.DatePickerDialog(
                    localizedContext,
                    { _, year, month, dayOfMonth ->
                        val selectedCal = java.util.Calendar.getInstance().apply {
                            set(java.util.Calendar.YEAR, year)
                            set(java.util.Calendar.MONTH, month)
                            set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth)
                            set(java.util.Calendar.HOUR_OF_DAY, 23)
                            set(java.util.Calendar.MINUTE, 59)
                            set(java.util.Calendar.SECOND, 59)
                        }
                        selectedGoalDateMs = selectedCal.timeInMillis
                    },
                    calendar.get(java.util.Calendar.YEAR),
                    calendar.get(java.util.Calendar.MONTH),
                    calendar.get(java.util.Calendar.DAY_OF_MONTH)
                )

                val displayDateStr = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(selectedGoalDateMs))

                OutlinedButton(
                    onClick = { datePickerDialog.show() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Rounded.CalendarToday, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = if (settings.idioma == "PT") "Prazo: $displayDateStr" else "Due Date: $displayDateStr")
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(if (settings.idioma == "PT") "Cancelar" else "Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val valor = valorObjetivoStr.replace(",", ".").toDoubleOrNull() ?: goal.valorObjetivo
                            if (nome.isNotBlank() && valor >= goal.valorAtual) {
                                val updated = goal.copy(
                                    nome = nome,
                                    valorObjetivo = valor,
                                    categoriaId = selectedCategory?.id ?: goal.categoriaId,
                                    dataLimite = selectedGoalDateMs
                                )
                                onConfirm(updated)
                                onDismiss()
                            } else if (valor < goal.valorAtual) {
                                Toast.makeText(
                                    context,
                                    if (settings.idioma == "PT") "O valor-objetivo não pode ser menor do que o já guardado (%.2f)!".format(java.util.Locale.US, goal.valorAtual)
                                    else "Target amount cannot be less than saved amount (%.2f)!".format(java.util.Locale.US, goal.valorAtual),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    ) {
                        Text(if (settings.idioma == "PT") "Guardar" else "Save")
                    }
                }
            }
        }
    }
}

@Composable
fun FinancialMetricsPillarsCard(
    idioma: String,
    incomes: Double,
    expenses: Double,
    formatter: java.text.DecimalFormat,
    moeda: String = "MZN"
) {
    val net = incomes + expenses
    val isPositive = net >= 0.0
    var showExplanationDialog by remember { mutableStateOf<String?>(null) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Pillar 1: Incomes
        Card(
            modifier = Modifier
                .weight(1f)
                .clickable {
                    showExplanationDialog = if (idioma == "PT")
                        "Receitas Previstas: Soma de todas as entradas fixas recorrentes, receitas pontuais agendadas e recebimentos no período selecionado."
                    else
                        "Projected Incomes: Sum of recurring fixed income, scheduled one-time incomes, and receipts for the selected period."
                },
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
            border = BorderStroke(1.dp, Color(0xFFA5D6A7)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.TrendingUp,
                        contentDescription = null,
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (idioma == "PT") "Receitas" else "Income",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B5E20)
                    )
                }
                Text(
                    text = "+${formatter.format(incomes)} $moeda",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF2E7D32)
                )
                Text(
                    text = if (idioma == "PT") "Previsto/Recebido" else "Expected/Paid",
                    fontSize = 9.sp,
                    color = Color(0xFF388E3C)
                )
            }
        }

        // Pillar 2: Expenses
        Card(
            modifier = Modifier
                .weight(1f)
                .clickable {
                    showExplanationDialog = if (idioma == "PT")
                        "Despesas Previstas: Soma das despesas recorrentes, assinaturas ativas, parcelas de empréstimos e saídas agendadas."
                    else
                        "Projected Expenses: Sum of recurring expenses, active subscriptions, loan installments, and scheduled payouts."
                },
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
            border = BorderStroke(1.dp, Color(0xFFEF9A9A)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.TrendingDown,
                        contentDescription = null,
                        tint = Color(0xFFC62828),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (idioma == "PT") "Despesas" else "Expense",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB71C1C)
                    )
                }
                Text(
                    text = "-${formatter.format(Math.abs(expenses))} $moeda",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFC62828)
                )
                Text(
                    text = if (idioma == "PT") "Previsto/Pago" else "Expected/Paid",
                    fontSize = 9.sp,
                    color = Color(0xFFD32F2F)
                )
            }
        }

        // Pillar 3: Net Balance
        Card(
            modifier = Modifier
                .weight(1f)
                .clickable {
                    showExplanationDialog = if (idioma == "PT")
                        "Saldo Líquido = Receitas Total - Despesas Total. Representa o fluxo de caixa esperado no período selecionado."
                    else
                        "Net Balance = Total Incomes - Total Expenses. Represents expected net cashflow in the selected period."
                },
            colors = CardDefaults.cardColors(containerColor = if (isPositive) Color(0xFFE0F2F1) else Color(0xFFFFF3E0)),
            border = BorderStroke(1.dp, if (isPositive) Color(0xFF80CBC4) else Color(0xFFFFCC80)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = if (isPositive) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                        contentDescription = null,
                        tint = if (isPositive) Color(0xFF00695C) else Color(0xFFE65100),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (idioma == "PT") "Saldo Líq." else "Net Bal.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPositive) Color(0xFF004D40) else Color(0xFFE65100)
                    )
                }
                Text(
                    text = "${if (net > 0) "+" else ""}${formatter.format(net)} $moeda",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isPositive) Color(0xFF00695C) else Color(0xFFD84315)
                )
                Text(
                    text = if (isPositive) (if (idioma == "PT") "Superávit" else "Surplus") else (if (idioma == "PT") "Atenção" else "Deficit"),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPositive) Color(0xFF00796B) else Color(0xFFEF6C00)
                )
            }
        }
    }

    if (showExplanationDialog != null) {
        AlertDialog(
            onDismissRequest = { showExplanationDialog = null },
            title = {
                Text(if (idioma == "PT") "Explicação do Cálculo" else "Calculation Explanation", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Text(showExplanationDialog ?: "", fontSize = 13.sp)
            },
            confirmButton = {
                TextButton(onClick = { showExplanationDialog = null }) {
                    Text(if (idioma == "PT") "Entendido" else "Got it")
                }
            }
        )
    }
}

// ------------------- TELA AUXILIAR: DIALOG DE PROJEÇÃO DE FLUXO FUTURO -------------------

private data class CalendarEvent(
    val descricao: String,
    val valor: Double,
    val tipo: String, // Entrada, Saída, Empréstimo, Recorrente, Meta -> usado para cor/legenda/badge
    val subtitle: String,
    val tag: String? = null,
    val iconKey: String? = null,   // chave para AppIcon (categorias/carteiras/metas)
    val brandKey: String? = null,  // chave para BrandIcon (assinaturas)
    val colorHex: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FutureFlowCalendarDialog(
    idioma: String,
    currentBalance: Double,
    rawTransactions: List<Transaction>,
    groupedLoans: List<com.example.domain.usecases.GroupedLoan>,
    goals: List<FinancialGoal>,
    viewModel: MainViewModel? = null,
    wallets: List<Wallet> = emptyList(),
    categories: List<Category> = emptyList(),
    subscriptions: List<Subscription> = emptyList(),
    onNavigate: ((String) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val formatter = remember { java.text.DecimalFormat("#,##0.00") }
    val isSystemDark = isSystemInDarkTheme()
    val bgColor = if (isSystemDark) Color(0xFF0F172A) else Color(0xFFF8FAFC)
    val surfaceColor = if (isSystemDark) Color(0xFF1E293B) else Color(0xFFFFFFFF)
    val textColor = if (isSystemDark) Color.White else Color(0xFF0F172A)
    val textMuted = if (isSystemDark) Color(0xFF94A3B8) else Color(0xFF64748B)

    // A app tem o seu próprio idioma (definido em Definições) — a formatação de datas
    // deve seguir esse idioma, não o locale do telefone.
    val localeApp = remember(idioma) { Locale(if (idioma == "PT") "pt" else "en") }

    var selectedWalletId by remember { mutableStateOf<Int?>(null) }
    var selectedFilter by remember { mutableStateOf("Hoje") } // Hoje, 30 dias, 90 dias, Ano
    var viewedDate by remember { mutableStateOf(Calendar.getInstance()) }
    var selectedDate by remember { mutableStateOf(Calendar.getInstance()) }
    var isWalletMenuOpen by remember { mutableStateOf(false) }
    var isAddMenuOpen by remember { mutableStateOf(false) }
    var isMoreMenuOpen by remember { mutableStateOf(false) }
    var showMonthYearPicker by remember { mutableStateOf(false) }
    var showAllDayEvents by remember { mutableStateOf(false) }

    // Legenda funcional: cada tipo pode ser ligado/desligado, filtrando o que aparece
    // no grid e na lista do dia selecionado.
    val allEventTypes = listOf("Entrada", "Saída", "Empréstimo", "Recorrente", "Meta")
    var activeTypes by remember { mutableStateOf(allEventTypes.toSet()) }
    var showLegend by remember { mutableStateOf(true) }

    val subscriptionsState = viewModel?.subscriptions?.collectAsStateWithLifecycle(initialValue = subscriptions)
    val activeSubscriptions = remember(subscriptionsState?.value, subscriptions) {
        (subscriptionsState?.value ?: subscriptions).filter { it.ativa }
    }

    val todayCal = remember { Calendar.getInstance() }

    val filteredTransactions = remember(rawTransactions, selectedWalletId) {
        if (selectedWalletId == null) rawTransactions else rawTransactions.filter { it.walletId == selectedWalletId }
    }

    val projectionStartBalance = remember(selectedWalletId, currentBalance, wallets) {
        if (selectedWalletId == null) currentBalance else wallets.find { it.id == selectedWalletId }?.saldoAtual ?: 0.0
    }

    fun eventColor(type: String): Color = when (type) {
        "Entrada" -> Color(0xFF10B981)
        "Saída" -> Color(0xFFEF4444)
        "Empréstimo" -> Color(0xFFA855F7)
        "Recorrente" -> Color(0xFF3B82F6)
        "Meta" -> Color(0xFFFFB300)
        else -> textMuted
    }

    fun eventIcon(type: String) = when (type) {
        "Entrada" -> Icons.Rounded.ArrowDownward
        "Saída" -> Icons.Rounded.ArrowUpward
        "Empréstimo" -> Icons.Rounded.AccountBalance
        "Recorrente" -> Icons.Rounded.Loop
        "Meta" -> Icons.Rounded.Star
        else -> Icons.Rounded.AttachMoney
    }

    // Pré-agrupamento por dia (chave "ano-mês-dia"), calculado uma única vez por alteração
    // dos dados-fonte. Evita que getDailyEvents percorra TODAS as transações/empréstimos/
    // metas a cada dia consultado — o que era especialmente pesado no filtro "Ano" (365
    // varreduras completas). Agora cada dia é um lookup direto no mapa.
    fun dateKey(year: Int, month: Int, day: Int) = "$year-$month-$day"

    val nonRecurringByDate = remember(filteredTransactions) {
        filteredTransactions.filter { !it.recorrente }.groupBy { t ->
            val c = Calendar.getInstance().apply { timeInMillis = t.data }
            dateKey(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
        }
    }
    val recurringByDayOfMonth = remember(filteredTransactions) {
        filteredTransactions.filter { it.recorrente }.groupBy { t ->
            Calendar.getInstance().apply { timeInMillis = t.data }.get(Calendar.DAY_OF_MONTH)
        }
    }
    val subscriptionsByDay = remember(activeSubscriptions) {
        activeSubscriptions.groupBy { it.diaCobranca }
    }
    val installmentsByDate = remember(groupedLoans) {
        val map = mutableMapOf<String, MutableList<Pair<com.example.domain.usecases.GroupedLoan, com.example.data.model.Installment>>>()
        groupedLoans.forEach { g ->
            g.installments.forEach { inst ->
                val c = Calendar.getInstance().apply { timeInMillis = inst.dueDate }
                val key = dateKey(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
                map.getOrPut(key) { mutableListOf() }.add(g to inst)
            }
        }
        map
    }
    val goalsByDate = remember(goals) {
        goals.groupBy { g ->
            val c = Calendar.getInstance().apply { timeInMillis = g.dataLimite }
            dateKey(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
        }
    }

    fun getDailyEvents(year: Int, month: Int, day: Int): List<CalendarEvent> {
        val events = mutableListOf<CalendarEvent>()
        val key = dateKey(year, month, day)
        val dayMillis = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0) }.timeInMillis

        // Não recorrentes: usa o ícone/cor reais da categoria (igual ao resto da app)
        nonRecurringByDate[key]?.forEach { t ->
            val cat = categories.find { it.id == t.categoriaId }
            val wallet = wallets.find { it.id == t.carteiraOrigemId }
            val isDespesa = t.tipo == "Despesa"
            events.add(
                CalendarEvent(
                    descricao = t.descricao,
                    valor = if (isDespesa) -t.valor else t.valor,
                    tipo = if (isDespesa) "Saída" else "Entrada",
                    subtitle = "${if (isDespesa) (if (idioma == "PT") "Despesa" else "Expense") else (if (idioma == "PT") "Receita" else "Income")} • ${cat?.nome ?: wallet?.nome ?: "-"}",
                    iconKey = cat?.icone,
                    colorHex = cat?.cor
                )
            )
        }
        // Recorrentes (lançamentos marcados como recorrentes)
        recurringByDayOfMonth[day]?.forEach { t ->
            if (dayMillis >= t.data) {
                val cat = categories.find { it.id == t.categoriaId }
                events.add(
                    CalendarEvent(
                        descricao = t.descricao,
                        valor = if (t.tipo == "Despesa") -t.valor else t.valor,
                        tipo = "Recorrente",
                        subtitle = "${if (idioma == "PT") "Recorrente" else "Recurring"} • ${cat?.nome ?: "-"}",
                        tag = if (idioma == "PT") "Recorrente" else "Recurring",
                        iconKey = cat?.icone,
                        colorHex = cat?.cor
                    )
                )
            }
        }
        // Assinaturas: usa a marca real (Netflix, Spotify, etc.) tal como no resto da app
        subscriptionsByDay[day]?.forEach { sub ->
            events.add(
                CalendarEvent(
                    descricao = sub.nome,
                    valor = -sub.valor,
                    tipo = "Recorrente",
                    subtitle = "${if (idioma == "PT") "Despesa" else "Expense"} • ${if (idioma == "PT") "Assinatura" else "Subscription"}",
                    tag = if (idioma == "PT") "Assinatura" else "Subscription",
                    brandKey = sub.icone.ifBlank { sub.nome },
                    colorHex = sub.corHex
                )
            )
        }
        installmentsByDate[key]?.forEach { (g, inst) ->
            events.add(
                CalendarEvent(
                    // Valor da própria parcela (remainingBalance + totalPaid), não o
                    // saldo total em dívida do empréstimo — mesma convenção usada em
                    // LoansScreen ("Valor da parcela").
                    descricao = g.loan.counterparty,
                    valor = -(inst.remainingBalance + inst.totalPaid),
                    tipo = "Empréstimo",
                    subtitle = if (idioma == "PT") "Parcela de empréstimo" else "Loan installment",
                    tag = if (idioma == "PT") "Empréstimo" else "Loan"
                )
            )
        }
        goalsByDate[key]?.forEach { g ->
            val cat = categories.find { it.id == g.categoriaId }
            events.add(
                CalendarEvent(
                    descricao = g.nome,
                    valor = -g.valorTotal,
                    tipo = "Meta",
                    subtitle = if (idioma == "PT") "Prazo da meta" else "Goal deadline",
                    tag = if (idioma == "PT") "Meta" else "Goal",
                    iconKey = cat?.icone
                )
            )
        }
        return events
    }

    val viewedYear = viewedDate.get(Calendar.YEAR)
    val viewedMonth = viewedDate.get(Calendar.MONTH)

    fun goToMonth(offset: Int) {
        viewedDate = (viewedDate.clone() as Calendar).apply { add(Calendar.MONTH, offset) }
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    fun goToToday() {
        viewedDate = Calendar.getInstance()
        selectedDate = Calendar.getInstance()
        selectedFilter = "Hoje"
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    val periodSummary = remember(selectedFilter, viewedDate, filteredTransactions, activeSubscriptions, groupedLoans, goals) {
        val startCal = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }
        val endCal = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }
        when (selectedFilter) {
            "Hoje" -> {
                // O chip "Hoje" deve mostrar apenas o dia de hoje, não o mês inteiro.
                val todayDom = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
                startCal.set(Calendar.DAY_OF_MONTH, todayDom)
                endCal.set(Calendar.DAY_OF_MONTH, todayDom)
            }
            "30 dias" -> { endCal.add(Calendar.DAY_OF_MONTH, 30) }
            "90 dias" -> { endCal.add(Calendar.DAY_OF_MONTH, 90) }
            "Ano" -> {
                startCal.set(Calendar.MONTH, 0); startCal.set(Calendar.DAY_OF_MONTH, 1)
                endCal.set(Calendar.MONTH, 11); endCal.set(Calendar.DAY_OF_MONTH, 31)
            }
        }

        var totRec = 0.0
        var totDes = 0.0
        var countRec = 0
        var countDes = 0

        val curr = startCal.clone() as Calendar
        while (!curr.after(endCal)) {
            val evs = getDailyEvents(curr.get(Calendar.YEAR), curr.get(Calendar.MONTH), curr.get(Calendar.DAY_OF_MONTH))
            evs.forEach { ev ->
                // "Meta" é só um prazo/lembrete, não um movimento de caixa real — não deve
                // entrar nos totais de receitas/despesas do período.
                if (ev.tipo != "Meta") {
                    if (ev.valor > 0) { totRec += ev.valor; countRec++ }
                    else { totDes += Math.abs(ev.valor); countDes++ }
                }
            }
            curr.add(Calendar.DAY_OF_MONTH, 1)
        }
        // (receitas, despesas, nº lançamentos de receita, nº lançamentos de despesa)
        Triple(Pair(totRec, totDes), countRec, countDes)
    }

    val monthEvents = remember(viewedYear, viewedMonth, filteredTransactions, groupedLoans, activeSubscriptions, goals) {
        val maxDays = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }.getActualMaximum(Calendar.DAY_OF_MONTH)
        (1..maxDays).associateWith { d -> getDailyEvents(viewedYear, viewedMonth, d) }
    }

    // Eventos filtrados pela legenda (afeta apenas o que é exibido, não os totais dos cartões)
    val monthEventsFiltered = remember(monthEvents, activeTypes) {
        monthEvents.mapValues { (_, evs) -> evs.filter { it.tipo in activeTypes } }
    }

    var monthReceitas = 0.0
    var monthDespesas = 0.0
    var monthMetas = 0
    monthEvents.values.flatten().forEach { ev ->
        // Mesma regra: metas (prazos) ficam de fora dos totais de receita/despesa do mês.
        if (ev.tipo == "Meta") {
            monthMetas++
        } else if (ev.valor > 0) {
            monthReceitas += ev.valor
        } else {
            monthDespesas += Math.abs(ev.valor)
        }
    }
    val monthSaldo = monthReceitas - monthDespesas

    val startOfMonthBal = remember(viewedYear, viewedMonth, projectionStartBalance, filteredTransactions, groupedLoans, activeSubscriptions, goals) {
        // Deriva o saldo de início do mês visualizado a partir do saldo atual da carteira,
        // andando dia a dia (com os mesmos eventos reais/projetados usados no resto do
        // calendário) entre hoje e o início do mês visualizado — em vez de usar sempre o
        // saldo atual como ponto de partida, o que só era correto para o mês corrente.
        fun netEventsValor(y: Int, m: Int, d: Int): Double =
            getDailyEvents(y, m, d).filter { it.tipo != "Meta" }.sumOf { it.valor }

        val startOfViewedMonth = (Calendar.getInstance().clone() as Calendar).apply {
            set(viewedYear, viewedMonth, 1, 0, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val today = (Calendar.getInstance().clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }

        if (!startOfViewedMonth.after(today)) {
            // Mês atual ou passado: subtrai ao saldo atual todos os eventos já ocorridos
            // desde o início desse mês até hoje (inclusive), chegando ao saldo que existia
            // no dia 1 desse mês.
            var sum = 0.0
            val cal = startOfViewedMonth.clone() as Calendar
            while (!cal.after(today)) {
                sum += netEventsValor(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
                cal.add(Calendar.DAY_OF_MONTH, 1)
            }
            projectionStartBalance - sum
        } else {
            // Mês futuro: soma ao saldo atual os eventos projetados entre hoje (exclusive)
            // e o início desse mês (exclusive).
            var sum = 0.0
            val cal = today.clone() as Calendar
            cal.add(Calendar.DAY_OF_MONTH, 1)
            while (cal.before(startOfViewedMonth)) {
                sum += netEventsValor(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
                cal.add(Calendar.DAY_OF_MONTH, 1)
            }
            projectionStartBalance + sum
        }
    }

    if (showMonthYearPicker) {
        MonthYearFastPickerDialog(
            currentYear = viewedYear,
            currentMonth = viewedMonth,
            idioma = idioma,
            onMonthYearSelected = { y, m ->
                viewedDate = (viewedDate.clone() as Calendar).apply { set(Calendar.YEAR, y); set(Calendar.MONTH, m) }
                showMonthYearPicker = false
            },
            onDismiss = { showMonthYearPicker = false }
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = bgColor) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                // HEADER — título clicável abre o seletor rápido de mês/ano; deslizar (swipe)
                // no grid também muda de mês.
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showMonthYearPicker = true
                        }
                    ) {
                        val monthYearLabel = remember(viewedYear, viewedMonth, localeApp) {
                            val cal = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }
                            SimpleDateFormat("MMMM yyyy", localeApp).format(cal.time)
                                .replaceFirstChar { it.uppercase() }
                        }
                        Text(
                            text = monthYearLabel,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                    }
                    Row {
                        Box {
                            IconButton(onClick = { isAddMenuOpen = true }) {
                                Icon(Icons.Rounded.Add, contentDescription = if (idioma == "PT") "Adicionar" else "Add", tint = textColor)
                            }
                            DropdownMenu(expanded = isAddMenuOpen, onDismissRequest = { isAddMenuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text(if (idioma == "PT") "Nova receita" else "New income") },
                                    leadingIcon = { Icon(Icons.Rounded.ArrowDownward, contentDescription = null, tint = Color(0xFF10B981)) },
                                    onClick = { isAddMenuOpen = false; onDismiss(); onNavigate?.invoke("adicionar_receita") }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (idioma == "PT") "Nova despesa" else "New expense") },
                                    leadingIcon = { Icon(Icons.Rounded.ArrowUpward, contentDescription = null, tint = Color(0xFFEF4444)) },
                                    onClick = { isAddMenuOpen = false; onDismiss(); onNavigate?.invoke("adicionar_despesa") }
                                )
                            }
                        }
                        Box {
                            IconButton(onClick = { isMoreMenuOpen = true }) {
                                Icon(Icons.Rounded.MoreVert, contentDescription = if (idioma == "PT") "Mais opções" else "More options", tint = textColor)
                            }
                            DropdownMenu(expanded = isMoreMenuOpen, onDismissRequest = { isMoreMenuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text(if (idioma == "PT") "Ir para hoje" else "Go to today") },
                                    leadingIcon = { Icon(Icons.Rounded.Today, contentDescription = null) },
                                    onClick = { isMoreMenuOpen = false; goToToday() }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (idioma == "PT") "Saúde financeira" else "Financial health") },
                                    leadingIcon = { Icon(Icons.Rounded.Favorite, contentDescription = null) },
                                    onClick = { isMoreMenuOpen = false; onDismiss(); onNavigate?.invoke("relatorios:saude") }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (idioma == "PT") "Ver recorrentes" else "View recurring") },
                                    leadingIcon = { Icon(Icons.Rounded.Loop, contentDescription = null) },
                                    onClick = { isMoreMenuOpen = false; onDismiss(); onNavigate?.invoke("relatorios:recorrentes") }
                                )
                            }
                        }
                    }
                }

                // FILTROS — carteira à esquerda, período à direita (com scroll de segurança
                // em ecrãs pequenos, sem quebrar o alinhamento nos ecrãs normais)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = surfaceColor,
                            border = BorderStroke(1.dp, textMuted.copy(alpha = 0.2f)),
                            modifier = Modifier.clickable { isWalletMenuOpen = true }
                        ) {
                            Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(16.dp), tint = textColor)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (selectedWalletId == null) (if (idioma == "PT") "Todas Carteiras" else "All Wallets") else wallets.find { it.id == selectedWalletId }?.nome ?: "Carteira",
                                    fontSize = 13.sp,
                                    color = textColor,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = textMuted)
                            }
                        }
                        DropdownMenu(expanded = isWalletMenuOpen, onDismissRequest = { isWalletMenuOpen = false }) {
                            DropdownMenuItem(text = { Text(if (idioma == "PT") "Todas Carteiras" else "All Wallets") }, onClick = { selectedWalletId = null; isWalletMenuOpen = false })
                            wallets.forEach { w ->
                                DropdownMenuItem(text = { Text(w.nome) }, onClick = { selectedWalletId = w.id; isWalletMenuOpen = false })
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val filters = listOf("Hoje", "30 dias", "90 dias", "Ano")
                        fun filterLabel(f: String): String = when (f) {
                            "Hoje" -> if (idioma == "PT") "Hoje" else "Today"
                            "30 dias" -> if (idioma == "PT") "30 dias" else "30 days"
                            "90 dias" -> if (idioma == "PT") "90 dias" else "90 days"
                            "Ano" -> if (idioma == "PT") "Ano" else "Year"
                            else -> f
                        }
                        filters.forEach { f ->
                            val isSel = selectedFilter == f
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) surfaceColor else Color.Transparent,
                                border = BorderStroke(1.dp, if (isSel) textMuted.copy(alpha = 0.3f) else Color.Transparent),
                                modifier = Modifier.clickable {
                                    selectedFilter = f
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    if (f == "Hoje") {
                                        viewedDate = Calendar.getInstance()
                                        selectedDate = Calendar.getInstance()
                                    }
                                }
                            ) {
                                Text(
                                    text = filterLabel(f),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    fontSize = 13.sp,
                                    color = if (isSel) textColor else textMuted,
                                    fontWeight = if (isSel) FontWeight.Medium else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // RESUMO FINANCEIRO (Cards) - Baseado no período selecionado
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val cardMod = Modifier.weight(1f)

                    val dispRec = periodSummary.first.first
                    val dispDes = periodSummary.first.second
                    val dispSal = dispRec - dispDes
                    val nRec = periodSummary.second
                    val nDes = periodSummary.third

                    Surface(shape = RoundedCornerShape(12.dp), color = surfaceColor, modifier = cardMod, border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.TrendingUp, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF10B981))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (idioma == "PT") "Receitas" else "Income", fontSize = 11.sp, color = textColor)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("+${formatter.format(dispRec)}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (idioma == "PT") "$nRec lançamento${if (nRec == 1) "" else "s"}" else "$nRec entr${if (nRec == 1) "y" else "ies"}",
                                fontSize = 9.sp, color = textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Surface(shape = RoundedCornerShape(12.dp), color = surfaceColor, modifier = cardMod, border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.TrendingDown, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFFEF4444))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (idioma == "PT") "Despesas" else "Expenses", fontSize = 11.sp, color = textColor)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("-${formatter.format(dispDes)}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (idioma == "PT") "$nDes lançamento${if (nDes == 1) "" else "s"}" else "$nDes entr${if (nDes == 1) "y" else "ies"}",
                                fontSize = 9.sp, color = textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Surface(shape = RoundedCornerShape(12.dp), color = surfaceColor, modifier = cardMod, border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF3B82F6))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (idioma == "PT") "Saldo Líquido" else "Net Balance", fontSize = 11.sp, color = textColor)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "${if (dispSal > 0) "+" else ""}${formatter.format(dispSal)}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF3B82F6),
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                if (dispSal >= 0) (if (idioma == "PT") "Superávit" else "Surplus") else (if (idioma == "PT") "Défice" else "Deficit"),
                                fontSize = 9.sp, color = textMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // LEGENDA — funcional: tocar num item liga/desliga esse tipo de evento
                // no grid e na lista do dia. Estilo minimalista (ponto + texto).
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { showLegend = !showLegend },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (showLegend) (if (idioma == "PT") "Ocultar legenda ∨" else "Hide legend ∨") else (if (idioma == "PT") "Mostrar legenda >" else "Show legend >"),
                            fontSize = 11.sp, color = textMuted
                        )
                        if (activeTypes.size < allEventTypes.size) {
                            Text(
                                if (idioma == "PT") "Repor filtros" else "Reset filters",
                                fontSize = 10.sp,
                                color = Color(0xFF3B82F6),
                                modifier = Modifier.clickable { activeTypes = allEventTypes.toSet() }
                            )
                        } else if (showLegend) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                allEventTypes.forEach { type ->
                                    val color = eventColor(type)
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable {
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            if (activeTypes.size > 1) activeTypes = activeTypes - type
                                        }
                                    ) {
                                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(type, fontSize = 9.sp, color = textMuted)
                                    }
                                }
                            }
                        }
                    }
                    // Quando existem filtros ativos (menos do que o total), mostra a lista
                    // completa numa segunda linha para que se veja o que está desligado.
                    if (showLegend && activeTypes.size < allEventTypes.size) {
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            allEventTypes.forEach { type ->
                                val isActive = type in activeTypes
                                val color = eventColor(type)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .alpha(if (isActive) 1f else 0.35f)
                                        .clickable {
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            activeTypes = if (isActive) {
                                                if (activeTypes.size > 1) activeTypes - type else activeTypes
                                            } else {
                                                activeTypes + type
                                            }
                                        }
                                ) {
                                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(type, fontSize = 9.sp, color = textMuted)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // GRID DO CALENDÁRIO
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = surfaceColor,
                    border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            val days = if (idioma == "PT") listOf("DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB") else listOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT")
                            days.forEachIndexed { i, d ->
                                val isWeekend = i == 0 || i == 6
                                Text(
                                    text = d,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Center,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isWeekend) Color(0xFF3B82F6) else textMuted
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        val cal = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }
                        val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = Dom
                        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                        val prevMonthMax = Calendar.getInstance().apply { set(viewedYear, viewedMonth - 1, 1) }.getActualMaximum(Calendar.DAY_OF_MONTH)

                        var dayCounter = 1
                        var nextMonthCounter = 1

                        val touchGestures = Modifier.pointerInput(Unit) {
                            detectHorizontalDragGestures { change, dragAmount ->
                                change.consume()
                                if (dragAmount > 30) goToMonth(-1) else if (dragAmount < -30) goToMonth(1)
                            }
                        }

                        Column(modifier = touchGestures) {
                            for (row in 0..5) {
                                Row(modifier = Modifier.fillMaxWidth()) {
                                    for (col in 0..6) {
                                        val isWeekend = col == 0 || col == 6

                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(56.dp)
                                                .padding(2.dp)
                                                .clip(RoundedCornerShape(8.dp)),
                                            contentAlignment = Alignment.TopCenter
                                        ) {
                                            if (row == 0 && col < firstDayOfWeek) {
                                                val d = prevMonthMax - firstDayOfWeek + col + 1
                                                Text(
                                                    text = "$d",
                                                    modifier = Modifier.padding(top = 4.dp).clickable { goToMonth(-1) },
                                                    fontSize = 14.sp,
                                                    color = textMuted.copy(alpha = 0.4f)
                                                )
                                            } else if (dayCounter > maxDays) {
                                                val d = nextMonthCounter++
                                                Text(
                                                    text = "$d",
                                                    modifier = Modifier.padding(top = 4.dp).clickable { goToMonth(1) },
                                                    fontSize = 14.sp,
                                                    color = if (isWeekend) Color(0xFF3B82F6).copy(alpha = 0.4f) else textMuted.copy(alpha = 0.4f)
                                                )
                                            } else {
                                                val d = dayCounter
                                                val isSelected = selectedDate.get(Calendar.DAY_OF_MONTH) == d && selectedDate.get(Calendar.MONTH) == viewedMonth && selectedDate.get(Calendar.YEAR) == viewedYear
                                                val isToday = d == todayCal.get(Calendar.DAY_OF_MONTH) && viewedMonth == todayCal.get(Calendar.MONTH) && viewedYear == todayCal.get(Calendar.YEAR)

                                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxSize().clickable {
                                                    selectedDate = Calendar.getInstance().apply { set(viewedYear, viewedMonth, d) }
                                                    showAllDayEvents = false
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                }) {
                                                    Box(
                                                        modifier = Modifier
                                                            .padding(top = 2.dp)
                                                            .size(28.dp)
                                                            .clip(RoundedCornerShape(8.dp))
                                                            .then(if (isToday && !isSelected) Modifier.border(1.dp, Color(0xFF3B82F6), RoundedCornerShape(8.dp)) else Modifier)
                                                            .background(if (isSelected) Color(0xFF3B82F6) else Color.Transparent),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = "$d",
                                                            fontSize = 14.sp,
                                                            color = if (isSelected) Color.White else if (isWeekend) Color(0xFF3B82F6) else textColor
                                                        )
                                                    }
                                                    val evs = monthEventsFiltered[d] ?: emptyList()
                                                    if (evs.isNotEmpty()) {
                                                        Spacer(modifier = Modifier.height(1.dp))
                                                        val displayEvs = evs.take(2)
                                                        displayEvs.forEach { ev ->
                                                            val color = eventColor(ev.tipo)
                                                            val label = when (ev.tipo) {
                                                                "Empréstimo" -> if (idioma == "PT") "Emprést." else "Loan"
                                                                "Recorrente" -> if (idioma == "PT") "Recorr." else "Recur."
                                                                "Meta" -> if (idioma == "PT") "Meta" else "Goal"
                                                                else -> "${if (ev.valor > 0) "+" else ""}${ev.valor.toInt()}"
                                                            }
                                                            Surface(
                                                                color = color.copy(alpha = 0.15f),
                                                                shape = RoundedCornerShape(4.dp),
                                                                modifier = Modifier.padding(bottom = 1.dp)
                                                            ) {
                                                                Text(text = label, fontSize = 7.sp, color = color, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp), maxLines = 1)
                                                            }
                                                        }
                                                        if (evs.size > 2) {
                                                            Text(
                                                                text = "+${evs.size - 2}",
                                                                fontSize = 7.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color(0xFF3B82F6)
                                                            )
                                                        }
                                                    }
                                                }
                                                dayCounter++
                                            }
                                        }
                                    }
                                }
                                if (dayCounter > maxDays && row >= 4) break
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // SECÇÃO INFERIOR
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val selD = selectedDate.get(Calendar.DAY_OF_MONTH)
                    val isSelToday = selectedDate.get(Calendar.YEAR) == todayCal.get(Calendar.YEAR) && selectedDate.get(Calendar.DAY_OF_YEAR) == todayCal.get(Calendar.DAY_OF_YEAR)
                    val selEvsAll = if (selectedDate.get(Calendar.MONTH) == viewedMonth) (monthEventsFiltered[selD] ?: emptyList()) else emptyList()
                    val dateLabel = remember(selectedDate.timeInMillis, localeApp) {
                        SimpleDateFormat("d MMM yyyy", localeApp).format(selectedDate.time).replaceFirstChar { it.uppercase() }
                    }

                    // "Meta" é só um prazo/lembrete (ver periodSummary acima) — excluído aqui
                    // também, para não fazer o saldo previsto cair pelo valor total da meta.
                    val selBal = startOfMonthBal + (monthEvents.filterKeys { it <= selD }.values.flatten().filter { it.tipo != "Meta" }.sumOf { it.valor })

                    Surface(
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(12.dp),
                        color = surfaceColor,
                        border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(if (isSelToday) "${if (idioma == "PT") "Hoje" else "Today"} • $dateLabel" else dateLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textColor)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(4.dp)) {
                                        Text(
                                            "${selEvsAll.size} ${if (idioma == "PT") "eventos" else "events"}",
                                            fontSize = 9.sp, color = Color(0xFF3B82F6), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(if (idioma == "PT") "Saldo previsto" else "Projected balance", fontSize = 9.sp, color = textMuted)
                                    Text("${if (selBal > 0) "+" else ""}${formatter.format(selBal)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (selBal >= 0) Color(0xFF10B981) else Color(0xFFEF4444))
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            val visibleEvs = if (showAllDayEvents) selEvsAll else selEvsAll.take(4)
                            visibleEvs.forEach { ev ->
                                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    val accent = eventColor(ev.tipo)
                                    Box(modifier = Modifier.width(3.dp).height(32.dp).clip(RoundedCornerShape(2.dp)).background(accent))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    when {
                                        ev.brandKey != null -> com.example.util.BrandIcon(
                                            nameOrKey = ev.brandKey,
                                            customColorHex = ev.colorHex,
                                            modifier = Modifier.size(32.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        ev.iconKey != null -> Box(
                                            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(accent.copy(alpha = 0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            AppIcon(iconKey = ev.iconKey, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
                                        }
                                        else -> Box(
                                            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(accent.copy(alpha = 0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(eventIcon(ev.tipo), contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(ev.descricao, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            if (ev.tag != null) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Surface(color = accent.copy(alpha = 0.12f), shape = RoundedCornerShape(4.dp)) {
                                                    Text(ev.tag, fontSize = 8.sp, color = accent, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                }
                                            }
                                        }
                                        Text(ev.subtitle, fontSize = 9.sp, color = textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Text(
                                        "${if (ev.valor > 0) "+" else ""}${formatter.format(ev.valor)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (ev.valor > 0) Color(0xFF10B981) else Color(0xFFEF4444)
                                    )
                                }
                            }
                            if (selEvsAll.isEmpty()) {
                                Text(
                                    if (activeTypes.size < allEventTypes.size)
                                        (if (idioma == "PT") "Nenhum evento visível com os filtros atuais." else "No events visible with current filters.")
                                    else
                                        (if (idioma == "PT") "Nenhum evento financeiro neste dia." else "No financial events on this day."),
                                    fontSize = 11.sp, color = textMuted, modifier = Modifier.padding(vertical = 12.dp)
                                )
                            }

                            if (selEvsAll.size > 4) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable { showAllDayEvents = !showAllDayEvents },
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        if (showAllDayEvents) (if (idioma == "PT") "Mostrar menos" else "Show less")
                                        else (if (idioma == "PT") "Ver todos os eventos do dia (${selEvsAll.size})" else "View all events (${selEvsAll.size})"),
                                        fontSize = 11.sp, color = Color(0xFF3B82F6)
                                    )
                                    Icon(
                                        if (showAllDayEvents) Icons.Rounded.KeyboardArrowUp else Icons.AutoMirrored.Rounded.ArrowForward,
                                        contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }

                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        color = surfaceColor,
                        border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(if (idioma == "PT") "Resumo do mês" else "Month summary", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = textColor)
                            Spacer(modifier = Modifier.height(12.dp))

                            @Composable
                            fun SumRow(label: String, value: String, color: Color) {
                                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(label, fontSize = 11.sp, color = textMuted)
                                    Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
                                }
                            }

                            SumRow(if (idioma == "PT") "Entradas" else "Income", "+${formatter.format(monthReceitas)}", Color(0xFF10B981))
                            SumRow(if (idioma == "PT") "Saídas" else "Expenses", "-${formatter.format(monthDespesas)}", Color(0xFFEF4444))
                            SumRow(if (idioma == "PT") "Saldo Previsto" else "Projected balance", "${if (monthSaldo > 0) "+" else ""}${formatter.format(monthSaldo)}", Color(0xFF3B82F6))
                            Spacer(modifier = Modifier.height(8.dp))
                            SumRow(if (idioma == "PT") "Metas" else "Goals", "$monthMetas / ${goals.size}", textColor)
                            Box(modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(textMuted.copy(alpha = 0.2f))) {
                                Box(modifier = Modifier.fillMaxWidth(if (goals.isEmpty()) 0f else monthMetas.toFloat() / goals.size.toFloat()).height(4.dp).clip(CircleShape).background(Color(0xFFFFB300)))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            SumRow(if (idioma == "PT") "Recorrentes" else "Recurring", "${activeSubscriptions.size} ${if (idioma == "PT") "ativos" else "active"}", textColor)

                            Spacer(modifier = Modifier.weight(1f))
                            Row(
                                modifier = Modifier.fillMaxWidth().clickable { onDismiss(); onNavigate?.invoke("relatorios:saude") },
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(if (idioma == "PT") "Ver mais detalhes" else "View more details", fontSize = 11.sp, color = Color(0xFF3B82F6))
                                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MonthYearFastPickerDialog(
    currentYear: Int,
    currentMonth: Int,
    idioma: String,
    onMonthYearSelected: (year: Int, month: Int) -> Unit,
    onDismiss: () -> Unit
) {
    var pickerYear by remember { mutableStateOf(currentYear) }
    val months = remember(idioma) {
        if (idioma == "PT") {
            listOf("Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez")
        } else {
            listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { pickerYear-- }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Prev Year")
                }
                Text("$pickerYear", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                IconButton(onClick = { pickerYear++ }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "Next Year")
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (row in 0..3) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (col in 0..2) {
                            val monthIdx = row * 3 + col
                            val isSelected = (pickerYear == currentYear && monthIdx == currentMonth)
                            Button(
                                onClick = { onMonthYearSelected(pickerYear, monthIdx) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(months[monthIdx], fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Cancelar" else "Cancel")
            }
        }
    )
}

@Composable
fun GoalProgressBar(goal: com.example.data.model.FinancialGoal, idioma: String) {
    val progress = if (goal.valorObjetivo > 0) (goal.valorAtual / goal.valorObjetivo).coerceIn(0.0, 1.0) else 0.0
    val pct = (progress * 100).roundToInt()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = goal.nome,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "$pct%",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }
        LinearProgressIndicator(
            progress = { progress.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val labelSub = if (idioma == "PT") "Progresso: " else "Progress: "
            Text(
                text = "$labelSub${String.format("%,.2f", goal.valorAtual)} / ${String.format("%,.2f", goal.valorObjetivo)} MZN",
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}

// ------------------- AUXILIARY: ACTIVITY TIMELINE ITEM -------------------
@Composable
fun ActivityItem(
    title: String,
    subtitle: String,
    time: String,
    isLast: Boolean,
    isSuccess: Boolean = false,
    isDark: Boolean
) {
    val textPrimary = if (isDark) Color(0xFFE2EAF4) else Color(0xFF172033)
    val textSecondary = if (isDark) Color(0xFF8895A7) else Color(0xFF667085)
    val circleColor = if (isSuccess) Color(0xFF087A35) else if (isDark) Color(0xFF2C312E) else Color(0xFFE2E8F0)
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(circleColor),
                contentAlignment = Alignment.Center
            ) {
                if (isSuccess) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(10.dp)
                    )
                }
            }
            
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(48.dp)
                        .background(if (isDark) Color(0xFF2C312E) else Color(0xFFE2E8F0))
                )
            }
        }
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = textPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = textSecondary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = time,
                fontSize = 11.sp,
                color = textSecondary,
                fontWeight = FontWeight.Light
            )
        }
    }
}

@Composable
fun FormatPremiumAmount(
    amountText: String,
    currency: String,
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit = 16.sp
) {
    val annotatedString = remember(amountText, currency, color, fontSize) {
        val parts = amountText.split(",")
        val mainPart = parts[0]
        val decimalPart = if (parts.size > 1) ",${parts[1]}" else ",00"
        
        androidx.compose.ui.text.buildAnnotatedString {
            withStyle(style = androidx.compose.ui.text.SpanStyle(fontSize = fontSize, fontWeight = FontWeight.Bold, color = color)) {
                append(mainPart)
            }
            withStyle(style = androidx.compose.ui.text.SpanStyle(fontSize = (fontSize.value * 0.75f).sp, fontWeight = FontWeight.Medium, color = color)) {
                append(decimalPart)
            }
            append("\u00A0")
            withStyle(style = androidx.compose.ui.text.SpanStyle(fontSize = (fontSize.value * 0.65f).sp, fontWeight = FontWeight.Medium, color = if (color == Color.White) Color(0xFF98A2B3) else color)) {
                append(currency)
            }
        }
    }

    Text(
        text = annotatedString,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}

// Basic Calculator helper structures for mathematical operations
fun evaluateExpression(expr: String): Double? {
    return try {
        val sanitized = expr.replace(" ", "").replace(",", ".")
        if (sanitized.isEmpty()) return null
        val parser = SimpleParser(sanitized)
        val result = parser.parse()
        if (result.isInfinite() || result.isNaN()) null else result
    } catch (e: Exception) {
        null
    }
}

class SimpleParser(val input: String) {
    private var pos = 0

    fun parse(): Double {
        if (input.isEmpty()) return 0.0
        val res = parseExpression()
        if (pos < input.length) {
            throw IllegalArgumentException("Unexpected character: " + input[pos])
        }
        return res
    }

    private fun parseExpression(): Double {
        var x = parseTerm()
        while (true) {
            when {
                eat('+') -> x += parseTerm()
                eat('-') -> x -= parseTerm()
                else -> return x
            }
        }
    }

    private fun parseTerm(): Double {
        var x = parseFactor()
        while (true) {
            when {
                eat('*') -> x *= parseFactor()
                eat('/') -> {
                    val factor = parseFactor()
                    if (factor == 0.0) throw ArithmeticException("Division by zero")
                    x /= factor
                }
                else -> return x
            }
        }
    }

    private fun parseFactor(): Double {
        if (eat('+')) return parseFactor() // unary plus
        if (eat('-')) return -parseFactor() // unary minus

        val startPos = this.pos
        if (eat('(')) { // parentheses
            val x = parseExpression()
            eat(')')
            return x
        }

        // Parse number
        while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) {
            pos++
        }
        val sub = input.substring(startPos, pos)
        if (sub.isEmpty()) return 0.0
        return sub.toDouble()
    }

    private fun eat(charToEat: Char): Boolean {
        while (pos < input.length && input[pos] == ' ') pos++
        if (pos < input.length && input[pos] == charToEat) {
            pos++
            return true
        }
        return false
    }
}

@Composable
fun CalculatorDialog(
    initialValue: String,
    idioma: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var expression by remember { mutableStateOf(if (initialValue.toDoubleOrNull() != null) initialValue else "") }
    var resultText by remember { mutableStateOf("") }

    // Auto-evaluate expression on change
    LaunchedEffect(expression) {
        if (expression.isBlank()) {
            resultText = ""
        } else {
            // Find if there is any arithmetic operator
            val hasOperator = expression.any { it == '+' || it == '-' || it == '*' || it == '/' }
            if (hasOperator) {
                val evaluated = evaluateExpression(expression)
                if (evaluated != null) {
                    resultText = String.format(java.util.Locale.US, "%.2f", evaluated).replace(Regex("\\.00$"), "")
                } else {
                    resultText = ""
                }
            } else {
                resultText = ""
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val finalVal = if (resultText.isNotEmpty() && resultText != "Error") resultText else {
                        val evaluated = evaluateExpression(expression)
                        if (evaluated != null) {
                            String.format(java.util.Locale.US, "%.2f", evaluated).replace(Regex("\\.00$"), "")
                        } else {
                            expression
                        }
                    }
                    onConfirm(finalVal)
                },
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (idioma == "PT") "Confirmar" else "Confirm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Cancelar" else "Cancel")
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Calculate,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = if (idioma == "PT") "Calculadora Básica" else "Basic Calculator",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Screen/Display
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.End
                    ) {
                        // Expression
                        Text(
                            text = expression.ifEmpty { "0" },
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        // Live Result
                        Text(
                            text = if (resultText.isNotEmpty()) "= $resultText" else "",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1
                        )
                    }
                }

                // Keyboard Grid
                val buttonRows = listOf(
                    listOf("7", "8", "9", "/"),
                    listOf("4", "5", "6", "*"),
                    listOf("1", "2", "3", "-"),
                    listOf("0", ".", "+", "C"),
                    listOf("⌫", "=")
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    buttonRows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { char ->
                                val isOperator = char in listOf("+", "-", "*", "/", "=")
                                val isClear = char == "C" || char == "⌫"
                                val weight = if (char == "=") 3f else 1f
                                
                                Button(
                                    onClick = {
                                        when (char) {
                                            "C" -> {
                                                expression = ""
                                                resultText = ""
                                            }
                                            "⌫" -> {
                                                if (expression.isNotEmpty()) {
                                                    expression = expression.substring(0, expression.length - 1)
                                                }
                                            }
                                            "=" -> {
                                                val evaluated = evaluateExpression(expression)
                                                if (evaluated != null) {
                                                    expression = String.format(java.util.Locale.US, "%.2f", evaluated).replace(Regex("\\.00$"), "")
                                                    resultText = ""
                                                } else {
                                                    resultText = "Error"
                                                }
                                            }
                                            else -> {
                                                // Append safely
                                                if (char in listOf("+", "-", "*", "/")) {
                                                    // Avoid double operators
                                                    if (expression.isNotEmpty() && expression.last() in listOf('+', '-', '*', '/')) {
                                                        expression = expression.dropLast(1) + char
                                                    } else {
                                                        expression += char
                                                    }
                                                } else {
                                                    expression += char
                                                }
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(weight).height(44.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = when {
                                            isClear -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f)
                                            isOperator -> MaterialTheme.colorScheme.primaryContainer
                                            else -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                                        },
                                        contentColor = when {
                                            isClear -> MaterialTheme.colorScheme.onErrorContainer
                                            isOperator -> MaterialTheme.colorScheme.onPrimaryContainer
                                            else -> MaterialTheme.colorScheme.onSecondaryContainer
                                        }
                                    ),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = char,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}

// ------------------- NOTIFICATION CENTRAL SHEET -------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationCentralSheet(
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
    onNavigate: ((String) -> Unit)? = null
) {
    val settings by viewModel.userSettings.collectAsStateWithLifecycle(UserSettings())
    val idioma = settings?.idioma ?: "PT"
    val creditCards by viewModel.creditCards.collectAsStateWithLifecycle(emptyList())
    val loans by viewModel.groupedLoans.collectAsStateWithLifecycle(emptyList())
    val subscriptions by viewModel.subscriptions.collectAsStateWithLifecycle(emptyList())
    val spendingLimits by viewModel.spendingLimits.collectAsStateWithLifecycle(emptyList())
    val categories by viewModel.categories.collectAsStateWithLifecycle(emptyList())
    val transactions by viewModel.filteredTransactions.collectAsStateWithLifecycle(emptyList())

    var selectedTab by remember { mutableStateOf("TODAS") } // "TODAS", "VENCIMENTOS", "ORCAMENTOS", "SISTEMA"

    data class NotificationItem(
        val id: String,
        val titulo: String,
        val descricao: String,
        val valor: Double?,
        val dataStr: String,
        val tipo: String, // "VENCIMENTO", "ORCAMENTO", "SISTEMA"
        val urgencia: String, // "URGENTE", "ATENCAO", "INFO"
        val acaoTexto: String?,
        val destinationScreen: String? = null,
        val onAcao: (() -> Unit)? = null
    )

    val notifications = remember(creditCards, loans, subscriptions, spendingLimits, categories, transactions, idioma) {
        val list = mutableListOf<NotificationItem>()
        val cal = Calendar.getInstance()
        val currentDay = cal.get(Calendar.DAY_OF_MONTH)

        // 1. Credit Card Notifications
        creditCards.filter { it.ativa }.forEach { card ->
            val faturaAtual = card.limiteTotal - card.limiteDisponivel
            if (faturaAtual > 0) {
                val diasParaVencimento = calculateDaysUntilDayOfMonth(card.diaVencimento)
                val statusStr = when {
                    diasParaVencimento in 0..3 -> if (idioma == "PT") "Vence em $diasParaVencimento dia(s)!" else "Due in $diasParaVencimento day(s)!"
                    diasParaVencimento < 0 -> if (idioma == "PT") "Fatura Vencida!" else "Overdue Invoice!"
                    else -> if (idioma == "PT") "Vence no dia ${card.diaVencimento}" else "Due on day ${card.diaVencimento}"
                }
                list.add(
                    NotificationItem(
                        id = "card_${card.id}",
                        titulo = if (idioma == "PT") "Fatura: ${card.nome}" else "Invoice: ${card.nome}",
                        descricao = "$statusStr (${card.tipo} •••• ${card.ultimos4Digitos})",
                        valor = faturaAtual,
                        dataStr = "Dia ${card.diaVencimento}",
                        tipo = "VENCIMENTO",
                        urgencia = if (diasParaVencimento <= 3) "URGENTE" else "ATENCAO",
                        acaoTexto = if (idioma == "PT") "Pagar Fatura" else "Pay Invoice",
                        destinationScreen = "contas"
                    )
                )
            }
        }

        // 2. Loans Notifications
        loans.filter { it.loan.status == "PENDING" }.forEach { gLoan ->
            val l = gLoan.loan
            val now = System.currentTimeMillis()
            val diffDays = ((l.dueDate - now) / (1000 * 60 * 60 * 24)).toInt()
            if (diffDays <= 7) {
                list.add(
                    NotificationItem(
                        id = "loan_${l.id}",
                        titulo = if (idioma == "PT") "Empréstimo: ${l.counterparty}" else "Loan: ${l.counterparty}",
                        descricao = if (diffDays < 0) {
                            if (idioma == "PT") "Pagamento em atraso há ${-diffDays} dias!" else "Overdue by ${-diffDays} days!"
                        } else {
                            if (idioma == "PT") "Vencimento em $diffDays dias" else "Due in $diffDays days"
                        },
                        valor = l.principalAmount,
                        dataStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(l.dueDate)),
                        tipo = "VENCIMENTO",
                        urgencia = if (diffDays <= 2) "URGENTE" else "ATENCAO",
                        acaoTexto = if (idioma == "PT") "Ver Detalhes" else "View Details",
                        destinationScreen = "relatorios"
                    )
                )
            }
        }

        // 3. Subscriptions Notifications
        subscriptions.filter { it.ativa }.forEach { sub ->
            val daysDiff = calculateDaysUntilDayOfMonth(sub.diaCobranca)
            if (daysDiff in 0..5) {
                list.add(
                    NotificationItem(
                        id = "sub_${sub.id}",
                        titulo = if (idioma == "PT") "Assinatura: ${sub.nome}" else "Subscription: ${sub.nome}",
                        descricao = if (idioma == "PT") "Cobrança automática no dia ${sub.diaCobranca}" else "Auto-charge on day ${sub.diaCobranca}",
                        valor = sub.valor,
                        dataStr = "Dia ${sub.diaCobranca}",
                        tipo = "VENCIMENTO",
                        urgencia = "INFO",
                        acaoTexto = if (idioma == "PT") "Ver Assinaturas" else "View Subscriptions",
                        destinationScreen = "contas"
                    )
                )
            }
        }

        // 4. Budget / Spending Limits Notifications
        val catsMap = categories.associateBy { it.id }
        val limitCheckMonthStart = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.DAY_OF_MONTH, 1)
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
        }.timeInMillis
        spendingLimits.forEach { limit ->
            val categoryName = catsMap[limit.categoryId]?.nome ?: "Geral"
            val spent = transactions.filter { it.categoriaId == limit.categoryId && it.isDespesa() && it.data >= limitCheckMonthStart }.sumOf { it.valor }
            val pct = if (limit.monthlyLimit > 0) (spent / limit.monthlyLimit) * 100 else 0.0
            if (pct >= 80.0) {
                list.add(
                    NotificationItem(
                        id = "limit_${limit.id}",
                        titulo = if (idioma == "PT") "Limite de Categoria: $categoryName" else "Category Limit: $categoryName",
                        descricao = if (pct >= 100.0) {
                            if (idioma == "PT") "Orçamento excedido (${String.format("%.0f", pct)}%)!" else "Budget exceeded (${String.format("%.0f", pct)}%)!"
                        } else {
                            if (idioma == "PT") "Atingiu ${String.format("%.0f", pct)}% do limite definido" else "Reached ${String.format("%.0f", pct)}% of set budget"
                        },
                        valor = spent,
                        dataStr = "Este Mês",
                        tipo = "ORCAMENTO",
                        urgencia = if (pct >= 100.0) "URGENTE" else "ATENCAO",
                        acaoTexto = if (idioma == "PT") "Ajustar Limite" else "Adjust Limit",
                        destinationScreen = "contas"
                    )
                )
            }
        }

        // 5. System General Notifications
        list.add(
            NotificationItem(
                id = "sys_backup",
                titulo = if (idioma == "PT") "Backup Automático Activo" else "Auto Backup Active",
                descricao = if (idioma == "PT") "Os seus dados estão protegidos localmente com encriptação AES." else "Your financial records are locally secured with AES encryption.",
                valor = null,
                dataStr = "Hoje",
                tipo = "SISTEMA",
                urgencia = "INFO",
                acaoTexto = if (idioma == "PT") "Ver Dashboard" else "View Dashboard",
                destinationScreen = "dashboard"
            )
        )

        list
    }

    val filteredNotifications = remember(notifications, selectedTab) {
        when (selectedTab) {
            "VENCIMENTOS" -> notifications.filter { it.tipo == "VENCIMENTO" }
            "ORCAMENTOS" -> notifications.filter { it.tipo == "ORCAMENTO" }
            "SISTEMA" -> notifications.filter { it.tipo == "SISTEMA" }
            else -> notifications
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E676).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.NotificationsActive,
                            contentDescription = null,
                            tint = Color(0xFF00E676)
                        )
                    }
                    Column {
                        Text(
                            text = if (idioma == "PT") "Central de Notificações" else "Notification Hub",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (idioma == "PT") "${notifications.size} alertas e lembretes activos" else "${notifications.size} active alerts & reminders",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Fechar")
                }
            }

            // Filter Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val tabs = listOf(
                    "TODAS" to (if (idioma == "PT") "Todas" else "All"),
                    "VENCIMENTOS" to (if (idioma == "PT") "Vencimentos" else "Due Dates"),
                    "ORCAMENTOS" to (if (idioma == "PT") "Orçamentos" else "Budgets"),
                    "SISTEMA" to (if (idioma == "PT") "Sistema" else "System")
                )
                tabs.forEach { (key, label) ->
                    val isSel = selectedTab == key
                    FilterChip(
                        selected = isSel,
                        onClick = { selectedTab = key },
                        label = { Text(label, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF00E676).copy(alpha = 0.2f),
                            selectedLabelColor = Color(0xFF00E676)
                        )
                    )
                }
            }

            // List of Notifications
            if (filteredNotifications.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (idioma == "PT") "Nenhuma notificação nesta categoria." else "No notifications in this category.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredNotifications, key = { it.id }) { item ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    item.destinationScreen?.let { dest ->
                                        onDismiss()
                                        onNavigate?.invoke(dest)
                                    }
                                },
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = BorderStroke(
                                width = 1.dp,
                                color = when (item.urgencia) {
                                    "URGENTE" -> Color(0xFFFF5252).copy(alpha = 0.4f)
                                    "ATENCAO" -> Color(0xFFFFB74D).copy(alpha = 0.4f)
                                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (item.urgencia) {
                                                "URGENTE" -> Color(0xFFFF5252).copy(alpha = 0.15f)
                                                "ATENCAO" -> Color(0xFFFFB74D).copy(alpha = 0.15f)
                                                else -> Color(0xFF1A73E8).copy(alpha = 0.15f)
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = when (item.tipo) {
                                            "VENCIMENTO" -> Icons.Outlined.CreditCard
                                            "ORCAMENTO" -> Icons.Outlined.PieChart
                                            else -> Icons.Outlined.Info
                                        },
                                        contentDescription = null,
                                        tint = when (item.urgencia) {
                                            "URGENTE" -> Color(0xFFFF5252)
                                            "ATENCAO" -> Color(0xFFFFB74D)
                                            else -> Color(0xFF1A73E8)
                                        }
                                    )
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.titulo,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = item.dataStr,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = item.descricao,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (item.valor != null) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${String.format("%,.2f", item.valor)} ${settings?.moedaPadrao ?: "MZN"}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFF00E676)
                                        )
                                    }
                                }

                                if (item.acaoTexto != null) {
                                    TextButton(
                                        onClick = {
                                            item.destinationScreen?.let { dest ->
                                                onDismiss()
                                                onNavigate?.invoke(dest)
                                            }
                                        }
                                    ) {
                                        Text(
                                            text = item.acaoTexto,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF00E676)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
