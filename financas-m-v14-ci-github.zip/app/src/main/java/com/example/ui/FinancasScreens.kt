@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*

import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

import androidx.compose.foundation.ExperimentalFoundationApi

typealias Transaction = com.example.data.model.FinancialTransaction

fun calculateDaysUntilDayOfMonth(targetDay: Int): Int {
    val today = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0)
        set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }

    val targetDate = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0)
        set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)

        val maxDayCurrentMonth = getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
        set(java.util.Calendar.DAY_OF_MONTH, targetDay.coerceAtMost(maxDayCurrentMonth))

        if (before(today)) {
            add(java.util.Calendar.MONTH, 1)
            val maxDayNextMonth = getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
            set(java.util.Calendar.DAY_OF_MONTH, targetDay.coerceAtMost(maxDayNextMonth))
        }
    }

    val diffMillis = targetDate.timeInMillis - today.timeInMillis
    return (diffMillis / (1000 * 60 * 60 * 24)).toInt()
}

fun sanitizeDoubleInput(oldValue: String, newValue: String): String {
    if (newValue.length <= oldValue.length) return newValue
    
    var prefixLen = 0
    while (prefixLen < oldValue.length && prefixLen < newValue.length && oldValue[prefixLen] == newValue[prefixLen]) {
        prefixLen++
    }
    
    var suffixLen = 0
    while (suffixLen < (oldValue.length - prefixLen) && suffixLen < (newValue.length - prefixLen) && 
           oldValue[oldValue.length - 1 - suffixLen] == newValue[newValue.length - 1 - suffixLen]) {
        suffixLen++
    }
    
    val inserted = newValue.substring(prefixLen, newValue.length - suffixLen)
    if (inserted.length == 2 && inserted[0] == inserted[1]) {
        val sanitizedInserted = inserted.substring(0, 1)
        return newValue.substring(0, prefixLen) + sanitizedInserted + newValue.substring(newValue.length - suffixLen)
    }
    
    return newValue
}

fun saveBitmapToCache(context: android.content.Context, bitmap: android.graphics.Bitmap): android.net.Uri {
    val file = java.io.File(context.cacheDir, "loan_receipt_${System.currentTimeMillis()}.jpg")
    java.io.FileOutputStream(file).use { out ->
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, out)
    }
    return android.net.Uri.fromFile(file)
}

object Translator {
    private val translations = mapOf(
        "PT" to mapOf(
            "dashboard" to "Inicial",
            "history" to "Historial",
            "accounts" to "Contas",
            "goals" to "Metas",
            "reports" to "Relatórios",
            "settings" to "Config.",
            "total_balance" to "Saldo Geral Disponível",
            "survival_forecast" to "Previsão de Sobrevivência",
            "month_incomes" to "Injeções Mês",
            "month_expenses" to "Despesas Mês",
            "categories_donut" to "Despesas por Categoria (30 dias)",
            "balance_line" to "Histórico do Saldo (Últimos 10 Dias)",
            "add_entry" to "Adicionar Lançamento",
            "new_income" to "Nova Receita",
            "new_expense" to "Nova Despesa",
            "new_transfer" to "Nova Transferência",
            "save" to "Guardar",
            "cancel" to "Cancelar",
            "delete" to "Eliminar",
            "edit" to "Editar",
            "confirm_delete" to "Deseja realmente eliminar?",
            "confirm" to "Confirmar",
            "daily_closing" to "Reconciliação Diária",
            "expected" to "Esperado",
            "actual" to "Real",
            "difference" to "Diferença",
            "currency" to "Moeda",
            "wallet" to "Carteira",
            "category" to "Categoria",
            "value" to "Valor",
            "description" to "Descrição",
            "date" to "Data",
            "limits" to "Limites de Gastos",
            "limit_remaining" to "restantes de limite",
            "limit_exceeded" to "Limite ultrapassado por",
            "loans" to "Empréstimos (Crédito / Débito)",
            "credit" to "Crédito (A Receber)",
            "debit" to "Débito (A Pagar)",
            "counterparty" to "Contraparte",
            "interest_rate" to "Taxa de Juros (%)",
            "penalty" to "Multa por Atraso (%)",
            "installments" to "Prestações",
            "due_date" to "Data de Vencimento",
            "total_due" to "Total Devido",
            "total_paid" to "Total Pago",
            "make_payment" to "Efectuar Pagamento",
            "biometrics" to "Autenticação Biométrica",
            "backup_encrypted" to "Cópia de Segurança Encriptada",
            "password" to "Palavra-passe (PIN)",
            "greeting" to "Olá",
            "close" to "Fechar",
            "close_app" to "Sair",
            "back" to "Voltar",
            "search" to "Pesquisar",
            "filter" to "Filtrar",
            "options" to "Opções",
            "export" to "Exportar",
            "share" to "Partilhar",
            "download" to "Baixar"
        ),
        "EN" to mapOf(
            "dashboard" to "Home",
            "history" to "History",
            "accounts" to "Accounts",
            "goals" to "Goals",
            "reports" to "Reports",
            "settings" to "Settings",
            "total_balance" to "Total Available Balance",
            "survival_forecast" to "Survival Forecast",
            "month_incomes" to "Month Incomes",
            "month_expenses" to "Month Expenses",
            "categories_donut" to "Expenses by Category (30 days)",
            "balance_line" to "Balance History (Last 10 Days)",
            "add_entry" to "Add Transaction",
            "new_income" to "New Income",
            "new_expense" to "New Expense",
            "new_transfer" to "New Transfer",
            "save" to "Save",
            "cancel" to "Cancel",
            "delete" to "Delete",
            "edit" to "Edit",
            "confirm_delete" to "Do you really want to delete?",
            "confirm" to "Confirm",
            "daily_closing" to "Daily Reconciliation",
            "expected" to "Expected",
            "actual" to "Actual",
            "difference" to "Difference",
            "currency" to "Currency",
            "wallet" to "Wallet",
            "category" to "Category",
            "value" to "Value",
            "description" to "Description",
            "date" to "Date",
            "limits" to "Spending Limits",
            "limit_remaining" to "remaining of limit",
            "limit_exceeded" to "Limit exceeded by",
            "loans" to "Loans (Credit / Debit)",
            "credit" to "Credit (To Receive)",
            "debit" to "Debit (To Pay)",
            "counterparty" to "Counterparty",
            "interest_rate" to "Interest Rate (%)",
            "penalty" to "Late Penalty (%)",
            "installments" to "Installments",
            "due_date" to "Due Date",
            "total_due" to "Total Due",
            "total_paid" to "Total Paid",
            "make_payment" to "Make Payment",
            "biometrics" to "Biometric Authentication",
            "backup_encrypted" to "Encrypted Backup",
            "password" to "Password (PIN)",
            "greeting" to "Hello",
            "close" to "Close",
            "close_app" to "Exit App",
            "back" to "Back",
            "search" to "Search",
            "filter" to "Filter",
            "options" to "Options",
            "export" to "Export",
            "share" to "Share",
            "download" to "Download"
        )
    )

    fun t(key: String, idioma: String): String {
        val ptMap = translations["PT"] ?: emptyMap()
        val langMap = translations[idioma.uppercase()] ?: ptMap
        return langMap[key] ?: ptMap[key] ?: key
    }

    fun getLocalizedCategoryName(categoryName: String, idioma: String): String {
        if (categoryName.isBlank()) return categoryName
        if (categoryName.contains(" / ")) {
            val parts = categoryName.split(" / ")
            return if (idioma == "PT") parts.firstOrNull()?.trim() ?: categoryName else parts.lastOrNull()?.trim() ?: categoryName
        }
        val norm = categoryName.lowercase().trim()
        return when {
            norm.contains("alimenta") || norm.contains("comida") || norm.contains("food") || norm.contains("restaur") -> {
                if (idioma == "PT") "Alimentação" else "Food & Dining"
            }
            norm.contains("transp") || norm.contains("veícul") || norm.contains("carro") -> {
                if (idioma == "PT") "Transporte" else "Transport"
            }
            norm.contains("habi") || norm.contains("casa") || norm.contains("morad") || norm.contains("hous") -> {
                if (idioma == "PT") "Habitação" else "Housing"
            }
            norm.contains("lazer") || norm.contains("cultura") || norm.contains("entreten") -> {
                if (idioma == "PT") "Lazer & Cultura" else "Entertainment"
            }
            norm.contains("saú") || norm.contains("farmá") || norm.contains("health") -> {
                if (idioma == "PT") "Saúde & Farmácia" else "Health & Pharmacy"
            }
            norm.contains("ajust") || norm.contains("taxa") || norm.contains("fee") -> {
                if (idioma == "PT") "Ajustes" else "Adjustments"
            }
            norm.contains("salár") || norm.contains("salar") || norm.contains("renda") || norm.contains("incom") -> {
                if (idioma == "PT") "Salário & Renda" else "Salary & Income"
            }
            norm.contains("negóc") || norm.contains("venda") || norm.contains("busin") -> {
                if (idioma == "PT") "Negócios & Vendas" else "Business & Sales"
            }
            norm.contains("invest") -> {
                if (idioma == "PT") "Investimentos" else "Investments"
            }
            norm.contains("educa") || norm.contains("curso") -> {
                if (idioma == "PT") "Educação" else "Education"
            }
            norm.contains("vestu") || norm.contains("moda") || norm.contains("cloth") -> {
                if (idioma == "PT") "Vestuário" else "Clothing"
            }
            norm.contains("mercado") || norm.contains("compra") || norm.contains("grocer") -> {
                if (idioma == "PT") "Mercado & Compras" else "Groceries & Shopping"
            }
            norm.contains("serviç") || norm.contains("utilit") || norm.contains("util") -> {
                if (idioma == "PT") "Serviços & Utilitários" else "Utilities"
            }
            norm.contains("present") || norm.contains("gift") -> {
                if (idioma == "PT") "Presentes" else "Gifts"
            }
            norm.contains("animai") || norm.contains("pet") -> {
                if (idioma == "PT") "Animais de Estimação" else "Pets"
            }
            norm.contains("viag") || norm.contains("turis") || norm.contains("travel") -> {
                if (idioma == "PT") "Viagens & Turismo" else "Travel"
            }
            norm.contains("desport") || norm.contains("esport") || norm.contains("fitn") || norm.contains("sport") -> {
                if (idioma == "PT") "Desporto & Fitness" else "Sports & Fitness"
            }
            norm.contains("empréstim") || norm.contains("loan") || norm.contains("crédito / débito") -> {
                if (idioma == "PT") "Empréstimos" else "Loans"
            }
            else -> categoryName
        }
    }
}

// --- Apple-Style Animation Utilities ---
fun Modifier.bounceClick() = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(isPressed) {
        if (isPressed) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "bounce_click_scale"
    )
    this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

fun Modifier.shimmerEffect(): Modifier = composed {
    val isDark = isSystemInDarkTheme()
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmer_translation"
    )

    val shimmerColors = if (isDark) {
        listOf(
            Color(0xFF242424),
            Color(0xFF383838),
            Color(0xFF242424)
        )
    } else {
        listOf(
            Color(0xFFE0E0E0),
            Color(0xFFF5F5F5),
            Color(0xFFE0E0E0)
        )
    }

    this.background(
        brush = Brush.linearGradient(
            colors = shimmerColors,
            start = Offset.Zero,
            end = Offset(x = translateAnim, y = translateAnim)
        )
    )
}

@Composable
fun StaggeredEntrance(
    index: Int,
    content: @Composable () -> Unit
) {
    var visible by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(index * 60L)
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(
            initialOffsetY = { 40 },
            animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioNoBouncy)
        ) + fadeIn(animationSpec = tween(150)),
        exit = fadeOut()
    ) {
        content()
    }
}

@Composable
fun rememberStaggeredTransition(index: Int, delayMs: Int = 40): State<Float> {
    val state = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay((index * delayMs).toLong())
        state.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMedium
            )
        )
    }
    return state.asState()
}

@Composable
fun SplashScreen(settings: UserSettings) {
    val isDark = settings.tema == "dark"
    val themeColor = try {
        Color(android.graphics.Color.parseColor(settings.corPrimaria.ifEmpty { "#6D4AFF" }))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDark) Color(0xFF0F121F) else Color(0xFFF8FAFC)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(themeColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.AccountBalanceWallet,
                    contentDescription = null,
                    tint = themeColor,
                    modifier = Modifier.size(48.dp)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Finanças M",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isDark) Color.White else Color(0xFF1E293B),
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (settings.idioma == "PT") "Gestão Financeira Pessoal" else "Personal Financial Management",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            CircularProgressIndicator(
                color = themeColor,
                strokeWidth = 3.dp,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContainer(viewModel: MainViewModel) {
    val settings by viewModel.userSettings.collectAsStateWithLifecycle()
    val wallets by viewModel.wallets.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val transactions by viewModel.filteredTransactions.collectAsStateWithLifecycle()
    val rawTransactions by viewModel.transactions.collectAsStateWithLifecycle()
    val closures by viewModel.closures.collectAsStateWithLifecycle()
    val goals by viewModel.goals.collectAsStateWithLifecycle()
    val trashItems by viewModel.trashItems.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val alertMessage by viewModel.alertMessage.collectAsStateWithLifecycle()
    val showDailyClosurePrompt by viewModel.showDailyClosurePrompt.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(viewModel.snackbarMessage) {
        viewModel.snackbarMessage.collect { request ->
            scope.launch {
                val result = snackbarHostState.showSnackbar(
                    message = request.message,
                    actionLabel = request.actionLabel,
                    duration = if (request.actionLabel != null) SnackbarDuration.Long else SnackbarDuration.Short
                )
                if (result == SnackbarResult.ActionPerformed) {
                    request.onAction?.invoke()
                }
            }
        }
    }

    val navStack = remember { mutableStateListOf("dashboard") }
    val currentScreen = navStack.lastOrNull() ?: "dashboard"
    var relatoriosInitialTab by remember { mutableIntStateOf(0) }

    val activity = context as? android.app.Activity
    LaunchedEffect(activity?.intent) {
        val target = activity?.intent?.getStringExtra("navigate_to")
        if (!target.isNullOrBlank()) {
            val destination = when (target) {
                "emprestimos", "loans" -> "loans"
                "shopping", "shopping_list" -> "shopping_list"
                "categories" -> "contas"
                else -> target
            }
            if (navStack.lastOrNull() != destination) {
                navStack.clear()
                navStack.add("dashboard")
                if (destination != "dashboard") navStack.add(destination)
            }
        }
    }

    fun navigateTo(screen: String) {
        var dest = screen
        if (screen.startsWith("relatorios")) {
            val parts = screen.split(":", "_", "?tab=")
            if (parts.size > 1) {
                val sub = parts[1].lowercase()
                relatoriosInitialTab = when (sub) {
                    "saude", "1" -> 1
                    "recorrentes", "2" -> 2
                    else -> 0
                }
            } else {
                relatoriosInitialTab = 0
            }
            dest = "relatorios"
        }
        val mainTabs = listOf("dashboard", "lancamentos", "contas", "metas", "relatorios")
        if (dest in mainTabs) {
            if (navStack.lastOrNull() != dest) {
                navStack.clear()
                navStack.add(dest)
            }
        } else {
            if (navStack.lastOrNull() != dest) {
                navStack.add(dest)
            }
        }
    }

    fun navigateBack() {
        if (navStack.size > 1) {
            navStack.removeAt(navStack.lastIndex)
        } else {
            if (navStack.firstOrNull() != "dashboard") {
                navStack.clear()
                navStack.add("dashboard")
            }
        }
    }

    BackHandler(enabled = navStack.size > 1) {
        navigateBack()
    }

    var selectedTransactionToEdit by remember { mutableStateOf<Transaction?>(null) }
    var selectedLoanForDetails by remember { mutableStateOf<Loan?>(null) }
    var addTransactionIsExpense by remember { mutableStateOf(true) }
    var addTransactionIsRecorrente by remember { mutableStateOf(false) }
    var addTransactionInitialType by remember { mutableStateOf("DESPESA") }
    val saveableStateHolder = androidx.compose.runtime.saveable.rememberSaveableStateHolder()

    val dashboardScrollState = rememberScrollState()
    val lancamentosLazyListState = rememberLazyListState()
    val contasLazyListState = rememberLazyListState()
    val metasLazyListState = rememberLazyListState()

    var isInitializing by remember { mutableStateOf(true) }
    var loadingTimedOut by remember { mutableStateOf(false) }

    LaunchedEffect(settings, wallets) {
        if (isInitializing) {
            val result = kotlinx.coroutines.withTimeoutOrNull(3000L) {
                while (settings == null) {
                    kotlinx.coroutines.delay(50)
                }
                true
            }
            if (result != true) {
                loadingTimedOut = true
            }
            isInitializing = false
        }
    }

    val idioma = settings?.idioma ?: "PT"

    LaunchedEffect(loadingTimedOut) {
        if (loadingTimedOut) {
            val msg = if (idioma == "PT") "Tempo limite de carregamento atingido." else "Loading timeout reached."
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
        }
    }

    // Handle Toast alerts from VM
    LaunchedEffect(alertMessage) {
        alertMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.alertMessage.value = null
        }
    }

    // App PIN Lock Simulator - Read theme_prefs synchronously to avoid first-frame leak/flicker
    val sharedPrefs = remember(context) { context.getSharedPreferences("theme_prefs", android.content.Context.MODE_PRIVATE) }
    val initialHasPin = remember { sharedPrefs.getBoolean("has_pin", false) }
    var isAppLocked by remember { mutableStateOf(initialHasPin) }
    var pinInput by remember { mutableStateOf("") }
    val autoLockMins by viewModel.autoLockTimeoutMins.collectAsState()
    var triggerBiometricsCount by remember { mutableStateOf(0) }
    var usePinOption by remember { mutableStateOf(false) }
    
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var lastOnStopTimestamp by remember { mutableStateOf(0L) }
    
    DisposableEffect(lifecycleOwner, settings, autoLockMins) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) {
                lastOnStopTimestamp = System.currentTimeMillis()
            } else if (event == androidx.lifecycle.Lifecycle.Event.ON_START) {
                if (settings?.pinHash?.isNotEmpty() == true) {
                    if (autoLockMins == 0) {
                        isAppLocked = true
                    } else if (lastOnStopTimestamp > 0L) {
                        val elapsedMins = (System.currentTimeMillis() - lastOnStopTimestamp) / (60L * 1000L)
                        if (elapsedMins >= autoLockMins) {
                            isAppLocked = true
                        }
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
    
    LaunchedEffect(isAppLocked, settings) {
        if (settings != null) {
            val hasPin = settings!!.pinHash.isNotEmpty()
            sharedPrefs.edit().putBoolean("has_pin", hasPin).apply()
            if (!hasPin) {
                isAppLocked = false
            }
        }
        if (isAppLocked) {
            pinInput = ""
            if (settings?.biometricsEnabled == true) {
                usePinOption = false
            } else {
                usePinOption = true
            }
        }
    }

    val fragmentActivity = remember(context) {
        var ctx = context
        while (ctx is android.content.ContextWrapper) {
            if (ctx is androidx.fragment.app.FragmentActivity) {
                break
            }
            ctx = ctx.baseContext
        }
        ctx as? androidx.fragment.app.FragmentActivity
    }
    LaunchedEffect(isAppLocked, settings, isInitializing, triggerBiometricsCount, usePinOption) {
        if (!isInitializing && isAppLocked && !usePinOption && settings?.biometricsEnabled == true && fragmentActivity != null) {
            try {
                // Ensure activity is in a valid state and not finishing/destroyed
                if (fragmentActivity.isFinishing || fragmentActivity.isDestroyed) {
                    return@LaunchedEffect
                }

                // Ensure activity lifecycle is at least STARTED
                if (!fragmentActivity.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) {
                    kotlinx.coroutines.delay(500)
                }
                if (fragmentActivity.isFinishing || fragmentActivity.isDestroyed) {
                    return@LaunchedEffect
                }

                // Check biometric hardware availability with BiometricManager
                val biometricManager = androidx.biometric.BiometricManager.from(fragmentActivity)
                val canAuthenticate = biometricManager.canAuthenticate(
                    androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
                )

                if (canAuthenticate == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS) {
                    val executor = androidx.core.content.ContextCompat.getMainExecutor(fragmentActivity)
                    val biometricPrompt = androidx.biometric.BiometricPrompt(
                        fragmentActivity,
                        executor,
                        object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                            override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) {
                                super.onAuthenticationSucceeded(result)
                                isAppLocked = false
                            }
                            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                                super.onAuthenticationError(errorCode, errString)
                            }
                        }
                    )
                    val promptInfo = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                        .setTitle("Finanças")
                        .setSubtitle(Translator.t("biometrics", idioma))
                        .setNegativeButtonText(Translator.t("cancel", idioma))
                        .build()
                    biometricPrompt.authenticate(promptInfo)
                } else {
                    android.util.Log.d("Biometrics", "Biometrics not available or not enrolled: $canAuthenticate. Falling back to PIN.")
                }
            } catch (t: Throwable) {
                // Safe fallback to PIN
                android.util.Log.e("Biometrics", "Failed to authenticate biometrics", t)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isInitializing) {
            val themeColor = try {
                Color(android.graphics.Color.parseColor(settings?.corPrimaria ?: "#1A73E8"))
            } catch (e: Exception) {
                MaterialTheme.colorScheme.primary
            }

            val isDark = settings?.tema == "dark"

            Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier
                        .height(80.dp)
                        .testTag("bottom_nav_bar"),
                    containerColor = if (isDark) Color(0xFF141B2D) else Color(0xFFFFFFFF),
                    tonalElevation = 0.dp
                ) {
                    val items = listOf(
                        Triple("dashboard", Icons.Rounded.Home to Icons.Outlined.Home, "dashboard"),
                        Triple("lancamentos", Icons.Rounded.History to Icons.Outlined.History, "history"),
                        Triple("contas", Icons.Rounded.Wallet to Icons.Outlined.Wallet, "accounts"),
                        Triple("metas", Icons.Rounded.TrackChanges to Icons.Outlined.TrackChanges, "goals"),
                        Triple("relatorios", Icons.Rounded.BarChart to Icons.Outlined.BarChart, "reports")
                    )

                    items.forEach { (screen, icons, translationKey) ->
                        val isSelected = currentScreen == screen
                        val icon = if (isSelected) icons.first else icons.second
                        
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { 
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                navigateTo(screen) 
                            },
                            icon = { 
                                Icon(
                                    imageVector = icon, 
                                    contentDescription = screen,
                                    tint = if (isSelected) themeColor else (if (isDark) Color(0xFF98A2B3) else Color(0xFF64748B)),
                                    modifier = Modifier.size(20.dp)
                                ) 
                            },
                            label = { 
                                Text(
                                    text = Translator.t(translationKey, idioma),
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                    color = if (isSelected) themeColor else (if (isDark) Color(0xFF98A2B3) else Color(0xFF64748B)),
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                ) 
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = themeColor,
                                selectedTextColor = themeColor,
                                unselectedIconColor = if (isDark) Color(0xFF98A2B3) else Color(0xFF64748B),
                                unselectedTextColor = if (isDark) Color(0xFF98A2B3) else Color(0xFF64748B),
                                indicatorColor = themeColor.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_$screen")
                        )
                    }
                }
            }
        ) { paddingValues ->
            val mainScreens = remember { listOf("dashboard", "lancamentos", "contas", "metas", "relatorios") }
            var accumulatedDrag by remember(currentScreen) { mutableStateOf(0f) }

            Box(
                modifier = Modifier
                    .padding(paddingValues)
                    .pointerInput(currentScreen) {
                        if (currentScreen in mainScreens) {
                            detectHorizontalDragGestures(
                                onDragStart = { accumulatedDrag = 0f },
                                onDragEnd = {
                                    val threshold = 180f
                                    if (Math.abs(accumulatedDrag) > threshold) {
                                        val currentIndex = mainScreens.indexOf(currentScreen)
                                        var switched = false
                                        if (accumulatedDrag < 0) { // Swiped left -> Next Screen
                                            if (currentIndex < mainScreens.lastIndex) {
                                                navigateTo(mainScreens[currentIndex + 1])
                                                switched = true
                                            }
                                        } else { // Swiped right -> Previous Screen
                                            if (currentIndex > 0) {
                                                navigateTo(mainScreens[currentIndex - 1])
                                                switched = true
                                            }
                                        }
                                        if (switched) {
                                            try {
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            } catch (e: Exception) {}
                                        }
                                    }
                                    accumulatedDrag = 0f
                                },
                                onDragCancel = { accumulatedDrag = 0f },
                                onHorizontalDrag = { change, dragAmount ->
                                    accumulatedDrag += dragAmount
                                }
                            )
                        }
                    }
            ) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        val screenOrder = listOf("dashboard", "shopping_list", "lancamentos", "adicionar", "contas", "metas", "relatorios", "settings")
                        val prevIndex = screenOrder.indexOf(initialState)
                        val targetIndex = screenOrder.indexOf(targetState)
                        if (targetIndex > prevIndex) {
                            (slideInHorizontally(animationSpec = spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioNoBouncy)) { it } + fadeIn(animationSpec = spring(stiffness = Spring.StiffnessLow))) togetherWith
                            (slideOutHorizontally(animationSpec = spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioNoBouncy)) { -it / 3 } + fadeOut(animationSpec = spring(stiffness = Spring.StiffnessLow)))
                        } else {
                            (slideInHorizontally(animationSpec = spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioNoBouncy)) { -it } + fadeIn(animationSpec = spring(stiffness = Spring.StiffnessLow))) togetherWith
                            (slideOutHorizontally(animationSpec = spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioNoBouncy)) { it / 3 } + fadeOut(animationSpec = spring(stiffness = Spring.StiffnessLow)))
                        }
                    },
                    label = "tab_fade_transition"
                ) { targetScreen ->
                    saveableStateHolder.SaveableStateProvider(key = targetScreen) {
                        when (targetScreen) {
                    "dashboard" -> DashboardScreen(
                        viewModel = viewModel,
                        wallets = wallets,
                        categories = categories,
                        transactions = transactions,
                        rawTransactions = rawTransactions,
                        goals = goals,
                        settings = settings ?: UserSettings(),
                        onNavigateToHistory = { navigateTo("lancamentos") },
                        onAddFixedExpenseClick = {
                            addTransactionIsExpense = true
                            addTransactionIsRecorrente = true
                            navigateTo("adicionar")
                        },
                        onNavigateToShoppingList = { navigateTo("shopping_list") },
                        onNavigateToSettings = { navigateTo("settings") },
                        onNavigate = { dest ->
                            when (dest) {
                                "adicionar_receita" -> {
                                    addTransactionIsExpense = false
                                    addTransactionIsRecorrente = false
                                    addTransactionInitialType = "INJECAO"
                                    navigateTo("adicionar")
                                }
                                "adicionar_despesa" -> {
                                    addTransactionIsExpense = true
                                    addTransactionIsRecorrente = false
                                    addTransactionInitialType = "DESPESA"
                                    navigateTo("adicionar")
                                }
                                "adicionar_transferencia" -> {
                                    addTransactionIsExpense = false
                                    addTransactionIsRecorrente = false
                                    addTransactionInitialType = "TRANSFERENCIA"
                                    navigateTo("adicionar")
                                }
                                "adicionar_recorrente" -> {
                                    addTransactionIsExpense = true
                                    addTransactionIsRecorrente = true
                                    addTransactionInitialType = "DESPESA"
                                    navigateTo("adicionar")
                                }
                                else -> navigateTo(dest)
                            }
                        },
                        scrollState = dashboardScrollState
                    )
                    "shopping_list" -> ShoppingListScreen(
                        viewModel = viewModel,
                        settings = settings ?: UserSettings(),
                        onBack = { navigateBack() },
                        onNavigateToHistory = { navigateTo("lancamentos") }
                    )
                    "lancamentos" -> LancamentosScreen(
                        viewModel = viewModel,
                        transactions = transactions,
                        categories = categories,
                        wallets = wallets,
                        settings = settings ?: UserSettings(),
                        onAddClick = { isExpense ->
                            addTransactionIsExpense = isExpense
                            addTransactionIsRecorrente = false
                            addTransactionInitialType = if (isExpense) "DESPESA" else "INJECAO"
                            navigateTo("adicionar")
                        },
                        onNavigateToGoal = { navigateTo("metas") },
                        onNavigateToLoan = { navigateTo("loans") },
                        lazyListState = lancamentosLazyListState
                    )
                    "adicionar" -> AdicionarTransactionScreen(
                        viewModel = viewModel,
                        wallets = wallets,
                        categories = categories,
                        isExpenseDefault = addTransactionIsExpense,
                        isRecorrenteDefault = addTransactionIsRecorrente,
                        initialTypeDefault = addTransactionInitialType,
                        onBack = { navigateBack() }
                    )
                    "contas" -> ContasScreen(
                        viewModel = viewModel,
                        wallets = wallets,
                        settings = settings ?: UserSettings(),
                        onLoansClick = { navigateTo("loans") },
                        lazyListState = contasLazyListState
                    )
                    "loans" -> LoansScreen(
                        viewModel = viewModel,
                        wallets = wallets,
                        settings = settings ?: UserSettings(),
                        onBack = { navigateBack() },
                        onNavigateToDetails = { loan ->
                            selectedLoanForDetails = loan
                            navigateTo("loan_details")
                        }
                    )
                    "loan_details" -> {
                        selectedLoanForDetails?.let { l ->
                            LoanDetailsScreen(
                                viewModel = viewModel,
                                loan = l,
                                wallets = wallets,
                                settings = settings ?: UserSettings(),
                                onBack = { navigateBack() }
                            )
                        } ?: run {
                            navigateTo("loans")
                        }
                    }
                    "metas" -> MetasScreen(
                        viewModel = viewModel,
                        goals = goals,
                        categories = categories,
                        settings = settings ?: UserSettings(),
                        lazyListState = metasLazyListState
                    )
                    "relatorios" -> RelatoriosScreen(
                        viewModel = viewModel,
                        transactions = transactions,
                        categories = categories,
                        wallets = wallets,
                        settings = settings ?: UserSettings(),
                        initialTab = relatoriosInitialTab
                    )
                    "settings" -> SettingsScreen(
                        viewModel = viewModel,
                        settings = settings ?: UserSettings(),
                        categories = categories,
                        trashItems = trashItems,
                        onNavigate = { targetScreen -> navigateTo(targetScreen) }
                    )
                    "notifications" -> NotificationsScreen(
                        viewModel = viewModel,
                        settings = settings ?: UserSettings(),
                        onBack = { navigateBack() },
                        onNavigateToEntity = { entityType, entityId ->
                            when (entityType) {
                                "LOAN" -> {
                                    val gl = viewModel.groupedLoans.value.find { it.loan.id == entityId }
                                    if (gl != null) {
                                        selectedLoanForDetails = gl.loan
                                        navigateTo("loan_details")
                                    } else {
                                        viewModel.showSnackbar("Empréstimo não encontrado.")
                                    }
                                }
                                "GOAL" -> navigateTo("goal_details_$entityId")
                                "TRANSACTION", "PURCHASE" -> navigateTo("transaction_details_$entityId")
                                // Cartões, assinaturas e limites de categoria são geridos dentro do
                                // ecrã "Contas" — não têm um ecrã de detalhe próprio ainda.
                                "CARD", "SUBSCRIPTION", "BUDGET" -> navigateTo("contas")
                                "SYSTEM" -> navigateTo("dashboard")
                                else -> viewModel.showSnackbar("Detalhes indisponíveis.")
                            }
                        }
                    )
                    else -> {
                        if (targetScreen.startsWith("goal_details_")) {
                            val id = targetScreen.removePrefix("goal_details_").toIntOrNull()
                            MetasScreen(
                                viewModel = viewModel,
                                goals = goals,
                                categories = categories,
                                settings = settings ?: UserSettings(),
                                deepLinkGoalId = id,
                                lazyListState = metasLazyListState
                            )
                        } else if (targetScreen.startsWith("transaction_details_")) {
                            val id = targetScreen.removePrefix("transaction_details_").toIntOrNull()
                            LancamentosScreen(
                                viewModel = viewModel,
                                transactions = transactions,
                                categories = categories,
                                wallets = wallets,
                                settings = settings ?: UserSettings(),
                                onAddClick = { isExpense ->
                                    addTransactionIsExpense = isExpense
                                    addTransactionIsRecorrente = false
                                    addTransactionInitialType = if (isExpense) "DESPESA" else "INJECAO"
                                    navigateTo("adicionar")
                                },
                                onNavigateToGoal = { navigateTo("metas") },
                                onNavigateToLoan = { navigateTo("loans") },
                                deepLinkTransactionId = id,
                                lazyListState = lancamentosLazyListState
                            )
                        }
                    }
                }
            }
        }
        }

            // Daily Closure Conciliação Obrigatória Prompt Modal
            if (showDailyClosurePrompt && wallets.isNotEmpty()) {
                DailyClosureModal(
                    wallets = wallets,
                    settings = settings ?: UserSettings(),
                    onIgnore = {
                        viewModel.dismissDailyClosure()
                    },
                    onSubmit = { walletId, realAmount ->
                        viewModel.submitDailyClosure(walletId, realAmount)
                    }
                )
            }
        }
    }

        // Overlay layer (Splash screen or Lock screen)
        if (isInitializing) {
            SplashScreen(settings = settings ?: UserSettings())
        } else if (isAppLocked) {
            // App Lock Screen Overlay (supporting biometric first and seamless PIN fallback)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .clickable(
                        enabled = true,
                        onClickLabel = "Lock Screen Background",
                        role = androidx.compose.ui.semantics.Role.Button,
                        indication = null,
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        onClick = {} // Swallows clicks so user cannot click underlying items
                    )
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Finanças",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (settings?.biometricsEnabled == true && !usePinOption) {
                        // --- BIOMETRICS-FIRST SCREEN ---
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                                .clickable { triggerBiometricsCount++ }
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Fingerprint,
                                contentDescription = if (idioma == "PT") "Impressão Digital" else "Fingerprint",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(72.dp)
                            )
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = if (idioma == "PT") "Toque para Desbloquear" else "Tap to Unlock",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = if (idioma == "PT") "Use a sua impressão digital para aceder à aplicação" else "Use your fingerprint to access the application",
                                textAlign = TextAlign.Center,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(
                            onClick = { usePinOption = true },
                            modifier = Modifier.testTag("switch_to_pin_button")
                        ) {
                            Text(
                                text = if (idioma == "PT") "Utilizar PIN" else "Use PIN",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    } else {
                        // --- PIN SCREEN ---
                        Text(
                            text = if (idioma == "PT") "Aplicação Bloqueada\nInsira o seu PIN para continuar" else "Application Locked\nEnter your PIN to continue",
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )

                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { if (it.length <= 4) pinInput = it },
                            label = { Text("PIN") },
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.width(180.dp).testTag("pin_input")
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    val isValid = verifyPin(pinInput, settings?.pinHash ?: "") {
                                        viewModel.updateSecurityPin(pinInput)
                                    }
                                    if (isValid) {
                                        isAppLocked = false
                                    } else {
                                        Toast.makeText(context, if (idioma == "PT") "PIN Incorrecto!" else "Incorrect PIN!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.testTag("pin_unlock_button")
                            ) {
                                Text(if (idioma == "PT") "Desbloquear" else "Unlock")
                            }

                            if (settings?.biometricsEnabled == true) {
                                IconButton(
                                    onClick = { 
                                        usePinOption = false
                                        triggerBiometricsCount++
                                    },
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp))
                                        .testTag("switch_to_biometrics_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Fingerprint,
                                        contentDescription = if (idioma == "PT") "Biometria" else "Biometrics",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
