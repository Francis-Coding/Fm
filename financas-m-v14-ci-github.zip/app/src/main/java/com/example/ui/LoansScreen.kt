@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File


// ------------------- TELA: GESTÃO DE EMPRÉSTIMOS (CRÉDITO / DÉBITO) -------------------
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LoansScreen(
    viewModel: MainViewModel,
    wallets: List<Wallet>,
    settings: UserSettings,
    onBack: () -> Unit,
    onNavigateToDetails: (Loan) -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val idioma = settings.idioma
    val groupedLoansList by viewModel.groupedLoans.collectAsStateWithLifecycle(emptyList())

    var tactileState by remember { mutableStateOf(TactileSuccessState()) }

    // Modal state for editing or creating a loan
    var editingLoan by remember { mutableStateOf<Loan?>(null) }
    var showAddLoanModal by remember { mutableStateOf(false) }
    var showLoanContractInfoId by remember { mutableStateOf<Int?>(null) }
    var showLoanSimulatorModal by remember { mutableStateOf(false) }

    // Dialog state for payment
    var showPaymentDialogForInstallment by remember { mutableStateOf<Installment?>(null) }
    var paymentAmountStr by remember { mutableStateOf("") }
    var selectedWalletForPayment by remember { mutableStateOf<Wallet?>(null) }
    var walletDropdownOpen by remember { mutableStateOf(false) }

    // Search and filter states
    val searchQuery by viewModel.loansSearchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.loansFilter.collectAsStateWithLifecycle()
    val sortBy by viewModel.loansSortBy.collectAsStateWithLifecycle()
    val sortDescending by viewModel.loansSortDescending.collectAsStateWithLifecycle()

    // Color theme
    val themeColor = try {
        Color(android.graphics.Color.parseColor(settings.corPrimaria))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }
    val isDark = settings.tema == "dark"

    val baseBackgroundColor = if (isDark) {
        MaterialTheme.colorScheme.background
    } else {
        Color(0xFFF8FAFC)
    }

    // Calculations for overall metrics
    val totalCredit = groupedLoansList.filter { it.loan.isCredit }.sumOf { it.remainingBalanceSum }
    val totalDebit = groupedLoansList.filter { !it.loan.isCredit }.sumOf { it.remainingBalanceSum }

    val activeCreditLoans = groupedLoansList.filter { it.loan.isCredit && it.remainingBalanceSum > 0.0 }
    val activeDebitLoans = groupedLoansList.filter { !it.loan.isCredit && it.remainingBalanceSum > 0.0 }

    val activeCreditCount = activeCreditLoans.size
    val activeDebitCount = activeDebitLoans.size

    val creditFooter = if (idioma == "PT") {
        if (activeCreditCount == 1) "1 crédito ativo" else "$activeCreditCount créditos ativos"
    } else {
        if (activeCreditCount == 1) "1 active loan" else "$activeCreditCount active loans"
    }

    val debitFooter = if (idioma == "PT") {
        if (activeDebitCount == 0) "Nenhum débito ativo" else if (activeDebitCount == 1) "1 débito ativo" else "$activeDebitCount débitos ativos"
    } else {
        if (activeDebitCount == 0) "No active debit" else if (activeDebitCount == 1) "1 active debit" else "$activeDebitCount active debits"
    }

    // Filtered and sorted list
    val filteredLoans = remember(groupedLoansList, searchQuery, selectedFilter, sortBy, sortDescending) {
        val baseList = groupedLoansList.filter { gl ->
            val matchesSearch = gl.loan.counterparty.contains(searchQuery, ignoreCase = true) ||
                    String.format("#%03d", gl.loan.id).contains(searchQuery)
            
            val matchesFilter = when (selectedFilter) {
                "Ativos" -> gl.remainingBalanceSum > 0.0
                "Pagos" -> gl.remainingBalanceSum <= 0.0
                "Atrasados" -> gl.installments.any { it.status != "PAID" && it.status != "Pago" && it.dueDate < System.currentTimeMillis() }
                else -> true
            }
            matchesSearch && matchesFilter
        }
        val sortedList = when (sortBy) {
            "Counterparty" -> baseList.sortedBy { it.loan.counterparty.lowercase() }
            "Value" -> baseList.sortedBy { it.loan.principalAmount }
            "DueDate" -> baseList.sortedBy { it.installments.firstOrNull()?.dueDate ?: Long.MAX_VALUE }
            else -> baseList.sortedBy { it.loan.id }
        }
        if (sortDescending) sortedList.reversed() else sortedList
    }

    val lazyListState = rememberLazyListState()

    Scaffold(
        containerColor = baseBackgroundColor
    ) { paddingValues ->
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = paddingValues.calculateTopPadding().coerceAtLeast(16.dp),
                    bottom = paddingValues.calculateBottomPadding().coerceAtLeast(16.dp),
                    start = 16.dp,
                    end = 16.dp
                ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row (Compact & Premium, matching guidelines)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Custom Back Button on a nice white/gray container
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White)
                                .border(
                                    1.dp,
                                    if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFE2E8F0),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onBack() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = if (isDark) Color.White else Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Title and Subtitle with requested sizes: Title 28, Subtitle 15
                        Column {
                            Text(
                                text = if (idioma == "PT") "Empréstimos" else "Loans",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDark) Color.White else Color(0xFF111827)
                            )
                            Text(
                                text = if (idioma == "PT") "Crédito e Débito" else "Credit & Debit",
                                fontSize = 15.sp,
                                color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF6B7280),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // "Simulador" Button
                        OutlinedButton(
                            onClick = { showLoanSimulatorModal = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF2E7D32)),
                            border = BorderStroke(1.dp, Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Calculate,
                                contentDescription = null,
                                tint = Color(0xFF2E7D32),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (idioma == "PT") "Simulador" else "Simulate",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        // "+ Novo" Button
                        Button(
                            onClick = { showAddLoanModal = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("new_loan_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (idioma == "PT") "Novo Empréstimo" else "New Loan",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // Spacer to create 24dp spacing between Header and Summary sections
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Summary Cards: Receivable & Payable (height reduced by approximately 30%, no extra descriptive text)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Receivable Card
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDark) Color(0xFF132D15) else Color(0xFFE8F5E9)
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isDark) Color(0xFF2E7D32).copy(alpha = 0.3f) else Color(0xFFC8E6C9)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF2E7D32)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Download,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = if (idioma == "PT") "A Receber" else "To Receive",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF6B7280)
                                )
                                Text(
                                    text = "${String.format("%,.2f", totalCredit)} MZN",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32),
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = creditFooter,
                                    fontSize = 12.sp,
                                    color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF6B7280),
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Payable Card
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDark) Color(0xFF3B1E1E) else Color(0xFFFFF5F5)
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isDark) Color(0xFFD32F2F).copy(alpha = 0.3f) else Color(0xFFFEE2E2)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFD32F2F)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ArrowUpward,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = if (idioma == "PT") "A Pagar" else "To Pay",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF6B7280)
                                )
                                Text(
                                    text = "${String.format("%,.2f", totalDebit)} MZN",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFD32F2F),
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = debitFooter,
                                    fontSize = 12.sp,
                                    color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF6B7280),
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Spacer to create 24dp spacing between Summary Cards and Filters sections
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Filters and Search Row (Clean & subtle, minimal shadow)
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Filter chips - Height of 36dp with rounded corners, Label size 13.sp
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val filters = listOf(
                            "Todos" to (if (idioma == "PT") "Todos" else "All"),
                            "Ativos" to (if (idioma == "PT") "Ativos" else "Active"),
                            "Pagos" to (if (idioma == "PT") "Pagos" else "Paid"),
                            "Atrasados" to (if (idioma == "PT") "Atrasados" else "Overdue")
                        )
                        filters.forEach { (filterId, label) ->
                            val isSelected = selectedFilter == filterId
                            Box(
                                modifier = Modifier
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(if (isSelected) Color(0xFF2E7D32) else (if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White))
                                    .border(
                                        1.dp,
                                        if (isSelected) Color(0xFF2E7D32) else (if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFE2E8F0)),
                                        RoundedCornerShape(18.dp)
                                    )
                                    .clickable { viewModel.setLoansFilter(filterId) }
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) Color.White else (if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFF6B7280))
                                )
                            }
                        }
                    }

                    // Search Bar + Tune button (clean Search Bar, right filter only, minimal shadow)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.loansSearchQuery.value = it },
                            placeholder = { 
                                Text(
                                    text = if (idioma == "PT") "Procurar cliente ou empréstimo..." else "Search client or loan...", 
                                    fontSize = 13.sp,
                                    color = if (isDark) Color.White.copy(alpha = 0.4f) else Color(0xFF94A3B8)
                                ) 
                            },
                            leadingIcon = {
                                Icon(Icons.Rounded.Search, null, tint = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B), modifier = Modifier.size(18.dp))
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF2E7D32),
                                unfocusedBorderColor = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFEEF2EE),
                                focusedContainerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White,
                                unfocusedContainerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp)
                        )

                        var showSortDialog by remember { mutableStateOf(false) }

                        if (showSortDialog) {
                            var tempSortBy by remember { mutableStateOf(sortBy) }
                            var tempSortDescending by remember { mutableStateOf(sortDescending) }

                            Dialog(
                                onDismissRequest = { showSortDialog = false }
                            ) {
                                Card(
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFE2E8F0)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Text(
                                            text = if (idioma == "PT") "Ordenar por" else "Sort by",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) Color.White else Color(0xFF111827)
                                        )

                                        Spacer(modifier = Modifier.height(4.dp))

                                        // Section 1: Sort Criteria
                                        val criteriaOptions = listOf(
                                            "Counterparty" to (if (idioma == "PT") "Nome" else "Name"),
                                            "DueDate" to (if (idioma == "PT") "Data" else "Date"),
                                            "Value" to (if (idioma == "PT") "Valor" else "Value"),
                                            "ID" to (if (idioma == "PT") "Código / Padrão" else "Code / Default")
                                        )

                                        criteriaOptions.forEach { (opt, label) ->
                                            val isSelected = tempSortBy == opt
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { 
                                                        tempSortBy = opt
                                                        if (opt == "Counterparty") {
                                                            tempSortDescending = false
                                                        } else {
                                                            tempSortDescending = true
                                                        }
                                                    }
                                                    .padding(vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                androidx.compose.material3.RadioButton(
                                                    selected = isSelected,
                                                    onClick = { 
                                                        tempSortBy = opt 
                                                        if (opt == "Counterparty") {
                                                            tempSortDescending = false
                                                        } else {
                                                            tempSortDescending = true
                                                        }
                                                    },
                                                    colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = themeColor)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = label,
                                                    fontSize = 15.sp,
                                                    color = if (isDark) Color.White else Color(0xFF334155),
                                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                                )
                                            }
                                        }

                                        HorizontalDivider(
                                            color = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFEEF2EE),
                                            thickness = 1.dp,
                                            modifier = Modifier.padding(vertical = 8.dp)
                                        )

                                        // Section 2: Order Direction
                                        val directionOptions = when (tempSortBy) {
                                            "Counterparty" -> listOf(
                                                false to (if (idioma == "PT") "De A a Z" else "From A to Z"),
                                                true to (if (idioma == "PT") "De Z a A" else "From Z to A")
                                            )
                                            "DueDate", "ID" -> listOf(
                                                true to (if (idioma == "PT") "Do novo ao antigo" else "Newest to oldest"),
                                                false to (if (idioma == "PT") "De antigo a novo" else "Oldest to newest")
                                            )
                                            else -> listOf(
                                                true to (if (idioma == "PT") "Do maior ao menor" else "Highest to lowest"),
                                                false to (if (idioma == "PT") "Do menor ao maior" else "Lowest to highest")
                                            )
                                        }

                                        directionOptions.forEach { (descending, label) ->
                                            val isSelected = tempSortDescending == descending
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { tempSortDescending = descending }
                                                    .padding(vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                androidx.compose.material3.RadioButton(
                                                    selected = isSelected,
                                                    onClick = { tempSortDescending = descending },
                                                    colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = themeColor)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = label,
                                                    fontSize = 15.sp,
                                                    color = if (isDark) Color.White else Color(0xFF334155),
                                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Section 3: Buttons
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(
                                                onClick = { showSortDialog = false }
                                            ) {
                                                Text(
                                                    text = if (idioma == "PT") "CANCELAR" else "CANCEL",
                                                    color = themeColor,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(16.dp))
                                            TextButton(
                                                onClick = {
                                                    viewModel.setLoansSortBy(tempSortBy)
                                                    viewModel.setLoansSortDescending(tempSortDescending)
                                                    showSortDialog = false
                                                }
                                            ) {
                                                Text(
                                                    text = "OK",
                                                    color = themeColor,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Box {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White)
                                    .border(1.dp, if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFEEF2EE), RoundedCornerShape(20.dp))
                                    .clickable { showSortDialog = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Tune,
                                    contentDescription = "Filter",
                                    tint = if (isDark) Color.White else Color(0xFF64748B),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Spacer to create 24dp spacing between Filter/Search section and Cards list
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (filteredLoans.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (idioma == "PT") "Nenhum empréstimo encontrado." else "No loans found.",
                            color = if (isDark) Color.White.copy(alpha = 0.4f) else Color(0xFF64748B),
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                items(filteredLoans, key = { it.loan.id }) { gl ->
                    val loan = gl.loan
                    val balance = gl.remainingBalanceSum
                    val isPaidOff = balance <= 0.0
                    val totalOutstanding = gl.totalDueSum
                    val isCredit = loan.isCredit
                    
                    // Active/Paid calculations
                    val paidCount = gl.installments.count { it.status == "PAID" || it.status == "Pago" }
                    val totalCount = gl.installments.size
                    val totalPaidSum = gl.installments.filter { it.status == "PAID" || it.status == "Pago" }.sumOf { it.totalPaid }
                    val totalRemainingSum = gl.installments.sumOf { it.remainingBalance }
                    val totalSum = totalPaidSum + totalRemainingSum
                    val progress = if (totalSum > 0) (totalPaidSum / totalSum).toFloat().coerceIn(0f, 1f) else 1f

                    // Current installment calculation
                    val currentInstallmentIndex = if (paidCount < totalCount) paidCount + 1 else totalCount

                    // Formatting dates nicely
                    val dueDateStr = try {
                        SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(loan.dueDate))
                    } catch (e: Exception) {
                        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(loan.dueDate))
                    }

                    var activeMenuLoanId by remember { mutableStateOf<Int?>(null) }
                    var isExpanded by remember { mutableStateOf(false) }

                    SwipeToDeleteContainer(
                        item = loan,
                        onDelete = { viewModel.deleteLoan(it) },
                        requireConfirmation = true,
                        modifier = Modifier.animateItem()
                    ) { swipedLoan ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToDetails(swipedLoan) },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.White
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFEEF2EE)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Row 1: Loan icon, Loan number, and Customer name with Status badge
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Custom visual icon box (compact 32.dp)
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isCredit) Color(0xFFE8F5E9) else Color(0xFFFFF5F5)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.AccountBalanceWallet,
                                                contentDescription = null,
                                                tint = if (isCredit) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = (if (idioma == "PT") "Empréstimo" else "Loan") + " #${String.format("%03d", swipedLoan.id)}",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp,
                                                color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF6B7280)
                                            )
                                            Text(
                                                text = "|",
                                                fontSize = 13.sp,
                                                color = if (isDark) Color.White.copy(alpha = 0.3f) else Color(0xFFE2E8F0)
                                            )
                                            Text(
                                                text = swipedLoan.counterparty,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = if (isDark) Color.White else Color(0xFF111827)
                                            )
                                            Text(
                                                text = "|",
                                                fontSize = 13.sp,
                                                color = if (isDark) Color.White.copy(alpha = 0.3f) else Color(0xFFE2E8F0)
                                            )

                                            // Status badge
                                            val isOverdue = !isPaidOff && gl.installments.any { it.status != "PAID" && it.status != "Pago" && it.dueDate < System.currentTimeMillis() }
                                            val badgeBg = if (isPaidOff) Color(0xFFE8F5E9) else if (isOverdue) Color(0xFFFFEBEE) else Color(0xFFFFF3E0)
                                            val badgeText = if (isPaidOff) Color(0xFF2E7D32) else if (isOverdue) Color(0xFFD32F2F) else Color(0xFFE65100)
                                            val badgeLabel = if (isPaidOff) {
                                                (if (idioma == "PT") "Pago" else "Paid")
                                            } else if (isOverdue) {
                                                (if (idioma == "PT") "Em atraso" else "Overdue")
                                            } else {
                                                (if (idioma == "PT") "Ativo" else "Active")
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(badgeBg)
                                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = badgeLabel,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = badgeText
                                                )
                                            }
                                        }
                                    }

                                    // Menu options trigger
                                    Box {
                                        IconButton(
                                            onClick = { activeMenuLoanId = swipedLoan.id },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.MoreVert,
                                                contentDescription = "Options",
                                                tint = if (isDark) Color.White else Color(0xFF6B7280),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        DropdownMenu(
                                            expanded = activeMenuLoanId == swipedLoan.id,
                                            onDismissRequest = { activeMenuLoanId = null }
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text(if (idioma == "PT") "Editar" else "Edit") },
                                                onClick = {
                                                    editingLoan = swipedLoan
                                                    activeMenuLoanId = null
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text(if (idioma == "PT") "Ver Histórico" else "View History") },
                                                onClick = {
                                                    activeMenuLoanId = null
                                                    Toast.makeText(context, if (idioma == "PT") "Histórico de transações" else "Transaction history", Toast.LENGTH_SHORT).show()
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text(if (idioma == "PT") "Excluir" else "Delete") },
                                                onClick = {
                                                    viewModel.deleteLoan(swipedLoan)
                                                    activeMenuLoanId = null
                                                }
                                            )
                                        }
                                    }
                                }

                                // Row 2: Total to receive, Current installment, Due Date
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1.2f)) {
                                        Text(
                                            text = if (isCredit) {
                                                (if (idioma == "PT") "Total a receber" else "Total to receive")
                                            } else {
                                                (if (idioma == "PT") "Total a pagar" else "Total to pay")
                                            },
                                            fontSize = 11.sp,
                                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF6B7280)
                                        )
                                        Text(
                                            text = "${String.format("%,.2f", totalOutstanding)} MZN",
                                            fontSize = 18.sp, // Reduced slightly to match premium layout
                                            fontWeight = FontWeight.Bold,
                                            color = if (isCredit) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = if (idioma == "PT") "Parcela" else "Installment",
                                            fontSize = 11.sp,
                                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF6B7280)
                                        )
                                        Text(
                                            text = if (isPaidOff) {
                                                (if (idioma == "PT") "Pago" else "Paid")
                                            } else {
                                                "$currentInstallmentIndex de $totalCount"
                                            },
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) Color.White else Color(0xFF111827)
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = if (idioma == "PT") "Vencimento" else "Due Date",
                                            fontSize = 11.sp,
                                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF6B7280)
                                        )
                                        Text(
                                            text = dueDateStr,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) Color.White else Color(0xFF111827)
                                        )
                                    }
                                }

                                // Progress Bar Section (Height: 6dp, fully rounded, percentage displayed on the right)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    LinearProgressIndicator(
                                        progress = { progress },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = if (isCredit) Color(0xFF2E7D32) else Color(0xFF38BDF8),
                                        trackColor = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFF1F5F9)
                                    )
                                    Text(
                                        text = "${(progress * 100).toInt()}%",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color.White else Color(0xFF111827)
                                    )
                                }

                                // Small footer indicating the number of installments (toggles expand state)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { isExpanded = !isExpanded }
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Description,
                                            contentDescription = null,
                                            tint = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF6B7280),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = if (idioma == "PT") {
                                                if (totalCount == 1) "1 parcela" else "$totalCount parcelas"
                                            } else {
                                                if (totalCount == 1) "1 installment" else "$totalCount installments"
                                            },
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF6B7280)
                                        )
                                    }

                                    Icon(
                                        imageVector = if (isExpanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                                        contentDescription = "Expand",
                                        tint = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF6B7280),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                // Accordion expanded contents (Installments list with Premium UI/UX)
                                AnimatedVisibility(
                                    visible = isExpanded,
                                    enter = expandVertically(animationSpec = spring()) + fadeIn(),
                                    exit = shrinkVertically(animationSpec = spring()) + fadeOut()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 8.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        HorizontalDivider(
                                            color = if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFF1F5F9),
                                            thickness = 1.dp,
                                            modifier = Modifier.padding(bottom = 4.dp)
                                        )

                                        // 1. Premium Overview Grid: 3 metrics panels
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Panel 1: Taxa de Juro
                                            Card(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f) else Color(0xFFF8FAFC)
                                                ),
                                                border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFE2E8F0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(10.dp),
                                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.Percent,
                                                            contentDescription = null,
                                                            tint = if (isCredit) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                                                            modifier = Modifier.size(12.dp)
                                                        )
                                                        Text(
                                                            text = if (idioma == "PT") "Juros" else "Interest",
                                                            fontSize = 11.sp,
                                                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B),
                                                            fontWeight = FontWeight.Medium
                                                        )
                                                    }
                                                    Text(
                                                        text = "${loan.interestRate}%",
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isDark) Color.White else Color(0xFF1E293B)
                                                    )
                                                    Text(
                                                        text = if (loan.interestType == "SIMPLE" || loan.interestType == "Simples") {
                                                            if (idioma == "PT") "Simples" else "Simple"
                                                        } else {
                                                            if (idioma == "PT") "Composto" else "Compound"
                                                        },
                                                        fontSize = 10.sp,
                                                        color = if (isDark) Color.White.copy(alpha = 0.4f) else Color(0xFF94A3B8)
                                                    )
                                                }
                                            }

                                            // Panel 2: Amortizado
                                            Card(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f) else Color(0xFFF8FAFC)
                                                ),
                                                border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFE2E8F0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(10.dp),
                                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.CheckCircle,
                                                            contentDescription = null,
                                                            tint = Color(0xFF2E7D32),
                                                            modifier = Modifier.size(12.dp)
                                                        )
                                                        Text(
                                                            text = if (idioma == "PT") "Amortizado" else "Paid",
                                                            fontSize = 11.sp,
                                                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B),
                                                            fontWeight = FontWeight.Medium
                                                        )
                                                    }
                                                    Text(
                                                        text = "${String.format("%,.2f", totalPaidSum)} MZN",
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isDark) Color.White else Color(0xFF1E293B),
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = "$paidCount de $totalCount",
                                                        fontSize = 10.sp,
                                                        color = if (isDark) Color.White.copy(alpha = 0.4f) else Color(0xFF94A3B8)
                                                    )
                                                }
                                            }

                                            // Panel 3: Multa
                                            Card(
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f) else Color(0xFFF8FAFC)
                                                ),
                                                border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFE2E8F0))
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(10.dp),
                                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.Warning,
                                                            contentDescription = null,
                                                            tint = Color(0xFFD32F2F),
                                                            modifier = Modifier.size(12.dp)
                                                        )
                                                        Text(
                                                            text = if (idioma == "PT") "Multa/Dia" else "Penalty",
                                                            fontSize = 11.sp,
                                                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B),
                                                            fontWeight = FontWeight.Medium
                                                        )
                                                    }
                                                    Text(
                                                        text = "${loan.penaltyPercentage}%",
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isDark) Color.White else Color(0xFF1E293B)
                                                    )
                                                    Text(
                                                        text = if (idioma == "PT") "por atraso" else "per day late",
                                                        fontSize = 10.sp,
                                                        color = if (isDark) Color.White.copy(alpha = 0.4f) else Color(0xFF94A3B8)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        // 2. Interactive Connected Vertical Timeline
                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(0.dp) // Zero spacing to let the timeline connect perfectly
                                        ) {
                                            gl.installments.forEachIndexed { idx, inst ->
                                                val instDueDateStr = try {
                                                    SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(inst.dueDate))
                                                } catch (e: Exception) {
                                                    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(inst.dueDate))
                                                }
                                                val isPaid = inst.status == "PAID" || inst.status == "Pago"
                                                val isOverdue = !isPaid && inst.dueDate < System.currentTimeMillis()
                                                val isDueToday = !isPaid && android.text.format.DateUtils.isToday(inst.dueDate)

                                                val instPenalty = if (isPaid) 0.0 else viewModel.calculatePenaltyUseCase.execute(
                                                    remainingBalance = inst.remainingBalance,
                                                    penaltyPercentage = loan.penaltyPercentage,
                                                    dueDate = inst.dueDate,
                                                    currentDate = System.currentTimeMillis()
                                                )
                                                val totalInstRemaining = inst.remainingBalance + instPenalty

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                                ) {
                                                    // Left vertical timeline axis
                                                    Column(
                                                        horizontalAlignment = Alignment.CenterHorizontally,
                                                        modifier = Modifier.width(24.dp)
                                                    ) {
                                                        val circleBg = when {
                                                            isPaid -> Color(0xFFE8F5E9)
                                                            isOverdue -> Color(0xFFFFF5F5)
                                                            else -> if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFF1F5F9)
                                                        }
                                                        val circleIcon = when {
                                                            isPaid -> Icons.Rounded.Check
                                                            isOverdue -> Icons.Rounded.Warning
                                                            else -> Icons.Rounded.Schedule
                                                        }
                                                        val circleIconColor = when {
                                                            isPaid -> Color(0xFF2E7D32)
                                                            isOverdue -> Color(0xFFD32F2F)
                                                            else -> if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B)
                                                        }

                                                        Box(
                                                            modifier = Modifier
                                                                .size(24.dp)
                                                                .clip(CircleShape)
                                                                .background(circleBg),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Icon(
                                                                imageVector = circleIcon,
                                                                contentDescription = null,
                                                                tint = circleIconColor,
                                                                modifier = Modifier.size(14.dp)
                                                            )
                                                        }

                                                        // Vertical line connecting steps
                                                        if (idx < gl.installments.lastIndex) {
                                                            Box(
                                                                modifier = Modifier
                                                                    .width(2.dp)
                                                                    .height(44.dp) // Generous height to fit installment cards nicely
                                                                    .background(
                                                                        if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFE2E8F0)
                                                                    )
                                                            )
                                                        }
                                                    }

                                                    // Right card with installment details
                                                    Card(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .padding(bottom = if (idx < gl.installments.lastIndex) 8.dp else 0.dp),
                                                        shape = RoundedCornerShape(12.dp),
                                                        colors = CardDefaults.cardColors(
                                                            containerColor = if (isPaid) {
                                                                if (isDark) Color.White.copy(alpha = 0.02f) else Color(0xFFF8FAFC).copy(alpha = 0.5f)
                                                            } else {
                                                                if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f) else Color.White
                                                            }
                                                        ),
                                                        border = BorderStroke(
                                                            width = 1.dp,
                                                            color = when {
                                                                isPaid -> Color.Transparent
                                                                isOverdue -> Color(0xFFFCA5A5).copy(alpha = 0.5f)
                                                                isDueToday -> Color(0xFF86EFAC).copy(alpha = 0.5f)
                                                                else -> if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFEEF2EE)
                                                            }
                                                        )
                                                    ) {
                                                        Row(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .padding(10.dp),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Column(modifier = Modifier.weight(1f)) {
                                                                Text(
                                                                    text = if (idioma == "PT") "Parcela ${idx + 1}" else "Installment ${idx + 1}",
                                                                    fontWeight = FontWeight.Bold,
                                                                    fontSize = 13.sp,
                                                                    color = if (isPaid) {
                                                                        if (isDark) Color.White.copy(alpha = 0.4f) else Color(0xFF94A3B8)
                                                                    } else {
                                                                        if (isDark) Color.White else Color(0xFF1E293B)
                                                                    }
                                                                )
                                                                Text(
                                                                    text = when {
                                                                        isPaid -> if (idioma == "PT") "Pago" else "Paid"
                                                                        isDueToday -> if (idioma == "PT") "Vence Hoje" else "Due Today"
                                                                        isOverdue -> if (idioma == "PT") "Atrasado • $instDueDateStr" else "Overdue • $instDueDateStr"
                                                                        else -> if (idioma == "PT") "Vence $instDueDateStr" else "Due $instDueDateStr"
                                                                    },
                                                                    fontSize = 11.sp,
                                                                    fontWeight = FontWeight.Medium,
                                                                    color = when {
                                                                        isPaid -> if (isDark) Color.White.copy(alpha = 0.3f) else Color(0xFF94A3B8)
                                                                        isOverdue -> Color(0xFFD32F2F)
                                                                        isDueToday -> Color(0xFF2E7D32)
                                                                        else -> if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B)
                                                                    }
                                                                )
                                                            }

                                                            Column(
                                                                horizontalAlignment = Alignment.End,
                                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                                            ) {
                                                                Text(
                                                                    text = "${String.format("%,.2f", totalInstRemaining)} MZN",
                                                                    fontSize = 13.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = when {
                                                                        isPaid -> if (isDark) Color.White.copy(alpha = 0.3f) else Color(0xFF94A3B8)
                                                                        isOverdue -> Color(0xFFD32F2F)
                                                                        else -> if (isDark) Color.White else Color(0xFF1E293B)
                                                                    }
                                                                )

                                                                if (!isPaid) {
                                                                    val confirmBtnLabel = if (isCredit) {
                                                                        if (idioma == "PT") "Receber" else "Receive"
                                                                    } else {
                                                                        if (idioma == "PT") "Pagar" else "Pay"
                                                                    }

                                                                    Button(
                                                                        onClick = {
                                                                            selectedWalletForPayment = wallets.firstOrNull()
                                                                            paymentAmountStr = totalInstRemaining.toString()
                                                                            showPaymentDialogForInstallment = inst
                                                                        },
                                                                        colors = ButtonDefaults.buttonColors(
                                                                            containerColor = if (isOverdue) Color(0xFFFEE2E2) else Color(0xFFE8F5E9),
                                                                            contentColor = if (isOverdue) Color(0xFF991B1B) else Color(0xFF2E7D32)
                                                                        ),
                                                                        shape = RoundedCornerShape(8.dp),
                                                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                                                        modifier = Modifier.height(28.dp)
                                                                    ) {
                                                                        Text(
                                                                            text = confirmBtnLabel,
                                                                            fontSize = 11.sp,
                                                                            fontWeight = FontWeight.Bold
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        // 3. Quick Actions shortcuts Row (Share statement, View original contracts)
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    Toast.makeText(
                                                        context,
                                                        if (idioma == "PT") "Extrato copiado para a área de transferência!" else "Statement copied to clipboard!",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                },
                                                modifier = Modifier.weight(1f).height(36.dp),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(
                                                    contentColor = if (isDark) Color.White else Color(0xFF475569)
                                                ),
                                                border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFCBD5E1)),
                                                contentPadding = PaddingValues(horizontal = 8.dp)
                                            ) {
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Share,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Text(
                                                        text = if (idioma == "PT") "Partilhar" else "Share",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                            }

                                            var showLoanContractInfoIdDialog by remember { mutableStateOf<Int?>(null) }
                                            
                                            OutlinedButton(
                                                onClick = { showLoanContractInfoIdDialog = swipedLoan.id },
                                                modifier = Modifier.weight(1f).height(36.dp),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(
                                                    contentColor = if (isDark) Color.White else Color(0xFF475569)
                                                ),
                                                border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFCBD5E1)),
                                                contentPadding = PaddingValues(horizontal = 8.dp)
                                            ) {
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Info,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Text(
                                                        text = if (idioma == "PT") "Mais Info" else "More Info",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                            }

                                            if (showLoanContractInfoIdDialog == swipedLoan.id) {
                                                AlertDialog(
                                                    onDismissRequest = { showLoanContractInfoIdDialog = null },
                                                    title = {
                                                        Text(
                                                            text = if (idioma == "PT") "Informação da Operação" else "Operation Details",
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 16.sp
                                                        )
                                                    },
                                                    text = {
                                                        val txDateStr = try {
                                                            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(swipedLoan.transactionDate))
                                                        } catch (e: Exception) {
                                                            "-"
                                                        }
                                                        val limitDateStr = try {
                                                            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(swipedLoan.dueDate))
                                                        } catch (e: Exception) {
                                                            "-"
                                                        }
                                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                                Text(if (idioma == "PT") "Contraparte:" else "Counterparty:", fontSize = 12.sp, color = Color.Gray)
                                                                Text(swipedLoan.counterparty, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                                            }
                                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                                Text(if (idioma == "PT") "Capital Principal:" else "Principal Capital:", fontSize = 12.sp, color = Color.Gray)
                                                                Text("${String.format("%,.2f", swipedLoan.principalAmount)} MZN", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                                            }
                                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                                Text(if (idioma == "PT") "Data Registro:" else "Registration Date:", fontSize = 12.sp, color = Color.Gray)
                                                                Text(txDateStr, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                                            }
                                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                                Text(if (idioma == "PT") "Vencimento Final:" else "Final Maturity:", fontSize = 12.sp, color = Color.Gray)
                                                                Text(limitDateStr, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                                            }
                                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                                Text(if (idioma == "PT") "Parcelas Totais:" else "Total Installments:", fontSize = 12.sp, color = Color.Gray)
                                                                Text("${swipedLoan.installmentCount}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                                            }
                                                            if (swipedLoan.status == "PAID" || swipedLoan.paidOffDate != null) {
                                                                val payoffDateStr = try {
                                                                    val dateVal = swipedLoan.paidOffDate ?: swipedLoan.transactionDate
                                                                    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(dateVal))
                                                                } catch (e: Exception) {
                                                                    "-"
                                                                }
                                                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                                    Text(if (idioma == "PT") "Data de Quitação:" else "Pay-off Date:", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                                                    Text(payoffDateStr, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF2E7D32))
                                                                }
                                                            }
                                                        }
                                                    },
                                                    confirmButton = {
                                                        TextButton(onClick = { showLoanContractInfoIdDialog = null }) {
                                                            Text("OK")
                                                        }
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal to Register a Loan
    if (showAddLoanModal) {
        var counterparty by remember { mutableStateOf("") }
        var counterpartyPhone by remember { mutableStateOf("") }
        var principalStr by remember { mutableStateOf("") }
        var interestRateStr by remember { mutableStateOf("") }
        var interestType by remember { mutableStateOf("Simples") } // "Simples" or "Composto"
        var penaltyStr by remember { mutableStateOf("") }
        var isCredit by remember { mutableStateOf(true) } // Credit is lent, Debit is borrowed
        var installmentCountStr by remember { mutableStateOf("1") }
        var dueDaysStr by remember { mutableStateOf("30") }
        var selectedLoanDueDateMs by remember { mutableStateOf<Long?>(System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000)) }
        var selectedAccountWallet by remember { mutableStateOf<Wallet?>(wallets.firstOrNull { it.ativa }) }
        var accountDropdownExpanded by remember { mutableStateOf(false) }

        val context = androidx.compose.ui.platform.LocalContext.current
        val pickContactLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
            contract = androidx.activity.result.contract.ActivityResultContracts.PickContact()
        ) { uri ->
            if (uri != null) {
                try {
                    val cursor = context.contentResolver.query(uri, null, null, null, null)
                    cursor?.use { c ->
                        if (c.moveToFirst()) {
                            val nameIndex = c.getColumnIndex(android.provider.ContactsContract.Contacts.DISPLAY_NAME)
                            if (nameIndex >= 0) {
                                val name = c.getString(nameIndex)
                                if (!name.isNullOrBlank()) {
                                    counterparty = name
                                }
                            }
                            val idIndex = c.getColumnIndex(android.provider.ContactsContract.Contacts._ID)
                            val hasPhoneIndex = c.getColumnIndex(android.provider.ContactsContract.Contacts.HAS_PHONE_NUMBER)
                            if (idIndex >= 0 && hasPhoneIndex >= 0) {
                                val contactId = c.getString(idIndex)
                                val hasPhone = c.getInt(hasPhoneIndex)
                                if (hasPhone > 0) {
                                    val pCursor = context.contentResolver.query(
                                        android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                        null,
                                        "${android.provider.ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                                        arrayOf(contactId),
                                        null
                                    )
                                    pCursor?.use { pc ->
                                        if (pc.moveToFirst()) {
                                            val numIndex = pc.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)
                                            if (numIndex >= 0) {
                                                val num = pc.getString(numIndex)
                                                if (!num.isNullOrBlank()) {
                                                    counterpartyPhone = num
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.e("LoansScreen", "Failed to parse contact data", e)
                }
            }
        }

        Dialog(
            onDismissRequest = { showAddLoanModal = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showAddLoanModal = false }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                        }
                        Text(
                            text = if (idioma == "PT") "Registar Empréstimo" else "Register Loan",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    // Credit or Debit segment
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { isCredit = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCredit) Color(0xFF2E7D32) else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isCredit) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (idioma == "PT") "Crédito (Emprestei)" else "Credit (Lent)")
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Button(
                            onClick = { isCredit = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isCredit) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (!isCredit) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (idioma == "PT") "Débito (Tomei)" else "Debit (Borrowed)")
                        }
                    }

                    // Account / Wallet Selection for Loan Dispersal / Borrowing
                    Text(
                        text = if (isCredit) (if (idioma == "PT") "Conta de onde sai o dinheiro:" else "Source Account / Wallet:") else (if (idioma == "PT") "Conta que recebe o dinheiro:" else "Destination Account / Wallet:"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { accountDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    selectedAccountWallet?.let {
                                        AppIcon(iconKey = it.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                    }
                                    Text(
                                        text = selectedAccountWallet?.let { "${it.nome} (${com.example.util.MoneyFormatter.format(it.saldoAtual, settings.moedaPadrao)})" } ?: (if (idioma == "PT") "Selecionar Conta" else "Select Account"),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
                            }
                        }
                        DropdownMenu(
                            expanded = accountDropdownExpanded,
                            onDismissRequest = { accountDropdownExpanded = false }
                        ) {
                            wallets.filter { it.ativa }.forEach { w ->
                                DropdownMenuItem(
                                    leadingIcon = {
                                        AppIcon(iconKey = w.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                    },
                                    text = { Text("${w.nome} (${com.example.util.MoneyFormatter.format(w.saldoAtual, settings.moedaPadrao)})") },
                                    onClick = {
                                        selectedAccountWallet = w
                                        accountDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Counterparty field with contact import button and phone input
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = counterparty,
                            onValueChange = { counterparty = it },
                            label = { Text(if (idioma == "PT") "Credor / Devedor" else "Creditor / Debtor Name") },
                            trailingIcon = {
                                IconButton(onClick = {
                                    try {
                                        pickContactLauncher.launch(null)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, if (idioma == "PT") "Não foi possível abrir os contactos" else "Could not open contacts", Toast.LENGTH_SHORT).show()
                                    }
                                }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Contacts,
                                        contentDescription = "Importar Contacto",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("loan_counterparty_input")
                        )

                        OutlinedTextField(
                            value = counterpartyPhone,
                            onValueChange = { counterpartyPhone = it },
                            label = { Text(if (idioma == "PT") "Telefone / Contacto Directo" else "Phone / Direct Contact") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            leadingIcon = { Icon(Icons.Rounded.Phone, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("loan_counterparty_phone_input")
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(listOf("João Silva", "Maria Santos", "Mercearia VIP", "Agente M-Pesa", "Empresa X")) { suggestName ->
                                FilterChip(
                                    selected = counterparty == suggestName,
                                    onClick = { counterparty = suggestName },
                                    label = { Text(suggestName, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = principalStr,
                        onValueChange = { principalStr = sanitizeDoubleInput(principalStr, it) },
                        label = { Text(if (idioma == "PT") "Valor Principal (MZN)" else "Principal Amount (MZN)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("loan_principal_input")
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = interestRateStr,
                            onValueChange = { interestRateStr = sanitizeDoubleInput(interestRateStr, it) },
                            label = { Text(if (idioma == "PT") "Juro Mensal (%)" else "Monthly Interest (%)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = penaltyStr,
                            onValueChange = { penaltyStr = sanitizeDoubleInput(penaltyStr, it) },
                            label = { Text(if (idioma == "PT") "Multa/Mora (%)" else "Penalty (%)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Interest Type selection
                    Text(if (idioma == "PT") "Tipo de Juro:" else "Interest Type:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        FilterChip(
                            selected = interestType == "Simples",
                            onClick = { interestType = "Simples" },
                            label = { Text(if (idioma == "PT") "Juros Simples" else "Simple Interest") }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        FilterChip(
                            selected = interestType == "Composto",
                            onClick = { interestType = "Composto" },
                            label = { Text(if (idioma == "PT") "Juros Compostos" else "Compound Interest") }
                        )
                    }

                    OutlinedTextField(
                        value = installmentCountStr,
                        onValueChange = { input ->
                            val digits = input.filter { it.isDigit() }
                            val sanitized = if (digits.length > installmentCountStr.length) {
                                val added = digits.substring(installmentCountStr.length)
                                if (added.length == 2 && added[0] == added[1]) {
                                    installmentCountStr + added[0]
                                } else {
                                    digits
                                }
                            } else {
                                digits
                            }
                            installmentCountStr = sanitized
                        },
                        label = { Text(if (idioma == "PT") "Número de Parcelas" else "Number of Installments") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    val context = LocalContext.current
                    val isPt = idioma == "PT"
                    val pickerLocale = if (isPt) java.util.Locale.forLanguageTag("pt-PT") else java.util.Locale.US
                    java.util.Locale.setDefault(pickerLocale)
                    val pickerConfig = android.content.res.Configuration(context.resources.configuration).apply {
                        setLocale(pickerLocale)
                    }
                    val localizedContext = context.createConfigurationContext(pickerConfig)
                    val calendar = java.util.Calendar.getInstance()
                    val datePickerDialog = android.app.DatePickerDialog(
                        context,
                        { _, year, month, dayOfMonth ->
                            val selectedCal = java.util.Calendar.getInstance().apply {
                                set(java.util.Calendar.YEAR, year)
                                set(java.util.Calendar.MONTH, month)
                                set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth)
                                set(java.util.Calendar.HOUR_OF_DAY, 23)
                                set(java.util.Calendar.MINUTE, 59)
                                set(java.util.Calendar.SECOND, 59)
                            }
                            val ms = selectedCal.timeInMillis
                            val diffMs = ms - System.currentTimeMillis()
                            val calculatedDays = (diffMs / 86400000L).coerceAtLeast(1L)
                            dueDaysStr = calculatedDays.toString()
                            selectedLoanDueDateMs = ms
                        },
                        calendar.get(java.util.Calendar.YEAR),
                        calendar.get(java.util.Calendar.MONTH),
                        calendar.get(java.util.Calendar.DAY_OF_MONTH)
                    )

                    val displayDateStr = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(selectedLoanDueDateMs ?: System.currentTimeMillis()))
                    Box(modifier = Modifier.fillMaxWidth().clickable { datePickerDialog.show() }) {
                        OutlinedTextField(
                            value = "$displayDateStr ($dueDaysStr " + (if (idioma == "PT") "dias" else "days") + ")",
                            onValueChange = {},
                            label = { Text(if (idioma == "PT") "Prazo Vencimento (Calendário)" else "Due Date (Calendar)") },
                            readOnly = true,
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            trailingIcon = { Icon(Icons.Rounded.DateRange, null) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // REAL-TIME INSTALLMENT SIMULATOR CARD
                    val principalVal = principalStr.toDoubleOrNull() ?: 0.0
                    if (principalVal > 0.0) {
                        val rateVal = interestRateStr.toDoubleOrNull() ?: 0.0
                        val instCountVal = (installmentCountStr.toIntOrNull() ?: 1).coerceAtLeast(1)
                        val totalInterest = if (interestType == "Composto") {
                            principalVal * (Math.pow(1.0 + (rateVal / 100.0), instCountVal.toDouble()) - 1.0)
                        } else {
                            principalVal * (rateVal / 100.0)
                        }
                        val grandTotal = principalVal + totalInterest
                        val perInstallment = grandTotal / instCountVal

                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Simulação em Tempo Real" else "Real-Time Simulation",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "$instCountVal " + (if (idioma == "PT") "parcela(s)" else "installment(s)"),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(if (idioma == "PT") "Valor por Parcela:" else "Per Installment:", fontSize = 12.sp)
                                    Text("${String.format("%,.2f", perInstallment)} MZN", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(if (idioma == "PT") "Juros Totais:" else "Total Interest:", fontSize = 12.sp)
                                    Text("${String.format("%,.2f", totalInterest)} MZN", fontSize = 12.sp)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(if (idioma == "PT") "Total a Pagar/Receber:" else "Grand Total:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("${String.format("%,.2f", grandTotal)} MZN", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAddLoanModal = false }) {
                            Text(Translator.t("cancel", idioma))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val amt = principalStr.toDoubleOrNull() ?: 0.0
                                val rate = interestRateStr.toDoubleOrNull() ?: 0.0
                                val penalty = penaltyStr.toDoubleOrNull() ?: 0.0
                                val instCount = installmentCountStr.toIntOrNull() ?: 1

                                if (counterparty.isNotBlank() && amt > 0.0) {
                                    val finalCounterparty = if (counterpartyPhone.isNotBlank()) "$counterparty ($counterpartyPhone)" else counterparty
                                    viewModel.createLoan(
                                        counterparty = finalCounterparty,
                                        principalAmount = amt,
                                        interestRate = rate,
                                        interestType = interestType,
                                        penaltyPercentage = penalty,
                                        installmentCount = instCount,
                                        dueDate = selectedLoanDueDateMs ?: (System.currentTimeMillis() + (30L * 24L * 60L * 60L * 1000L)),
                                        isCredit = isCredit,
                                        walletId = selectedAccountWallet?.id
                                    )
                                    showAddLoanModal = false
                                    TactileFeedbackHelper.triggerSuccessHaptic(haptic, context, scope)
                                    tactileState = TactileSuccessState(
                                        visible = true,
                                        title = if (isCredit) {
                                            if (idioma == "PT") "Empréstimo Concedido" else "Loan Granted"
                                        } else {
                                            if (idioma == "PT") "Empréstimo Recebido" else "Loan Received"
                                        },
                                        detail = finalCounterparty,
                                        amount = "MT ${String.format(Locale.getDefault(), "%,.2f", amt)}",
                                        color = Color(0xFF3B82F6),
                                        icon = Icons.Rounded.AccountBalance
                                    )
                                } else {
                                    Toast.makeText(context, if (idioma == "PT") "Preencha os dados obrigatórios!" else "Fill mandatory fields!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Text(Translator.t("save", idioma))
                        }
                    }
                }
            }
        }
    }

    // Modal to execute payment of installment
    if (showPaymentDialogForInstallment != null) {
        val inst = showPaymentDialogForInstallment!!
        Dialog(onDismissRequest = { showPaymentDialogForInstallment = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(if (idioma == "PT") "Confirmar Pagamento de Parcela" else "Confirm Installment Payment", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    
                    OutlinedTextField(
                        value = paymentAmountStr,
                        onValueChange = { paymentAmountStr = it },
                        label = { Text(if (idioma == "PT") "Valor a Pagar (MZN)" else "Payment Amount (MZN)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("installment_payment_input")
                    )

                    // Wallet selection
                    Text(
                        text = if (idioma == "PT") "Conta de Destino/Origem:" else "Source/Destination Account:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { walletDropdownOpen = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    selectedWalletForPayment?.let {
                                        AppIcon(iconKey = it.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                    }
                                    Text(
                                        text = selectedWalletForPayment?.let { "${it.nome} (${com.example.util.MoneyFormatter.format(it.saldoAtual, settings.moedaPadrao)})" }
                                            ?: (if (idioma == "PT") "Escolha a conta" else "Select account"),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 14.sp
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Rounded.ArrowDropDown,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = walletDropdownOpen,
                            onDismissRequest = { walletDropdownOpen = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            wallets.forEach { w ->
                                DropdownMenuItem(
                                    leadingIcon = {
                                        AppIcon(iconKey = w.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                    },
                                    text = {
                                        Text(
                                            text = "${w.nome} (${com.example.util.MoneyFormatter.format(w.saldoAtual, settings.moedaPadrao)})",
                                            fontSize = 14.sp
                                        )
                                    },
                                    onClick = {
                                        selectedWalletForPayment = w
                                        walletDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showPaymentDialogForInstallment = null }) {
                            Text(Translator.t("cancel", idioma))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val payAmt = paymentAmountStr.toDoubleOrNull() ?: 0.0
                                val parentLoan = groupedLoansList.find { it.loan.id == inst.parentId }?.loan
                                val isLoanCredit = parentLoan?.isCredit ?: true

                                if (payAmt > 0.0 && selectedWalletForPayment != null) {
                                    viewModel.payLoanInstallment(
                                        installment = inst,
                                        amount = payAmt,
                                        walletId = selectedWalletForPayment!!.id,
                                        isCredit = isLoanCredit
                                    )
                                    showPaymentDialogForInstallment = null
                                    TactileFeedbackHelper.triggerSuccessHaptic(haptic, context, scope)
                                    tactileState = TactileSuccessState(
                                        visible = true,
                                        title = if (idioma == "PT") "Pagamento de Parcela Efetuado" else "Installment Payment Completed",
                                        detail = "${selectedWalletForPayment!!.nome} • ${parentLoan?.counterparty ?: ""}",
                                        amount = "MT ${String.format(Locale.getDefault(), "%,.2f", payAmt)}",
                                        color = Color(0xFF10B981),
                                        icon = Icons.Rounded.CheckCircle
                                    )
                                } else {
                                    Toast.makeText(context, if (idioma == "PT") "Selecione uma conta e insira um valor válido!" else "Select an account and enter a valid amount!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = themeColor)
                        ) {
                            Text(if (idioma == "PT") "Confirmar" else "Confirm")
                        }
                    }
                }
            }
        }
    }

    if (editingLoan != null) {
        EditLoanDialog(
            loan = editingLoan!!,
            settings = settings,
            onDismiss = { editingLoan = null },
            onConfirm = { updatedLoan ->
                viewModel.updateLoan(updatedLoan)
                editingLoan = null
                Toast.makeText(context, if (idioma == "PT") "Empréstimo atualizado!" else "Loan updated!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showLoanSimulatorModal) {
        Dialog(onDismissRequest = { showLoanSimulatorModal = false }) {
            Card(
                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.85f).padding(12.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") "Simulador de Juros" else "Interest Simulator",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color(0xFF2E7D32)
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    var principalStr by remember { mutableStateOf("0") }
                    var interestRateStr by remember { mutableStateOf("0") }
                    var installmentsStr by remember { mutableStateOf("0") }
                    var selectedSystem by remember { mutableStateOf("PRICE") } // PRICE, SAC, SIMPLE, COMPOUND

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = principalStr,
                            onValueChange = { principalStr = it },
                            label = { Text(if (idioma == "PT") "Valor (MZN)" else "Amount (MZN)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = interestRateStr,
                            onValueChange = { interestRateStr = it },
                            label = { Text(if (idioma == "PT") "Taxa (% a.a.)" else "Rate (% p.a.)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = installmentsStr,
                            onValueChange = { installmentsStr = it },
                            label = { Text(if (idioma == "PT") "Meses" else "Months", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(0.8f)
                        )
                    }

                    // Amortization System selection chips
                    Text(
                        text = if (idioma == "PT") "Tipo de Juros / Amortização:" else "Interest System:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            Triple("SIMPLES", if (idioma == "PT") "Juros Simples" else "Simple Interest", "J. Simples"),
                            Triple("COMPOSTOS", if (idioma == "PT") "Juros Compostos" else "Compound Interest", "J. Compostos"),
                            Triple("PRICE", "PRICE", "PRICE"),
                            Triple("SAC", "SAC", "SAC")
                        ).forEach { (sysKey, sysLabelFull, sysLabelShort) ->
                            val isSelected = selectedSystem == sysKey
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) Color(0xFF2E7D32) else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { selectedSystem = sysKey }
                                    .padding(vertical = 8.dp, horizontal = 2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = sysLabelShort,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    // Calculate Schedule & Exact Totals
                    val principal = principalStr.toDoubleOrNull() ?: 0.0
                    val rateYear = interestRateStr.toDoubleOrNull() ?: 0.0
                    val months = installmentsStr.toIntOrNull() ?: 0
                    val rateMonth = (rateYear / 12.0) / 100.0

                    val (totalPaySum, totalInterestSum, firstInstallmentVal) = remember(principal, rateYear, months, selectedSystem) {
                        if (principal <= 0.0 || months <= 0) {
                            Triple(0.0, 0.0, 0.0)
                        } else {
                            when (selectedSystem) {
                                "SIMPLES" -> {
                                    val totalInterest = principal * (rateYear / 100.0) * (months / 12.0)
                                    val totalPay = principal + totalInterest
                                    Triple(totalPay, totalInterest, totalPay / months)
                                }
                                "COMPOSTOS" -> {
                                    val totalPay = principal * Math.pow(1.0 + rateMonth, months.toDouble())
                                    val totalInterest = Math.max(0.0, totalPay - principal)
                                    Triple(totalPay, totalInterest, totalPay / months)
                                }
                                "SAC" -> {
                                    val totalInterest = principal * rateMonth * (months + 1) / 2.0
                                    val totalPay = principal + totalInterest
                                    val firstInst = (principal / months) + (principal * rateMonth)
                                    Triple(totalPay, totalInterest, firstInst)
                                }
                                else -> { // PRICE
                                    val firstInst = if (rateMonth == 0.0) principal / months
                                    else principal * (rateMonth * Math.pow(1.0 + rateMonth, months.toDouble())) / (Math.pow(1.0 + rateMonth, months.toDouble()) - 1.0)
                                    val totalPay = firstInst * months
                                    val totalInterest = Math.max(0.0, totalPay - principal)
                                    Triple(totalPay, totalInterest, firstInst)
                                }
                            }
                        }
                    }

                    val scheduleList = remember(principal, rateYear, months, selectedSystem) {
                        val list = mutableListOf<Triple<Int, Double, Double>>()
                        if (principal > 0.0 && months > 0) {
                            val maxDisplay = Math.min(months, 420) // Smooth schedule preview up to 35 years (420 months) in table
                            when (selectedSystem) {
                                "SIMPLES" -> {
                                    val totalInterest = principal * (rateYear / 100.0) * (months / 12.0)
                                    val totalPay = principal + totalInterest
                                    val inst = totalPay / months
                                    for (i in 1..maxDisplay) {
                                        list.add(Triple(i, inst, Math.max(0.0, totalPay - (inst * i))))
                                    }
                                }
                                "COMPOSTOS" -> {
                                    val totalPay = principal * Math.pow(1.0 + rateMonth, months.toDouble())
                                    val inst = totalPay / months
                                    for (i in 1..maxDisplay) {
                                        list.add(Triple(i, inst, Math.max(0.0, totalPay - (inst * i))))
                                    }
                                }
                                "SAC" -> {
                                    val amort = principal / months
                                    var balance = principal
                                    for (i in 1..maxDisplay) {
                                        val interest = balance * rateMonth
                                        val inst = amort + interest
                                        balance -= amort
                                        list.add(Triple(i, inst, Math.max(0.0, balance)))
                                    }
                                }
                                else -> { // PRICE
                                    if (rateMonth == 0.0) {
                                        val inst = principal / months
                                        for (i in 1..maxDisplay) {
                                            list.add(Triple(i, inst, Math.max(0.0, principal - (inst * i))))
                                        }
                                    } else {
                                        val inst = principal * (rateMonth * Math.pow(1.0 + rateMonth, months.toDouble())) / (Math.pow(1.0 + rateMonth, months.toDouble()) - 1.0)
                                        var balance = principal
                                        for (i in 1..maxDisplay) {
                                            val interest = balance * rateMonth
                                            val amort = inst - interest
                                            balance -= amort
                                            list.add(Triple(i, inst, Math.max(0.0, balance)))
                                        }
                                    }
                                }
                            }
                        }
                        list
                    }

                    // KPI Summary Cards
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFDCFCE7)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    if (idioma == "PT") "Total a Pagar" else "Total Payment",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF166534)
                                )
                                Text(
                                    "${String.format("%,.2f", totalPaySum)} MZN",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFFEDD5)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    if (idioma == "PT") "Total Juros" else "Total Interest",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF9A3412)
                                )
                                Text(
                                    "${String.format("%,.2f", totalInterestSum)} MZN",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFC2410C)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFE0F2FE)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    if (idioma == "PT") "Parcela (1ª)" else "Installment",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF075985)
                                )
                                Text(
                                    "${String.format("%,.2f", firstInstallmentVal)} MZN",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0284C7)
                                )
                            }
                        }
                    }

                    // Schedule Table
                    Text(
                        text = if (idioma == "PT") "Plano de Amortização Projetado:" else "Projected Amortization Plan:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    ) {
                        LazyColumn(
                            modifier = Modifier.padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Mes", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("Parcela", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("Saldo Restante", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                            }

                            items(scheduleList, key = { it.first }) { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("#${item.first}", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                    Text("${String.format("%,.2f", item.second)} MZN", fontSize = 11.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                    Text("${String.format("%,.2f", item.third)} MZN", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { showLoanSimulatorModal = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Fechar")
                        }
                    }
                }
            }
        }
    }

    TactileSuccessBannerOverlay(
        state = tactileState,
        onDismiss = { tactileState = tactileState.copy(visible = false) }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditLoanDialog(
    loan: Loan,
    settings: UserSettings,
    onDismiss: () -> Unit,
    onConfirm: (Loan) -> Unit
) {
    var counterparty by remember { mutableStateOf(loan.counterparty) }
    var interestRateStr by remember { mutableStateOf(loan.interestRate.toString()) }
    var penaltyRateStr by remember { mutableStateOf(loan.penaltyPercentage.toString()) }
    var selectedLoanDueDateMs by remember { mutableStateOf(loan.dueDate) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = if (settings.idioma == "PT") "Editar Empréstimo" else "Edit Loan",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = counterparty,
                    onValueChange = { counterparty = it },
                    label = { Text(if (settings.idioma == "PT") "Contraparte" else "Counterparty") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = interestRateStr,
                    onValueChange = { interestRateStr = it },
                    label = { Text(if (settings.idioma == "PT") "Taxa de Juros (%)" else "Interest Rate (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = penaltyRateStr,
                    onValueChange = { penaltyRateStr = it },
                    label = { Text(if (settings.idioma == "PT") "Multa por Atraso (%)" else "Late Penalty (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                // Date Picker for due date
                val context = LocalContext.current
                val isPt = settings.idioma == "PT"
                val pickerLocale = if (isPt) java.util.Locale.forLanguageTag("pt-PT") else java.util.Locale.US
                java.util.Locale.setDefault(pickerLocale)
                val pickerConfig = android.content.res.Configuration(context.resources.configuration).apply {
                    setLocale(pickerLocale)
                }
                val localizedContext = context.createConfigurationContext(pickerConfig)
                val calendar = java.util.Calendar.getInstance().apply {
                    timeInMillis = selectedLoanDueDateMs
                }
                val datePickerDialog = android.app.DatePickerDialog(
                    context,
                    { _, year, month, dayOfMonth ->
                        val selectedCal = java.util.Calendar.getInstance().apply {
                            set(java.util.Calendar.YEAR, year)
                            set(java.util.Calendar.MONTH, month)
                            set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth)
                            set(java.util.Calendar.HOUR_OF_DAY, 23)
                            set(java.util.Calendar.MINUTE, 59)
                            set(java.util.Calendar.SECOND, 59)
                        }
                        selectedLoanDueDateMs = selectedCal.timeInMillis
                    },
                    calendar.get(java.util.Calendar.YEAR),
                    calendar.get(java.util.Calendar.MONTH),
                    calendar.get(java.util.Calendar.DAY_OF_MONTH)
                )

                val displayDateStr = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(selectedLoanDueDateMs))

                OutlinedButton(
                    onClick = { datePickerDialog.show() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Rounded.CalendarToday, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = if (settings.idioma == "PT") "Data de Vencimento: $displayDateStr" else "Due Date: $displayDateStr")
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(if (settings.idioma == "PT") "Cancelar" else "Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val interest = interestRateStr.toDoubleOrNull() ?: loan.interestRate
                            val penalty = penaltyRateStr.toDoubleOrNull() ?: loan.penaltyPercentage
                            if (counterparty.isNotBlank()) {
                                val updated = loan.copy(
                                    counterparty = counterparty,
                                    interestRate = interest,
                                    penaltyPercentage = penalty,
                                    dueDate = selectedLoanDueDateMs
                                )
                                onConfirm(updated)
                                onDismiss()
                            }
                        }
                    ) {
                        Text(if (settings.idioma == "PT") "Guardar" else "Save")
                    }
                }
            }
        }
    }
}

// ------------------- TELA: DETALHES DE EMPRÉSTIMO HIGH-FIDELITY -------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoanDetailsScreen(
    viewModel: MainViewModel,
    loan: Loan,
    wallets: List<Wallet>,
    settings: UserSettings,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val idioma = settings.idioma
    val groupedLoansList by viewModel.groupedLoans.collectAsStateWithLifecycle(emptyList())
    
    // Dynamically retrieve the latest data for this loan
    val currentGroupedLoan = groupedLoansList.firstOrNull { it.loan.id == loan.id }
    val activeLoan = currentGroupedLoan?.loan ?: loan
    val installments = currentGroupedLoan?.installments ?: emptyList()
    
    val receiptsState = viewModel.getLoanReceipts(activeLoan.id).collectAsStateWithLifecycle(initialValue = emptyList())
    val receipts = receiptsState.value
    var fullScreenImageUri by remember { mutableStateOf<String?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.addLoanReceipt(activeLoan.id, uri.toString())
            Toast.makeText(context, if (idioma == "PT") "Comprovativo anexado!" else "Receipt attached!", Toast.LENGTH_SHORT).show()
        }
    }
    
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: android.graphics.Bitmap? ->
        if (bitmap != null) {
            val uri = saveBitmapToCache(context, bitmap)
            viewModel.addLoanReceipt(activeLoan.id, uri.toString())
            Toast.makeText(context, if (idioma == "PT") "Foto tirada com sucesso!" else "Photo taken successfully!", Toast.LENGTH_SHORT).show()
        }
    }
    
    // Modal states
    var editingLoan by remember { mutableStateOf<Loan?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var menuExpanded by remember { mutableStateOf(false) }
    
    // Tab State
    var selectedTab by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(0) } // 0: Resumo, 1: Parcelas, 2: Documentos, 3: Atividades
    
    // Installment expanded states (for tab 1)
    val expandedInstallments = remember { mutableStateMapOf<Int, Boolean>() }
    
    // Payment dialog states
    var showPaymentDialogForInstallment by remember { mutableStateOf<Installment?>(null) }
    var paymentAmountStr by remember { mutableStateOf("") }
    var selectedWalletForPayment by remember { mutableStateOf<Wallet?>(null) }
    var walletDropdownOpen by remember { mutableStateOf(false) }

    // Colors
    val isDark = settings.tema == "dark"
    val themePrimary = Color(0xFF087A35) // Verde principal
    val backgroundColor = if (isDark) Color(0xFF111413) else Color(0xFFF8FAF9) // Fundo suave
    val cardBg = if (isDark) Color(0xFF1B1E1C) else Color(0xFFFFFFFF)
    val textPrimary = if (isDark) Color(0xFFE2EAF4) else Color(0xFF172033) // Texto principal
    val textSecondary = if (isDark) Color(0xFF8895A7) else Color(0xFF667085) // Texto secundário
    val borderCol = if (isDark) Color(0xFF2B322D) else Color(0xFFEEF2EE)
    val dividerCol = if (isDark) Color(0xFF252927) else Color(0xFFEEF2EE)
    val surfaceVariantColor = if (isDark) Color(0xFF222624) else Color(0xFFF1F5F9)

    // Derived statistics
    val totalCount = installments.size
    val paidCount = installments.count { it.status == "PAID" || it.status == "Pago" }
    val currentInstallmentIndex = if (paidCount < totalCount) paidCount + 1 else totalCount
    
    val totalPaidAmount = installments.filter { it.status == "PAID" || it.status == "Pago" }.sumOf { it.totalPaid }
    val totalRemainingAmount = installments.sumOf { it.remainingBalance }
    val totalLoanAmount = totalPaidAmount + totalRemainingAmount
    
    val progress = if (totalLoanAmount > 0) (totalPaidAmount / totalLoanAmount).toFloat().coerceIn(0f, 1f) else 1f
    
    val isPaidOff = activeLoan.status == "PAID" || totalRemainingAmount <= 0.0
    val isOverdue = installments.any { it.status != "PAID" && it.status != "Pago" && it.dueDate < System.currentTimeMillis() }
    
    val firstInstallmentAmount = installments.firstOrNull()?.let { it.remainingBalance + it.totalPaid } ?: (activeLoan.principalAmount / if (totalCount > 0) totalCount else 1)

    // Main Layout
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Empréstimo #${String.format("%03d", activeLoan.id)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = textPrimary
                        )
                        Text(
                            text = if (idioma == "PT") "Detalhes da operação" else "Operation details",
                            fontSize = 12.sp,
                            color = textSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = textPrimary
                        )
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(
                                imageVector = Icons.Rounded.MoreVert,
                                contentDescription = "More options",
                                tint = textPrimary
                            )
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(if (idioma == "PT") "Editar" else "Edit") },
                                onClick = {
                                    editingLoan = activeLoan
                                    menuExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (idioma == "PT") "Excluir" else "Delete") },
                                onClick = {
                                    showDeleteConfirm = true
                                    menuExpanded = false
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = backgroundColor
                )
            )
        },
        bottomBar = {
            // Persistent Bottom Action Bar (only if operation is not fully paid)
            if (!isPaidOff) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = cardBg,
                    border = BorderStroke(1.dp, borderCol)
                ) {
                    Row(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Compartilhar Button
                        OutlinedButton(
                            onClick = {
                                val summary = buildString {
                                    appendLine("*Resumo de Empréstimo #${String.format("%03d", activeLoan.id)}*")
                                    appendLine("Contraparte: ${activeLoan.counterparty}")
                                    appendLine("Tipo: ${if (activeLoan.isCredit) "Crédito" else "Débito"}")
                                    appendLine("Total: ${String.format("%,.2f", totalLoanAmount)} MZN")
                                    appendLine("Pago: ${String.format("%,.2f", totalPaidAmount)} MZN")
                                    appendLine("Progresso: ${(progress * 100).toInt()}%")
                                    appendLine("Status: ${if (isOverdue) "Atrasado" else "Em Dia"}")
                                }
                                val clipboardManager = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                clipboardManager.setPrimaryClip(android.content.ClipData.newPlainText("Empréstimo", summary))
                                Toast.makeText(context, if (idioma == "PT") "Resumo copiado para a área de transferência!" else "Summary copied to clipboard!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = themePrimary
                            ),
                            border = BorderStroke(1.dp, themePrimary)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (idioma == "PT") "Compartilhar" else "Share",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        // Pagar Parcela Button
                        Button(
                            onClick = {
                                // Find next pending installment
                                val nextPending = installments.firstOrNull { it.status == "PENDING" }
                                if (nextPending != null) {
                                    showPaymentDialogForInstallment = nextPending
                                    paymentAmountStr = nextPending.remainingBalance.toString()
                                    selectedWalletForPayment = wallets.firstOrNull()
                                } else {
                                    Toast.makeText(context, if (idioma == "PT") "Todas as parcelas já estão pagas!" else "All installments already paid!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = themePrimary,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Payment,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (idioma == "PT") "Pagar parcela" else "Pay installment",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        },
        containerColor = backgroundColor
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // ------------------- TABS NAVIGATION -------------------
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = backgroundColor,
                contentColor = themePrimary,
                edgePadding = 16.dp,
                divider = { HorizontalDivider(color = dividerCol) },
                indicator = { tabPositions ->
                    if (selectedTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = with(TabRowDefaults) { Modifier.tabIndicatorOffset(tabPositions[selectedTab]) },
                            color = themePrimary,
                            height = 3.dp
                        )
                    }
                }
            ) {
                val tabLabels = listOf(
                    if (idioma == "PT") "Resumo" else "Summary",
                    if (idioma == "PT") "Parcelas" else "Installments",
                    if (idioma == "PT") "Documentos" else "Documents",
                    if (idioma == "PT") "Atividades" else "Activities"
                )
                val tabIcons = listOf(
                    Icons.Rounded.Description,
                    Icons.Rounded.CalendarToday,
                    Icons.Rounded.FolderShared,
                    Icons.Rounded.History
                )

                tabLabels.forEachIndexed { index, label ->
                    val isSelected = selectedTab == index
                    Tab(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = label,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) themePrimary else textSecondary
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = tabIcons[index],
                                contentDescription = null,
                                tint = if (isSelected) themePrimary else textSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    )
                }
            }

            // ------------------- TAB CONTENT -------------------
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        // --- RESUMO TAB ---
                        // 1. Cabeçalho Visual (Wallet Icon, Status Badge, Title, Subtitle)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(themePrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Column(
                                modifier = Modifier
                                    .padding(start = 16.dp)
                                    .weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Ativo/Pago badge
                                    val badgeText = if (isPaidOff) {
                                        if (idioma == "PT") "Pago" else "Paid"
                                    } else if (isOverdue) {
                                        if (idioma == "PT") "Em atraso" else "Overdue"
                                    } else {
                                        if (idioma == "PT") "Ativo" else "Active"
                                    }
                                    val badgeBg = if (isPaidOff) Color(0xFFE8F5E9) else if (isOverdue) Color(0xFFFFF5F5) else Color(0xFFEBF8EE)
                                    val badgeColor = if (isPaidOff) Color(0xFF2E7D32) else if (isOverdue) Color(0xFFD32F2F) else themePrimary
                                    
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(badgeBg)
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = badgeText,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = badgeColor
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Empréstimo #${String.format("%03d", activeLoan.id)}",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textPrimary
                                )
                                Text(
                                    text = activeLoan.counterparty,
                                    fontSize = 14.sp,
                                    color = textSecondary
                                )
                            }
                        }

                        // 2. Card Principal
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            border = BorderStroke(1.dp, borderCol)
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = if (activeLoan.isCredit) {
                                                if (idioma == "PT") "Valor total a receber" else "Total value to receive"
                                            } else {
                                                if (idioma == "PT") "Valor total a pagar" else "Total value to pay"
                                            },
                                            fontSize = 12.sp,
                                            color = textSecondary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${String.format("%,.2f", totalRemainingAmount)} MZN",
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = themePrimary
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = if (idioma == "PT") "Parcela atual" else "Current installment",
                                            fontSize = 12.sp,
                                            color = textSecondary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = if (isPaidOff) {
                                                if (idioma == "PT") "Pago" else "Paid"
                                            } else {
                                                "$currentInstallmentIndex de $totalCount"
                                            },
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = textPrimary
                                        )
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Progresso de pagamento" else "Payment progress",
                                        fontSize = 12.sp,
                                        color = textSecondary
                                    )
                                    Text(
                                        text = "${(progress * 100).toInt()}%",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = textPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = themePrimary,
                                    trackColor = if (isDark) Color(0xFF222624) else Color(0xFFEBF8EE)
                                )
                            }
                        }

                        // 3. Resumo da Operação
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            border = BorderStroke(1.dp, borderCol)
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Description,
                                        contentDescription = null,
                                        tint = themePrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = if (idioma == "PT") "Resumo da operação" else "Operation summary",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = textPrimary
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider(color = dividerCol)
                                Spacer(modifier = Modifier.height(12.dp))

                                val opDateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(activeLoan.transactionDate))
                                val duDateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(activeLoan.dueDate))

                                val fields = listOf(
                                    (if (idioma == "PT") "Tipo de operação" else "Operation type") to (if (activeLoan.isCredit) (if (idioma == "PT") "Crédito" else "Credit") else (if (idioma == "PT") "Débito" else "Debit")),
                                    (if (idioma == "PT") "Data da criação" else "Creation date") to opDateStr,
                                    (if (idioma == "PT") "Vencimento" else "Due Date") to duDateStr,
                                    (if (idioma == "PT") "Total de parcelas" else "Total installments") to (if (totalCount == 1) (if (idioma == "PT") "1 parcela" else "1 installment") else "$totalCount " + (if (idioma == "PT") "parcelas" else "installments")),
                                    (if (idioma == "PT") "Valor da parcela" else "Installment value") to "${String.format("%,.2f", firstInstallmentAmount)} MZN",
                                    (if (idioma == "PT") "Taxa de juros" else "Interest rate") to "${activeLoan.interestRate}%",
                                    (if (idioma == "PT") "Finalidade" else "Purpose") to (if (idioma == "PT") "Pessoal" else "Personal")
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    fields.forEach { (label, value) ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = label,
                                                fontSize = 14.sp,
                                                color = textSecondary
                                            )
                                            Text(
                                                text = value,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textPrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // 4. Status da Operação
                        val alertBg = if (isOverdue) Color(0xFFFFF5F5) else Color(0xFFEBF8EE)
                        val alertBorder = if (isOverdue) Color(0xFFFCA5A5) else Color(0xFF86EFAC)
                        
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = alertBg),
                            border = BorderStroke(1.dp, alertBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isOverdue) Color(0xFFFEE2E2) else Color(0xFFD1FAE5)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isOverdue) Icons.Rounded.Warning else Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = if (isOverdue) Color(0xFFD32F2F) else Color(0xFF2E7D32),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = if (isOverdue) (if (idioma == "PT") "Em atraso" else "Overdue") else (if (idioma == "PT") "Em dia" else "In order"),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isOverdue) Color(0xFF991B1B) else Color(0xFF166534)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (isOverdue) {
                                            if (idioma == "PT") "Existe uma parcela pendente." else "There is a pending installment."
                                        } else {
                                            if (idioma == "PT") "Esta operação está em dia. Não há valores em atraso." else "This operation is in order. There are no overdue values."
                                        },
                                        fontSize = 12.sp,
                                        color = if (isOverdue) Color(0xFFB91C1C) else Color(0xFF15803D)
                                    )
                                }
                            }
                        }
                    }

                    1 -> {
                        // --- PARCELAS TAB (Cronograma) ---
                        Text(
                            text = if (idioma == "PT") "Cronograma de pagamento" else "Payment schedule",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = textPrimary,
                            modifier = Modifier.padding(top = 8.dp)
                        )

                        // 1. Mini Resumo de Pagamentos
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF161E1A) else Color(0xFFEBF8EE).copy(alpha = 0.5f)),
                            border = BorderStroke(1.dp, if (isDark) Color(0xFF233129) else Color(0xFF86EFAC).copy(alpha = 0.4f))
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = if (activeLoan.isCredit) (if (idioma == "PT") "Total a receber" else "Total to receive") else (if (idioma == "PT") "Total a pagar" else "Total to pay"),
                                            fontSize = 12.sp,
                                            color = textSecondary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${String.format("%,.2f", totalLoanAmount)} MZN",
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = themePrimary
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = if (idioma == "PT") "Total pago" else "Total paid",
                                            fontSize = 12.sp,
                                            color = textSecondary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${String.format("%,.2f", totalPaidAmount)} MZN",
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = themePrimary
                                        )
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Progresso" else "Progress",
                                        fontSize = 12.sp,
                                        color = textSecondary
                                    )
                                    Text(
                                        text = "${(progress * 100).toInt()}%",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = textPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = themePrimary,
                                    trackColor = if (isDark) Color(0xFF222624) else Color(0xFFD1FAE5)
                                )
                            }
                        }

                        // 2. Cronograma de Parcelas
                        installments.forEachIndexed { idx, inst ->
                            val isInstPaid = inst.status == "PAID" || inst.status == "Pago"
                            val isInstOverdue = !isInstPaid && inst.dueDate < System.currentTimeMillis()
                            val instDueDateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(inst.dueDate))
                            
                            val isExpanded = expandedInstallments[inst.id] == true

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expandedInstallments[inst.id] = !isExpanded },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = cardBg),
                                border = BorderStroke(1.dp, if (isExpanded) themePrimary else borderCol)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Circled Number
                                            Box(
                                                modifier = Modifier
                                                    .size(36.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isInstPaid) themePrimary else if (isInstOverdue) Color(0xFFD32F2F) else surfaceVariantColor),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = "${idx + 1}",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = if (isInstPaid || isInstOverdue) Color.White else textPrimary
                                                )
                                            }
                                            Column {
                                                Text(
                                                    text = if (idioma == "PT") "Parcela ${idx + 1} de $totalCount" else "Installment ${idx + 1} of $totalCount",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = textPrimary
                                                )
                                                Text(
                                                    text = instDueDateStr,
                                                    fontSize = 12.sp,
                                                    color = textSecondary
                                                )
                                            }
                                        }

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(horizontalAlignment = Alignment.End) {
                                                // Status badge
                                                val instBadgeText = if (isInstPaid) {
                                                    if (idioma == "PT") "Pago" else "Paid"
                                                } else if (isInstOverdue) {
                                                    if (idioma == "PT") "Atrasado" else "Overdue"
                                                } else {
                                                    if (idioma == "PT") "Pendente" else "Pending"
                                                }
                                                val instBadgeBg = if (isInstPaid) Color(0xFFEBF8EE) else if (isInstOverdue) Color(0xFFFFF5F5) else Color(0xFFFFF3E0)
                                                val instBadgeColor = if (isInstPaid) themePrimary else if (isInstOverdue) Color(0xFFD32F2F) else Color(0xFFE65100)

                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(instBadgeBg)
                                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = instBadgeText,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = instBadgeColor
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "${String.format("%,.2f", inst.remainingBalance + inst.totalPaid)} MZN",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = textPrimary
                                                )
                                            }
                                            Icon(
                                                imageVector = if (isExpanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                                                contentDescription = null,
                                                tint = textSecondary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    AnimatedVisibility(visible = isExpanded) {
                                        Column {
                                            Spacer(modifier = Modifier.height(16.dp))
                                            HorizontalDivider(color = dividerCol)
                                            Spacer(modifier = Modifier.height(12.dp))

                                            val details = listOf(
                                                (if (idioma == "PT") "Valor da parcela" else "Installment value") to "${String.format("%,.2f", inst.remainingBalance + inst.totalPaid)} MZN",
                                                (if (idioma == "PT") "Valor pago" else "Paid value") to "${String.format("%,.2f", inst.totalPaid)} MZN",
                                                (if (idioma == "PT") "Data do pagamento" else "Payment date") to (if (isInstPaid) instDueDateStr else "-"),
                                                (if (idioma == "PT") "Método de pagamento" else "Payment method") to (if (isInstPaid) (if (idioma == "PT") "Carteira Móvel" else "Mobile Wallet") else "-"),
                                                (if (idioma == "PT") "Observação" else "Remarks") to (if (isInstPaid) (if (idioma == "PT") "Pagamento realizado com sucesso." else "Payment completed successfully.") else (if (idioma == "PT") "Aguardando pagamento." else "Awaiting payment."))
                                            )

                                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                details.forEach { (lbl, valStr) ->
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(text = lbl, fontSize = 13.sp, color = textSecondary)
                                                        if (lbl.contains("Método") && isInstPaid) {
                                                            Row(
                                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Icon(
                                                                    imageVector = Icons.Rounded.CreditCard,
                                                                    contentDescription = null,
                                                                    tint = textSecondary,
                                                                    modifier = Modifier.size(14.dp)
                                                                )
                                                                Text(text = valStr, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                                                            }
                                                        } else {
                                                            Text(text = valStr, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                                                        }
                                                    }
                                                }
                                                
                                                // Quick payment button inside expanded installment if not paid!
                                                if (!isInstPaid) {
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Button(
                                                        onClick = {
                                                            showPaymentDialogForInstallment = inst
                                                            paymentAmountStr = inst.remainingBalance.toString()
                                                            selectedWalletForPayment = wallets.firstOrNull()
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = themePrimary),
                                                        modifier = Modifier.fillMaxWidth(),
                                                        shape = RoundedCornerShape(10.dp)
                                                    ) {
                                                        Text(if (idioma == "PT") "Pagar parcela" else "Pay installment")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // --- DOCUMENTOS TAB (Real interactive receipts gallery) ---
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = if (idioma == "PT") "Fotos e Comprovativos" else "Photos and Receipts",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = textPrimary
                                    )
                                    Text(
                                        text = if (idioma == "PT") "${receipts.size} fotos anexadas" else "${receipts.size} photos attached",
                                        fontSize = 12.sp,
                                        color = textSecondary
                                    )
                                }
                                
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconButton(
                                        onClick = { cameraLauncher.launch(null) },
                                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = surfaceVariantColor)
                                    ) {
                                        Icon(Icons.Rounded.PhotoCamera, contentDescription = "Camera", tint = themePrimary)
                                    }
                                    IconButton(
                                        onClick = { galleryLauncher.launch("image/*") },
                                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = surfaceVariantColor)
                                    ) {
                                        Icon(Icons.Rounded.Image, contentDescription = "Gallery", tint = themePrimary)
                                    }
                                }
                            }
                            
                            if (receipts.isEmpty()) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(80.dp)
                                            .clip(CircleShape)
                                            .background(surfaceVariantColor),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.FolderShared,
                                            contentDescription = null,
                                            tint = textSecondary,
                                            modifier = Modifier.size(40.dp)
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = if (idioma == "PT") "Nenhum documento anexado" else "No documents attached",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = textPrimary
                                        )
                                        Text(
                                            text = if (idioma == "PT") "Adicione fotos ou tire fotos dos comprovativos deste empréstimo." else "Add photos or take pictures of receipts for this loan.",
                                            fontSize = 12.sp,
                                            color = textSecondary,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(horizontal = 24.dp)
                                        )
                                    }
                                    
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { cameraLauncher.launch(null) },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = themePrimary),
                                            border = BorderStroke(1.dp, themePrimary)
                                        ) {
                                            Icon(Icons.Rounded.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(if (idioma == "PT") "Tirar Foto" else "Take Photo")
                                        }
                                        OutlinedButton(
                                            onClick = { galleryLauncher.launch("image/*") },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = themePrimary),
                                            border = BorderStroke(1.dp, themePrimary)
                                        ) {
                                            Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(if (idioma == "PT") "Galeria" else "Gallery")
                                        }
                                    }
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    val chunks = receipts.chunked(2)
                                    chunks.forEach { pair ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            pair.forEach { rec ->
                                                Card(
                                                    shape = RoundedCornerShape(12.dp),
                                                    colors = CardDefaults.cardColors(containerColor = cardBg),
                                                    border = BorderStroke(1.dp, borderCol),
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clickable { fullScreenImageUri = rec.imageUri }
                                                ) {
                                                    Box(modifier = Modifier.fillMaxWidth()) {
                                                        AsyncImage(
                                                            model = rec.imageUri,
                                                            contentDescription = null,
                                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .height(130.dp)
                                                        )
                                                        
                                                        IconButton(
                                                            onClick = { viewModel.deleteLoanReceipt(rec) },
                                                            modifier = Modifier
                                                                .align(Alignment.TopEnd)
                                                                .padding(4.dp)
                                                                .size(28.dp)
                                                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Rounded.Delete,
                                                                contentDescription = "Delete",
                                                                tint = Color.White,
                                                                modifier = Modifier.size(14.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                            if (pair.size < 2) {
                                                Spacer(modifier = Modifier.weight(1f))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (fullScreenImageUri != null) {
                            Dialog(onDismissRequest = { fullScreenImageUri = null }) {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = cardBg),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        AsyncImage(
                                            model = fullScreenImageUri,
                                            contentDescription = null,
                                            contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        IconButton(
                                            onClick = { fullScreenImageUri = null },
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(12.dp)
                                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                        ) {
                                            Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        // --- ATIVIDADES TAB ---
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = if (idioma == "PT") "Histórico de atividades" else "Activity history",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = textPrimary
                            )
                            
                            val creationDateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(activeLoan.transactionDate))
                            
                            // Activity 1: Creation
                            ActivityItem(
                                title = if (idioma == "PT") "Operação Registada" else "Operation Registered",
                                subtitle = if (idioma == "PT") "Empréstimo criado com sucesso no sistema" else "Loan successfully created in the system",
                                time = creationDateStr,
                                isLast = !isPaidOff && paidCount == 0,
                                isDark = isDark
                            )

                            // Payments
                            installments.forEachIndexed { i, inst ->
                                if (inst.status == "PAID" || inst.status == "Pago") {
                                    val payDateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(inst.dueDate))
                                    ActivityItem(
                                        title = if (idioma == "PT") "Pagamento da Parcela ${i + 1}" else "Payment of Installment ${i + 1}",
                                        subtitle = if (idioma == "PT") "Amortização parcial no valor de ${String.format("%,.2f", inst.totalPaid)} MZN" else "Partial payment of ${String.format("%,.2f", inst.totalPaid)} MZN",
                                        time = payDateStr,
                                        isLast = !isPaidOff && (i == paidCount - 1),
                                        isDark = isDark
                                    )
                                }
                            }

                            // Payoff
                            if (isPaidOff) {
                                val poDate = activeLoan.paidOffDate ?: activeLoan.dueDate
                                val payoffDateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(poDate))
                                ActivityItem(
                                    title = if (idioma == "PT") "Operação Liquidada" else "Operation Fully Paid",
                                    subtitle = if (idioma == "PT") "O empréstimo foi totalmente quitado e encerrado" else "The loan has been fully paid off and closed",
                                    time = payoffDateStr,
                                    isLast = true,
                                    isSuccess = true,
                                    isDark = isDark
                                )
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(80.dp)) // Extra scroll height
            }
        }
    }

    // --- REUSABLE DELETE CONFIRMATION DIALOG ---
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(if (idioma == "PT") "Confirmar Exclusão" else "Confirm Delete") },
            text = { Text(if (idioma == "PT") "Tem certeza de que deseja excluir este empréstimo? Todos os dados associados serão perdidos permanentemente." else "Are you sure you want to delete this loan? All associated data will be permanently lost.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteLoan(activeLoan)
                        showDeleteConfirm = false
                        onBack()
                        Toast.makeText(context, if (idioma == "PT") "Empréstimo excluído!" else "Loan deleted!", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text(if (idioma == "PT") "Excluir" else "Delete", color = Color(0xFFD32F2F))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(if (idioma == "PT") "Cancelar" else "Cancel")
                }
            }
        )
    }

    // --- REUSABLE LOAN EDIT DIALOG ---
    if (editingLoan != null) {
        EditLoanDialog(
            loan = editingLoan!!,
            settings = settings,
            onDismiss = { editingLoan = null },
            onConfirm = { updated ->
                viewModel.updateLoan(updated)
                editingLoan = null
                Toast.makeText(context, if (idioma == "PT") "Alterações gravadas!" else "Changes saved!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // --- REUSABLE PAYMENT DIALOG ---
    if (showPaymentDialogForInstallment != null) {
        val inst = showPaymentDialogForInstallment!!
        Dialog(onDismissRequest = { showPaymentDialogForInstallment = null }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.dp, borderCol),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") "Confirmar Pagamento de Parcela" else "Confirm Installment Payment",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = textPrimary
                    )
                    
                    OutlinedTextField(
                        value = paymentAmountStr,
                        onValueChange = { paymentAmountStr = it },
                        label = { Text(if (idioma == "PT") "Valor a Pagar (MZN)" else "Payment Amount (MZN)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = themePrimary,
                            focusedLabelColor = themePrimary
                        )
                    )

                    // Wallet selector
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = selectedWalletForPayment?.nome ?: (if (idioma == "PT") "Selecione uma conta" else "Select account"),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (idioma == "PT") "Pagar usando" else "Pay using") },
                            trailingIcon = {
                                IconButton(onClick = { walletDropdownOpen = true }) {
                                    Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = themePrimary,
                                focusedLabelColor = themePrimary
                            )
                        )
                        
                        DropdownMenu(
                            expanded = walletDropdownOpen,
                            onDismissRequest = { walletDropdownOpen = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            wallets.forEach { w ->
                                DropdownMenuItem(
                                    text = { Text("${w.nome} (Saldo: ${String.format("%,.2f", w.saldoAtual)} MZN)") },
                                    onClick = {
                                        selectedWalletForPayment = w
                                        walletDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showPaymentDialogForInstallment = null }) {
                            Text(if (idioma == "PT") "Cancelar" else "Cancel", color = textSecondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val payAmt = paymentAmountStr.toDoubleOrNull() ?: 0.0
                                val isLoanCredit = activeLoan.isCredit

                                if (payAmt > 0.0 && selectedWalletForPayment != null) {
                                    viewModel.payLoanInstallment(
                                        installment = inst,
                                        amount = payAmt,
                                        walletId = selectedWalletForPayment!!.id,
                                        isCredit = isLoanCredit
                                    )
                                    showPaymentDialogForInstallment = null
                                    Toast.makeText(context, if (idioma == "PT") "Pagamento efetuado!" else "Payment completed!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, if (idioma == "PT") "Selecione uma conta e insira um valor válido!" else "Select an account and enter a valid amount!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = themePrimary)
                        ) {
                            Text(if (idioma == "PT") "Confirmar" else "Confirm")
                        }
                    }
                }
            }
        }
    }
}
