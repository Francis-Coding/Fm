package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> SwipeToDeleteContainer(
    item: T,
    onDelete: (T) -> Unit,
    animationDuration: Int = 500,
    requireConfirmation: Boolean = false,
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit
) {
    androidx.compose.runtime.key(item) {
        var isRemoved by remember { mutableStateOf(false) }
        var showConfirmationDialog by remember { mutableStateOf(false) }
        val haptic = LocalHapticFeedback.current

        val state = rememberSwipeToDismissBoxState(
            confirmValueChange = { value ->
                if (value == SwipeToDismissBoxValue.EndToStart || value == SwipeToDismissBoxValue.StartToEnd) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    if (requireConfirmation) {
                        showConfirmationDialog = true
                        false
                    } else {
                        isRemoved = true
                        true
                    }
                } else {
                    false
                }
            }
        )

        LaunchedEffect(item) {
            isRemoved = false
            showConfirmationDialog = false
            state.snapTo(SwipeToDismissBoxValue.Settled)
        }

        LaunchedEffect(key1 = isRemoved) {
            if (isRemoved) {
                delay(animationDuration.toLong())
                onDelete(item)
            }
        }

        if (showConfirmationDialog) {
            AlertDialog(
                onDismissRequest = {
                    showConfirmationDialog = false
                },
                title = { Text("Confirmar eliminação") },
                text = { Text("Tem certeza que deseja eliminar este item? Esta ação não pode ser desfeita.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showConfirmationDialog = false
                            isRemoved = true
                        }
                    ) {
                        Text("Excluir")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showConfirmationDialog = false
                        }
                    ) {
                        Text("Cancelar")
                    }
                }
            )
        }

        AnimatedVisibility(
            visible = !isRemoved,
            modifier = modifier,
            exit = shrinkVertically(
                animationSpec = tween(durationMillis = animationDuration),
                shrinkTowards = Alignment.Top
            ) + fadeOut()
        ) {
            SwipeToDismissBox(
                state = state,
                backgroundContent = {
                    val isSettled = state.dismissDirection == SwipeToDismissBoxValue.Settled
                    val color = if (isSettled) Color.Transparent else Color.Red
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(color)
                            .padding(horizontal = 20.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        if (!isSettled) {
                            Icon(
                                imageVector = Icons.Rounded.Delete,
                                contentDescription = "Delete",
                                tint = Color.White
                            )
                        }
                    }
                },
                content = { content(item) }
            )
        }
    }
}
