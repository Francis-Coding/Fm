@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import com.example.util.AutoResizedText
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File


// ------------------- TELA 2: HISTORIAL LANÇAMENTOS -------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LancamentosScreen(
    viewModel: MainViewModel,
    transactions: List<Transaction>,
    categories: List<Category>,
    wallets: List<Wallet>,
    settings: UserSettings,
    onAddClick: (Boolean) -> Unit,
    onNavigateToGoal: () -> Unit = {},
    onNavigateToLoan: () -> Unit = {},
    deepLinkTransactionId: Int? = null,
    lazyListState: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState()
) {
    val context = LocalContext.current
    val filter by viewModel.transactionPeriodFilter.collectAsStateWithLifecycle()
    val categoryMap = remember(categories) { categories.associateBy { it.id } }
    val walletMap = remember(wallets) { wallets.associateBy { it.id } }

    val idioma = settings.idioma
    val isDark = settings.tema == "dark"
    val themeColor = try {
        Color(android.graphics.Color.parseColor(settings.corPrimaria))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    var showAdvancedFilters by remember { mutableStateOf(false) }
    val searchQuery by viewModel.historySearchQuery.collectAsStateWithLifecycle()
    var isSearchExpanded by remember { mutableStateOf(false) }
    val selectedCategoryFilterId by viewModel.historyCategoryFilterId.collectAsStateWithLifecycle()
    val selectedWalletFilterId by viewModel.historyWalletFilterId.collectAsStateWithLifecycle()
    val selectedCategoryFilter = categoryMap[selectedCategoryFilterId]
    val selectedWalletFilter = walletMap[selectedWalletFilterId]

    // Multi-factor advanced filters
    var filterMinVal by remember { mutableStateOf("") }
    var filterMaxVal by remember { mutableStateOf("") }
    var filterTagQuery by remember { mutableStateOf("") }

    // Bulk selection state
    var selectedBulkIds by remember { mutableStateOf(setOf<Int>()) }

    val searchedAndFilteredTransactions = remember(transactions, searchQuery, selectedCategoryFilter, selectedWalletFilter, filterMinVal, filterMaxVal, filterTagQuery) {
        transactions.filter { t ->
            val matchesSearch = searchQuery.isBlank() || 
                t.descricao.contains(searchQuery, ignoreCase = true) ||
                (categoryMap[t.categoriaId]?.nome?.contains(searchQuery, ignoreCase = true) ?: false) ||
                (walletMap[t.carteiraOrigemId]?.nome?.contains(searchQuery, ignoreCase = true) ?: false)
            
            val matchesCategory = selectedCategoryFilter == null || t.categoriaId == selectedCategoryFilter.id
            val matchesWallet = selectedWalletFilter == null || t.carteiraOrigemId == selectedWalletFilter.id
            
            // Value range filters
            val minDouble = filterMinVal.toDoubleOrNull()
            val matchesMin = minDouble == null || t.valor >= minDouble
            
            val maxDouble = filterMaxVal.toDoubleOrNull()
            val matchesMax = maxDouble == null || t.valor <= maxDouble

            // Tag filter
            val matchesTag = filterTagQuery.isBlank() || 
                t.descricao.contains(filterTagQuery, ignoreCase = true) || 
                (t.observacoes?.contains(filterTagQuery, ignoreCase = true) == true)
            
            matchesSearch && matchesCategory && matchesWallet && matchesMin && matchesMax && matchesTag
        }
    }

    val stats = remember(searchedAndFilteredTransactions, settings.moedaPadrao) {
        val totalRecebido = searchedAndFilteredTransactions.filter { it.isReceita() }.sumOf { it.valor }
        val totalPago = searchedAndFilteredTransactions.filter { it.isDespesa() }.sumOf { it.valor }
        val saldoPeriodo = totalRecebido - totalPago

        val totalRecConv = viewModel.currencyService.convertFromMT(totalRecebido, settings.moedaPadrao)
        val totalPagoConv = viewModel.currencyService.convertFromMT(totalPago, settings.moedaPadrao)
        val saldoPeriodoConv = viewModel.currencyService.convertFromMT(saldoPeriodo, settings.moedaPadrao)
        
        object {
            val totalRecConv = totalRecConv
            val totalPagoConv = totalPagoConv
            val saldoPeriodoConv = saldoPeriodoConv
            val saldoPeriodo = saldoPeriodo
        }
    }
    val totalRecConv = stats.totalRecConv
    val totalPagoConv = stats.totalPagoConv
    val saldoPeriodoConv = stats.saldoPeriodoConv
    val saldoPeriodo = stats.saldoPeriodo

    var showAddOptionsDialog by remember { mutableStateOf(false) }
    var showTransferDialog by remember { mutableStateOf(false) }
    var showActionDialogForTransaction by remember { mutableStateOf<Transaction?>(null) }
    var showEditTransactionDialog by remember { mutableStateOf<Transaction?>(null) }

    LaunchedEffect(deepLinkTransactionId, transactions) {
        if (deepLinkTransactionId != null) {
            val transaction = transactions.find { it.id == deepLinkTransactionId }
            if (transaction != null) {
                showActionDialogForTransaction = transaction
            }
        }
    }




    // Main UI State for filters and lists
    val activeTypeTab by viewModel.historyActiveTab.collectAsStateWithLifecycle()
    var isFabExpanded by remember { mutableStateOf(false) }
    var isPeriodDropdownExpanded by remember { mutableStateOf(false) }
    var isAmountVisible by remember { mutableStateOf(true) }
    val customStartDate by viewModel.customStartDate.collectAsStateWithLifecycle()
    val customEndDate by viewModel.customEndDate.collectAsStateWithLifecycle()
    var showCustomDateRangeDialog by remember { mutableStateOf(false) }

    val finalFilteredList = remember(searchedAndFilteredTransactions, activeTypeTab, categories) {
        when (activeTypeTab) {
            "Receitas" -> searchedAndFilteredTransactions.filter { it.isReceita() }
            "Despesas" -> searchedAndFilteredTransactions.filter { it.isDespesa() }
            "Transferências" -> searchedAndFilteredTransactions.filter { it.tipo == "Transferencia" }
            "Empréstimos" -> searchedAndFilteredTransactions.filter { it.tipo == "PagamentoEmprestimo" }
            else -> searchedAndFilteredTransactions
        }
    }

    // Date/Subtitle calculation for the header card
    val subtitleText = remember(filter, idioma) {
        val locale = if (idioma == "PT") Locale("pt", "MZ") else Locale.ENGLISH
        val sdfPattern = if (idioma == "PT") "dd 'de' MMMM" else "MMMM dd"
        val sdf = SimpleDateFormat(sdfPattern, locale)
        val cal = Calendar.getInstance()
        when (filter) {
            "Diário" -> sdf.format(cal.time)
            "Semanal" -> {
                val end = sdf.format(cal.time)
                cal.add(Calendar.DAY_OF_YEAR, -6)
                val start = sdf.format(cal.time)
                "$start - $end"
            }
            "Mensal" -> {
                val end = sdf.format(cal.time)
                cal.set(Calendar.DAY_OF_MONTH, 1)
                val start = sdf.format(cal.time)
                "$start - $end"
            }
            "Personalizado" -> {
                if (customStartDate != null && customEndDate != null) {
                    val startStr = sdf.format(java.util.Date(customStartDate!!))
                    val endStr = sdf.format(java.util.Date(customEndDate!!))
                    "$startStr - $endStr"
                } else {
                    if (idioma == "PT") "Período personalizado" else "Custom range"
                }
            }
            else -> if (idioma == "PT") "Todo o tempo" else "All time"
        }
    }

    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = { viewModel.refreshData() },
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- BULK ACTIONS TOP BANNER ---
            if (selectedBulkIds.isNotEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth().animateContentSize(),
                    color = themeColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, themeColor)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(onClick = { selectedBulkIds = emptySet() }) {
                                Icon(Icons.Rounded.Close, "Cancel Selection", tint = themeColor)
                            }
                            Text(
                                text = if (idioma == "PT") "${selectedBulkIds.size} selecionados" else "${selectedBulkIds.size} selected",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp
                            )
                        }
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            var showBulkDeleteConfirmDialog by remember { mutableStateOf(false) }

                            if (showBulkDeleteConfirmDialog) {
                                AlertDialog(
                                    onDismissRequest = { showBulkDeleteConfirmDialog = false },
                                    title = { Text(if (idioma == "PT") "Eliminar lançamentos?" else "Delete transactions?") },
                                    text = { Text(if (idioma == "PT") "Deseja eliminar os ${selectedBulkIds.size} lançamentos selecionados? Esta ação não pode ser desfeita." else "Are you sure you want to delete the ${selectedBulkIds.size} selected transactions? This action cannot be undone.") },
                                    confirmButton = {
                                        Button(
                                            onClick = {
                                                val toDelete = transactions.filter { it.id in selectedBulkIds }
                                                viewModel.deleteTransactions(toDelete)
                                                selectedBulkIds = emptySet()
                                                showBulkDeleteConfirmDialog = false
                                                Toast.makeText(context, if (idioma == "PT") "Lançamentos removidos" else "Transactions deleted", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                        ) {
                                            Text(if (idioma == "PT") "Eliminar" else "Delete")
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(onClick = { showBulkDeleteConfirmDialog = false }) {
                                            Text(if (idioma == "PT") "Cancelar" else "Cancel")
                                        }
                                    }
                                )
                            }

                            // Bulk Delete button
                            IconButton(
                                onClick = { showBulkDeleteConfirmDialog = true }
                            ) {
                                Icon(Icons.Rounded.Delete, "Delete selected", tint = MaterialTheme.colorScheme.error)
                            }
                            
                            // Bulk Edit Category dropdown/button
                            var showBulkCatMenu by remember { mutableStateOf(false) }
                            Box {
                                IconButton(onClick = { showBulkCatMenu = true }) {
                                    Icon(Icons.Rounded.Category, "Edit category in bulk", tint = themeColor)
                                }
                                DropdownMenu(expanded = showBulkCatMenu, onDismissRequest = { showBulkCatMenu = false }) {
                                    categories.forEach { cat ->
                                        DropdownMenuItem(
                                            text = {
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    AppIcon(iconKey = cat.icone, modifier = Modifier.size(16.dp))
                                                    Text(Translator.getLocalizedCategoryName(cat.nome, idioma))
                                                }
                                            },
                                            onClick = {
                                                val toUpdate = transactions.filter { it.id in selectedBulkIds }
                                                toUpdate.forEach { t ->
                                                    viewModel.updateTransaction(t, t.copy(categoriaId = cat.id))
                                                }
                                                selectedBulkIds = emptySet()
                                                showBulkCatMenu = false
                                                Toast.makeText(context, if (idioma == "PT") "Categorias atualizadas" else "Categories updated", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }
                                }
                            }
                            
                            // Bulk Edit Wallet dropdown/button
                            var showBulkWalleMenu by remember { mutableStateOf(false) }
                            Box {
                                IconButton(onClick = { showBulkWalleMenu = true }) {
                                    Icon(Icons.Rounded.Wallet, "Edit wallet in bulk", tint = themeColor)
                                }
                                DropdownMenu(expanded = showBulkWalleMenu, onDismissRequest = { showBulkWalleMenu = false }) {
                                    wallets.forEach { w ->
                                        DropdownMenuItem(
                                            leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary) },
                                            text = { Text(w.nome) },
                                            onClick = {
                                                val toUpdate = transactions.filter { it.id in selectedBulkIds }
                                                toUpdate.forEach { t ->
                                                    viewModel.updateTransaction(t, t.copy(carteiraOrigemId = w.id))
                                                }
                                                selectedBulkIds = emptySet()
                                                showBulkWalleMenu = false
                                                Toast.makeText(context, if (idioma == "PT") "Carteiras atualizadas" else "Accounts updated", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- HEADER WITH ANIMATED SEARCH BAR EXPANSION ---
            AnimatedContent(
                targetState = isSearchExpanded,
                transitionSpec = {
                    fadeIn(animationSpec = tween(150)) togetherWith fadeOut(animationSpec = tween(150))
                },
                label = "search_bar_expansion"
            ) { expanded ->
                if (!expanded) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = Translator.t("history", idioma),
                            fontSize = 32.sp, // Sleek modern title size
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (searchQuery.isNotEmpty() || selectedCategoryFilter != null || selectedWalletFilter != null || filterMinVal.isNotEmpty() || filterMaxVal.isNotEmpty() || filterTagQuery.isNotEmpty()) {
                                TextButton(
                                    onClick = {
                                        viewModel.historySearchQuery.value = ""
                                        viewModel.setHistoryCategoryFilterId(-1)
                                        viewModel.setHistoryWalletFilterId(-1)
                                        filterMinVal = ""
                                        filterMaxVal = ""
                                        filterTagQuery = ""
                                    }
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Limpar" else "Clear",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = themeColor
                                    )
                                }
                            }
                            
                            // Lupa (Magnifying glass search icon) to open the search bar
                            IconButton(
                                onClick = { isSearchExpanded = true },
                                modifier = Modifier.testTag("open_history_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = "Search",
                                    tint = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                } else {
                    // Full-width search input in the header row when expanded
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.historySearchQuery.value = it },
                            placeholder = {
                                Text(
                                    text = if (idioma == "PT") "Pesquisar por descrição..." else "Search by description...",
                                    fontSize = 13.sp,
                                    color = if (isDark) Color(0xFF98A2B3) else Color(0xFF667085)
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = "Search",
                                    tint = if (isDark) Color(0xFF98A2B3) else Color(0xFF667085),
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(end = 4.dp)
                                ) {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.historySearchQuery.value = "" }) {
                                            Icon(
                                                imageVector = Icons.Rounded.Clear,
                                                contentDescription = "Clear search",
                                                tint = if (isDark) Color(0xFF98A2B3) else Color(0xFF667085)
                                            )
                                        }
                                    }
                                    IconButton(onClick = { showAdvancedFilters = !showAdvancedFilters }) {
                                        Icon(
                                            imageVector = Icons.Rounded.Tune,
                                            contentDescription = "Advanced filters",
                                            tint = if (showAdvancedFilters || selectedCategoryFilter != null || selectedWalletFilter != null || filterMinVal.isNotEmpty() || filterMaxVal.isNotEmpty() || filterTagQuery.isNotEmpty()) {
                                                themeColor
                                            } else {
                                                if (isDark) Color(0xFF98A2B3) else Color(0xFF667085)
                                            }
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = if (isDark) Color(0xFF141B2D) else Color(0xFFF1F5F9),
                                unfocusedContainerColor = if (isDark) Color(0xFF141B2D) else Color(0xFFF8FAFC),
                                focusedBorderColor = themeColor,
                                unfocusedBorderColor = if (isDark) Color(0x1AFFFFFF) else Color(0x1A000000),
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("history_search_input"),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp)
                        )
 
                        IconButton(
                            onClick = { 
                                isSearchExpanded = false 
                                viewModel.historySearchQuery.value = "" // Reset search when collapsing
                            },
                            modifier = Modifier.testTag("close_history_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close search",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }
 
            // Expanding advanced filters section (Category & Account)
            AnimatedVisibility(
                visible = showAdvancedFilters,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) Color(0xFF141B2D) else Color(0xFFF8FAFC)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, if (isDark) Color(0x0DFFFFFF) else Color(0x1A000000))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Category Filter Dropdown
                            var catDropdownOpen by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1.0f)) {
                                val isCatActive = selectedCategoryFilter != null
                                OutlinedButton(
                                    onClick = { catDropdownOpen = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isCatActive) themeColor.copy(alpha = 0.15f) else Color.Transparent
                                    ),
                                    border = BorderStroke(
                                        width = 1.dp,
                                        color = if (isCatActive) themeColor else (if (isDark) Color(0x1AFFFFFF) else Color(0x1A000000))
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                                            modifier = Modifier.weight(1f, fill = false)
                                        ) {
                                            selectedCategoryFilter?.let {
                                                AppIcon(iconKey = it.icone, modifier = Modifier.size(14.dp))
                                            }
                                            Text(
                                                text = selectedCategoryFilter?.let { Translator.getLocalizedCategoryName(it.nome, idioma) } ?: (if (idioma == "PT") "Categoria" else "Category"),
                                                fontSize = 11.sp,
                                                color = if (isDark) Color.White else Color.Black,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Rounded.ArrowDropDown,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (isDark) Color.White.copy(alpha = 0.6f) else Color.Black.copy(alpha = 0.6f)
                                        )
                                    }
                                }
                                DropdownMenu(
                                    expanded = catDropdownOpen,
                                    onDismissRequest = { catDropdownOpen = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text(if (idioma == "PT") "Todas as Categorias" else "All Categories") },
                                        onClick = {
                                            viewModel.setHistoryCategoryFilterId(-1)
                                            catDropdownOpen = false
                                        }
                                    )
                                    categories.forEach { cat ->
                                            DropdownMenuItem(
                                                text = { Text(Translator.getLocalizedCategoryName(cat.nome, idioma)) },
                                                onClick = {
                                                    viewModel.setHistoryCategoryFilterId(cat.id)
                                                    catDropdownOpen = false
                                                }
                                            )
                                    }
                                }
                            }
 
                            // Wallet/Account Filter Dropdown
                            var walletDropdownOpen by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1.0f)) {
                                val isWalletActive = selectedWalletFilter != null
                                OutlinedButton(
                                    onClick = { walletDropdownOpen = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isWalletActive) themeColor.copy(alpha = 0.15f) else Color.Transparent
                                    ),
                                    border = BorderStroke(
                                        width = 1.dp,
                                        color = if (isWalletActive) themeColor else (if (isDark) Color(0x1AFFFFFF) else Color(0x1A000000))
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = selectedWalletFilter?.nome ?: (if (idioma == "PT") "Conta" else "Account"),
                                            fontSize = 11.sp,
                                            color = if (isDark) Color.White else Color.Black,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        Icon(
                                            imageVector = Icons.Rounded.ArrowDropDown,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (isDark) Color.White.copy(alpha = 0.6f) else Color.Black.copy(alpha = 0.6f)
                                        )
                                    }
                                }
                                DropdownMenu(
                                    expanded = walletDropdownOpen,
                                    onDismissRequest = { walletDropdownOpen = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text(if (idioma == "PT") "Todas as Contas" else "All Accounts") },
                                        onClick = {
                                            viewModel.setHistoryWalletFilterId(-1)
                                            walletDropdownOpen = false
                                        }
                                    )
                                    wallets.forEach { w ->
                                            DropdownMenuItem(
                                                text = { Text(w.nome) },
                                                onClick = {
                                                    viewModel.setHistoryWalletFilterId(w.id)
                                                    walletDropdownOpen = false
                                                }
                                            )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = filterMinVal,
                                onValueChange = { filterMinVal = it },
                                label = { Text(if (idioma == "PT") "Valor Mín (MZN)" else "Min Value", fontSize = 10.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f).height(48.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                )
                            )
                            
                            OutlinedTextField(
                                value = filterMaxVal,
                                onValueChange = { filterMaxVal = it },
                                label = { Text(if (idioma == "PT") "Valor Máx (MZN)" else "Max Value", fontSize = 10.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f).height(48.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                )
                            )
                        }
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = filterTagQuery,
                                onValueChange = { filterTagQuery = it },
                                placeholder = { Text(if (idioma == "PT") "Filtrar por #tag..." else "Filter by #tag...", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f).height(46.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                leadingIcon = { Icon(Icons.Rounded.Tag, null, modifier = Modifier.size(16.dp)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                )
                            )
                            
                            if (filterMinVal.isNotEmpty() || filterMaxVal.isNotEmpty() || filterTagQuery.isNotEmpty() || selectedCategoryFilter != null || selectedWalletFilter != null) {
                                TextButton(
                                    onClick = {
                                        filterMinVal = ""
                                        filterMaxVal = ""
                                        filterTagQuery = ""
                                        viewModel.setHistoryCategoryFilterId(-1)
                                        viewModel.setHistoryWalletFilterId(-1)
                                    }
                                ) {
                                    Text(if (idioma == "PT") "Limpar" else "Reset", fontSize = 11.sp, color = themeColor, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // --- FILTER CHIPS ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val filterOptions = listOf("Todos", "Receitas", "Despesas", "Transferências", "Empréstimos")
                filterOptions.forEach { p ->
                    val isSelected = activeTypeTab == p
                    val labelText = when (p) {
                        "Receitas" -> Translator.t("new_income", idioma)
                        "Despesas" -> Translator.t("new_expense", idioma)
                        "Transferências" -> if (idioma == "PT") "Transferências" else "Transfers"
                        "Empréstimos" -> if (idioma == "PT") "Empréstimos" else "Loans"
                        else -> if (idioma == "PT") "Todos" else "All"
                    }
                    val icon = when (p) {
                        "Receitas" -> Icons.Rounded.ArrowUpward
                        "Despesas" -> Icons.Rounded.ArrowDownward
                        "Transferências" -> Icons.Rounded.SwapHoriz
                        "Empréstimos" -> Icons.Rounded.MonetizationOn
                        else -> Icons.Rounded.Check
                    }
                    val iconColor = when (p) {
                        "Receitas" -> Color(0xFF35D07F)
                        "Despesas" -> Color(0xFFFF5C5C)
                        "Transferências" -> Color(0xFF8B5CF6)
                        "Empréstimos" -> Color(0xFFFBBF24)
                        else -> Color.White
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50.dp))
                            .background(
                                if (isSelected) themeColor else (if (isDark) Color(0xFF141B2D) else Color(0xFFF1F5F9))
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) Color.Transparent else (if (isDark) Color(0x0DFFFFFF) else Color(0x0F000000)),
                                shape = RoundedCornerShape(50.dp)
                            )
                            .clickable {
                                viewModel.setHistoryActiveTab(p)
                                viewModel.setTransactionTypeFilter(when (p) {
                                    "Receitas" -> "Injecao"
                                    "Despesas" -> "Despesa"
                                    else -> "Todos"
                                })
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (isSelected || p != "Todos") {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) Color.White else iconColor,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Text(
                                text = labelText,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else (if (isDark) Color(0xFF98A2B3) else Color(0xFF475569))
                            )
                        }
                    }
                }
            }

            // --- DATE SEPARATED TRANSACTION LIST ---
            val sdfGroup = remember { SimpleDateFormat("EEEE, dd 'de' MMMM", Locale("pt", "MZ")) }
            val timeFormatter = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
            val grouped = remember(finalFilteredList) {
                finalFilteredList.groupBy {
                    it.data / 86400000L * 86400000L
                }
            }

            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("transactions_lazy_column"),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    // --- SUMMARY CARD ---
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF141B2D) else Color(0xFFFFFFFF)),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, if (isDark) Color(0x0DFFFFFF) else Color(0xFFE2E8F0))
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(20.dp)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Title, Subtitle, and Month Selector Dropdown
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    val summaryTitle = when (filter) {
                                        "Diário" -> if (idioma == "PT") "Resumo de Hoje" else "Today's Summary"
                                        "Semanal" -> if (idioma == "PT") "Resumo da Semana" else "This Week's Summary"
                                        "Mensal" -> if (idioma == "PT") "Resumo do Mês" else "This Month's Summary"
                                        "Personalizado" -> if (idioma == "PT") "Resumo Personalizado" else "Custom Summary"
                                        else -> if (idioma == "PT") "Resumo Geral" else "Overall Summary"
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(themeColor.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.BarChart,
                                            contentDescription = "Analytics Icon",
                                            tint = themeColor,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = summaryTitle,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A)
                                            )
                                            Icon(
                                                imageVector = if (isAmountVisible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                                contentDescription = "Toggle Amount",
                                                tint = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B),
                                                modifier = Modifier
                                                    .size(18.dp)
                                                    .clickable { isAmountVisible = !isAmountVisible }
                                            )
                                        }
                                        Text(
                                            text = subtitleText,
                                            fontSize = 12.sp,
                                            color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                        )
                                    }
                                }
                                
                                // Month/Period Dropdown Selector button
                                Box {
                                    val periodLabel = when (filter) {
                                        "Diário" -> if (idioma == "PT") "Hoje" else "Today"
                                        "Semanal" -> if (idioma == "PT") "Esta semana" else "This week"
                                        "Mensal" -> if (idioma == "PT") "Este mês" else "This month"
                                        "Personalizado" -> {
                                            if (customStartDate != null && customEndDate != null) {
                                                val sdf = java.text.SimpleDateFormat("dd/MM", java.util.Locale.getDefault())
                                                "${sdf.format(java.util.Date(customStartDate!!))} - ${sdf.format(java.util.Date(customEndDate!!))}"
                                            } else {
                                                if (idioma == "PT") "Personalizado" else "Custom"
                                            }
                                        }
                                        else -> if (idioma == "PT") "Histórico" else "Full History"
                                    }
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (isSystemInDarkTheme()) Color(0xFF1F2D42) else Color(0xFFF1F5F9))
                                            .clickable { isPeriodDropdownExpanded = true }
                                            .padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = periodLabel,
                                            color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Icon(
                                            imageVector = Icons.Rounded.ArrowDropDown,
                                            contentDescription = null,
                                            tint = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = isPeriodDropdownExpanded,
                                        onDismissRequest = { isPeriodDropdownExpanded = false }
                                    ) {
                                        listOf(
                                            "Todos" to (if (idioma == "PT") "Histórico completo" else "Full History"),
                                            "Diário" to (if (idioma == "PT") "Hoje" else "Today"),
                                            "Semanal" to (if (idioma == "PT") "Esta semana" else "This week"),
                                            "Mensal" to (if (idioma == "PT") "Este mês" else "This month"),
                                            "Personalizado" to (if (idioma == "PT") "Personalizado" else "Custom")
                                        ).forEach { (value, labelText) ->
                                            DropdownMenuItem(
                                                text = { Text(labelText) },
                                                onClick = {
                                                    if (value == "Personalizado") {
                                                        isPeriodDropdownExpanded = false
                                                        showCustomDateRangeDialog = true
                                                    } else {
                                                        viewModel.setTransactionPeriodFilter(value)
                                                        isPeriodDropdownExpanded = false
                                                    }
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // Three Equal Sections (Receitas, Despesas, Saldo)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val incomeOps = searchedAndFilteredTransactions.count { it.isReceita() }
                                val expenseOps = searchedAndFilteredTransactions.count { it.isDespesa() }

                                // Section 1: Receitas
                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Receitas" else "Income",
                                        fontSize = 11.sp,
                                        color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                    )
                                    if (isAmountVisible) {
                                        FormatPremiumAmount(
                                            amountText = String.format("%,.2f", totalRecConv),
                                            currency = settings.moedaPadrao,
                                            color = Color(0xFF35D07F),
                                            fontSize = 15.sp
                                        )
                                    } else {
                                        Text("•••• ${settings.moedaPadrao}", color = Color(0xFF35D07F), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(50.dp))
                                            .background(Color(0xFF35D07F).copy(alpha = 0.12f))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (idioma == "PT") "$incomeOps oper." else "$incomeOps ops.",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF35D07F)
                                        )
                                    }
                                }

                                // Divider 1
                                Box(
                                    modifier = Modifier
                                        .height(40.dp)
                                        .width(1.dp)
                                        .background(if (isSystemInDarkTheme()) Color(0x1AFFFFFF) else Color(0xFFE2E8F0))
                                        .padding(horizontal = 8.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))

                                // Section 2: Despesas
                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Despesas" else "Expenses",
                                        fontSize = 11.sp,
                                        color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                    )
                                    if (isAmountVisible) {
                                        FormatPremiumAmount(
                                            amountText = String.format("%,.2f", totalPagoConv),
                                            currency = settings.moedaPadrao,
                                            color = Color(0xFFFF5C5C),
                                            fontSize = 15.sp
                                        )
                                    } else {
                                        Text("•••• ${settings.moedaPadrao}", color = Color(0xFFFF5C5C), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(50.dp))
                                            .background(Color(0xFFFF5C5C).copy(alpha = 0.12f))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (idioma == "PT") "$expenseOps oper." else "$expenseOps ops.",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFFFF5C5C)
                                        )
                                    }
                                }

                                // Divider 2
                                Box(
                                    modifier = Modifier
                                        .height(40.dp)
                                        .width(1.dp)
                                        .background(if (isSystemInDarkTheme()) Color(0x1AFFFFFF) else Color(0xFFE2E8F0))
                                        .padding(horizontal = 8.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))

                                // Section 3: Saldo
                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Saldo" else "Balance",
                                        fontSize = 11.sp,
                                        color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                    )
                                    if (isAmountVisible) {
                                        FormatPremiumAmount(
                                            amountText = "${if (saldoPeriodo >= 0) "" else "-"}${String.format("%,.2f", Math.abs(saldoPeriodoConv))}",
                                            currency = settings.moedaPadrao,
                                            color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A),
                                            fontSize = 15.sp
                                        )
                                    } else {
                                        Text("•••• ${settings.moedaPadrao}", color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(50.dp))
                                            .background(if (isSystemInDarkTheme()) Color(0x1AFFFFFF) else Color(0xFFF1F5F9))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "Total",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                        )
                                    }
                                }
                            }

                            // Bottom Indicator Lines
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(16.dp)
                                        .height(3.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0x1AFFFFFF))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height(3.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(themeColor)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (grouped.isEmpty()) {
                    val hasActiveFilters = searchQuery.isNotBlank() || 
                        selectedCategoryFilter != null || 
                        selectedWalletFilter != null || 
                        filterMinVal.isNotBlank() || 
                        filterMaxVal.isNotBlank() || 
                        filterTagQuery.isNotBlank() || 
                        activeTypeTab != "Todos"
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 40.dp),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            Text(
                                text = if (hasActiveFilters) {
                                    if (idioma == "PT") "Nenhum resultado para os filtros aplicados." else "No results for the applied filters."
                                } else {
                                    if (idioma == "PT") "Nenhum lançamento registado." else "No transactions registered."
                                },
                                color = Color(0xFF98A2B3),
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    grouped.forEach { (dateMs, list) ->
                        item {
                            Text(
                                text = sdfGroup.format(Date(dateMs)).replaceFirstChar { it.uppercase() },
                                fontWeight = FontWeight.Medium,
                                fontSize = 14.sp,
                                color = Color(0xFF98A2B3),
                                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                            )
                        }

                        items(list, key = { it.id }) { t ->
                            val cat = categoryMap[t.categoriaId]
                            val wallet = walletMap[t.carteiraOrigemId]
                            
                            SwipeToDeleteContainer(
                                item = t,
                                onDelete = { viewModel.deleteTransaction(it) },
                                modifier = Modifier.animateItem()
                            ) { transaction ->
                                // Styled transaction item card
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(76.dp)
                                        .combinedClickable(
                                            onClick = {
                                                if (selectedBulkIds.isNotEmpty()) {
                                                    selectedBulkIds = if (transaction.id in selectedBulkIds) {
                                                        selectedBulkIds - transaction.id
                                                    } else {
                                                        selectedBulkIds + transaction.id
                                                    }
                                                } else {
                                                    showActionDialogForTransaction = transaction
                                                }
                                            },
                                            onLongClick = {
                                                selectedBulkIds = if (transaction.id in selectedBulkIds) {
                                                    selectedBulkIds - transaction.id
                                                } else {
                                                    selectedBulkIds + transaction.id
                                                }
                                            }
                                        )
                                        .testTag("transaction_item_${transaction.id}"),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (transaction.id in selectedBulkIds) {
                                            themeColor.copy(alpha = 0.12f)
                                        } else {
                                            if (isDark) Color(0xFF141B2D) else Color(0xFFFFFFFF)
                                        }
                                    ),
                                    shape = RoundedCornerShape(18.dp),
                                    border = BorderStroke(
                                        width = if (transaction.id in selectedBulkIds) 2.dp else 1.dp,
                                        color = if (transaction.id in selectedBulkIds) themeColor else (if (isDark) Color(0x0DFFFFFF) else Color(0x0F000000))
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        // Category icon circular background
                                        val catColor = remember(cat, settings.corPrimaria) {
                                            try {
                                                Color(android.graphics.Color.parseColor(cat?.cor?.ifEmpty { settings.corPrimaria } ?: settings.corPrimaria))
                                            } catch (e: Exception) {
                                                themeColor
                                            }
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(catColor.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            AppIcon(iconKey = cat?.icone ?: "receipt", modifier = Modifier.size(20.dp), tint = catColor)
                                        }

                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    text = transaction.descricao,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 15.sp,
                                                    color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f, fill = false)
                                                )
                                                if (transaction.recorrente) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Repeat,
                                                        contentDescription = "Recorrente",
                                                        tint = themeColor,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = wallet?.nome ?: "Carteira",
                                                    fontSize = 12.sp,
                                                    color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                                )
                                                Text(
                                                    text = "•",
                                                    fontSize = 12.sp,
                                                    color = if (isSystemInDarkTheme()) Color(0x4DFFFFFF) else Color(0x33000000)
                                                )
                                                
                                                // Small rounded badge
                                                val badgeIcon = remember(transaction.tipo, cat?.nome) {
                                                    if (transaction.tipo == "Transferencia") Icons.Rounded.SwapHoriz
                                                    else if (transaction.tipo == "PagamentoEmprestimo") Icons.Rounded.AccountBalance
                                                    else {
                                                        val name = cat?.nome?.lowercase() ?: ""
                                                        if (name.contains("aliment") || name.contains("comida")) Icons.Rounded.Restaurant
                                                        else if (name.contains("negóc") || name.contains("work")) Icons.Rounded.BusinessCenter
                                                        else if (name.contains("ajust") || name.contains("config")) Icons.Rounded.Settings
                                                        else if (name.contains("transp") || name.contains("bus")) Icons.Rounded.DirectionsBus
                                                        else if (name.contains("casa") || name.contains("rent") || name.contains("morad")) Icons.Rounded.Home
                                                        else if (name.contains("compra") || name.contains("shop")) Icons.Rounded.ShoppingCart
                                                        else if (name.contains("receit") || name.contains("salár") || name.contains("salar")) Icons.Rounded.Payments
                                                        else Icons.Rounded.Tag
                                                    }
                                                }
                                                val badgeText = remember(transaction.tipo, cat?.nome, idioma) {
                                                    when (transaction.tipo) {
                                                        "Transferencia" -> if (idioma == "PT") "Transferência" else "Transfer"
                                                        "PagamentoEmprestimo" -> if (idioma == "PT") "Empréstimo" else "Loan Payment"
                                                        else -> Translator.getLocalizedCategoryName(cat?.nome ?: "Geral", idioma)
                                                    }
                                                }

                                                Row(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(catColor.copy(alpha = 0.12f))
                                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = badgeIcon,
                                                        contentDescription = null,
                                                        tint = catColor,
                                                        modifier = Modifier.size(10.dp)
                                                    )
                                                    Text(
                                                        text = badgeText,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = catColor
                                                    )
                                                }
                                            }

                                            // Tags line rendering inside card
                                            val hashtags = remember(transaction.descricao, transaction.observacoes) {
                                                val fullText = transaction.descricao + " " + (transaction.observacoes ?: "")
                                                fullText.split(Regex("\\s+")).filter { it.startsWith("#") && it.length > 1 }.distinct()
                                            }
                                            if (hashtags.isNotEmpty()) {
                                                Row(
                                                    modifier = Modifier.padding(top = 2.dp),
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    hashtags.forEach { tag ->
                                                        Box(
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(4.dp))
                                                                .background(themeColor.copy(alpha = 0.1f))
                                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                                        ) {
                                                            Text(tag, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = themeColor)
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        // Right aligned section (Amount, Time, Actions)
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.End,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                val amtConv = remember(transaction.valor, settings.moedaPadrao) { viewModel.currencyService.convertFromMT(transaction.valor, settings.moedaPadrao) }
                                                val prefix = when (transaction.tipo) {
                                                    "Despesa" -> "-"
                                                    "Transferencia" -> "⇄"
                                                    "PagamentoEmprestimo" -> "💳"
                                                    else -> "+"
                                                }
                                                val col = when (transaction.tipo) {
                                                    "Despesa" -> Color(0xFFFF5C5C)
                                                    "Transferencia" -> Color(0xFF1A73E8)
                                                    "PagamentoEmprestimo" -> Color(0xFFFF9800)
                                                    else -> Color(0xFF35D07F)
                                                }

                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    if (!transaction.comprovanteUrl.isNullOrBlank()) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.AttachFile,
                                                            contentDescription = "Attachment",
                                                            tint = themeColor,
                                                            modifier = Modifier.size(12.dp).padding(end = 2.dp)
                                                        )
                                                    }
                                                    if (isAmountVisible) {
                                                        FormatPremiumAmount(
                                                            amountText = "$prefix ${String.format("%,.2f", amtConv)}",
                                                            currency = settings.moedaPadrao,
                                                            color = col,
                                                            fontSize = 15.sp
                                                        )
                                                    } else {
                                                        Text("•••• ${settings.moedaPadrao}", color = col, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                                    }
                                                }

                                                val timeStr = remember(transaction.data) { timeFormatter.format(Date(transaction.data)) }
                                                Text(
                                                    text = timeStr,
                                                    fontSize = 12.sp,
                                                    color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                                )
                                            }

                                            // More options button (...) instead of raw delete trash can
                                            IconButton(
                                                onClick = { showActionDialogForTransaction = transaction },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.MoreVert,
                                                    contentDescription = "Mais opções",
                                                    tint = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- EXPANDABLE SPEED DIAL FAB ---
        AnimatedVisibility(
            visible = isFabExpanded,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .clickable { isFabExpanded = false }
            )
        }

        // Stacked speed dial options
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 96.dp, end = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            val speedDialItems = listOf(
                Triple(if (idioma == "PT") "Receita" else "Income", Icons.Rounded.ArrowUpward, Color(0xFF35D07F)),
                Triple(if (idioma == "PT") "Despesa" else "Expense", Icons.Rounded.ArrowDownward, Color(0xFFFF5C5C)),
                Triple(if (idioma == "PT") "Transferência" else "Transfer", Icons.Rounded.SwapHoriz, Color(0xFF2F80ED)),
                Triple(if (idioma == "PT") "Empréstimo" else "Loan", Icons.Rounded.MonetizationOn, Color(0xFF9B51E0)),
                Triple(if (idioma == "PT") "Meta" else "Goal", Icons.Rounded.Star, Color(0xFFF2994A))
            )

            speedDialItems.forEach { (label, icon, color) ->
                AnimatedVisibility(
                    visible = isFabExpanded,
                    enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.clickable {
                            isFabExpanded = false
                            when {
                                label.contains("Receita") || label.contains("Income") -> onAddClick(false)
                                label.contains("Despesa") || label.contains("Expense") -> onAddClick(true)
                                label.contains("Transfer") || label.contains("Transferência") -> showTransferDialog = true
                                label.contains("Empréstimo") || label.contains("Loan") -> {
                                    onNavigateToLoan()
                                }
                                label.contains("Meta") || label.contains("Goal") -> {
                                    onNavigateToGoal()
                                }
                            }
                        }
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (isSystemInDarkTheme()) Color(0xFF141B2D) else Color(0xFFFFFFFF)),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (isSystemInDarkTheme()) Color(0x0DFFFFFF) else Color(0xFFE2E8F0))
                        ) {
                            Text(
                                text = label,
                                color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(color),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // Main round Floating Action Button with scroll-responsive AnimatedVisibility
        val isFabVisible = !lazyListState.isScrollInProgress || isFabExpanded
        AnimatedVisibility(
            visible = isFabVisible,
            enter = scaleIn(animationSpec = spring(stiffness = Spring.StiffnessLow)) + fadeIn(),
            exit = scaleOut(animationSpec = spring(stiffness = Spring.StiffnessLow)) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
        ) {
            FloatingActionButton(
                onClick = { isFabExpanded = !isFabExpanded },
                modifier = Modifier.testTag("floating_add_button"),
                containerColor = themeColor,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = if (isFabExpanded) Icons.Rounded.Close else Icons.Rounded.Add,
                    contentDescription = "Menu Lançamento",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }

    // Modal Add Options Select Bottom Sheet
    if (showAddOptionsDialog) {
        ModalBottomSheet(
            onDismissRequest = { showAddOptionsDialog = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (idioma == "PT") "Novo Lançamento" else "New Entry",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = {
                        showAddOptionsDialog = false
                        onAddClick(false) // Income
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.ArrowCircleUp, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(Translator.t("new_income", idioma))
                    }
                }

                Button(
                    onClick = {
                        showAddOptionsDialog = false
                        onAddClick(true) // Expense
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.ArrowCircleDown, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(Translator.t("new_expense", idioma))
                    }
                }

                Button(
                    onClick = {
                        showAddOptionsDialog = false
                        showTransferDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.SyncAlt, null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(Translator.t("new_transfer", idioma))
                    }
                }
            }
        }
    }

    // Modal Wallet-to-Wallet Transfer Dialog
    if (showTransferDialog) {
        var selectedFromWallet by remember { mutableStateOf(wallets.firstOrNull()) }
        var selectedToWallet by remember { mutableStateOf(wallets.getOrNull(1) ?: wallets.firstOrNull()) }
        var transferAmountStr by remember { mutableStateOf("") }
        var transferDesc by remember { mutableStateOf("Transferência de Fundos") }
        var fromDropdownOpen by remember { mutableStateOf(false) }
        var toDropdownOpen by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { showTransferDialog = false }) {
            Card(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(Translator.t("new_transfer", idioma), fontWeight = FontWeight.Bold, fontSize = 16.sp)

                    // Origin Wallet Selector
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = selectedFromWallet?.nome ?: "Escolha a origem",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (idioma == "PT") "Carteira Origem" else "From Wallet") },
                            trailingIcon = { Icon(Icons.Rounded.ArrowDropDown, null) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .clickable { fromDropdownOpen = true }
                        )
                        DropdownMenu(expanded = fromDropdownOpen, onDismissRequest = { fromDropdownOpen = false }) {
                            wallets.filter { it.ativa }.forEach { w ->
                                DropdownMenuItem(
                                    leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary) },
                                    text = { Text(w.nome) },
                                    onClick = {
                                        selectedFromWallet = w
                                        fromDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    // Destination Wallet Selector
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = selectedToWallet?.nome ?: "Escolha o destino",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (idioma == "PT") "Carteira Destino" else "To Wallet") },
                            trailingIcon = { Icon(Icons.Rounded.ArrowDropDown, null) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .clickable { toDropdownOpen = true }
                        )
                        DropdownMenu(expanded = toDropdownOpen, onDismissRequest = { toDropdownOpen = false }) {
                            wallets.filter { it.ativa }.forEach { w ->
                                DropdownMenuItem(
                                    leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary) },
                                    text = { Text(w.nome) },
                                    onClick = {
                                        selectedToWallet = w
                                        toDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = transferAmountStr,
                        onValueChange = { transferAmountStr = sanitizeDoubleInput(transferAmountStr, it) },
                        label = { Text(Translator.t("value", idioma) + " (MZN)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Quick Transfer Amount Presets
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(100, 500, 1000, 5000).forEach { amount ->
                            Button(
                                onClick = {
                                    val currentVal = transferAmountStr.toDoubleOrNull() ?: 0.0
                                    transferAmountStr = String.format(java.util.Locale.US, "%.2f", currentVal + amount)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f).height(30.dp)
                            ) {
                                Text("+$amount", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        IconButton(
                            onClick = { transferAmountStr = "" },
                            modifier = Modifier.size(30.dp).background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        ) {
                            Icon(Icons.Rounded.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
                        }
                    }

                    OutlinedTextField(
                        value = transferDesc,
                        onValueChange = { transferDesc = it },
                        label = { Text(Translator.t("description", idioma)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showTransferDialog = false }) {
                            Text(Translator.t("cancel", idioma))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val amt = transferAmountStr.toDoubleOrNull() ?: 0.0
                                if (selectedFromWallet?.id == selectedToWallet?.id) {
                                    Toast.makeText(context, if (idioma == "PT") "As carteiras de origem e destino têm de ser diferentes!" else "Source and destination wallets must be different!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (selectedFromWallet != null && selectedToWallet != null && amt > 0.0) {
                                    viewModel.executeTransfer(
                                        fromWalletId = selectedFromWallet!!.id,
                                        toWalletId = selectedToWallet!!.id,
                                        amount = amt,
                                        description = transferDesc
                                    )
                                    showTransferDialog = false
                                } else {
                                    Toast.makeText(context, if (idioma == "PT") "Insira valores válidos!" else "Please enter valid values!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Text(Translator.t("confirm", idioma))
                        }
                    }
                }
            }
        }
    }

    // Interactive Transaction Detail Bottom Sheet (Improvements 6 & 7)
    if (showActionDialogForTransaction != null) {
        val trans = showActionDialogForTransaction!!
        val cat = categoryMap[trans.categoriaId]
        val wallet = walletMap[trans.carteiraOrigemId]
        val catColor = try {
            Color(android.graphics.Color.parseColor(cat?.cor ?: "#4F46E5"))
        } catch (e: Exception) {
            MaterialTheme.colorScheme.primary
        }
        val isExpense = trans.tipo == "Despesa"
        val displayAmount = if (settings.ocultarSaldos) "•••••" else {
            val convertedAmount = viewModel.currencyService.convertFromMT(trans.valor, settings.moedaPadrao)
            String.format(java.util.Locale.GERMAN, "%,.2f", convertedAmount).replace('.', ' ') + " " + settings.moedaPadrao
        }
        
        ModalBottomSheet(
            onDismissRequest = { showActionDialogForTransaction = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false),
            containerColor = MaterialTheme.colorScheme.surface,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header with Emoji and Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(catColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        AppIcon(iconKey = cat?.icone ?: "account_balance_wallet", modifier = Modifier.size(28.dp), tint = catColor)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = trans.descricao,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        Text(
                            text = cat?.nome ?: (if (idioma == "PT") "Sem Categoria" else "No Category"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = catColor
                        )
                    }
                }

                // Elegant Amount Banner Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isExpense) Color(0xFFFF5C5C).copy(alpha = 0.08f) else Color(0xFF35D07F).copy(alpha = 0.08f)
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isExpense) Color(0xFFFF5C5C).copy(alpha = 0.2f) else Color(0xFF35D07F).copy(alpha = 0.2f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (isExpense) {
                                if (idioma == "PT") "VALOR PAGO" else "AMOUNT PAID"
                            } else {
                                if (idioma == "PT") "VALOR RECEBIDO" else "AMOUNT RECEIVED"
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isExpense) Color(0xFFFF5C5C) else Color(0xFF35D07F),
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = (if (isExpense) "-" else "+") + displayAmount,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = if (isExpense) Color(0xFFFF5C5C) else Color(0xFF35D07F)
                        )
                        if (trans.moedaOriginal != "MZN" && trans.valorOriginal > 0.0) {
                            Text(
                                text = "Equiv: " + String.format(java.util.Locale.US, "%.2f", trans.valorOriginal) + " " + trans.moedaOriginal + " (Câmbio: " + trans.taxaCambioUsada + ")",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Grid of detailed metadata
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Wallet / Source
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (idioma == "PT") "Conta / Carteira" else "Account / Wallet",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                AppIcon(iconKey = wallet?.icone ?: "credit_card", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = wallet?.nome ?: (if (idioma == "PT") "Desconhecido" else "Unknown"),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))

                        // Date Time
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (idioma == "PT") "Data e Hora" else "Date and Time",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                fontWeight = FontWeight.SemiBold
                            )
                            val formatedDate = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(trans.data))
                            Text(
                                text = formatedDate,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))

                        // Recurrence Status
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (idioma == "PT") "Recorrência" else "Recurrence",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (trans.recorrente) {
                                    if (idioma == "PT") "Mensal Recorrente" else "Monthly Recurring"
                                } else {
                                    if (idioma == "PT") "Única" else "One-time"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (trans.recorrente) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Observations / Notes if exists
                        if (!trans.observacoes.isNullOrBlank()) {
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Observações" else "Observations",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = trans.observacoes,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        // Simulated Proof thumbnail / image indicator if url exists
                        if (!trans.comprovanteUrl.isNullOrBlank()) {
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Anexo de Comprovativo" else "Attached Proof",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                        .clickable {
                                            Toast.makeText(context, if (idioma == "PT") "Visualizando comprovativo..." else "Opening receipt proof...", Toast.LENGTH_SHORT).show()
                                        },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Rounded.AttachFile, null, tint = MaterialTheme.colorScheme.primary)
                                            Text(
                                                text = if (idioma == "PT") "Ver Imagem do Recibo" else "View Receipt Image",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Actions Block (Sleek Horizontal Buttons)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            if (trans.tipo == "Transferencia") {
                                Toast.makeText(
                                    context,
                                    if (idioma == "PT") "Transferências não podem ser editadas aqui. Elimine e lance novamente." else "Transfers can't be edited here. Delete and re-enter instead.",
                                    Toast.LENGTH_LONG
                                ).show()
                            } else {
                                showEditTransactionDialog = trans
                            }
                            showActionDialogForTransaction = null
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Icon(Icons.Rounded.Edit, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Translator.t("edit", idioma), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            viewModel.deleteTransaction(trans)
                            showActionDialogForTransaction = null
                            Toast.makeText(context, if (idioma == "PT") "Movido para a Lixeira!" else "Moved to Trash!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Delete, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Translator.t("delete", idioma), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Simulated Attachment Selection Row & Dialog
                var showAttachmentSelector by remember { mutableStateOf(false) }
                OutlinedButton(
                    onClick = { showAttachmentSelector = true },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.AttachFile, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (idioma == "PT") "Anexar Comprovativo / Foto" else "Attach Proof / Photo", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                if (showAttachmentSelector) {
                    Dialog(onDismissRequest = { showAttachmentSelector = false }) {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Selecionar Comprovativo" else "Select Proof Document",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                                val options = listOf(
                                    "Captura_M-Pesa_Transf_91823.png" to "https://example.com/mpesa.png",
                                    "Recibo_Supermercado_Recheio.png" to "https://example.com/recheio.png",
                                    "Fatura_EDM_Credelec_Janeiro.pdf" to "https://example.com/credelec.pdf",
                                    "Comprovativo_ATM_BIM_993.png" to "https://example.com/atm.png",
                                    "Recibo_Combustivel_Petromoc.png" to "https://example.com/petromoc.png"
                                )
                                options.forEach { (label, url) ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.updateTransaction(trans, trans.copy(comprovanteUrl = url))
                                                showAttachmentSelector = false
                                                showActionDialogForTransaction = null
                                                Toast.makeText(context, if (idioma == "PT") "Comprovativo anexado com sucesso!" else "Proof attached successfully!", Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(vertical = 8.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Rounded.AttachFile, null, tint = themeColor, modifier = Modifier.size(16.dp))
                                        Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                                    }
                                }
                                if (!trans.comprovanteUrl.isNullOrBlank()) {
                                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                                    TextButton(
                                        onClick = {
                                            viewModel.updateTransaction(trans, trans.copy(comprovanteUrl = null))
                                            showAttachmentSelector = false
                                            showActionDialogForTransaction = null
                                            Toast.makeText(context, if (idioma == "PT") "Comprovativo removido!" else "Proof removed!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(if (idioma == "PT") "Remover Comprovativo Atual" else "Remove Current Proof", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditTransactionDialog != null) {
        EditTransactionDialog(
            viewModel = viewModel,
            transaction = showEditTransactionDialog!!,
            wallets = wallets,
            categories = categories,
            onDismiss = { showEditTransactionDialog = null }
        )
    }

    if (showCustomDateRangeDialog) {
        val defaultStart = customStartDate ?: System.currentTimeMillis()
        val defaultEnd = customEndDate ?: System.currentTimeMillis()
        var selStart by remember { mutableStateOf(defaultStart) }
        var selEnd by remember { mutableStateOf(defaultEnd) }
        val dateFormatter = remember { java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()) }

        AlertDialog(
            onDismissRequest = { showCustomDateRangeDialog = false },
            title = {
                Text(
                    if (idioma == "PT") "Intervalo de Datas Personalizado" else "Custom Date Range",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val cal = Calendar.getInstance().apply { timeInMillis = selStart }
                                android.app.DatePickerDialog(
                                    context,
                                    { _, y, m, d ->
                                        val c = Calendar.getInstance().apply {
                                            set(y, m, d, 0, 0, 0)
                                            set(Calendar.MILLISECOND, 0)
                                        }
                                        selStart = c.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSystemInDarkTheme()) Color(0xFF1F2D42) else Color(0xFFF1F5F9)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = if (idioma == "PT") "Data Inicial" else "Start Date",
                                    fontSize = 11.sp,
                                    color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                )
                                Text(
                                    text = dateFormatter.format(java.util.Date(selStart)),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A)
                                )
                            }
                            Icon(
                                imageVector = Icons.Rounded.CalendarToday,
                                contentDescription = null,
                                tint = themeColor
                            )
                        }
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val cal = Calendar.getInstance().apply { timeInMillis = selEnd }
                                android.app.DatePickerDialog(
                                    context,
                                    { _, y, m, d ->
                                        val c = Calendar.getInstance().apply {
                                            set(y, m, d, 23, 59, 59)
                                            set(Calendar.MILLISECOND, 999)
                                        }
                                        selEnd = c.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSystemInDarkTheme()) Color(0xFF1F2D42) else Color(0xFFF1F5F9)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = if (idioma == "PT") "Data Final" else "End Date",
                                    fontSize = 11.sp,
                                    color = if (isSystemInDarkTheme()) Color(0xFF98A2B3) else Color(0xFF64748B)
                                )
                                Text(
                                    text = dateFormatter.format(java.util.Date(selEnd)),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0F172A)
                                )
                            }
                            Icon(
                                imageVector = Icons.Rounded.CalendarToday,
                                contentDescription = null,
                                tint = themeColor
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setCustomDateRange(selStart, selEnd)
                        showCustomDateRangeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeColor)
                ) {
                    Text(if (idioma == "PT") "Aplicar" else "Apply")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomDateRangeDialog = false }) {
                    Text(if (idioma == "PT") "Cancelar" else "Cancel")
                }
            }
        )
    }
}

// ------------------- TELA 3: ADICIONAR LANÇAMENTO -------------------
@Composable
fun AdicionarTransactionScreen(
    viewModel: MainViewModel,
    wallets: List<Wallet>,
    categories: List<Category>,
    isExpenseDefault: Boolean,
    isRecorrenteDefault: Boolean = false,
    initialTypeDefault: String = "DESPESA",
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current

    // 1. Transaction Type: DESPESA, INJECAO, TRANSFERENCIA
    var transactionType by remember(initialTypeDefault, isExpenseDefault) {
        mutableStateOf(if (initialTypeDefault.isNotBlank()) initialTypeDefault else if (isExpenseDefault) "DESPESA" else "INJECAO")
    }
    var isExpense by remember(transactionType) { mutableStateOf(transactionType == "DESPESA") }

    // 2. Continuous Entry Mode
    var continuarLancando by remember { mutableStateOf(false) }

    // Form fields
    var isSubmitting by remember { mutableStateOf(false) }
    var descricao by remember { mutableStateOf("") }
    var valorStr by remember { mutableStateOf("") }
    var showCalculator by remember { mutableStateOf(false) }
    var recorrente by remember { mutableStateOf(isRecorrenteDefault) }
    var frequenciaRecorrencia by remember { mutableStateOf("Mensal") }
    var diaDoMesRecorrencia by remember { mutableStateOf("5") }
    var freqDropdownOpen by remember { mutableStateOf(false) }
    var diaDropdownOpen by remember { mutableStateOf(false) }
    var observacoesText by remember { mutableStateOf("") }
    var dataTransacao by remember { mutableStateOf(System.currentTimeMillis()) }
    
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
    val transactionsList by viewModel.transactions.collectAsStateWithLifecycle(emptyList())
    val idioma = userSettings?.idioma ?: "PT"

    var selectedCategory by remember { mutableStateOf<Category?>(null) }
    var categoriaEscolhidaManualmente by remember { mutableStateOf(false) }
    var selectedWallet by remember { mutableStateOf<Wallet?>(null) }
    var selectedToWallet by remember { mutableStateOf<Wallet?>(wallets.getOrNull(1) ?: wallets.firstOrNull()) }
    var moedaSelected by remember(userSettings) { mutableStateOf(userSettings?.moedaPadrao ?: "MZN") }
    var comprovanteSimulatedUrl by remember { mutableStateOf<String?>(null) }
    var showFullReceiptDialog by remember { mutableStateOf(false) }

    // 6. Payment Status (Efetivação)
    var statusEfetivacao by remember { mutableStateOf("Pago") } // "Pago", "Pendente"

    var currencyDropdownOpen by remember { mutableStateOf(false) }
    var showDuplicateWarning by remember { mutableStateOf(false) }
    var tactileState by remember { mutableStateOf(TactileSuccessState()) }

    LaunchedEffect(descricao) {
        if (descricao.length >= 3 && !categoriaEscolhidaManualmente) {
            delay(300) // debounce: evita chamar suggestCategory a cada tecla digitada
            val suggestedCatId = viewModel.suggestCategory(descricao)
            if (suggestedCatId != null) {
                val cat = categories.find { it.id == suggestedCatId }
                if (cat != null) {
                    selectedCategory = cat
                }
            }
        }
    }

    // Sync isExpense with transactionType
    LaunchedEffect(transactionType) {
        if (transactionType == "DESPESA") isExpense = true
        else if (transactionType == "INJECAO") isExpense = false
    }

    val filteredCats = remember(categories, transactionsList, isExpense) {
        val counts = transactionsList.groupingBy { it.categoriaId }.eachCount()
        categories
            .filter { if (isExpense) it.tipo == "Despesa" else it.tipo == "Injecao" }
            .sortedByDescending { counts[it.id] ?: 0 }
    }

    LaunchedEffect(isExpense, categories) {
        val currentType = if (isExpense) "Despesa" else "Injecao"
        if (selectedCategory == null || selectedCategory!!.tipo != currentType) {
            selectedCategory = filteredCats.firstOrNull()
        }
    }

    LaunchedEffect(wallets) {
        if (selectedWallet == null) {
            selectedWallet = wallets.firstOrNull()
        }
        if (selectedToWallet == null) {
            selectedToWallet = wallets.getOrNull(1) ?: wallets.firstOrNull()
        }
    }

    // Math evaluator helper (Improvement 7)
    fun evaluateMathExpression(input: String): Double? {
        try {
            val sanitized = input.replace(",", ".").replace(" ", "")
            if (sanitized.toDoubleOrNull() != null) return sanitized.toDouble()
            val tokens = mutableListOf<String>()
            var i = 0
            val sb = StringBuilder()
            while (i < sanitized.length) {
                val c = sanitized[i]
                if (c in "+-*/") {
                    if (sb.isNotEmpty()) {
                        tokens.add(sb.toString())
                        sb.clear()
                    }
                    if (c == '-' && (tokens.isEmpty() || tokens.last() in listOf("+", "-", "*", "/"))) {
                        sb.append(c)
                    } else {
                        tokens.add(c.toString())
                    }
                } else {
                    sb.append(c)
                }
                i++
            }
            if (sb.isNotEmpty()) tokens.add(sb.toString())

            if (tokens.size < 3) return null

            // 1ª passagem: resolve * e / (maior precedência), da esquerda para a direita.
            val stage1 = mutableListOf<String>()
            stage1.add(tokens[0])
            var idx = 1
            while (idx < tokens.size - 1) {
                val op = tokens[idx]
                val nextVal = tokens[idx + 1].toDoubleOrNull() ?: return null
                if (op == "*" || op == "/") {
                    val prevVal = stage1.removeAt(stage1.size - 1).toDoubleOrNull() ?: return null
                    val result = if (op == "*") prevVal * nextVal else {
                        if (nextVal == 0.0) return null
                        prevVal / nextVal
                    }
                    stage1.add(result.toString())
                } else {
                    stage1.add(op)
                    stage1.add(tokens[idx + 1])
                }
                idx += 2
            }

            // 2ª passagem: resolve + e - (menor precedência), da esquerda para a direita.
            var total = stage1[0].toDoubleOrNull() ?: return null
            idx = 1
            while (idx < stage1.size - 1) {
                val op = stage1[idx]
                val nextVal = stage1[idx + 1].toDoubleOrNull() ?: return null
                when (op) {
                    "+" -> total += nextVal
                    "-" -> total -= nextVal
                }
                idx += 2
            }
            return total
        } catch (e: Exception) {
            return null
        }
    }

    val evaluatedMathVal = remember(valorStr) { evaluateMathExpression(valorStr) }

    // Photo Attach result launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            comprovanteSimulatedUrl = uri.toString()
            Toast.makeText(context, if (idioma == "PT") "Comprovativo anexado! Processando OCR..." else "Receipt attached! Running OCR...", Toast.LENGTH_SHORT).show()
            viewModel.processOcrReceipt(uri)
        }
    }

    val viewCor = rememberCoroutineScope()

    fun submitTransaction() {
        if (isSubmitting) return
        isSubmitting = true
        try {
            val mathVal = evaluatedMathVal ?: valorStr.toDoubleOrNull() ?: 0.0

            if (transactionType == "TRANSFERENCIA") {
                if (selectedWallet == null || selectedToWallet == null || mathVal <= 0.0) {
                    Toast.makeText(context, if (idioma == "PT") "Selecione carteira de origem, destino e um valor válido!" else "Select source, destination wallets and valid amount!", Toast.LENGTH_SHORT).show()
                    return
                }
                if (selectedWallet?.id == selectedToWallet?.id) {
                    Toast.makeText(context, if (idioma == "PT") "As carteiras de origem e destino têm de ser diferentes!" else "Source and destination wallets must be different!", Toast.LENGTH_SHORT).show()
                    return
                }

                val transferTitle = if (descricao.isNotBlank()) descricao else if (idioma == "PT") "Transferência entre Carteiras" else "Wallet Transfer"
                viewModel.executeTransfer(
                    fromWalletId = selectedWallet!!.id,
                    toWalletId = selectedToWallet!!.id,
                    amount = mathVal,
                    description = transferTitle
                )
                TactileFeedbackHelper.triggerSuccessHaptic(haptic, context, viewCor)
                tactileState = TactileSuccessState(
                    visible = true,
                    title = if (idioma == "PT") "Transferência Efetuada" else "Transfer Completed",
                    detail = "$transferTitle (${selectedWallet?.nome} → ${selectedToWallet?.nome})",
                    amount = "$moedaSelected ${String.format(Locale.getDefault(), "%,.2f", mathVal)}",
                    color = Color(0xFF0EA5E9),
                    icon = Icons.Rounded.SwapHoriz
                )
            } else {
                if (descricao.isBlank() || mathVal <= 0.0 || selectedCategory == null || selectedWallet == null) {
                    Toast.makeText(context, if (idioma == "PT") "Por favor preencha os dados correctamente!" else "Please fill all fields correctly!", Toast.LENGTH_SHORT).show()
                    return
                }

                val fullObs = buildString {
                    if (observacoesText.isNotBlank()) append(observacoesText)
                    if (statusEfetivacao == "Pendente") {
                        if (isNotEmpty()) append(" ")
                        append("[Status: Pendente]")
                    }
                }

                val targetDay = diaDoMesRecorrencia.toIntOrNull() ?: 5
                val cal = Calendar.getInstance().apply { timeInMillis = dataTransacao }
                when (frequenciaRecorrencia) {
                    "Semanal" -> cal.add(Calendar.DAY_OF_MONTH, 7)
                    "Trimestral" -> cal.add(Calendar.MONTH, 3)
                    "Anual" -> cal.add(Calendar.YEAR, 1)
                    else -> { // Mensal
                        cal.add(Calendar.MONTH, 1)
                        cal.set(Calendar.DAY_OF_MONTH, targetDay.coerceAtMost(cal.getActualMaximum(Calendar.DAY_OF_MONTH)))
                    }
                }
                val calculatedNextOccurrence = cal.timeInMillis

                val isExpenseType = (transactionType == "DESPESA")

                viewModel.addTransaction(
                    descricao = descricao,
                    valor = mathVal,
                    tipo = if (isExpenseType) "Despesa" else "Injecao",
                    categoriaId = selectedCategory!!.id,
                    carteiraId = selectedWallet!!.id,
                    moedaTransacao = moedaSelected,
                    comprovanteUrl = comprovanteSimulatedUrl,
                    recorrente = recorrente,
                    observacoes = fullObs,
                    data = dataTransacao,
                    recurrenceFrequency = if (recorrente) frequenciaRecorrencia else null,
                    nextOccurrenceDate = if (recorrente) calculatedNextOccurrence else null
                )

                TactileFeedbackHelper.triggerSuccessHaptic(haptic, context, viewCor)
                tactileState = TactileSuccessState(
                    visible = true,
                    title = if (isExpenseType) {
                        if (idioma == "PT") "Despesa Registada com Sucesso" else "Expense Successfully Recorded"
                    } else {
                        if (idioma == "PT") "Receita Lançada com Sucesso" else "Income Successfully Recorded"
                    },
                    detail = "$descricao (${selectedWallet?.nome} • ${selectedCategory?.nome})",
                    amount = "${if (isExpenseType) "-" else "+"} $moedaSelected ${String.format(Locale.getDefault(), "%,.2f", mathVal)}",
                    color = if (isExpenseType) Color(0xFFEF4444) else Color(0xFF10B981),
                    icon = if (isExpenseType) Icons.Rounded.CheckCircle else Icons.Rounded.AccountBalanceWallet
                )
            }

            if (continuarLancando) {
                // Continuous entry mode: clear values for next transaction
                descricao = ""
                valorStr = ""
                observacoesText = ""
                comprovanteSimulatedUrl = null
            } else {
                onBack()
            }
        } finally {
            isSubmitting = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
        topBar = {
            Surface(
                shadowElevation = 4.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // TOP HEADER WITH CONTINUOUS MODE TOGGLE
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Voltar")
                        }
                        Text(Translator.t("add_entry", idioma), fontSize = 18.sp, fontWeight = FontWeight.Bold)

                        // Continuar lançando toggle
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (continuarLancando) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (idioma == "PT") "Contínuo" else "Continuous",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (continuarLancando) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Switch(
                                checked = continuarLancando,
                                onCheckedChange = { continuarLancando = it },
                                modifier = Modifier.testTag("switch_continuar_lancando")
                            )
                        }
                    }

                    // 1. TOGGLE SEGMENTADO DO TIPO DE TRANSAÇÃO (Sticky UI)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf(
                                Triple("DESPESA", if (idioma == "PT") "Despesa" else "Expense", Color(0xFFE53935)),
                                Triple("INJECAO", if (idioma == "PT") "Receita" else "Income", Color(0xFF43A047)),
                                Triple("TRANSFERENCIA", if (idioma == "PT") "Transferência" else "Transfer", Color(0xFF1E88E5))
                            ).forEach { (typeKey, label, color) ->
                                val isSelected = transactionType == typeKey
                                val isDisabledTransfer = typeKey == "TRANSFERENCIA" && wallets.size < 2
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) color else Color.Transparent)
                                        .clickable {
                                            if (isDisabledTransfer) {
                                                Toast.makeText(
                                                    context,
                                                    if (idioma == "PT") "Crie uma 2ª carteira para transferir" else "Create a 2nd wallet to transfer",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            } else {
                                                transactionType = typeKey
                                                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                        color = if (isDisabledTransfer) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
                                                else if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.imePadding()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val previewAmt = evaluatedMathVal ?: valorStr.toDoubleOrNull() ?: 0.0
                    if (previewAmt > 0.0) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (idioma == "PT") "Valor a lançar:" else "Amount to save:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "%.2f %s".format(java.util.Locale.US, previewAmt, moedaSelected),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (transactionType == "DESPESA") Color(0xFFE53935) else if (transactionType == "INJECAO") Color(0xFF43A047) else Color(0xFF1E88E5)
                            )
                        }
                    }

                    // 2. BOTÃO SALVAR / CONTINUAR LANÇANDO (Sticky UI)
                    Button(
                        enabled = !isSubmitting,
                        onClick = {
                            val mathVal = evaluatedMathVal ?: valorStr.toDoubleOrNull() ?: 0.0
                            if (transactionType != "TRANSFERENCIA" && descricao.isNotBlank() && selectedCategory != null && selectedWallet != null && mathVal > 0.0) {
                                viewCor.launch {
                                    val isDup = viewModel.isTransactionDuplicate(
                                        date = dataTransacao,
                                        categoryId = selectedCategory!!.id,
                                        amount = viewModel.currencyService.convertToMZN(mathVal, moedaSelected),
                                        walletId = selectedWallet!!.id
                                    )
                                    if (isDup) showDuplicateWarning = true
                                    else submitTransaction()
                                }
                            } else {
                                submitTransaction()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_transaction_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (transactionType == "DESPESA") Color(0xFFE53935)
                            else if (transactionType == "INJECAO") Color(0xFF43A047)
                            else Color(0xFF1E88E5)
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = if (continuarLancando) {
                                if (idioma == "PT") "Guardar e Adicionar Outro" else "Save & Add Another"
                            } else {
                                Translator.t("save", idioma)
                            },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // DIGITALIZAR RECIBO (OCR IA) CARD
            val ocrScanResult by viewModel.ocrScanResult.collectAsStateWithLifecycle()
            val isScanningOcr by viewModel.isScanningOcr.collectAsStateWithLifecycle()
            var showOcrTextSimulatorDialog by remember { mutableStateOf(false) }

        LaunchedEffect(ocrScanResult) {
            val res = ocrScanResult
            if (res != null) {
                val foundTotal = res.total != null
                val foundEst = res.establishment != null && res.establishment!!.isNotBlank()
                val foundDate = res.date != null && res.date!!.isNotBlank()

                if (foundTotal || foundEst || foundDate) {
                    descricao = res.establishment ?: ""
                    valorStr = res.total?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: ""
                    
                    res.date?.let { dStr ->
                        val parsedDate = try {
                            val formats = listOf(
                                java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.US),
                                java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.US),
                                java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                            )
                            var dateObj: java.util.Date? = null
                            for (f in formats) {
                                try {
                                    dateObj = f.parse(dStr)
                                    if (dateObj != null) break
                                } catch (e: Exception) {}
                            }
                            dateObj?.time
                        } catch (e: Exception) {
                            null
                        }
                        if (parsedDate != null) {
                            dataTransacao = parsedDate
                        }
                    }

                    val matchedCat = categories.filter { if (isExpense) it.tipo == "Despesa" else it.tipo == "Injecao" }.find { cat ->
                        val est = res.establishment ?: ""
                        cat.nome.contains(est, ignoreCase = true) ||
                        est.contains(cat.nome, ignoreCase = true)
                    }
                    if (matchedCat != null) {
                        selectedCategory = matchedCat
                    }
                    Toast.makeText(context, if (idioma == "PT") "Dados extraídos com sucesso por OCR!" else "Data extracted successfully via OCR!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, if (idioma == "PT") "Não foi possível extrair dados por OCR. Por favor insira manualmente." else "Could not extract data via OCR. Please enter manually.", Toast.LENGTH_LONG).show()
                }
                viewModel.clearOcrResult()
            }
        }

        val ocrImagePickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            if (uri != null) {
                viewModel.processOcrReceipt(uri)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth().testTag("ocr_scanner_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Rounded.CameraAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Column {
                        Text(
                            text = if (idioma == "PT") "DIGITALIZAR RECIBO (OCR IA)" else "SCAN RECEIPT (AI OCR)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = if (idioma == "PT") "Preenchimento automático por imagem" else "Auto-populate from receipt image",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { ocrImagePickerLauncher.launch("image/*") },
                        enabled = !isScanningOcr,
                        modifier = Modifier.weight(1f).height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        if (isScanningOcr) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Rounded.Star, null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (idioma == "PT") "Carregar Imagem" else "Upload Image", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = { showOcrTextSimulatorDialog = true },
                        enabled = !isScanningOcr,
                        modifier = Modifier.weight(1f).height(36.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Icon(Icons.Rounded.Input, null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (idioma == "PT") "Simular Recibo" else "Simulate Receipt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showOcrTextSimulatorDialog) {
            AlertDialog(
                onDismissRequest = { showOcrTextSimulatorDialog = false },
                title = { Text(if (idioma == "PT") "Simulador de Leitura OCR" else "OCR Text Simulator") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = if (idioma == "PT") "Escolha um exemplo de texto para simular o preenchimento:" else "Choose sample text to simulate:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )

                        val examples = listOf(
                            Triple("Mercearia VIP MZN", "MERCEARIA VIP\nData: 02/07/2026\nItem A: 450\nTOTAL: 1,250.00 MZN", "Compras"),
                            Triple("Restaurante Costa do Sol", "RESTAURANTE COSTA DO SOL\n01/07/2026\nPratos: 3200\nTotal a Pagar: 3200 MZN", "Alimentação"),
                            Triple("Farmácia Central", "FARMACIA CENTRAL\nData: 04-07-2026\nMedicamentos\nTotal Pago: 850.00 MZN", "Saúde")
                        )

                        examples.forEach { (title, raw, _) ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.processOcrText(raw)
                                        showOcrTextSimulatorDialog = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    Text(raw.replace("\n", " | "), fontSize = 10.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showOcrTextSimulatorDialog = false }) {
                        Text("Fechar")
                    }
                }
            )
        }

        // 8. PREVIEW EM MINIATURA DO COMPROVANTE ANEXADO (Improvement 8)
        if (comprovanteSimulatedUrl != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = comprovanteSimulatedUrl,
                                contentDescription = "Preview Recibo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        }
                        Column {
                            Text(
                                text = if (idioma == "PT") "Comprovativo Anexado" else "Receipt Attached",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (idioma == "PT") "Imagem pronta para guardar" else "Image ready to save",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = { showFullReceiptDialog = true }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Rounded.Visibility, "Visualizar", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = { comprovanteSimulatedUrl = null }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Rounded.Delete, "Remover", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        if (showFullReceiptDialog && comprovanteSimulatedUrl != null) {
            Dialog(onDismissRequest = { showFullReceiptDialog = false }) {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (idioma == "PT") "Comprovativo de Lançamento" else "Transaction Receipt", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        AsyncImage(
                            model = comprovanteSimulatedUrl,
                            contentDescription = "Full Receipt",
                            modifier = Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(12.dp)),
                            contentScale = androidx.compose.ui.layout.ContentScale.Fit
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { showFullReceiptDialog = false }, modifier = Modifier.fillMaxWidth()) {
                            Text("Fechar")
                        }
                    }
                }
            }
        }

        // DATE PICKER SHORTCUTS
        val calendarObj = remember { Calendar.getInstance() }
        val datePickerDialog = remember(dataTransacao, statusEfetivacao) {
            android.app.DatePickerDialog(
                context,
                { _, year, month, dayOfMonth ->
                    val calObj = Calendar.getInstance().apply {
                        timeInMillis = dataTransacao
                        set(Calendar.YEAR, year)
                        set(Calendar.MONTH, month)
                        set(Calendar.DAY_OF_MONTH, dayOfMonth)
                    }
                    android.app.TimePickerDialog(
                        context,
                        { _, hourOfDay, minute ->
                            calObj.set(Calendar.HOUR_OF_DAY, hourOfDay)
                            calObj.set(Calendar.MINUTE, minute)
                            calObj.set(Calendar.SECOND, 0)
                            calObj.set(Calendar.MILLISECOND, 0)
                            dataTransacao = calObj.timeInMillis
                        },
                        calObj.get(Calendar.HOUR_OF_DAY),
                        calObj.get(Calendar.MINUTE),
                        true
                    ).show()
                },
                calendarObj.get(Calendar.YEAR),
                calendarObj.get(Calendar.MONTH),
                calendarObj.get(Calendar.DAY_OF_MONTH)
            ).apply {
                // O limite de "hoje" só faz sentido para lançamentos já Pagos; um lançamento
                // "Pendente" (ex.: fatura que vence na próxima semana) precisa de permitir data futura.
                if (statusEfetivacao != "Pendente") {
                    datePicker.maxDate = System.currentTimeMillis()
                }
            }
        }

        val isToday = remember(dataTransacao) {
            val c1 = Calendar.getInstance().apply { timeInMillis = dataTransacao }
            val c2 = Calendar.getInstance()
            c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) && c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
        }
        val isYesterday = remember(dataTransacao) {
            val c1 = Calendar.getInstance().apply { timeInMillis = dataTransacao }
            val c2 = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
            c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) && c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = isToday,
                    onClick = {
                        dataTransacao = System.currentTimeMillis()
                        Toast.makeText(context, if (idioma == "PT") "Data: Hoje" else "Date: Today", Toast.LENGTH_SHORT).show()
                    },
                    label = { Text(if (idioma == "PT") "Hoje" else "Today", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = isYesterday,
                    onClick = {
                        dataTransacao = System.currentTimeMillis() - (24L * 60L * 60L * 1000L)
                        Toast.makeText(context, if (idioma == "PT") "Data: Ontem" else "Date: Yesterday", Toast.LENGTH_SHORT).show()
                    },
                    label = { Text(if (idioma == "PT") "Ontem" else "Yesterday", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = false,
                    onClick = { datePickerDialog.show() },
                    label = { Text(if (idioma == "PT") "Outra Data" else "Choose Date", fontSize = 11.sp) }
                )
            }

            val displayDateStr = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(dataTransacao))
            OutlinedTextField(
                value = displayDateStr,
                onValueChange = { },
                readOnly = true,
                label = { Text(if (idioma == "PT") "DATA E HORA DA TRANSAÇÃO" else "TRANSACTION DATE & TIME") },
                modifier = Modifier.fillMaxWidth().clickable { datePickerDialog.show() },
                trailingIcon = {
                    IconButton(onClick = { datePickerDialog.show() }) {
                        Icon(Icons.Rounded.CalendarToday, "Data e Hora")
                    }
                }
            )
        }

        // TITLE / DESCRIPTION WITH AUTOCOMPLETE
        val titleSuggestions = remember(descricao, transactionsList) {
            val query = descricao.trim()
            if (query.isNotEmpty()) {
                transactionsList
                    .map { it.descricao.trim() }
                    .filter { it.isNotBlank() && it.contains(query, ignoreCase = true) && !it.equals(query, ignoreCase = true) }
                    .distinctBy { it.lowercase() }
                    .take(5)
            } else {
                emptyList()
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedTextField(
                value = descricao,
                onValueChange = { descricao = it },
                label = { Text(if (transactionType == "TRANSFERENCIA") "DESCRIÇÃO / TÍTULO DA TRANSFERÊNCIA" else "TÍTULO DA TRANSAÇÃO") },
                placeholder = { Text(if (transactionType == "TRANSFERENCIA") "Ex: Envio para Poupança" else "Ex: Compras Supermercado") },
                trailingIcon = {
                    if (descricao.isNotEmpty()) {
                        IconButton(onClick = { descricao = "" }) {
                            Icon(Icons.Rounded.Clear, contentDescription = "Limpar")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().testTag("input_descricao")
            )

            if (titleSuggestions.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(bottom = 2.dp)
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                            Text(if (idioma == "PT") "Autocompletar histórico:" else "Autocomplete history:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            items(titleSuggestions, key = { it }) { suggestion ->
                                FilterChip(
                                    selected = false,
                                    onClick = {
                                        descricao = suggestion
                                        val pastTx = transactionsList.find { it.descricao.equals(suggestion, ignoreCase = true) }
                                        if (pastTx != null) {
                                            val matchedCat = categories.find { it.id == pastTx.categoriaId }
                                            if (matchedCat != null) {
                                                selectedCategory = matchedCat
                                                categoriaEscolhidaManualmente = true
                                            }
                                            if (pastTx.valor > 0) valorStr = String.format(java.util.Locale.US, "%.2f", pastTx.valor)
                                            wallets.find { it.id == pastTx.carteiraOrigemId }?.let { selectedWallet = it }
                                        }
                                    },
                                    label = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Icon(Icons.Rounded.FlashOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                                            Text(suggestion, fontSize = 11.sp)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 7. EXPRESSÃO MATEMÁTICA INLINE NO CAMPO DE VALOR (Improvement 7)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = valorStr,
                    onValueChange = { valorStr = it },
                    label = { Text("VALOR (MZN)") },
                    placeholder = { Text("Ex: 150+45 ou 200*2") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    modifier = Modifier.weight(1.2f).testTag("input_valor"),
                    trailingIcon = {
                        IconButton(onClick = { showCalculator = true }) {
                            Icon(Icons.Rounded.Calculate, "Calculadora", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                    }
                )

                Box(modifier = Modifier.weight(0.8f)) {
                    OutlinedTextField(
                        value = moedaSelected,
                        onValueChange = { },
                        readOnly = true,
                        label = { Text("MOEDA") },
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { currencyDropdownOpen = true }) {
                                Icon(Icons.Rounded.ArrowDropDown, "Open")
                            }
                        }
                    )
                    DropdownMenu(expanded = currencyDropdownOpen, onDismissRequest = { currencyDropdownOpen = false }) {
                        listOf("MZN", "USD", "ZAR", "EUR").forEach { currency ->
                            DropdownMenuItem(text = { Text(currency) }, onClick = { moedaSelected = currency; currencyDropdownOpen = false })
                        }
                    }
                }
            }

            // Inline Math Expression Result Badge
            if (evaluatedMathVal != null && evaluatedMathVal != valorStr.toDoubleOrNull()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Calculate, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                        Text(
                            text = if (idioma == "PT") "Cálculo resolvido:" else "Math calculated:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = String.format(java.util.Locale.US, "%.2f MZN", evaluatedMathVal),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    TextButton(
                        onClick = { valorStr = String.format(java.util.Locale.US, "%.2f", evaluatedMathVal) },
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Text(if (idioma == "PT") "Aplicar" else "Apply", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showCalculator) {
            CalculatorDialog(
                initialValue = evaluatedMathVal?.toString() ?: valorStr,
                idioma = idioma,
                onDismiss = { showCalculator = false },
                onConfirm = { result ->
                    valorStr = result
                    showCalculator = false
                }
            )
        }

        // Quick Amount Presets
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf(100, 500, 1000, 5000).forEach { amount ->
                Button(
                    onClick = {
                        val currentVal = evaluatedMathVal ?: valorStr.toDoubleOrNull() ?: 0.0
                        valorStr = String.format(java.util.Locale.US, "%.2f", currentVal + amount)
                        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.weight(1f).height(30.dp)
                ) {
                    Text("+$amount", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            IconButton(
                onClick = {
                    valorStr = ""
                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                },
                modifier = Modifier.size(30.dp).background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            ) {
                Icon(Icons.Rounded.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
            }
        }

        // 3. PAINEL DE IMPACTO DE SALDO EM TEMPO REAL (Improvement 3)
        selectedWallet?.let { wallet ->
            val numVal = evaluatedMathVal ?: valorStr.toDoubleOrNull() ?: 0.0
            val numValMZN = if (moedaSelected == "MZN") numVal else viewModel.currencyService.convertToMZN(numVal, moedaSelected)
            val isNegativeImpact = (transactionType == "DESPESA" || transactionType == "TRANSFERENCIA")
            val impactVal = if (isNegativeImpact) -numValMZN else numValMZN
            val currentBal = wallet.saldoAtual
            val projectedBal = currentBal + impactVal

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (idioma == "PT") "Impacto no Saldo (${wallet.nome})" else "Balance Impact (${wallet.nome})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (projectedBal < 0) {
                            Text(
                                text = if (idioma == "PT") "Saldo Insuficiente" else "Insufficient Balance",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (idioma == "PT") "Saldo Atual" else "Current", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            AutoResizedText(
                                text = String.format(java.util.Locale.GERMAN, "%,.2f MZN", currentBal),
                                maxFontSize = 12.sp,
                                minFontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }

                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (idioma == "PT") "Impacto" else "Impact", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            AutoResizedText(
                                text = "${if (impactVal > 0) "+" else ""}${String.format(java.util.Locale.GERMAN, "%,.2f MZN", impactVal)}",
                                maxFontSize = 12.sp,
                                minFontSize = 8.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (impactVal > 0) Color(0xFF2E7D32) else if (impactVal < 0) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                softWrap = false,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }

                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (idioma == "PT") "Saldo Projetado" else "Projected", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            AutoResizedText(
                                text = String.format(java.util.Locale.GERMAN, "%,.2f MZN", projectedBal),
                                maxFontSize = 12.sp,
                                minFontSize = 8.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (projectedBal >= 0) Color(0xFF00695C) else MaterialTheme.colorScheme.error,
                                maxLines = 1,
                                softWrap = false,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // CARTEIRA SELECTION
        if (transactionType == "TRANSFERENCIA") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(if (idioma == "PT") "CARTEIRA ORIGEM" else "FROM WALLET", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(wallets, key = { "from_${it.id}" }) { w ->
                            val isSel = selectedWallet?.id == w.id
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedWallet = w },
                                leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(16.dp)) },
                                label = { Text(w.nome, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(if (idioma == "PT") "CARTEIRA DESTINO" else "TO WALLET", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(wallets, key = { "to_${it.id}" }) { w ->
                            val isSel = selectedToWallet?.id == w.id
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedToWallet = w },
                                leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(16.dp)) },
                                label = { Text(w.nome, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(if (idioma == "PT") "CARTEIRA DE ORIGEM" else "SOURCE WALLET", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 0.5.sp)
                LazyRow(
                    modifier = Modifier.fillMaxWidth().testTag("horizontal_wallet_selector"),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    items(wallets, key = { it.id }) { w ->
                        val isSelected = selectedWallet?.id == w.id
                        val defaultColor = MaterialTheme.colorScheme.primary
                        val wColor = remember(w.cor, defaultColor) {
                            try { Color(android.graphics.Color.parseColor(w.cor)) } catch (e: Exception) { defaultColor }
                        }
                        Card(
                            modifier = Modifier
                                .width(140.dp)
                                .clickable { selectedWallet = w; haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = if (isSelected) wColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            border = BorderStroke(width = if (isSelected) 2.dp else 1.dp, color = if (isSelected) wColor else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        ) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                com.example.util.AppIcon(
                                    iconKey = if (w.icone.isNotBlank()) w.icone else w.nome,
                                    contentDescription = w.nome,
                                    tint = wColor,
                                    modifier = Modifier.size(18.dp)
                                )
                                Column {
                                    Text(w.nome, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                    Text("${String.format(java.util.Locale.GERMAN, "%,.0f", w.saldoAtual)} MZN", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }
                }
            }
        }

        // SELEÇÃO DE CATEGORIAS (Mais frequentes primeiro)
        if (transactionType != "TRANSFERENCIA") {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(if (idioma == "PT") "SELECIONAR CATEGORIA" else "SELECT CATEGORY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 0.5.sp)
                LazyRow(
                    modifier = Modifier.fillMaxWidth().testTag("horizontal_category_selector"),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredCats, key = { it.id }) { cat ->
                        val isSelected = selectedCategory?.id == cat.id
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = cat; categoriaEscolhidaManualmente = true; haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress) },
                            leadingIcon = {
                                AppIcon(
                                    iconKey = cat.icone,
                                    modifier = Modifier.size(15.dp),
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = { Text(Translator.getLocalizedCategoryName(cat.nome, idioma), fontSize = 11.5.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }
        }


        // 6. STATUS DE EFETIVAÇÃO (Liquidado vs Pendente) (Improvement 6)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(if (idioma == "PT") "STATUS DE EFETIVAÇÃO" else "SETTLEMENT STATUS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 0.5.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = statusEfetivacao == "Pago",
                    onClick = { statusEfetivacao = "Pago" },
                    label = { Text(if (idioma == "PT") "Liquidado (Efetivado)" else "Settled (Paid)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = statusEfetivacao == "Pendente",
                    onClick = { statusEfetivacao = "Pendente" },
                    label = { Text(if (idioma == "PT") "Pendente / A Pagar" else "Pending / Due", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // OBSERVAÇÕES
        OutlinedTextField(
            value = observacoesText,
            onValueChange = { observacoesText = it },
            label = { Text(if (idioma == "PT") "OBSERVAÇÕES" else "NOTES") },
            placeholder = { Text(if (idioma == "PT") "Observações adicionais..." else "Additional notes...") },
            modifier = Modifier.fillMaxWidth().height(80.dp),
            maxLines = 3
        )

        // RECURRING SWITCH
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(if (idioma == "PT") "Transação Fixa / Recorrente" else "Fixed / Recurring Transaction", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(if (idioma == "PT") "Ative para cobranças mensais automáticas" else "Enable for automatic monthly charges", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
            Switch(checked = recorrente, onCheckedChange = { recorrente = it }, modifier = Modifier.testTag("switch_recorrente"))
        }

        if (recorrente) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (idioma == "PT") "CONFIGURAÇÃO DA RECORRÊNCIA" else "RECURRING SETUP", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("FREQUÊNCIA", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Box(modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = { freqDropdownOpen = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                                    Text(frequenciaRecorrencia, fontSize = 11.sp)
                                }
                                DropdownMenu(expanded = freqDropdownOpen, onDismissRequest = { freqDropdownOpen = false }) {
                                    listOf("Mensal", "Semanal", "Trimestral", "Anual").forEach { freq ->
                                        DropdownMenuItem(text = { Text(freq) }, onClick = { frequenciaRecorrencia = freq; freqDropdownOpen = false })
                                    }
                                }
                            }
                        }
                        // "Dia do Mês" só se aplica a recorrências Mensal/Trimestral/Anual — numa
                        // recorrência Semanal a próxima ocorrência é calculada por dia da semana (+7 dias).
                        if (frequenciaRecorrencia != "Semanal") {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("DIA DO MÊS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedButton(onClick = { diaDropdownOpen = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                                        Text("Dia $diaDoMesRecorrencia", fontSize = 11.sp)
                                    }
                                    DropdownMenu(expanded = diaDropdownOpen, onDismissRequest = { diaDropdownOpen = false }) {
                                        (1..31).forEach { day ->
                                            DropdownMenuItem(text = { Text("Dia $day") }, onClick = { diaDoMesRecorrencia = day.toString(); diaDropdownOpen = false })
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (frequenciaRecorrencia == "Semanal") {
                        Text(
                            if (idioma == "PT") "A próxima cobrança será 7 dias após a data de lançamento." else "The next charge will be 7 days after the entry date.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }

        // ANEXAR COMPROVANTE IMAGE BUTTON
        if (comprovanteSimulatedUrl == null) {
            Button(
                onClick = { imagePickerLauncher.launch("image/*") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AttachFile, null, modifier = Modifier.size(18.dp))
                    Text(if (idioma == "PT") "Anexar Comprovativo (Imagem / Recibo)" else "Attach Receipt (Image)")
                }
            }
        }

        }
    }

    // Duplicate alert warning dialog
    if (showDuplicateWarning) {
        AlertDialog(
            onDismissRequest = { showDuplicateWarning = false },
            title = { Text(if (idioma == "PT") "Possível Transação Duplicada" else "Possible Duplicate Transaction") },
            text = { Text(if (idioma == "PT") "Detectamos um lançamento com o mesmo valor, carteira e categoria registado hoje. Deseja guardar mesmo assim?" else "A transaction with the same amount, wallet and category was recorded today. Do you want to save anyway?") },
            confirmButton = {
                Button(
                    onClick = {
                        showDuplicateWarning = false
                        submitTransaction()
                    }
                ) {
                    Text(if (idioma == "PT") "Sim, Continuar" else "Yes, Continue")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDuplicateWarning = false }) {
                    Text(if (idioma == "PT") "Não, Cancelar" else "No, Cancel")
                }
            }
        )
    }

        TactileSuccessBannerOverlay(
            state = tactileState,
            onDismiss = { tactileState = tactileState.copy(visible = false) }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTransactionDialog(
    viewModel: MainViewModel,
    transaction: Transaction,
    wallets: List<Wallet>,
    categories: List<Category>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
    val idioma = userSettings?.idioma ?: "PT"
    var isExpense by remember { mutableStateOf(transaction.tipo == "Despesa") }
    var descricao by remember { mutableStateOf(transaction.descricao) }
    var valorStr by remember {
        mutableStateOf(
            if (transaction.valorOriginal > 0) String.format(java.util.Locale.US, "%.2f", transaction.valorOriginal)
            else if (transaction.valor > 0) String.format(java.util.Locale.US, "%.2f", transaction.valor)
            else ""
        )
    }
    var showCalculator by remember { mutableStateOf(false) }
    
    val filteredCategories = remember(categories, isExpense) {
        categories.filter { if (isExpense) it.tipo == "Despesa" else it.tipo == "Injecao" }
    }
    var selectedCategory by remember(isExpense) {
        mutableStateOf(
            categories.find { it.id == transaction.categoriaId && (if (isExpense) it.tipo == "Despesa" else it.tipo == "Injecao") }
                ?: filteredCategories.firstOrNull()
        )
    }
    var selectedWallet by remember { mutableStateOf(wallets.find { it.id == transaction.carteiraOrigemId } ?: wallets.firstOrNull()) }
    var categoryDropdownOpen by remember { mutableStateOf(false) }
    var walletDropdownOpen by remember { mutableStateOf(false) }

    var moedaOriginal by remember { mutableStateOf(transaction.moedaOriginal ?: userSettings?.moedaPadrao ?: "MZN") }
    var taxaCambioUsadaStr by remember { mutableStateOf(transaction.taxaCambioUsada.toString()) }
    var observacoesText by remember { mutableStateOf(transaction.observacoes ?: "") }
    var comprovanteUrlState by remember { mutableStateOf(transaction.comprovanteUrl) }
    var currencyDropdownOpen by remember { mutableStateOf(false) }
    var showConfirmDismissDialog by remember { mutableStateOf(false) }
    var showDuplicateWarningDialog by remember { mutableStateOf(false) }

    val currencyOptions = listOf("MZN", "USD", "ZAR", "EUR")

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            comprovanteUrlState = uri.toString()
            Toast.makeText(context, if (idioma == "PT") "Comprovativo anexado!" else "Receipt attached!", Toast.LENGTH_SHORT).show()
        }
    }

    val initialDesc = transaction.descricao
    val initialValor = if (transaction.valor > 0) String.format(java.util.Locale.US, "%.2f", transaction.valor) else ""
    val initialCatId = transaction.categoriaId
    val initialWalId = transaction.carteiraOrigemId
    val initialData = transaction.data
    val initialObs = transaction.observacoes ?: ""
    val initialComp = transaction.comprovanteUrl

    var dataTransacao by remember { mutableStateOf(transaction.data) }

    val hasChanges = remember(descricao, valorStr, selectedCategory, selectedWallet, dataTransacao, observacoesText, comprovanteUrlState) {
        descricao != initialDesc ||
        valorStr != initialValor ||
        selectedCategory?.id != initialCatId ||
        selectedWallet?.id != initialWalId ||
        dataTransacao != initialData ||
        observacoesText != initialObs ||
        comprovanteUrlState != initialComp
    }

    fun safeDismiss() {
        if (hasChanges) {
            showConfirmDismissDialog = true
        } else {
            onDismiss()
        }
    }

    fun executeSave() {
        val valor = valorStr.toDoubleOrNull() ?: 0.0
        val cambio = taxaCambioUsadaStr.toDoubleOrNull() ?: 1.0
        val cat = selectedCategory
        val wal = selectedWallet
        if (descricao.isNotBlank() && valor > 0.0 && cat != null && wal != null) {
            if (moedaOriginal != "MZN" && cambio <= 0.0) {
                Toast.makeText(context, if (idioma == "PT") "Insira uma taxa de câmbio válida!" else "Please enter a valid exchange rate!", Toast.LENGTH_SHORT).show()
                return
            }
            val valorMZN = if (moedaOriginal == "MZN") valor else valor * cambio

            val updated = transaction.copy(
                descricao = descricao,
                valor = valorMZN,
                tipo = if (isExpense) "Despesa" else "Injecao",
                categoriaId = cat.id,
                carteiraOrigemId = wal.id,
                moedaOriginal = moedaOriginal,
                valorOriginal = valor,
                taxaCambioUsada = cambio,
                observacoes = observacoesText,
                comprovanteUrl = comprovanteUrlState,
                data = dataTransacao
            )
            viewModel.updateTransaction(transaction, updated)
            onDismiss()
        } else {
            Toast.makeText(context, if (idioma == "PT") "Por favor preencha todos os campos correctamente" else "Please fill all fields correctly", Toast.LENGTH_SHORT).show()
        }
    }

    val coroutineScope = rememberCoroutineScope()

    if (showConfirmDismissDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDismissDialog = false },
            title = { Text(if (idioma == "PT") "Descartar alterações?" else "Discard changes?") },
            text = { Text(if (idioma == "PT") "Existem alterações não guardadas. Tem a certeza que pretende sair?" else "You have unsaved changes. Are you sure you want to exit?") },
            confirmButton = {
                Button(onClick = { showConfirmDismissDialog = false; onDismiss() }) {
                    Text(if (idioma == "PT") "Descartar" else "Discard")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showConfirmDismissDialog = false }) {
                    Text(if (idioma == "PT") "Continuar a Editar" else "Keep Editing")
                }
            }
        )
    }

    if (showDuplicateWarningDialog) {
        AlertDialog(
            onDismissRequest = { showDuplicateWarningDialog = false },
            title = { Text(if (idioma == "PT") "Possível Transação Duplicada" else "Possible Duplicate Transaction") },
            text = { Text(if (idioma == "PT") "Já existe outra transação com o mesmo valor, carteira e categoria nesta data. Guardar mesmo assim?" else "Another transaction with the same amount, wallet and category exists on this date. Save anyway?") },
            confirmButton = {
                Button(onClick = { showDuplicateWarningDialog = false; executeSave() }) {
                    Text(if (idioma == "PT") "Sim, Guardar" else "Yes, Save")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDuplicateWarningDialog = false }) {
                    Text(if (idioma == "PT") "Cancelar" else "Cancel")
                }
            }
        )
    }

    Dialog(
        onDismissRequest = { safeDismiss() },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { safeDismiss() }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = if (idioma == "PT") "Editar Lançamento" else "Edit Transaction",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                // 1. TÍTULO / DESCRIÇÃO
                OutlinedTextField(
                    value = descricao,
                    onValueChange = { descricao = it },
                    label = { Text(if (idioma == "PT") "TÍTULO" else "TITLE") },
                    placeholder = { Text(if (idioma == "PT") "Ex: Energia Elétrica" else "Ex: Electricity") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Date & Time picker for editing
                val calendarObj = remember { Calendar.getInstance().apply { timeInMillis = dataTransacao } }
                val datePickerDialog = remember(dataTransacao, observacoesText) {
                    android.app.DatePickerDialog(
                        context,
                        { _, year, month, dayOfMonth ->
                            val calObj = Calendar.getInstance().apply {
                                timeInMillis = dataTransacao
                                set(Calendar.YEAR, year)
                                set(Calendar.MONTH, month)
                                set(Calendar.DAY_OF_MONTH, dayOfMonth)
                            }
                            android.app.TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    calObj.set(Calendar.HOUR_OF_DAY, hourOfDay)
                                    calObj.set(Calendar.MINUTE, minute)
                                    calObj.set(Calendar.SECOND, 0)
                                    calObj.set(Calendar.MILLISECOND, 0)
                                    dataTransacao = calObj.timeInMillis
                                },
                                calObj.get(Calendar.HOUR_OF_DAY),
                                calObj.get(Calendar.MINUTE),
                                true
                            ).show()
                        },
                        calendarObj.get(Calendar.YEAR),
                        calendarObj.get(Calendar.MONTH),
                        calendarObj.get(Calendar.DAY_OF_MONTH)
                    ).apply {
                        // Mesma regra da tela de Adicionar: um lançamento marcado como Pendente
                        // pode ter data futura (ex.: fatura a vencer).
                        if (!observacoesText.contains("[Status: Pendente]")) {
                            datePicker.maxDate = System.currentTimeMillis()
                        }
                    }
                }

                val displayDateStr = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(dataTransacao))
                OutlinedTextField(
                    value = displayDateStr,
                    onValueChange = { },
                    readOnly = true,
                    label = { Text(if (idioma == "PT") "DATA E HORA DA TRANSAÇÃO" else "TRANSACTION DATE & TIME") },
                    modifier = Modifier.fillMaxWidth().clickable { datePickerDialog.show() },
                    trailingIcon = {
                        IconButton(onClick = { datePickerDialog.show() }) {
                            Icon(Icons.Rounded.CalendarToday, "Selecionar Data e Hora")
                        }
                    }
                )

                // 2. MOEDA ORIGINAL & CÂMBIO FIXO
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = moedaOriginal,
                            onValueChange = { },
                            readOnly = true,
                            label = { Text(if (idioma == "PT") "MOEDA ORIGINAL" else "CURRENCY") },
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { currencyDropdownOpen = true }) {
                                    Icon(Icons.Rounded.ArrowDropDown, "Open")
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = currencyDropdownOpen,
                            onDismissRequest = { currencyDropdownOpen = false }
                        ) {
                            currencyOptions.forEach { currency ->
                                DropdownMenuItem(
                                    text = { Text(currency) },
                                    onClick = {
                                        moedaOriginal = currency
                                        val rate = viewModel.currencyService.getRate(currency)
                                        taxaCambioUsadaStr = rate.toString()
                                        currencyDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = taxaCambioUsadaStr,
                        onValueChange = { taxaCambioUsadaStr = it },
                        label = { Text(if (idioma == "PT") "CÂMBIO FIXO" else "EXCHANGE RATE") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        enabled = moedaOriginal != "MZN"
                    )
                }

                // 3. VALOR & TIPO
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = valorStr,
                        onValueChange = { valorStr = it },
                        label = { Text(if (idioma == "PT") "VALOR" else "AMOUNT") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1.2f),
                        trailingIcon = {
                            IconButton(onClick = { showCalculator = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.Calculate,
                                    contentDescription = "Calculadora",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    )

                    if (showCalculator) {
                        CalculatorDialog(
                            initialValue = valorStr,
                            idioma = idioma,
                            onDismiss = { showCalculator = false },
                            onConfirm = { result ->
                                valorStr = result
                                showCalculator = false
                            }
                        )
                    }

                    var tipoDropdownOpen by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.weight(0.8f)) {
                        OutlinedTextField(
                            value = if (isExpense) (if (idioma == "PT") "Despesa" else "Expense") else (if (idioma == "PT") "Injeção" else "Income"),
                            onValueChange = { },
                            readOnly = true,
                            label = { Text(if (idioma == "PT") "TIPO" else "TYPE") },
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { tipoDropdownOpen = true }) {
                                    Icon(Icons.Rounded.ArrowDropDown, "Open")
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = tipoDropdownOpen,
                            onDismissRequest = { tipoDropdownOpen = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(if (idioma == "PT") "Despesa" else "Expense") },
                                onClick = {
                                    isExpense = true
                                    tipoDropdownOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (idioma == "PT") "Injeção" else "Income") },
                                onClick = {
                                    isExpense = false
                                    tipoDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                // 4. CATEGORIA
                Box {
                    OutlinedTextField(
                        value = selectedCategory?.let { Translator.getLocalizedCategoryName(it.nome, idioma) } ?: (if (idioma == "PT") "Selecionar Categoria" else "Select Category"),
                        onValueChange = { },
                        readOnly = true,
                        label = { Text(if (idioma == "PT") "CATEGORIA" else "CATEGORY") },
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { categoryDropdownOpen = true }) {
                                Icon(Icons.Rounded.ArrowDropDown, "Open")
                            }
                        }
                    )
                    DropdownMenu(
                        expanded = categoryDropdownOpen,
                        onDismissRequest = { categoryDropdownOpen = false }
                    ) {
                        filteredCategories.forEach { cat ->
                            DropdownMenuItem(
                                text = {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        AppIcon(iconKey = cat.icone, modifier = Modifier.size(16.dp))
                                        Text(Translator.getLocalizedCategoryName(cat.nome, idioma))
                                    }
                                },
                                onClick = {
                                    selectedCategory = cat
                                    categoryDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                // 5. CARTEIRA DE ORIGEM
                Box {
                    OutlinedTextField(
                        value = selectedWallet?.nome ?: (if (idioma == "PT") "Selecionar Carteira" else "Select Wallet"),
                        onValueChange = { },
                        readOnly = true,
                        leadingIcon = {
                            selectedWallet?.let {
                                AppIcon(iconKey = it.icone, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        },
                        label = { Text(if (idioma == "PT") "CARTEIRA DE ORIGEM" else "SOURCE WALLET") },
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { walletDropdownOpen = true }) {
                                Icon(Icons.Rounded.ArrowDropDown, "Open")
                            }
                        }
                    )
                    DropdownMenu(
                        expanded = walletDropdownOpen,
                        onDismissRequest = { walletDropdownOpen = false }
                    ) {
                        wallets.forEach { w ->
                            DropdownMenuItem(
                                leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary) },
                                text = { Text(w.nome) },
                                onClick = {
                                    selectedWallet = w
                                    walletDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                // 6. OBSERVAÇÕES
                OutlinedTextField(
                    value = observacoesText,
                    onValueChange = { observacoesText = it },
                    label = { Text(if (idioma == "PT") "OBSERVAÇÕES" else "NOTES") },
                    placeholder = { Text(if (idioma == "PT") "Observações adicionais..." else "Additional notes...") },
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    maxLines = 4,
                    singleLine = false
                )

                // 7. COMPROVANTE ATTACH / PREVIEW / ZOOM / REMOVE
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (comprovanteUrlState != null) {
                        var showFullScreenZoom by remember { mutableStateOf(false) }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (idioma == "PT") "Recibo Anexado" else "Attached Receipt",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            TextButton(onClick = { comprovanteUrlState = null }) {
                                Text(if (idioma == "PT") "Remover" else "Remove", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            }
                        }
                        
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { showFullScreenZoom = true },
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = comprovanteUrlState,
                                contentDescription = "Preview Recibo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.3f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ZoomIn,
                                    contentDescription = "Zoom",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        if (showFullScreenZoom) {
                            Dialog(
                                onDismissRequest = { showFullScreenZoom = false },
                                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
                            ) {
                                Surface(
                                    modifier = Modifier.fillMaxSize(),
                                    color = Color.Black
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        var scale by remember { mutableStateOf(1f) }
                                        var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }

                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .pointerInput(Unit) {
                                                    detectTransformGestures { _, pan, zoom, _ ->
                                                        scale = (scale * zoom).coerceIn(1f, 5f)
                                                        if (scale > 1f) {
                                                            offset += pan
                                                        } else {
                                                            offset = androidx.compose.ui.geometry.Offset.Zero
                                                        }
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            AsyncImage(
                                                model = comprovanteUrlState,
                                                contentDescription = "Recibo em Tela Cheia",
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .graphicsLayer(
                                                        scaleX = scale,
                                                        scaleY = scale,
                                                        translationX = offset.x,
                                                        translationY = offset.y
                                                    ),
                                                contentScale = androidx.compose.ui.layout.ContentScale.Fit
                                            )
                                        }

                                        IconButton(
                                            onClick = { showFullScreenZoom = false },
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(24.dp)
                                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Close,
                                                contentDescription = "Fechar",
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AttachFile, null, modifier = Modifier.size(18.dp))
                                Text(if (idioma == "PT") "Anexar Comprovativo" else "Attach Receipt")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Actions buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { safeDismiss() }) {
                        Text(Translator.t("cancel", idioma))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val valor = valorStr.toDoubleOrNull() ?: 0.0
                            val cat = selectedCategory
                            val wal = selectedWallet
                            if (descricao.isNotBlank() && valor > 0.0 && cat != null && wal != null) {
                                coroutineScope.launch {
                                    val isDup = viewModel.isTransactionDuplicate(
                                        date = dataTransacao,
                                        categoryId = cat.id,
                                        amount = viewModel.currencyService.convertToMZN(valor, moedaOriginal),
                                        walletId = wal.id,
                                        excludeId = transaction.id
                                    )
                                    if (isDup) {
                                        showDuplicateWarningDialog = true
                                    } else {
                                        executeSave()
                                    }
                                }
                            } else {
                                Toast.makeText(context, if (idioma == "PT") "Por favor preencha todos os campos correctamente" else "Please fill all fields correctly", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) {
                        Text(Translator.t("save", idioma))
                    }
                }
            }
        }
    }
}
