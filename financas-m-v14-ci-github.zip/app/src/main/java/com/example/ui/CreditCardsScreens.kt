@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File


// ------------------- CREDIT CARDS MODULE UI -------------------
@Composable
fun CreditCardsModuleSection(
    viewModel: MainViewModel,
    wallets: List<Wallet>,
    settings: UserSettings
) {
    val creditCards by viewModel.creditCards.collectAsStateWithLifecycle(emptyList())
    val categories by viewModel.categories.collectAsStateWithLifecycle(emptyList())
    val idioma = settings.idioma

    var showAddCardDialog by remember { mutableStateOf(false) }
    var cardToEdit by remember { mutableStateOf<CreditCard?>(null) }
    var cardToPayInvoice by remember { mutableStateOf<CreditCard?>(null) }
    var cardToAddPurchase by remember { mutableStateOf<CreditCard?>(null) }

    val totalLimite = remember(creditCards) { creditCards.filter { it.ativa }.sumOf { it.limiteTotal } }
    val totalDisponivel = remember(creditCards) { creditCards.filter { it.ativa }.sumOf { it.limiteDisponivel } }
    val totalFaturaAtual = remember(totalLimite, totalDisponivel) { (totalLimite - totalDisponivel).coerceAtLeast(0.0) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Summary Header Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = Color(0xFF1E293B),
            shadowElevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CreditCard,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8)
                        )
                        Text(
                            text = if (idioma == "PT") "Gestão de Cartões de Crédito" else "Credit Cards Hub",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    FilledTonalButton(
                        onClick = { showAddCardDialog = true },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF00E676).copy(alpha = 0.2f),
                            contentColor = Color(0xFF00E676)
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (idioma == "PT") "Novo Cartão" else "New Card", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (idioma == "PT") "Fatura Atual Total" else "Total Current Invoice",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            text = "${String.format("%,.2f", totalFaturaAtual)} ${settings.moedaPadrao}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFFF5252)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (idioma == "PT") "Limite Disponível Total" else "Total Available Limit",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            text = "${String.format("%,.2f", totalDisponivel)} ${settings.moedaPadrao}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF00E676)
                        )
                    }
                }

                // Global Limit Progress Bar
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    val pct = if (totalLimite > 0) ((totalLimite - totalDisponivel) / totalLimite).toFloat() else 0f
                    LinearProgressIndicator(
                        progress = { pct.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = Color(0xFFFF5252),
                        trackColor = Color.White.copy(alpha = 0.15f)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (idioma == "PT") "Uso de Limite Total: ${String.format("%.0f", pct * 100)}%" else "Total Limit Usage: ${String.format("%.0f", pct * 100)}%",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                        Text(
                            text = "T: ${String.format("%,.0f", totalLimite)} ${settings.moedaPadrao}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // Cards Carousel List
        if (creditCards.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (idioma == "PT") "Nenhum cartão registado. Clique em 'Novo Cartão'." else "No cards registered. Tap 'New Card'.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                items(creditCards, key = { it.id }) { card ->
                    CreditCardItemVisual(
                        card = card,
                        settings = settings,
                        onPayInvoice = { cardToPayInvoice = card },
                        onAddPurchase = { cardToAddPurchase = card },
                        onEdit = { cardToEdit = card },
                        onDelete = { viewModel.deleteCreditCard(card) }
                    )
                }
            }
        }
    }

    // Dialogs
    if (showAddCardDialog) {
        AddEditCreditCardDialog(
            card = null,
            wallets = wallets,
            idioma = idioma,
            onDismiss = { showAddCardDialog = false },
            onSave = { newCard ->
                viewModel.addCreditCard(newCard)
                showAddCardDialog = false
            }
        )
    }

    cardToEdit?.let { card ->
        AddEditCreditCardDialog(
            card = card,
            wallets = wallets,
            idioma = idioma,
            onDismiss = { cardToEdit = null },
            onSave = { updatedCard ->
                viewModel.updateCreditCard(updatedCard)
                cardToEdit = null
            }
        )
    }

    cardToPayInvoice?.let { card ->
        PayCreditCardInvoiceDialog(
            card = card,
            wallets = wallets,
            idioma = idioma,
            currencySymbol = settings.moedaPadrao,
            onDismiss = { cardToPayInvoice = null },
            onConfirm = { amount, walletId ->
                viewModel.payCreditCardInvoice(card.id, amount, walletId)
                cardToPayInvoice = null
            }
        )
    }

    cardToAddPurchase?.let { card ->
        AddCreditCardPurchaseDialog(
            card = card,
            categories = categories,
            idioma = idioma,
            currencySymbol = settings.moedaPadrao,
            onDismiss = { cardToAddPurchase = null },
            onConfirm = { amount, desc, catId ->
                viewModel.addCreditCardPurchase(card.id, amount, desc, catId)
                cardToAddPurchase = null
            }
        )
    }
}

@Composable
fun CreditCardItemVisual(
    card: CreditCard,
    settings: UserSettings,
    onPayInvoice: () -> Unit,
    onAddPurchase: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val idioma = settings.idioma
    val cardColor = remember(card.corHex) {
        try {
            Color(android.graphics.Color.parseColor(card.corHex))
        } catch (e: Exception) {
            Color(0xFF1E293B)
        }
    }

    val faturaAtual = (card.limiteTotal - card.limiteDisponivel).coerceAtLeast(0.0)
    val pctUsed = if (card.limiteTotal > 0) (faturaAtual / card.limiteTotal).toFloat() else 0f

    Surface(
        modifier = Modifier
            .width(310.dp)
            .clip(RoundedCornerShape(20.dp)),
        color = cardColor,
        shadowElevation = 8.dp
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Background subtle circles decoration
            Canvas(modifier = Modifier.matchParentSize()) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.05f),
                    radius = size.width * 0.45f,
                    center = Offset(size.width * 0.85f, size.height * 0.2f)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Top Header: Name, Tipo & Brand
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = card.nome,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color.White.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = card.tipo,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            val brandColor = try {
                                Color(android.graphics.Color.parseColor(card.corHex))
                            } catch (e: Exception) {
                                Color(0xFF00E676)
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = brandColor.copy(alpha = 0.85f)
                            ) {
                                Text(
                                    text = card.bandeira,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Outlined.Edit, contentDescription = "Editar", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Outlined.Delete, contentDescription = "Eliminar", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                        }
                    }
                }

                // Statement Closing Alert Badge (B.11)
                val daysUntilClosing = calculateDaysUntilDayOfMonth(card.diaFechamento)
                if (daysUntilClosing in 0..5) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFF9800).copy(alpha = 0.9f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Schedule, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (daysUntilClosing == 0) (if (idioma == "PT") "Fatura fecha hoje" else "Invoice closes today")
                                else (if (idioma == "PT") "Fatura fecha em $daysUntilClosing dias" else "Invoice closes in $daysUntilClosing days"),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                // Card Chip and Number
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Gold Chip representation
                    Box(
                        modifier = Modifier
                            .size(32.dp, 24.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFFFD700))
                            .border(1.dp, Color(0xFFDAA520), RoundedCornerShape(4.dp))
                    )
                    Text(
                        text = "•••• •••• •••• ${card.ultimos4Digitos}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.9f),
                        letterSpacing = 1.sp
                    )
                }

                // Dates info (Fechamento & Vencimento)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (idioma == "PT") "Fechamento" else "Closing Day",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            text = "Dia ${card.diaFechamento}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (idioma == "PT") "Vencimento" else "Due Day",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            text = "Dia ${card.diaVencimento}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFB74D)
                        )
                    }
                }

                // Invoice Amount & Progress
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (idioma == "PT") "Fatura Atual:" else "Current Invoice:",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                        Text(
                            text = "${String.format("%,.2f", faturaAtual)} ${settings.moedaPadrao}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (faturaAtual > 0) Color(0xFFFF5252) else Color(0xFF00E676)
                        )
                    }

                    LinearProgressIndicator(
                        progress = { pctUsed.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = if (pctUsed > 0.9f) Color(0xFFFF1744) else Color(0xFF38BDF8),
                        trackColor = Color.White.copy(alpha = 0.2f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (idioma == "PT") "Disp: ${String.format("%,.0f", card.limiteDisponivel)} ${settings.moedaPadrao}" else "Avail: ${String.format("%,.0f", card.limiteDisponivel)} ${settings.moedaPadrao}",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                        Text(
                            text = if (idioma == "PT") "Limite: ${String.format("%,.0f", card.limiteTotal)} ${settings.moedaPadrao}" else "Limit: ${String.format("%,.0f", card.limiteTotal)} ${settings.moedaPadrao}",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }

                // Card Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onAddPurchase,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.2f),
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Rounded.ShoppingCart, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (idioma == "PT") "+ Compra" else "+ Purchase", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onPayInvoice,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E676),
                            contentColor = Color(0xFF0F2C24)
                        ),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (idioma == "PT") "Pagar Fatura" else "Pay Invoice", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditCreditCardDialog(
    card: CreditCard?,
    wallets: List<Wallet>,
    idioma: String,
    onDismiss: () -> Unit,
    onSave: (CreditCard) -> Unit
) {
    var nome by remember { mutableStateOf(card?.nome ?: "") }
    var tipo by remember { mutableStateOf(card?.tipo ?: "Físico") }
    var bandeira by remember { mutableStateOf(card?.bandeira ?: "Visa") }
    var digitos by remember { mutableStateOf(card?.ultimos4Digitos ?: "4321") }
    var limiteTotalStr by remember { mutableStateOf(card?.limiteTotal?.toString() ?: "50000") }
    var limiteDisponivelStr by remember { mutableStateOf(card?.limiteDisponivel?.toString() ?: "50000") }
    var diaFechamentoStr by remember { mutableStateOf(card?.diaFechamento?.toString() ?: "15") }
    var diaVencimentoStr by remember { mutableStateOf(card?.diaVencimento?.toString() ?: "25") }
    var corHex by remember { mutableStateOf(card?.corHex ?: "#1E293B") }

    val colorsList = listOf("#1E293B", "#10B981", "#1A73E8", "#8B5CF6", "#EC4899", "#F59E0B")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (card == null) (if (idioma == "PT") "Adicionar Cartão de Crédito" else "Add Credit Card")
                else (if (idioma == "PT") "Editar Cartão de Crédito" else "Edit Credit Card"),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text(if (idioma == "PT") "Nome do Cartão" else "Card Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(if (idioma == "PT") "Tipo" else "Type", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row {
                            FilterChip(
                                selected = tipo == "Físico",
                                onClick = { tipo = "Físico" },
                                label = { Text("Físico", fontSize = 11.sp) }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            FilterChip(
                                selected = tipo == "Digital",
                                onClick = { tipo = "Digital" },
                                label = { Text("Digital", fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = bandeira,
                        onValueChange = { bandeira = it },
                        label = { Text(if (idioma == "PT") "Bandeira/Banco" else "Brand/Bank") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = digitos,
                        onValueChange = { if (it.length <= 4) digitos = it },
                        label = { Text("Últimos 4") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(0.8f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = limiteTotalStr,
                        onValueChange = { limiteTotalStr = it },
                        label = { Text(if (idioma == "PT") "Limite Total" else "Total Limit") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = limiteDisponivelStr,
                        onValueChange = { limiteDisponivelStr = it },
                        label = { Text(if (idioma == "PT") "Limite Disponível" else "Available") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                var showClosingDayDropdown by remember { mutableStateOf(false) }
                var showDueDayDropdown by remember { mutableStateOf(false) }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = "Dia $diaFechamentoStr",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (idioma == "PT") "Dia Fechamento" else "Closing Day") },
                            trailingIcon = { Icon(Icons.Rounded.ArrowDropDown, null) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Box(modifier = Modifier.matchParentSize().clickable { showClosingDayDropdown = true })
                        DropdownMenu(expanded = showClosingDayDropdown, onDismissRequest = { showClosingDayDropdown = false }) {
                            (1..31).forEach { day ->
                                DropdownMenuItem(
                                    text = { Text("Dia $day") },
                                    onClick = {
                                        diaFechamentoStr = day.toString()
                                        showClosingDayDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = "Dia $diaVencimentoStr",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(if (idioma == "PT") "Dia Vencimento" else "Due Day") },
                            trailingIcon = { Icon(Icons.Rounded.ArrowDropDown, null) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Box(modifier = Modifier.matchParentSize().clickable { showDueDayDropdown = true })
                        DropdownMenu(expanded = showDueDayDropdown, onDismissRequest = { showDueDayDropdown = false }) {
                            (1..31).forEach { day ->
                                DropdownMenuItem(
                                    text = { Text("Dia $day") },
                                    onClick = {
                                        diaVencimentoStr = day.toString()
                                        showDueDayDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                Text(if (idioma == "PT") "Cor do Cartão" else "Card Color", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    colorsList.forEach { hex ->
                        val colorVal = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { Color.Gray }
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clickable { corHex = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(colorVal)
                                    .border(
                                        width = if (corHex == hex) 3.dp else 0.dp,
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = CircleShape
                                    )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val lTot = limiteTotalStr.toDoubleOrNull() ?: 50000.0
                    val lDisp = limiteDisponivelStr.toDoubleOrNull() ?: lTot
                    val dFech = diaFechamentoStr.toIntOrNull()?.coerceIn(1, 31) ?: 15
                    val dVenc = diaVencimentoStr.toIntOrNull()?.coerceIn(1, 31) ?: 25

                    onSave(
                        CreditCard(
                            id = card?.id ?: 0,
                            nome = nome.ifBlank { "Cartão de Crédito" },
                            tipo = tipo,
                            bandeira = bandeira.ifBlank { "Visa" },
                            ultimos4Digitos = digitos.ifBlank { "1234" },
                            limiteTotal = lTot,
                            limiteDisponivel = lDisp,
                            diaFechamento = dFech,
                            diaVencimento = dVenc,
                            corHex = corHex,
                            carteiraPagamentoId = card?.carteiraPagamentoId ?: (wallets.firstOrNull()?.id ?: 0)
                        )
                    )
                }
            ) {
                Text(if (idioma == "PT") "Guardar" else "Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Cancelar" else "Cancel")
            }
        }
    )
}

@Composable
fun PayCreditCardInvoiceDialog(
    card: CreditCard,
    wallets: List<Wallet>,
    idioma: String,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (Double, Int) -> Unit
) {
    val faturaAtual = (card.limiteTotal - card.limiteDisponivel).coerceAtLeast(0.0)
    var valorStr by remember { mutableStateOf(faturaAtual.toString()) }
    var selectedWalletId by remember { mutableStateOf(wallets.firstOrNull()?.id ?: 0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (idioma == "PT") "Pagar Fatura - ${card.nome}" else "Pay Invoice - ${card.nome}",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = if (idioma == "PT") "Fatura atual acumulada: ${String.format("%,.2f", faturaAtual)} $currencySymbol"
                    else "Current balance due: ${String.format("%,.2f", faturaAtual)} $currencySymbol",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = valorStr,
                    onValueChange = { valorStr = it },
                    label = { Text(if (idioma == "PT") "Valor a Pagar ($currencySymbol)" else "Payment Amount ($currencySymbol)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Text(if (idioma == "PT") "Debitar da Carteira:" else "Debit From Wallet:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(wallets.filter { it.ativa }) { w ->
                        FilterChip(
                            selected = selectedWalletId == w.id,
                            onClick = { selectedWalletId = w.id },
                            leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(16.dp)) },
                            label = { Text("${w.nome} (${com.example.util.MoneyFormatter.format(w.saldoAtual, currencySymbol)})", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = valorStr.toDoubleOrNull() ?: 0.0
                    if (amount > 0 && selectedWalletId != 0) {
                        onConfirm(amount, selectedWalletId)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676))
            ) {
                Text(if (idioma == "PT") "Confirmar Pagamento" else "Confirm Payment", color = Color(0xFF0F2C24), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Cancelar" else "Cancel")
            }
        }
    )
}

@Composable
fun AddCreditCardPurchaseDialog(
    card: CreditCard,
    categories: List<Category>,
    idioma: String,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (Double, String, Int) -> Unit
) {
    var valorStr by remember { mutableStateOf("") }
    var descricao by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf(categories.firstOrNull()?.id ?: 0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (idioma == "PT") "Nova Compra no Cartão (${card.nome})" else "New Card Purchase (${card.nome})",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = valorStr,
                    onValueChange = { valorStr = it },
                    label = { Text(if (idioma == "PT") "Valor da Compra ($currencySymbol)" else "Purchase Amount ($currencySymbol)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = descricao,
                    onValueChange = { descricao = it },
                    label = { Text(if (idioma == "PT") "Descrição (ex: Supermercado, Loja)" else "Description") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text(if (idioma == "PT") "Categoria:" else "Category:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories.filter { it.tipo == "Despesa" }) { cat ->
                        FilterChip(
                            selected = selectedCategoryId == cat.id,
                            onClick = { selectedCategoryId = cat.id },
                            leadingIcon = {
                                AppIcon(
                                    iconKey = cat.icone,
                                    modifier = Modifier.size(15.dp),
                                    tint = if (selectedCategoryId == cat.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = { Text(Translator.getLocalizedCategoryName(cat.nome, idioma), fontSize = 11.5.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = valorStr.toDoubleOrNull() ?: 0.0
                    if (amount > 0 && selectedCategoryId != 0) {
                        onConfirm(amount, descricao.ifBlank { "Compra no Cartão" }, selectedCategoryId)
                    }
                }
            ) {
                Text(if (idioma == "PT") "Registar Compra" else "Record Purchase")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (idioma == "PT") "Cancelar" else "Cancel")
            }
        }
    )
}

private data class TransactionSample(
    val title: String,
    val subtitle: String,
    val amount: Double,
    val dateLabel: String,
    val type: String
)

@Composable
fun TransactionRowItem(
    title: String,
    subtitle: String,
    amount: Double,
    dateLabel: String,
    type: String,
    moeda: String,
    ocultarSaldos: Boolean = false,
    isAjuste: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val (bgColor, iconTint, iconVector) = when (type) {
                "food" -> Triple(Color(0xFF2C3545), Color.White, Icons.Outlined.Restaurant)
                "income" -> Triple(Color(0xFF0F2C24), Color(0xFF00E676), Icons.Outlined.AttachMoney)
                "transport" -> Triple(Color(0xFF321A1E), Color(0xFFFF5252), Icons.Outlined.DirectionsBus)
                "internet" -> Triple(Color(0xFF132845), Color(0xFF4285F4), Icons.Outlined.Wifi)
                "mpesa" -> Triple(Color(0xFF0F2C24), Color(0xFF00E676), Icons.Outlined.Smartphone)
                else -> if (amount < 0) Triple(Color(0xFF321A1E), Color(0xFFFF5252), Icons.Outlined.ReceiptLong)
                else Triple(Color(0xFF0F2C24), Color(0xFF00E676), Icons.Outlined.AccountBalanceWallet)
            }

            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (isAjuste) Color(0xFF374151) else bgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isAjuste) Icons.Outlined.Tune else iconVector,
                    contentDescription = null,
                    tint = if (isAjuste) Color(0xFFF59E0B) else iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = title,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (isAjuste || title.contains("Ajuste", ignoreCase = true) || subtitle.contains("Ajuste", ignoreCase = true)) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFFF59E0B).copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "SISTEMA",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF59E0B),
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                if (subtitle.isNotBlank()) {
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            val isExpense = amount < 0
            val valText = if (ocultarSaldos) "••••" else if (isExpense) "- ${String.format("%,.2f", Math.abs(amount))} $moeda" else "+ ${String.format("%,.2f", amount)} $moeda"
            Text(
                text = valText,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (isExpense) Color(0xFFFF5252) else Color(0xFF00E676)
            )
            Text(
                text = dateLabel,
                fontSize = 10.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}


