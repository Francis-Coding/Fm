@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import com.example.util.AutoResizedText
import com.example.util.MoneyFormatter
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File


// ------------------- TELA 1: DASHBOARD -------------------
@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    wallets: List<Wallet>,
    categories: List<Category>,
    transactions: List<Transaction>,
    rawTransactions: List<Transaction>,
    goals: List<FinancialGoal>,
    settings: UserSettings,
    onNavigateToHistory: () -> Unit,
    onAddFixedExpenseClick: () -> Unit,
    onNavigateToShoppingList: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigate: ((String) -> Unit)? = null,
    scrollState: ScrollState = rememberScrollState()
) {
    val context = LocalContext.current
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var showGeminiInsightsSheet by remember { mutableStateOf(false) }

    val activeSubscriptions by viewModel.subscriptions.collectAsStateWithLifecycle(emptyList())
    val loansList by viewModel.loans.collectAsStateWithLifecycle(emptyList())
    val shoppingItemsList by viewModel.shoppingItems.collectAsStateWithLifecycle(emptyList())
    val goalsList by viewModel.goals.collectAsStateWithLifecycle(emptyList())
    val creditCardsState by viewModel.creditCards.collectAsStateWithLifecycle(emptyList())
    val spendingLimitsState by viewModel.spendingLimits.collectAsStateWithLifecycle(emptyList())

    val dbNotifications by viewModel.notifications.collectAsStateWithLifecycle(emptyList())
    val activeNotificationsCount = remember(dbNotifications) {
        dbNotifications.count { it.status == "UNREAD" }
    }

    var lastOpenedNotificationCount by remember { mutableIntStateOf(-1) }
    val showNotificationRedDot = activeNotificationsCount > 0 && lastOpenedNotificationCount != activeNotificationsCount

    val totalBalance = remember(wallets) { wallets.sumOf { it.saldoAtual } }
    val totalBalanceConverted = remember(totalBalance, settings.moedaPadrao) {
        viewModel.currencyService.convertFromMZN(totalBalance, settings.moedaPadrao)
    }

    val idioma = settings.idioma
    val isDark = settings.tema == "dark"

    // Recalcula periodicamente em vez de ficar preso ao valor do primeiro render: se o
    // utilizador deixar o dashboard aberto durante a viragem do dia, "Receitas/Despesas de
    // hoje" e a Saúde Financeira passam a refletir o novo dia em vez de ficarem no anterior.
    val todayDayOfYear by produceState(initialValue = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)) {
        while (true) {
            delay(60_000L)
            val current = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
            if (current != value) value = current
        }
    }
    val startOfMonthMillis = remember(todayDayOfYear) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.timeInMillis
    }
    val startOfTodayMillis = remember(todayDayOfYear) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.timeInMillis
    }

    val monthTransactions = remember(rawTransactions, startOfMonthMillis) {
        rawTransactions.filter { it.data >= startOfMonthMillis }
    }
    val monthIncomes = remember(monthTransactions) {
        monthTransactions.filter { it.isReceita() }.sumOf { it.valor }
    }
    val monthExpenses = remember(monthTransactions) {
        monthTransactions.filter { it.isDespesa() }.sumOf { it.valor }
    }
    val monthTransfers = remember(monthTransactions) {
        // Cada transferência grava DUAS pernas (saída + entrada), ambas com ajusteCaixa=true
        // e tipo="Transferencia" — o filtro anterior (!it.ajusteCaixa) excluía as DUAS pernas,
        // pelo que este cartão mostrava sempre 0. Para não contar o mesmo movimento em
        // duplicado, soma-se apenas a perna de saída (mesma convenção de sufixo usada em
        // FinancialRepository.transferBetweenWallets e em ContasScreen).
        monthTransactions.filter {
            it.tipo == "Transferencia" && (it.descricao.endsWith(" (Saída)") || it.descricao.endsWith(" (Out)"))
        }.sumOf { it.valor }
    }

    val monthIncomesConv = remember(monthIncomes, settings.moedaPadrao) { viewModel.currencyService.convertFromMZN(monthIncomes, settings.moedaPadrao) }
    val monthExpensesConv = remember(monthExpenses, settings.moedaPadrao) { viewModel.currencyService.convertFromMZN(monthExpenses, settings.moedaPadrao) }
    val monthTransfersConv = remember(monthTransfers, settings.moedaPadrao) { viewModel.currencyService.convertFromMZN(monthTransfers, settings.moedaPadrao) }

    val monthNetVariation = monthIncomes - monthExpenses
    val monthNetVariationConv = remember(monthNetVariation, settings.moedaPadrao) { viewModel.currencyService.convertFromMZN(monthNetVariation, settings.moedaPadrao) }

    val todayTransactions = remember(rawTransactions, startOfTodayMillis) {
        rawTransactions.filter { it.data >= startOfTodayMillis }
    }
    val todayIncomes = remember(todayTransactions) {
        todayTransactions.filter { it.isReceita() }.sumOf { it.valor }
    }
    val todayExpenses = remember(todayTransactions) {
        todayTransactions.filter { it.isDespesa() }.sumOf { it.valor }
    }
    val todayDiff = todayIncomes - todayExpenses
    val todayDiffConv = viewModel.currencyService.convertFromMZN(todayDiff, settings.moedaPadrao)

    val healthIndexData = remember(rawTransactions, wallets, categories, goalsList, idioma) {
        com.example.util.FinancialHealthCalculator.calculate(
            transactions = rawTransactions,
            wallets = wallets,
            categories = categories,
            goals = goalsList,
            idioma = idioma
        )
    }
    val healthResult = healthIndexData
    val survivalDays = remember(rawTransactions, totalBalance) {
        val start30 = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
        val exp30 = rawTransactions.filter { it.isDespesa() && it.data >= start30 }.sumOf { it.valor }
        val avgDaily = exp30 / 30.0
        if (avgDaily > 0) (totalBalance / avgDaily).toInt() else 0
    }

    val sparklinePoints = remember(rawTransactions, totalBalance) {
        if (rawTransactions.isEmpty()) listOf(totalBalance, totalBalance)
        else {
            val now = System.currentTimeMillis()
            val points = mutableListOf<Double>()
            var curBalance = totalBalance
            val dayMs = 24 * 60 * 60 * 1000L
            for (i in 0..11) {
                points.add(0, curBalance)
                val dayStart = now - (i * dayMs)
                val dayPrev = dayStart - dayMs
                val dayTxs = rawTransactions.filter { it.data in dayPrev until dayStart && !it.ajusteCaixa }
                val netChange = dayTxs.sumOf { if (it.isReceita()) it.valor else -it.valor }
                curBalance -= netChange
            }
            points
        }
    }

    val prevMonthPatrimony = remember(rawTransactions, wallets) {
        val cal = java.util.Calendar.getInstance().apply {
            add(java.util.Calendar.MONTH, -1)
            set(java.util.Calendar.DAY_OF_MONTH, getActualMaximum(java.util.Calendar.DAY_OF_MONTH))
            set(java.util.Calendar.HOUR_OF_DAY, 23)
            set(java.util.Calendar.MINUTE, 59)
            set(java.util.Calendar.SECOND, 59)
        }
        val endOfPrevMonth = cal.timeInMillis
        val curTotal = (wallets).sumOf { it.saldoAtual }
        val txsAfterEnd = rawTransactions.filter { it.data > endOfPrevMonth && !it.ajusteCaixa }
        val netChangeAfter = txsAfterEnd.sumOf { if (it.isReceita()) it.valor else -it.valor }
        // Não forçar para 0: um saldo anterior negativo (dívida) é um valor válido e
        // precisa manter-se para que a % de crescimento (ver netWorthGrowthPct) não fique distorcida.
        curTotal - netChangeAfter
    }
    val prevMonthPatrimonyConv = remember(prevMonthPatrimony, settings.moedaPadrao) {
        viewModel.currencyService.convertFromMZN(prevMonthPatrimony, settings.moedaPadrao)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ------------------ TOP BAR / HEADER ------------------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val userName = settings.name.ifBlank { if (idioma == "PT") "Utilizador" else "User" }
                val initialLetter = userName.take(1).uppercase()

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0F2C24))
                        .border(1.dp, Color(0xFF00E676).copy(alpha = 0.4f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = initialLetter,
                        color = Color(0xFF00E676),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column {
                    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                    val greeting = when {
                        hour in 5..11 -> if (idioma == "PT") "Bom dia," else "Good morning,"
                        hour in 12..17 -> if (idioma == "PT") "Boa tarde," else "Good afternoon,"
                        else -> if (idioma == "PT") "Boa noite," else "Good evening,"
                    }
                    Text(
                        text = greeting,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal
                    )
                    Text(
                        text = userName,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                val context = LocalContext.current
                IconButton(
                    onClick = { 
                        viewModel.toggleHideBalances() 
                        val willHide = !settings.ocultarSaldos
                        val msg = if (willHide) {
                            if (idioma == "PT") "Modo de privacidade ativado (saldos ocultos)" else "Privacy mode activated (balances hidden)"
                        } else {
                            if (idioma == "PT") "Modo de privacidade desativado (saldos visíveis)" else "Privacy mode deactivated (balances visible)"
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("toggle_balance_button")
                ) {
                    val eyeDesc = if (settings.ocultarSaldos) 
                        (if (idioma == "PT") "Mostrar valores e saldos" else "Show balances") 
                    else 
                        (if (idioma == "PT") "Ocultar valores e saldos (Modo de Privacidade)" else "Hide balances (Privacy Mode)")
                    Icon(
                        imageVector = if (settings.ocultarSaldos) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                        contentDescription = eyeDesc,
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Box {
                    IconButton(onClick = {
                        onNavigate?.invoke("notifications")
                        lastOpenedNotificationCount = activeNotificationsCount
                    }) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = if (idioma == "PT") "Notificações ($activeNotificationsCount ativas)" else "Notifications ($activeNotificationsCount active)",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (activeNotificationsCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = (-4).dp, y = 4.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFF5252))
                                .padding(horizontal = 4.dp, vertical = 1.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (activeNotificationsCount > 99) "99+" else activeNotificationsCount.toString(),
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onNavigateToSettings,
                    modifier = Modifier.testTag("dashboard_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Configurações",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // ------------------ 1. CARD: SALDO TOTAL (Reference Target) ------------------
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("total_balance_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (idioma == "PT") "Saldo Total" else "Total Balance",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    SparklineChart(
                        dataPoints = sparklinePoints,
                        moeda = settings.moedaPadrao,
                        modifier = Modifier
                            .width(64.dp)
                            .height(28.dp),
                        color = Color(0xFF00E676)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                val displayBalance = totalBalanceConverted
                val isNegativeBalance = displayBalance < 0
                AutoResizedText(
                    text = if (settings.ocultarSaldos) "•••• ${settings.moedaPadrao}" else MoneyFormatter.formatWithDecimals(displayBalance, settings.moedaPadrao),
                    color = if (isNegativeBalance) Color(0xFFFF5252) else MaterialTheme.colorScheme.onSurface,
                    maxFontSize = 30.sp,
                    minFontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    val isPos = monthNetVariation >= 0
                    val sign = if (isPos) "↑" else "↓"
                    val varColor = if (isPos) Color(0xFF00E676) else Color(0xFFFF5252)
                    AutoResizedText(
                        text = "$sign ${MoneyFormatter.formatWithDecimals(Math.abs(monthNetVariationConv), settings.moedaPadrao)} " + (if (idioma == "PT") "este mês" else "this month"),
                        color = varColor,
                        maxFontSize = 12.sp,
                        minFontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                
                // Visual Ratio Bar (Income vs Expense) with legend
                val totalTurnover = (monthIncomesConv + monthExpensesConv).coerceAtLeast(0.001)
                val incomePct = ((monthIncomesConv / totalTurnover) * 100).toInt()
                val expensePct = (100 - incomePct).coerceAtLeast(0)
                val incomeRatio = (monthIncomesConv / totalTurnover).toFloat().coerceIn(0f, 1f)
                val expenseRatio = (monthExpensesConv / totalTurnover).toFloat().coerceIn(0f, 1f)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (idioma == "PT") "Proporção do Mês" else "Monthly Proportion",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = if (idioma == "PT") "$incomePct% Receitas  •  $expensePct% Despesas" else "$incomePct% Incomes  •  $expensePct% Expenses",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        .semantics {
                            contentDescription = if (idioma == "PT") "Proporção do mês: $incomePct% receitas, $expensePct% despesas"
                            else "Monthly ratio: $incomePct% incomes, $expensePct% expenses"
                        }
                ) {
                    if (incomeRatio > 0f) {
                        Box(
                            modifier = Modifier
                                .weight(incomeRatio)
                                .fillMaxHeight()
                                .background(Color(0xFF00E676))
                        )
                    }
                    if (expenseRatio > 0f) {
                        Box(
                            modifier = Modifier
                                .weight(expenseRatio)
                                .fillMaxHeight()
                                .background(Color(0xFFFF5252))
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // RECEITAS
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToHistory() }
                    ) {
                        Text(
                            text = if (idioma == "PT") "Receitas" else "Incomes",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        AutoResizedText(
                            text = if (settings.ocultarSaldos) "••••" else MoneyFormatter.formatWithDecimals(monthIncomesConv, settings.moedaPadrao),
                            color = Color(0xFF00E676),
                            maxFontSize = 13.sp,
                            minFontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }

                    // DESPESAS
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToHistory() }
                    ) {
                        Text(
                            text = if (idioma == "PT") "Despesa" else "Expenses",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        AutoResizedText(
                            text = if (settings.ocultarSaldos) "••••" else MoneyFormatter.formatWithDecimals(monthExpensesConv, settings.moedaPadrao),
                            color = Color(0xFFFF5252),
                            maxFontSize = 13.sp,
                            minFontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }

                    // TRANSFERÊNCIAS
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToHistory() }
                    ) {
                        Text(
                            text = if (idioma == "PT") "Transferências" else "Transfers",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        AutoResizedText(
                            text = if (settings.ocultarSaldos) "••••" else MoneyFormatter.formatWithDecimals(monthTransfersConv, settings.moedaPadrao),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxFontSize = 13.sp,
                            minFontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // ------------------ 2. ROW: 4 QUICK ACTION BUTTONS ------------------
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Receita
            FilledTonalButton(
                onClick = { onNavigate?.invoke("adicionar_receita") },
                modifier = Modifier
                    .weight(0.9f)
                    .height(48.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = Color(0xFF1B8A4C).copy(alpha = 0.15f),
                    contentColor = Color(0xFF1B8A4C)
                ),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text(if (idioma == "PT") "Receita" else "Income", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            // Despesa (AÇÃO PRINCIPAL)
            Button(
                onClick = { onNavigate?.invoke("adicionar_despesa") },
                modifier = Modifier
                    .weight(1.3f)
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                Text("—", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (idioma == "PT") "Despesa" else "Expense", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }

            // Transferir
            FilledTonalButton(
                onClick = { onNavigate?.invoke("adicionar_transferencia") },
                modifier = Modifier
                    .weight(0.9f)
                    .height(48.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = Color(0xFF1E66D0).copy(alpha = 0.15f),
                    contentColor = Color(0xFF1E66D0)
                ),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                Icon(Icons.AutoMirrored.Rounded.CompareArrows, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text(if (idioma == "PT") "Transf." else "Transfer", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            // Empréstimo
            FilledTonalButton(
                onClick = { onNavigate?.invoke("loans") },
                modifier = Modifier
                    .weight(0.9f)
                    .height(48.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = Color(0xFF7B2CBF).copy(alpha = 0.15f),
                    contentColor = Color(0xFF7B2CBF)
                ),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                Icon(Icons.Outlined.AccountBalance, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text(if (idioma == "PT") "Emprést." else "Loan", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        // ------------------ CARD: SUA SITUAÇÃO HOJE & SAÚDE FINANCEIRA ------------------
        val healthResult = remember(rawTransactions, wallets, categories, goals, idioma) {
            com.example.util.FinancialHealthCalculator.calculate(
                transactions = rawTransactions,
                wallets = wallets,
                categories = categories,
                goals = goals,
                idioma = idioma
            )
        }
        val todayStart = remember {
            Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        }
        val todayIncomes = rawTransactions.filter { it.isReceita() && it.data >= todayStart }.sumOf { it.valor }
        val todayExpenses = rawTransactions.filter { it.isDespesa() && it.data >= todayStart }.sumOf { it.valor }
        val todayDiff = todayIncomes - todayExpenses
        val displayTodayDiff = remember(todayDiff, settings.moedaPadrao) {
            viewModel.currencyService.convertFromMZN(todayDiff, settings.moedaPadrao)
        }

        var showHealthDetailDialog by remember { mutableStateOf(false) }
        val scoreColor = when {
            healthResult.score >= 75 -> Color(0xFF00E676)
            healthResult.score >= 50 -> Color(0xFFFFB300)
            else -> Color(0xFFFF5252)
        }

        StaggeredEntrance(index = 1) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showHealthDetailDialog = true }
                    .testTag("health_and_today_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {

                    // Header Row: Title & Health Gauge Badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (idioma == "PT") "Situação Hoje & Saúde" else "Today's Status & Health",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                val isPosToday = displayTodayDiff >= 0
                                Text(if (isPosToday) "↑" else "↓", color = if (isPosToday) Color(0xFF00E676) else Color(0xFFFF5252), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                                val thresholdMin = when {
                                    healthResult.score >= 75 -> 75f
                                    healthResult.score >= 50 -> 50f
                                    else -> 0f
                                }
                                val thresholdMax = when {
                                    healthResult.score >= 75 -> 100f
                                    healthResult.score >= 50 -> 75f
                                    else -> 50f
                                }
                                val fraction = ((healthResult.score - thresholdMin) / (thresholdMax - thresholdMin)).coerceIn(0f, 1f)
                                
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = scoreColor.copy(alpha = 0.1f),
                                    border = BorderStroke(0.5.dp, scoreColor.copy(alpha = 0.3f))
                                ) {
                                    Box {
                                        Box(modifier = Modifier
                                            .matchParentSize()
                                            .background(
                                                androidx.compose.ui.graphics.Brush.horizontalGradient(
                                                    0f to scoreColor.copy(alpha = 0.3f),
                                                    fraction to scoreColor.copy(alpha = 0.3f),
                                                    fraction to Color.Transparent,
                                                    1f to Color.Transparent
                                                )
                                            )
                                        )
                                        Text(
                                            text = healthResult.status,
                                            color = scoreColor,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Score Badge with Gauge Arc
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = scoreColor.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, scoreColor.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier.size(22.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val scoreProgress = (healthResult.score.toFloat() / 100f).coerceIn(0f, 1f)
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        drawArc(
                                            color = scoreColor.copy(alpha = 0.2f),
                                            startAngle = 135f,
                                            sweepAngle = 270f,
                                            useCenter = false,
                                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            color = scoreColor,
                                            startAngle = 135f,
                                            sweepAngle = 270f * scoreProgress,
                                            useCenter = false,
                                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Outlined.Favorite,
                                        contentDescription = null,
                                        tint = scoreColor,
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                                Text(
                                    text = "${healthResult.score} / 100",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = scoreColor
                                )
                            }
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // Metrics Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Diferença Hoje
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (idioma == "PT") "Saldo líq. hoje" else "Today's net",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            val formattedDiff = if (settings.ocultarSaldos) "••••" else MoneyFormatter.formatWithDecimals(displayTodayDiff, settings.moedaPadrao)
                            Text(
                                text = formattedDiff,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (displayTodayDiff < 0) Color(0xFFFF5252) else Color(0xFF00E676)
                            )
                        }

                        // Previsão
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (idioma == "PT") "O saldo dura" else "Balance lasts",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            val daysText = "$survivalDays " + (if (idioma == "PT") "dias" else "days")
                            Text(
                                text = daysText,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Short recommendation + Action link
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (idioma == "PT") "Mantenha o seu orçamento sob controlo." else "Keep your budget under control.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (idioma == "PT") "Ver análise >" else "See analysis >",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E676),
                            modifier = Modifier.clickable { onNavigate?.invoke("relatorios:saude") }
                        )
                    }
                }
            }
        }

        if (showHealthDetailDialog) {
            AlertDialog(
                onDismissRequest = { showHealthDetailDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.Favorite, contentDescription = null, tint = scoreColor)
                        Text(if (idioma == "PT") "Detalhamento de Saúde Financeira" else "Financial Health Breakdown", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "${if (idioma == "PT") "Pontuação Geral" else "Overall Score"}: ${healthResult.score}/100 (${healthResult.status})",
                            fontWeight = FontWeight.Bold,
                            color = scoreColor,
                            fontSize = 14.sp
                        )
                        HorizontalDivider()
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (idioma == "PT") "Taxa de Poupança" else "Savings Rate", fontSize = 13.sp)
                            Text("${healthResult.savingsRateScore}/30", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (idioma == "PT") "Fundo de Emergência" else "Emergency Fund", fontSize = 13.sp)
                            Text("${healthResult.emergencyFundScore}/30", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (idioma == "PT") "Limites de Gastos" else "Spending Limits", fontSize = 13.sp)
                            Text("${healthResult.limitsScore}/20", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (idioma == "PT") "Metas Financeiras" else "Financial Goals", fontSize = 13.sp)
                            Text("${healthResult.goalsScore}/20", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        if (healthResult.feedback.isNotBlank()) {
                            HorizontalDivider()
                            Text(healthResult.feedback, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showHealthDetailDialog = false }) {
                        Text(if (idioma == "PT") "Fechar" else "Close")
                    }
                }
            )
        }

        // ------------------ SECTION: PRÓXIMOS PAGAMENTOS (SUBSCRIPTIONS) ------------------
        val activeSubscriptions by viewModel.subscriptions.collectAsStateWithLifecycle(emptyList())
        val activeList = remember(activeSubscriptions) { activeSubscriptions.filter { it.ativa } }

        StaggeredEntrance(index = 2) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (idioma == "PT") "Próximos pagamentos" else "Upcoming Payments",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = if (idioma == "PT") "Ver todos >" else "See all >",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E676),
                        modifier = Modifier.clickable { onNavigate?.invoke("relatorios:recorrentes") }
                    )
                }

                if (activeList.isEmpty()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate?.invoke("relatorios:recorrentes") },
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF00E676).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Subscriptions,
                                        contentDescription = null,
                                        tint = Color(0xFF00E676),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Text(
                                    text = if (idioma == "PT") "Nenhuma subscrição cadastrada." else "No registered subscriptions.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = if (idioma == "PT") "+ Adicionar" else "+ Add",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00E676)
                            )
                        }
                    }
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(activeList, key = { it.id }) { sub ->
                            val daysRemaining = calculateDaysUntilDayOfMonth(sub.diaCobranca)
                            val daysText = if (daysRemaining <= 0) (if (idioma == "PT") "Hoje" else "Today") else "$daysRemaining " + (if (idioma == "PT") "dias" else "days")

                            val subValConv = remember(sub.valor, settings.moedaPadrao) {
                                viewModel.currencyService.convertFromMZN(sub.valor, settings.moedaPadrao)
                            }

                            Surface(
                                modifier = Modifier
                                    .width(160.dp)
                                    .clickable { onNavigate?.invoke("relatorios:recorrentes") },
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    com.example.util.BrandIcon(
                                        nameOrKey = if (sub.icone.isNotBlank()) sub.icone else sub.nome,
                                        customColorHex = sub.corHex,
                                        modifier = Modifier.size(36.dp)
                                    )

                                    Column {
                                        Text(
                                            text = sub.nome,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = if (settings.ocultarSaldos) "••••" else MoneyFormatter.format(subValConv, settings.moedaPadrao),
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = daysText,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ------------------ CARD: LISTA DE COMPRAS AT-A-GLANCE ------------------
        val shoppingItemsList by viewModel.shoppingItems.collectAsStateWithLifecycle()
        val pendingCount = shoppingItemsList.count { !it.pago }
        val boughtCount = shoppingItemsList.count { it.pago }
        
        StaggeredEntrance(index = 2) {
            Card(
                modifier = Modifier.fillMaxWidth().bounceClick().clickable { onNavigateToShoppingList() }.testTag("dashboard_shopping_list_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ShoppingCart,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Text(
                                text = if (idioma == "PT") "LISTA DE COMPRAS" else "SHOPPING LIST",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                        
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    if (shoppingItemsList.isEmpty()) {
                        Text(
                            text = if (idioma == "PT") "Nenhum item adicionado à sua lista." else "No items added to your list.",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            fontSize = 13.sp
                        )
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (idioma == "PT") {
                                    "$pendingCount pendentes • $boughtCount comprados"
                                } else {
                                    "$pendingCount pending • $boughtCount bought"
                                },
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            
                            // Small Progress Bar
                            val fraction = if (shoppingItemsList.isNotEmpty()) boughtCount.toFloat() / shoppingItemsList.size else 0f
                            LinearProgressIndicator(
                                progress = fraction,
                                color = Color(0xFF1E66D0), // distinctive blue
                                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f),
                                modifier = Modifier.width(80.dp).height(6.dp).clip(RoundedCornerShape(3.dp))
                            )
                        }
                    }
                }
            }
        }

        // ------------------ CARD: CONTAS ------------------
        StaggeredEntrance(index = 3) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .bounceClick()
                    .clickable { onNavigate?.invoke("contas") }
                    .testTag("dashboard_contas_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (idioma == "PT") "Contas" else "Accounts",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (idioma == "PT") "Ver todas >" else "See all >",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E676)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (wallets.isEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (idioma == "PT") "Nenhuma conta cadastrada." else "No accounts registered.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (idioma == "PT") "+ Criar conta" else "+ Add account",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00E676)
                            )
                        }
                    } else {
                        val displayWallets = wallets.take(3)
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            displayWallets.forEach { wallet ->
                                val balConv = viewModel.currencyService.convertFromMZN(wallet.saldoAtual, settings.moedaPadrao)
                                val walletColor = try {
                                    Color(android.graphics.Color.parseColor(wallet.cor))
                                } catch (e: Exception) {
                                    MaterialTheme.colorScheme.primary
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(walletColor.copy(alpha = 0.2f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            val lname = wallet.nome.lowercase()
                                            when {
                                                lname.contains("banco") || lname.contains("bank") || lname.contains("poupança") || lname.contains("poupanca") || lname.contains("savings") -> Icon(Icons.Outlined.AccountBalance, contentDescription = null, tint = walletColor, modifier = Modifier.size(20.dp))
                                                lname.contains("carteira") || lname.contains("cash") || lname.contains("dinheiro") || lname.contains("wallet") -> Icon(Icons.Outlined.AccountBalanceWallet, contentDescription = null, tint = walletColor, modifier = Modifier.size(20.dp))
                                                lname.contains("mpesa") || lname.contains("m-pesa") || lname.contains("emola") || lname.contains("e-mola") || lname.contains("mkesh") || lname.contains("mobile money") -> Icon(Icons.Outlined.Smartphone, contentDescription = null, tint = walletColor, modifier = Modifier.size(20.dp))
                                                else -> Icon(Icons.Outlined.CreditCard, contentDescription = null, tint = walletColor, modifier = Modifier.size(20.dp))
                                            }
                                        }
                                        Column {
                                            Text(
                                                text = wallet.nome,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            val pct = if (totalBalance > 0) ((wallet.saldoAtual / totalBalance) * 100).toInt().coerceIn(0, 100) else 0
                                            Text(
                                                text = "$pct% " + (if (idioma == "PT") "do total" else "of total"),
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = if (settings.ocultarSaldos) "••••" else MoneyFormatter.formatWithDecimals(balConv, settings.moedaPadrao),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (balConv < 0) Color(0xFFFF5252) else Color(0xFF00E676)
                                        )
                                        Icon(
                                            imageVector = Icons.Rounded.ChevronRight,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                            if (wallets.size > 3) {
                                Text(
                                    text = if (idioma == "PT") "+ ${wallets.size - 3} contas ocultas" else "+ ${wallets.size - 3} hidden accounts",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(top = 4.dp).align(Alignment.CenterHorizontally)
                                )
                            }
                        }
                    }
                }
            }
        }

        // ------------------ CARD: INSIGHTS ------------------
        val (lastMonthExp, thisMonthExp) = remember(rawTransactions) {
            val thisMonthStart = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0) }.timeInMillis
            val lastMonthStart = Calendar.getInstance().apply { add(Calendar.MONTH, -1); set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0) }.timeInMillis
            val thisExp = rawTransactions.filter { it.isDespesa() && it.data >= thisMonthStart }.sumOf { it.valor }
            val lastExp = rawTransactions.filter { it.isDespesa() && it.data in lastMonthStart until thisMonthStart }.sumOf { it.valor }
            Pair(lastExp, thisExp)
        }
        val savingsPct = if (lastMonthExp > 0) (((lastMonthExp - thisMonthExp) / lastMonthExp) * 100).toInt() else 0

        val topCategoryInsight = remember(rawTransactions, categories) {
            val thisMonthStart = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0) }.timeInMillis
            val expByCat = rawTransactions
                .filter { it.isDespesa() && it.data >= thisMonthStart }
                .groupBy { it.categoriaId }
                .mapValues { it.value.sumOf { t -> t.valor } }
            val topCatId = expByCat.maxByOrNull { it.value }?.key
            val cat = categories.firstOrNull { it.id == topCatId }
            val catName = cat?.nome ?: if (idioma == "PT") "Geral" else "General"
            val catIcon = cat?.icone ?: "label"
            
            // Try to find the generic group name for the icon to provide more context
            val iconGroup = com.example.util.AppIcons.CATEGORY_ICONS.firstOrNull { it.key == catIcon }
            val groupName = iconGroup?.let { if (idioma == "PT") it.labelPt else it.labelEn }
            val finalName = if (groupName != null && catName != groupName) {
                "$catName — $groupName"
            } else {
                catName
            }
            
            val catAmount = expByCat[topCatId] ?: 0.0
            Triple(finalName, catIcon, catAmount)
        }

        val potentialSavingsConv = remember(monthExpenses, monthIncomes, settings.moedaPadrao) {
            val estimatedSaving = if (monthExpenses > 0) (monthExpenses * 0.15) else if (monthIncomes > 0) (monthIncomes * 0.10) else 0.0
            viewModel.currencyService.convertFromMZN(estimatedSaving, settings.moedaPadrao)
        }

        StaggeredEntrance(index = 4) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (idioma == "PT") "Insights" else "Insights",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.clickable {
                            viewModel.fetchGeminiAdvice(idioma)
                            showGeminiInsightsSheet = true
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Star,
                            contentDescription = null,
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = if (idioma == "PT") "Ver todas (IA) >" else "See all (AI) >",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E676)
                        )
                    }
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    // Card 1: Comparação de Poupança / Economia
                    item {
                        Surface(
                            modifier = Modifier
                                .width(155.dp)
                                .height(105.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFF0A291A),
                            border = BorderStroke(1.dp, Color(0xFF00E676).copy(alpha = 0.2f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF00E676).copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (savingsPct >= 0) Icons.Outlined.TrendingDown else Icons.Outlined.TrendingUp,
                                            contentDescription = null,
                                            tint = if (savingsPct >= 0) Color(0xFF00E676) else Color(0xFFFF5252),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Text(
                                        text = if (savingsPct >= 0) (if (idioma == "PT") "Economia" else "Savings") else (if (idioma == "PT") "Aumento" else "Increase"),
                                        fontSize = 10.sp,
                                        color = Color.White.copy(alpha = 0.8f),
                                        lineHeight = 12.sp
                                    )
                                }

                                Text(
                                    text = "${Math.abs(savingsPct)}%",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (savingsPct >= 0) Color(0xFF00E676) else Color(0xFFFF5252)
                                )

                                Text(
                                    text = if (idioma == "PT") "vs. mês anterior" else "vs. last month",
                                    fontSize = 9.sp,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    // Card 2: Maior Categoria de Gastos
                    item {
                        Surface(
                            modifier = Modifier
                                .width(155.dp)
                                .height(105.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFF291116),
                            border = BorderStroke(1.dp, Color(0xFFFF5252).copy(alpha = 0.2f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFFF5252).copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        com.example.util.AppIcon(
                                            iconKey = topCategoryInsight.second,
                                            contentDescription = topCategoryInsight.first,
                                            tint = Color(0xFFFF5252),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Text(
                                        text = topCategoryInsight.first,
                                        fontSize = 10.sp,
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                val topCatValConv = viewModel.currencyService.convertFromMZN(topCategoryInsight.third, settings.moedaPadrao)
                                Text(
                                    text = if (settings.ocultarSaldos) "••••" else MoneyFormatter.format(topCatValConv, settings.moedaPadrao),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFFF5252)
                                )

                                Text(
                                    text = if (idioma == "PT") "maior despesa do mês" else "top expense this month",
                                    fontSize = 9.sp,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    // Card 3: Meta de Poupança Potencial
                    item {
                        Surface(
                            modifier = Modifier
                                .width(155.dp)
                                .height(105.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFF0E2038),
                            border = BorderStroke(1.dp, Color(0xFF1E66D0).copy(alpha = 0.2f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF1E66D0).copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Outlined.Savings, contentDescription = null, tint = Color(0xFF1E66D0), modifier = Modifier.size(16.dp))
                                    }
                                    Text(
                                        text = if (idioma == "PT") "Meta de poupança" else "Potential saving",
                                        fontSize = 10.sp,
                                        color = Color.White.copy(alpha = 0.8f),
                                        lineHeight = 12.sp
                                    )
                                }

                                Text(
                                    text = if (settings.ocultarSaldos) "••••" else MoneyFormatter.format(potentialSavingsConv, settings.moedaPadrao),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF4285F4)
                                )

                                Text(
                                    text = if (idioma == "PT") "pode poupar este mês" else "you can save this month",
                                    fontSize = 9.sp,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // ------------------ GRID ROW: METAS & PATRIMÔNIO ------------------
        StaggeredEntrance(index = 5) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // METAS CARD
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(230.dp)
                        .clickable { onNavigate?.invoke("metas") },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Metas" else "Goals",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (idioma == "PT") "Ver todas" else "See all",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00E676)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (goalsList.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f, fill = false)
                                        .padding(vertical = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (idioma == "PT") "Nenhuma meta cadastrada." else "No goals registered.",
                                        fontSize = 11.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    goalsList.take(2).forEach { g ->
                                        val progress = if (g.valorObjetivo > 0) (g.valorAtual / g.valorObjetivo).toFloat().coerceIn(0f, 1f) else 0f
                                        val currConv = viewModel.currencyService.convertFromMZN(g.valorAtual, settings.moedaPadrao)
                                        val targetConv = viewModel.currencyService.convertFromMZN(g.valorObjetivo, settings.moedaPadrao)

                                        Column {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = g.nome,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "${(progress * 100).toInt()}%",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(3.dp))
                                            LinearProgressIndicator(
                                                progress = { progress },
                                                color = Color(0xFF00E676),
                                                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f),
                                                modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp))
                                            )
                                            Text(
                                                text = if (settings.ocultarSaldos) "•••• / ••••" else "${MoneyFormatter.format(currConv, "").trim()} / ${MoneyFormatter.format(targetConv, settings.moedaPadrao)}",
                                                fontSize = 9.5.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Add Goal Link
                        Text(
                            text = if (idioma == "PT") "+ Adicionar meta" else "+ Add goal",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E676),
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }

                // PATRIMÔNIO CARD
                // A % de crescimento deriva do MESMO prevMonthPatrimonyConv usado nos rótulos
                // "Mês passado" mais abaixo neste cartão, para que os dois valores nunca divirjam
                // (antes eram calculados por duas fórmulas independentes que podiam mostrar
                // números inconsistentes lado a lado).
                val netWorthGrowthPct = remember(totalBalanceConverted, prevMonthPatrimonyConv) {
                    val netChangeConv = totalBalanceConverted - prevMonthPatrimonyConv
                    if (prevMonthPatrimonyConv != 0.0) {
                        (netChangeConv / kotlin.math.abs(prevMonthPatrimonyConv)) * 100.0
                    } else {
                        0.0
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(230.dp)
                        .clickable { onNavigate?.invoke("relatorios:saude") },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Patrimônio" else "Net Worth",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (idioma == "PT") "Ver detalhes" else "See details",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00E676)
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = if (settings.ocultarSaldos) "•••• ${settings.moedaPadrao}" else MoneyFormatter.formatWithDecimals(totalBalanceConverted, settings.moedaPadrao),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            val isPositiveNetGrowth = netWorthGrowthPct >= 0
                            val growthArrow = if (isPositiveNetGrowth) "↑" else "↓"
                            val growthColor = if (isPositiveNetGrowth) Color(0xFF00E676) else Color(0xFFFF5252)

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(growthArrow, color = growthColor, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "${String.format(java.util.Locale.US, "%.1f", Math.abs(netWorthGrowthPct))}% " + (if (idioma == "PT") "este mês" else "this month"),
                                    color = growthColor,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = (if (idioma == "PT") "Mês passado: " else "Last month: ") + (if (settings.ocultarSaldos) "••••" else MoneyFormatter.format(prevMonthPatrimonyConv, settings.moedaPadrao)),
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Canvas Line Graph representing Equity trend
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(65.dp)
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val w = size.width
                                    val h = size.height

                                    // Guide dots/grid lines
                                    drawLine(
                                        color = Color.White.copy(alpha = 0.1f),
                                        start = Offset(0f, h * 0.5f),
                                        end = Offset(w, h * 0.5f),
                                        strokeWidth = 1.dp.toPx(),
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                                    )

                                    val path = Path().apply {
                                        moveTo(0f, h * 0.75f)
                                        cubicTo(w * 0.25f, h * 0.85f, w * 0.5f, h * 0.35f, w * 0.75f, h * 0.45f)
                                        lineTo(w, h * 0.15f)
                                    }

                                    // Gradient fill
                                    val fillPath = Path().apply {
                                        addPath(path)
                                        lineTo(w, h)
                                        lineTo(0f, h)
                                        close()
                                    }

                                    drawPath(
                                        path = fillPath,
                                        brush = Brush.verticalGradient(
                                            colors = listOf(Color(0xFF00E676).copy(alpha = 0.25f), Color.Transparent)
                                        )
                                    )

                                    drawPath(
                                        path = path,
                                        color = Color(0xFF00E676),
                                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                                    )

                                    // Dot at end
                                    drawCircle(
                                        color = Color(0xFF00E676),
                                        radius = 4.dp.toPx(),
                                        center = Offset(w, h * 0.15f)
                                    )
                                }
                            }
                        }

                        // Bottom Previous Month Comparison
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (idioma == "PT") "Mês passado" else "Last month",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (settings.ocultarSaldos) "••••" else MoneyFormatter.format(prevMonthPatrimonyConv, settings.moedaPadrao),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // ------------------ CARD 3: LIMITES DE DESPESAS MENSAIS (Image 3) ------------------
        var showSetLimitDialog by remember { mutableStateOf(false) }
        var selectedCategoryForLimit by remember { mutableStateOf<Category?>(null) }
        var limitAmountStr by remember { mutableStateOf("") }
        var categoryDropdownOpenForLimit by remember { mutableStateOf(false) }

        StaggeredEntrance(index = 3) {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("spending_limits_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (idioma == "PT") "LIMITES DE DESPESAS MENSAIS" else "MONTHLY SPENDING LIMITS",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        )
                        IconButton(
                            onClick = {
                                selectedCategoryForLimit = categories.firstOrNull { it.tipo == "Despesa" }
                                limitAmountStr = ""
                                showSetLimitDialog = true
                            },
                            modifier = Modifier.size(32.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = if (idioma == "PT") "Adicionar ou definir limite de despesa" else "Add or set spending limit",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val categoriesWithLimits = categories.filter { it.tipo == "Despesa" && it.limiteMensal > 0.0 }

                    if (categoriesWithLimits.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (idioma == "PT") "Nenhum limite configurado. Toque no '+' para definir limites de gastos!" else "No limits configured. Tap '+' to define spending limits!",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            categoriesWithLimits.forEach { cat ->
                                val spent = rawTransactions
                                    .filter { it.isDespesa() && it.categoriaId == cat.id && it.data >= startOfMonthMillis }
                                    .sumOf { it.valor }
                                val spentConverted = viewModel.currencyService.convertFromMZN(spent, settings.moedaPadrao)
                                val limitConverted = viewModel.currencyService.convertFromMZN(cat.limiteMensal, settings.moedaPadrao)
                                
                                val progress = if (cat.limiteMensal > 0) (spent / cat.limiteMensal).toFloat().coerceIn(0f, 1f) else 0f
                                val progressColor = when {
                                    progress >= 1f -> MaterialTheme.colorScheme.error
                                    progress >= 0.8f -> Color(0xFFFBC02D) // Yellow/orange warning
                                    else -> MaterialTheme.colorScheme.primary
                                }

                                        val pctVal = if (cat.limiteMensal > 0) ((spent / cat.limiteMensal) * 100).toInt() else 0
                                        val isOverLimit = pctVal >= 100

                                        Column {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    AppIcon(iconKey = cat.icone, modifier = Modifier.size(16.dp))
                                                    Text(
                                                        text = Translator.getLocalizedCategoryName(cat.nome, idioma),
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = progressColor.copy(alpha = 0.15f)
                                                    ) {
                                                        Text(
                                                            text = when {
                                                                isOverLimit -> "EXCEDIDO (${pctVal}%)"
                                                                pctVal == 0 -> if (idioma == "PT") "Sem gastos (0%)" else "No spending (0%)"
                                                                else -> "${pctVal}%"
                                                            },
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = progressColor,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                val spentStr = if (settings.ocultarSaldos) "••••" else MoneyFormatter.formatWithDecimals(spentConverted, "").trim()
                                                val limitStr = if (settings.ocultarSaldos) "••••" else MoneyFormatter.formatWithDecimals(limitConverted, "").trim()
                                                Text(
                                                    text = "$spentStr / $limitStr ${settings.moedaPadrao}",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                                )
                                            }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    LinearProgressIndicator(
                                        progress = { progress },
                                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                        color = progressColor,
                                        trackColor = progressColor.copy(alpha = 0.15f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Set Limit Dialog
        if (showSetLimitDialog) {
            Dialog(onDismissRequest = { showSetLimitDialog = false }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = if (idioma == "PT") "Definir Limite Mensal" else "Set Monthly Limit",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Category Dropdown
                        Box {
                            OutlinedButton(
                                onClick = { categoryDropdownOpenForLimit = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(selectedCategoryForLimit?.let { "${Translator.getLocalizedCategoryName(it.nome, idioma)}" } ?: (if (idioma == "PT") "Selecionar Categoria" else "Select Category"))
                            }
                            DropdownMenu(
                                expanded = categoryDropdownOpenForLimit,
                                onDismissRequest = { categoryDropdownOpenForLimit = false }
                            ) {
                                categories.filter { it.tipo == "Despesa" }.forEach { cat ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                AppIcon(iconKey = cat.icone, modifier = Modifier.size(16.dp))
                                                Text(Translator.getLocalizedCategoryName(cat.nome, idioma))
                                            }
                                        },
                                        onClick = {
                                            selectedCategoryForLimit = cat
                                            categoryDropdownOpenForLimit = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = limitAmountStr,
                            onValueChange = { limitAmountStr = sanitizeDoubleInput(limitAmountStr, it) },
                            label = { Text(if (idioma == "PT") "Limite Mensal (MZN)" else "Monthly Limit (MZN)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { showSetLimitDialog = false }) {
                                Text(if (idioma == "PT") "Cancelar" else "Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val cat = selectedCategoryForLimit
                                    val amount = limitAmountStr.toDoubleOrNull() ?: 0.0
                                    if (cat != null && amount >= 0.0) {
                                        viewModel.updateCategory(cat.copy(limiteMensal = amount))
                                        showSetLimitDialog = false
                                        Toast.makeText(context, if (idioma == "PT") "Limite atualizado!" else "Limit updated!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, if (idioma == "PT") "Insira um valor válido!" else "Enter a valid amount!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) {
                                Text(if (idioma == "PT") "Salvar" else "Save")
                            }
                        }
                    }
                }
            }
        }

        // ------------------ CARD: ÚLTIMAS TRANSAÇÕES ------------------
        val displayTransactions = remember(rawTransactions) {
            if (rawTransactions.isNotEmpty()) {
                rawTransactions
                    .sortedWith(compareByDescending<Transaction> { it.data }.thenByDescending { it.id })
                    .take(4)
            } else {
                emptyList()
            }
        }

        StaggeredEntrance(index = 6) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (idioma == "PT") "Últimas Transações" else "Recent Transactions",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (idioma == "PT") "Ver todas >" else "See all >",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E676),
                        modifier = Modifier.clickable { onNavigateToHistory() }
                    )
                }

                val categoryMap = remember(categories) { categories.associateBy { it.id } }
                val walletMap = remember(wallets) { wallets.associateBy { it.id } }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (displayTransactions.isEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Nenhuma transação registada." else "No transactions registered.",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = if (idioma == "PT") "+ Nova transação" else "+ New transaction",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00E676),
                                    modifier = Modifier.clickable { onNavigateToHistory() }
                                )
                            }
                        } else {
                            val nowCal = java.util.Calendar.getInstance()
                            displayTransactions.forEach { t ->
                                val cat = categoryMap[t.categoriaId]
                                val wallet = walletMap[t.carteiraOrigemId]
                                val isExpense = t.tipo == "Despesa"
                                val amount = if (isExpense) -t.valor else t.valor
                                
                                val tCal = java.util.Calendar.getInstance().apply { timeInMillis = t.data }
                                val isToday = nowCal.get(java.util.Calendar.YEAR) == tCal.get(java.util.Calendar.YEAR) &&
                                        nowCal.get(java.util.Calendar.DAY_OF_YEAR) == tCal.get(java.util.Calendar.DAY_OF_YEAR)
                                val isYesterday = nowCal.get(java.util.Calendar.YEAR) == tCal.get(java.util.Calendar.YEAR) &&
                                        nowCal.get(java.util.Calendar.DAY_OF_YEAR) - tCal.get(java.util.Calendar.DAY_OF_YEAR) == 1

                                val dateLabel = when {
                                    isToday -> if (idioma == "PT") "Hoje" else "Today"
                                    isYesterday -> if (idioma == "PT") "Ontem" else "Yesterday"
                                    else -> java.text.SimpleDateFormat("dd/MM", java.util.Locale.getDefault()).format(java.util.Date(t.data))
                                }

                                val itemType = when {
                                    cat?.nome?.lowercase()?.contains("alim") == true || cat?.nome?.lowercase()?.contains("rest") == true -> "food"
                                    t.tipo == "Injecao" || cat?.nome?.lowercase()?.contains("sal") == true -> "income"
                                    cat?.nome?.lowercase()?.contains("transp") == true || cat?.nome?.lowercase()?.contains("comb") == true -> "transport"
                                    cat?.nome?.lowercase()?.contains("inter") == true || cat?.nome?.lowercase()?.contains("net") == true -> "internet"
                                    wallet?.nome?.lowercase()?.contains("mpesa") == true -> "mpesa"
                                    else -> if (isExpense) "expense" else "income"
                                }

                                val amountConv = viewModel.currencyService.convertFromMZN(amount, settings.moedaPadrao)
                                TransactionRowItem(
                                    title = cat?.nome ?: t.descricao.ifBlank { "Transação" },
                                    subtitle = t.descricao.ifBlank { wallet?.nome ?: "" },
                                    amount = amountConv,
                                    dateLabel = dateLabel,
                                    type = itemType,
                                    moeda = settings.moedaPadrao,
                                    ocultarSaldos = settings.ocultarSaldos,
                                    isAjuste = t.ajusteCaixa
                                )
                            }
                        }
                    }
                }
            }
        }



        // ------------------ CARD: CALENDÁRIO FLUXO FUTURO ------------------
        var showCalendarProjection by remember { mutableStateOf(false) }
        val groupedLoansList by viewModel.groupedLoans.collectAsStateWithLifecycle()

        Card(
            modifier = Modifier.fillMaxWidth().bounceClick().clickable { showCalendarProjection = true }.testTag("future_flow_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DateRange,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = if (idioma == "PT") "PROJEÇÃO DE FLUXO FUTURO" else "FUTURE FLOW PROJECTION",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (idioma == "PT") "Veja projeções diárias de receitas, despesas recorrentes, assinaturas ativas, parcelas de empréstimos e saídas agendadas." else "View daily projections of income, recurring expenses, active subscriptions, loan installments, and scheduled payouts.",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Render Calendar Dialog
        if (showCalendarProjection) {
            val goalsList by viewModel.goals.collectAsStateWithLifecycle()
            FutureFlowCalendarDialog(
                idioma = idioma,
                currentBalance = totalBalance,
                rawTransactions = rawTransactions,
                groupedLoans = groupedLoansList,
                goals = goalsList,
                viewModel = viewModel,
                wallets = wallets,
                categories = categories,
                onNavigate = onNavigate,
                onDismiss = { showCalendarProjection = false }
            )
        }

        if (showGeminiInsightsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showGeminiInsightsSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = Color(0xFF131824)
            ) {
                val sheetAdvice by viewModel.geminiAdvice.collectAsStateWithLifecycle()
                val sheetGenerating by viewModel.isGeneratingAdvice.collectAsStateWithLifecycle()

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1E2638)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Rounded.AutoAwesome, contentDescription = null, tint = Color(0xFF90CAF9), modifier = Modifier.size(22.dp))
                            }
                            Column {
                                Text(
                                    text = "GEMINI AI COACH",
                                    color = Color(0xFF90CAF9),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = if (idioma == "PT") "Insights e Recomendações IA" else "AI Insights & Coaching",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        IconButton(onClick = { showGeminiInsightsSheet = false }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Fechar", tint = Color.White)
                        }
                    }

                    if (sheetGenerating) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(color = Color(0xFF00E676))
                                Text(
                                    text = if (idioma == "PT") "Analizando o seu perfil financeiro com Gemini IA..." else "Analyzing your financial profile with Gemini AI...",
                                    color = Color.LightGray,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    } else if (sheetAdvice != null) {
                        Text(
                            text = sheetAdvice ?: "",
                            color = Color(0xFFE0E0E0),
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF1A1F2C), RoundedCornerShape(16.dp))
                                .padding(16.dp)
                        )
                    } else {
                        Text(
                            text = if (idioma == "PT") "Sem análises disponíveis no momento. Clique no botão abaixo para gerar conselhos com a IA." else "No insights available yet. Click below to generate AI recommendations.",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.fetchGeminiAdvice(idioma) },
                        enabled = !sheetGenerating,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (idioma == "PT") "Atualizar Insights com Gemini IA" else "Refresh Insights with Gemini AI",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
