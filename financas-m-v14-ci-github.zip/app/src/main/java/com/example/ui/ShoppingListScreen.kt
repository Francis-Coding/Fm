package com.example.ui

import java.util.Locale
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.animation.core.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material3.*
import com.example.util.AppIcon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ShoppingCategory
import com.example.data.model.ShoppingItem
import com.example.data.model.ShoppingList
import com.example.data.model.UserSettings
import com.example.data.model.Category
import com.example.data.model.Wallet

// --- FEATURE FLAGS FOR ROLLBACK & PHASES ---
object ShoppingFeatureFlags {
    const val MULTI_LIST_ENABLED = true
    const val CATEGORY_REORDERING_ENABLED = true
    const val PRICE_HISTORY_SUGGESTIONS_ENABLED = true
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingListScreen(
    viewModel: MainViewModel,
    settings: UserSettings,
    onBack: () -> Unit,
    onNavigateToHistory: () -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val idioma = settings.idioma
    var tactileState by remember { mutableStateOf(TactileSuccessState()) }

    // Flows from ViewModel
    val lists by viewModel.shoppingLists.collectAsStateWithLifecycle()
    val activeListId by viewModel.selectedShoppingListId.collectAsStateWithLifecycle()
    val rawItems by viewModel.shoppingItemsForSelectedList.collectAsStateWithLifecycle()
    val allShoppingItems by viewModel.shoppingItems.collectAsStateWithLifecycle()
    val categories by viewModel.shoppingCategories.collectAsStateWithLifecycle()
    val productSuggestions by viewModel.distinctProductNames.collectAsStateWithLifecycle()
    val averagePrices by viewModel.averagePrices.collectAsStateWithLifecycle()

    // Financial system flows for automatic expense registration
    val financialCategories by viewModel.categories.collectAsStateWithLifecycle()
    val wallets by viewModel.wallets.collectAsStateWithLifecycle()

    val expenseCategories = remember(financialCategories) {
        financialCategories.filter { it.tipo == "Despesa" }
    }
    val activeWallets = remember(wallets) {
        wallets.filter { it.ativa }
    }

    // Quick Filters State
    var filterStatus by remember { mutableStateOf("Todos") } // "Todos", "Pendentes", "Comprados"
    var filterPriority by remember { mutableStateOf("Todos") } // "Todos", "ALTA", "MEDIA", "BAIXA"
    var selectedCategoryFilterId by remember { mutableStateOf<Int?>(null) } // null = All, -1 = Uncategorized, >0 = Category ID
    var showCategoryFilterDropdown by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredRawItems = remember(rawItems, filterStatus, filterPriority, selectedCategoryFilterId, searchQuery) {
        rawItems.filter { item ->
            val matchesStatus = when (filterStatus) {
                "Pendentes" -> !item.pago
                "Comprados" -> item.pago
                else -> true
            }
            val matchesPriority = when (filterPriority) {
                "ALTA" -> item.prioridade == "ALTA"
                "MEDIA" -> item.prioridade == "MEDIA"
                "BAIXA" -> item.prioridade == "BAIXA"
                else -> true
            }
            val matchesCategory = when (selectedCategoryFilterId) {
                null -> true
                -1 -> item.categoriaId == null
                else -> item.categoriaId == selectedCategoryFilterId
            }
            val matchesSearch = item.nome.contains(searchQuery, ignoreCase = true)
            matchesStatus && matchesPriority && matchesCategory && matchesSearch
        }
    }

    // Expense confirmation dialog trigger
    var showExpenseDialogForItem by remember { mutableStateOf<ShoppingItem?>(null) }
    var showBatchExpenseDialog by remember { mutableStateOf(false) }
    var showExpenseSuccessDialog by remember { mutableStateOf<Triple<String, Double, String>?>(null) } // description, value, categoryName

    // Dialog & Modal states
    var showAddDialog by remember { mutableStateOf(false) }
    var showEditDialogItem by remember { mutableStateOf<ShoppingItem?>(null) }
    var showCreateListDialog by remember { mutableStateOf(false) }
    var showCategoryMgmtDialog by remember { mutableStateOf(false) }
    var showListOptionsSheet by remember { mutableStateOf<ShoppingList?>(null) }

    // Statistics Calculations
    val activeList = lists.find { it.id == activeListId } ?: lists.firstOrNull()
    val totalEstimatedMZN = rawItems.sumOf { it.preco * it.quantidade }
    val totalPaidMZN = rawItems.filter { it.pago }.sumOf { it.preco * it.quantidade }
    val totalPendingMZN = rawItems.filter { !it.pago }.sumOf { it.preco * it.quantidade }

    val totalEstimated = viewModel.currencyService.convertFromMZN(totalEstimatedMZN, settings.moedaPadrao)
    val totalPaid = viewModel.currencyService.convertFromMZN(totalPaidMZN, settings.moedaPadrao)
    val totalPending = viewModel.currencyService.convertFromMZN(totalPendingMZN, settings.moedaPadrao)

    // Grand totals across ALL shopping lists
    val grandTotalMZN = remember(allShoppingItems) { allShoppingItems.sumOf { it.preco * it.quantidade } }
    val grandTotalPaidMZN = remember(allShoppingItems) { allShoppingItems.filter { it.pago }.sumOf { it.preco * it.quantidade } }
    val grandTotalPendingMZN = remember(allShoppingItems) { allShoppingItems.filter { !it.pago }.sumOf { it.preco * it.quantidade } }

    val grandTotalEstimated = viewModel.currencyService.convertFromMZN(grandTotalMZN, settings.moedaPadrao)
    val grandTotalPaid = viewModel.currencyService.convertFromMZN(grandTotalPaidMZN, settings.moedaPadrao)
    val grandTotalPending = viewModel.currencyService.convertFromMZN(grandTotalPendingMZN, settings.moedaPadrao)

    var showAllListsGrandTotal by remember { mutableStateOf(false) }

    val completedCount = rawItems.count { it.pago }
    val totalCount = rawItems.size
    val progressFraction = if (totalCount > 0) completedCount.toFloat() / totalCount.toFloat() else 0f

    // Ensure we have a default active list id set if empty
    LaunchedEffect(lists) {
        if (activeListId == null && lists.isNotEmpty()) {
            viewModel.selectedShoppingListId.value = lists.first().id
        }
    }

    val lazyListState = rememberLazyListState()


    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (idioma == "PT") "Lista de Compras" else "Shopping List",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        activeList?.let {
                            Text(
                                text = it.nome + (if (it.isTemplate) " (Modelo)" else ""),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("shopping_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = if (idioma == "PT") "Voltar" else "Back"
                        )
                    }
                },
                actions = {
                    // Register entire shopping list purchase as financial expense
                    if (rawItems.isNotEmpty()) {
                        IconButton(
                            onClick = { showBatchExpenseDialog = true },
                            modifier = Modifier.testTag("batch_expense_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ShoppingCartCheckout,
                                contentDescription = if (idioma == "PT") "Efetivar Compra no Caixa" else "Settle List Expense",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Category Management Button
                    IconButton(
                        onClick = { showCategoryMgmtDialog = true },
                        modifier = Modifier.testTag("manage_categories_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Category,
                            contentDescription = if (idioma == "PT") "Gerenciar Categorias" else "Manage Categories",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Clear Paid Items
                    if (rawItems.any { it.pago }) {
                        IconButton(
                            onClick = {
                                activeListId?.let { listId ->
                                    viewModel.clearPaidShoppingItems()
                                    Toast.makeText(
                                        context,
                                        if (idioma == "PT") "Itens comprados limpos!" else "Paid items cleared!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            modifier = Modifier.testTag("clear_paid_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteSweep,
                                contentDescription = if (idioma == "PT") "Limpar Comprados" else "Clear Bought",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.bounceClick().testTag("add_shopping_item_fab")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = if (idioma == "PT") "Adicionar Item" else "Add Item"
                )
            }
        }
    ) { paddingValues ->
        // Group items by category (using the filtered items list!)
        val groupedItems = remember(filteredRawItems, categories) {
            val uncategorized = filteredRawItems.filter { it.categoriaId == null }
            val categorizedMap = filteredRawItems.filter { it.categoriaId != null }.groupBy { it.categoriaId }
            
            val listResult = mutableListOf<Pair<ShoppingCategory?, List<ShoppingItem>>>()
            // Sort categories by their display order index
            categories.forEach { cat ->
                val itemsInCat = categorizedMap[cat.id] ?: emptyList()
                if (itemsInCat.isNotEmpty()) {
                    listResult.add(cat to itemsInCat)
                }
            }
            if (uncategorized.isNotEmpty()) {
                listResult.add(null to uncategorized)
            }
            listResult
        }

        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .testTag("shopping_items_list"),
            contentPadding = PaddingValues(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // --- MULTI LIST SWITCHER ROW ---
            if (ShoppingFeatureFlags.MULTI_LIST_ENABLED) {
                item {
                    Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (lists.isNotEmpty()) {
                                lists.forEach { list ->
                                    val isSelected = list.id == activeListId
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { viewModel.selectedShoppingListId.value = list.id },
                                        label = {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                if (list.isTemplate) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Repeat,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                                Text(list.nome)
                                            }
                                        },
                                        trailingIcon = {
                                            Icon(
                                                imageVector = Icons.Rounded.MoreVert,
                                                contentDescription = "Options",
                                                modifier = Modifier
                                                    .size(16.dp)
                                                    .clickable { showListOptionsSheet = list }
                                            )
                                        },
                                        modifier = Modifier.testTag("list_chip_${list.id}")
                                    )
                                }
                            }

                            // Add List button
                            AssistChip(
                                onClick = { showCreateListDialog = true },
                                label = { Text(if (idioma == "PT") "+ Nova Lista" else "+ New List") },
                                modifier = Modifier.testTag("add_list_chip")
                            )
                        }
                    }
                }

            // --- STATISTICS DASHBOARD CARD ---
            if (lists.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .bounceClick()
                            .testTag("shopping_stats_card"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // View Mode Toggle (Active List vs All Lists)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (showAllListsGrandTotal) {
                                        if (idioma == "PT") "TOTAL GERAL (TODAS AS LISTAS)" else "GRAND TOTAL (ALL LISTS)"
                                    } else {
                                        if (idioma == "PT") "TOTAL ESTIMADO (${activeList?.nome ?: "LISTA"})" else "TOTAL ESTIMATED (${activeList?.nome ?: "LIST"})"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )

                                FilterChip(
                                    selected = showAllListsGrandTotal,
                                    onClick = { showAllListsGrandTotal = !showAllListsGrandTotal },
                                    label = {
                                        Text(
                                            text = if (showAllListsGrandTotal) {
                                                if (idioma == "PT") "Todas as Listas (${lists.size})" else "All Lists (${lists.size})"
                                            } else {
                                                if (idioma == "PT") "Ver Total Global" else "View Global Total"
                                            },
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Rounded.FormatListNumbered,
                                            contentDescription = null,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(28.dp)
                                )
                            }

                            val displayTotal = if (showAllListsGrandTotal) grandTotalEstimated else totalEstimated
                            val displayPaid = if (showAllListsGrandTotal) grandTotalPaid else totalPaid
                            val displayPending = if (showAllListsGrandTotal) grandTotalPending else totalPending

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${String.format("%,.2f", displayTotal)} ${settings.moedaPadrao}",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (showAllListsGrandTotal) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                                    )
                                }

                                // Circular Progress Indicator
                                Box(contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(
                                        progress = { progressFraction },
                                        strokeWidth = 5.dp,
                                        color = if (showAllListsGrandTotal) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Text(
                                        text = "${(progressFraction * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = if (idioma == "PT") "Comprado" else "Bought",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                    Text(
                                        text = "${String.format("%,.2f", displayPaid)} ${settings.moedaPadrao}",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF4CAF50)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (idioma == "PT") "Pendente" else "Pending",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                    Text(
                                        text = "${String.format("%,.2f", displayPending)} ${settings.moedaPadrao}",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFF9800)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Overall summary banner across all lists if multiple exist
                            if (lists.size > 1 && !showAllListsGrandTotal) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp)
                                        .clickable { showAllListsGrandTotal = true }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.FormatListBulleted,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = if (idioma == "PT") "Soma de ${lists.size} Listas:" else "Total of ${lists.size} Lists:",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                        Text(
                                            text = "${String.format("%,.2f", grandTotalEstimated)} ${settings.moedaPadrao}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (idioma == "PT") {
                                    "Progresso: $completedCount de $totalCount itens marcados"
                                } else {
                                    "Progress: $completedCount of $totalCount items checked"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }

            // --- SEARCH BAR ---
            if (lists.isNotEmpty()) {
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("search_shopping_items"),
                        placeholder = { Text(if (idioma == "PT") "Pesquisar itens..." else "Search items...") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Rounded.Clear, contentDescription = "Limpar")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // --- PANTRY QUICK SUGGESTIONS ---
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (idioma == "PT") "Adicionar Rápido:" else "Quick Add Suggestions:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val popularSuggestions = if (idioma == "PT") {
                                listOf("Leite", "Pão", "Ovos", "Café", "Açúcar", "Arroz", "Banana", "Manteiga", "Maçã", "Sabonete")
                            } else {
                                listOf("Milk", "Bread", "Eggs", "Coffee", "Sugar", "Rice", "Banana", "Butter", "Apple", "Soap")
                            }
                            popularSuggestions.forEach { name ->
                                AssistChip(
                                    onClick = {
                                        viewModel.addShoppingItem(
                                            nome = name,
                                            preco = averagePrices[name] ?: 50.0,
                                            quantidade = 1.0,
                                            unidade = "un",
                                            prioridade = "MEDIA",
                                            categoriaId = null,
                                            observacoes = "",
                                            listaId = activeListId ?: 1
                                        )
                                        Toast.makeText(context, if (idioma == "PT") "$name adicionado!" else "$name added!", Toast.LENGTH_SHORT).show()
                                    },
                                    label = { Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Rounded.Add,
                                            contentDescription = null,
                                            modifier = Modifier.size(12.dp),
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // --- QUICK FILTERS BAR ---
            if (lists.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FilterList,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )

                        Text(
                            text = if (idioma == "PT") "Status:" else "Status:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        FilterChip(
                            selected = filterStatus == "Todos",
                            onClick = { filterStatus = "Todos" },
                            label = { Text(if (idioma == "PT") "Todos" else "All") }
                        )
                        FilterChip(
                            selected = filterStatus == "Pendentes",
                            onClick = { filterStatus = "Pendentes" },
                            label = { Text(if (idioma == "PT") "Pendentes" else "Pending") }
                        )
                        FilterChip(
                            selected = filterStatus == "Comprados",
                            onClick = { filterStatus = "Comprados" },
                            label = { Text(if (idioma == "PT") "Comprados" else "Bought") }
                        )

                        Spacer(modifier = Modifier.width(4.dp))
                        VerticalDivider(modifier = Modifier.height(20.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.width(4.dp))

                        Text(
                            text = if (idioma == "PT") "Prioridade:" else "Priority:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        FilterChip(
                            selected = filterPriority == "Todos",
                            onClick = { filterPriority = "Todos" },
                            label = { Text(if (idioma == "PT") "Todas" else "All") }
                        )
                        FilterChip(
                            selected = filterPriority == "ALTA",
                            onClick = { filterPriority = "ALTA" },
                            label = { Text(if (idioma == "PT") "Alta" else "High") }
                        )
                        FilterChip(
                            selected = filterPriority == "MEDIA",
                            onClick = { filterPriority = "MEDIA" },
                            label = { Text(if (idioma == "PT") "Média" else "Medium") }
                        )
                        FilterChip(
                            selected = filterPriority == "BAIXA",
                            onClick = { filterPriority = "BAIXA" },
                            label = { Text(if (idioma == "PT") "Baixa" else "Low") }
                        )

                        Spacer(modifier = Modifier.width(4.dp))
                        VerticalDivider(modifier = Modifier.height(20.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.width(4.dp))

                        // --- CATEGORY DROPDOWN FILTER BUTTON ---
                        Box {
                            val selectedCatText = when (selectedCategoryFilterId) {
                                null -> if (idioma == "PT") "Todas as Categorias" else "All Categories"
                                -1 -> if (idioma == "PT") "Sem Categoria" else "Uncategorized"
                                else -> categories.find { it.id == selectedCategoryFilterId }?.nome ?: if (idioma == "PT") "Categoria" else "Category"
                            }

                            FilterChip(
                                selected = selectedCategoryFilterId != null,
                                onClick = { showCategoryFilterDropdown = true },
                                label = { Text(selectedCatText, fontWeight = FontWeight.Bold) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Category,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedCategoryFilterId != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.ArrowDropDown,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                modifier = Modifier.testTag("category_dropdown_filter_chip")
                            )

                            DropdownMenu(
                                expanded = showCategoryFilterDropdown,
                                onDismissRequest = { showCategoryFilterDropdown = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(if (idioma == "PT") "Todas as Categorias" else "All Categories", fontWeight = FontWeight.Bold) },
                                    leadingIcon = { Icon(Icons.AutoMirrored.Rounded.List, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                    onClick = {
                                        selectedCategoryFilterId = null
                                        showCategoryFilterDropdown = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (idioma == "PT") "Sem Categoria" else "Uncategorized") },
                                    leadingIcon = { Icon(Icons.Rounded.FolderOff, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                    onClick = {
                                        selectedCategoryFilterId = -1
                                        showCategoryFilterDropdown = false
                                    }
                                )
                                HorizontalDivider()
                                categories.forEach { cat ->
                                    val isCurrent = cat.id == selectedCategoryFilterId
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = cat.nome,
                                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        trailingIcon = if (isCurrent) {
                                            { Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp)) }
                                        } else null,
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Rounded.Folder,
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp),
                                                tint = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        },
                                        onClick = {
                                            selectedCategoryFilterId = cat.id
                                            showCategoryFilterDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- CATEGORIZED MAIN LIST ---
            if (lists.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ListAlt,
                                contentDescription = null,
                                modifier = Modifier.size(72.dp),
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                            )
                            Text(
                                text = if (idioma == "PT") "Nenhuma Lista de Compras!" else "No Shopping Lists!",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                            Text(
                                text = if (idioma == "PT") "Crie uma nova lista de compras clicando no botão abaixo para começar a planejar suas compras." else "Create a new shopping list by clicking the button below to start planning your purchases.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth(),
                                lineHeight = 18.sp
                            )
                            Button(
                                onClick = { showCreateListDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Rounded.Add, null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (idioma == "PT") "Criar Nova Lista" else "Create New List")
                            }
                        }
                    }
                }
            } else if (rawItems.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ShoppingCart,
                                    contentDescription = null,
                                    modifier = Modifier.size(36.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = if (idioma == "PT") "Sua lista está pronta!" else "Your list is ready!",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (idioma == "PT") 
                                        "Adicione itens tocando no '+' ou escolha uma das sugestões rápidas abaixo para começar." 
                                        else "Add items by tapping '+' or select from the quick suggestions below to start.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    textAlign = TextAlign.Center,
                                    lineHeight = 16.sp
                                )
                            }

                            // Empty State Quick Suggestion row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val popularSuggestions = if (idioma == "PT") {
                                    listOf("Leite", "Pão", "Ovos", "Arroz", "Banana")
                                } else {
                                    listOf("Milk", "Bread", "Eggs", "Rice", "Banana")
                                }
                                popularSuggestions.forEach { name ->
                                    Button(
                                        onClick = {
                                            viewModel.addShoppingItem(
                                                nome = name,
                                                preco = averagePrices[name] ?: 50.0,
                                                quantidade = 1.0,
                                                unidade = "un",
                                                prioridade = "MEDIA",
                                                categoriaId = null,
                                                observacoes = "",
                                                listaId = activeListId ?: 1
                                            )
                                            Toast.makeText(context, if (idioma == "PT") "$name adicionado!" else "$name added!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                            contentColor = MaterialTheme.colorScheme.primary
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(Icons.Rounded.Add, null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(name, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (filteredRawItems.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FilterList,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)
                            )
                            Text(
                                text = if (idioma == "PT") "Nenhum item corresponde aos filtros!" else "No items match filters!",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                            )
                            Text(
                                text = if (idioma == "PT") "Experimente alterar seus filtros rápidos de status ou prioridade." else "Try changing your quick status or priority filters.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                                modifier = Modifier.fillMaxWidth(),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            } else {
                groupedItems.forEach { (category, items) ->
                    val categoryTotalMZN = items.sumOf { it.preco * it.quantidade }
                    val categoryTotalConv = viewModel.currencyService.convertFromMZN(categoryTotalMZN, settings.moedaPadrao)

                    item {
                        CategoryHeaderRow(
                            category = category,
                            count = items.size,
                            categoryTotal = categoryTotalConv,
                            currencySymbol = settings.moedaPadrao,
                            idioma = idioma,
                            onMoveUp = {
                                if (category != null) {
                                    val index = categories.indexOfFirst { it.id == category.id }
                                    if (index > 0) {
                                        viewModel.reorderCategories(category.id, categories[index - 1].ordem)
                                        viewModel.reorderCategories(categories[index - 1].id, category.ordem)
                                    }
                                }
                            },
                            onMoveDown = {
                                if (category != null) {
                                    val index = categories.indexOfFirst { it.id == category.id }
                                    if (index >= 0 && index < categories.size - 1) {
                                        viewModel.reorderCategories(category.id, categories[index + 1].ordem)
                                        viewModel.reorderCategories(categories[index + 1].id, category.ordem)
                                    }
                                }
                            }
                        )
                    }

                    items(items, key = { it.id }) { item ->
                        ShoppingItemDetailedRow(
                            item = item,
                            categories = categories,
                            settings = settings,
                            viewModel = viewModel,
                            onEdit = { showEditDialogItem = item },
                            onTogglePaid = { clickedItem ->
                                if (clickedItem.pago) {
                                    viewModel.toggleShoppingItemPaid(clickedItem)
                                } else {
                                    showExpenseDialogForItem = clickedItem
                                }
                            },
                            modifier = Modifier.animateItem()
                        )
                    }
                }
            }
        }
    }

    // --- DIALOG: ADD SHOPPING ITEM ---
    if (showAddDialog) {
        val listId = activeListId ?: 1
        AddOrEditShoppingItemDialog(
            idioma = idioma,
            initialItem = null,
            categories = categories,
            productSuggestions = productSuggestions,
            averagePrices = averagePrices,
            viewModel = viewModel,
            activeListId = listId,
            onDismiss = { showAddDialog = false },
            onConfirm = { item ->
                viewModel.addShoppingItem(
                    nome = item.nome,
                    preco = item.preco,
                    quantidade = item.quantidade,
                    unidade = item.unidade,
                    prioridade = item.prioridade,
                    categoriaId = item.categoriaId,
                    observacoes = item.observacoes,
                    listaId = listId
                )
                showAddDialog = false
                TactileFeedbackHelper.triggerSuccessHaptic(haptic, context, scope)
                tactileState = TactileSuccessState(
                    visible = true,
                    title = if (idioma == "PT") "Item Adicionado à Lista" else "Item Added to Shopping List",
                    detail = item.nome,
                    amount = if (item.preco > 0) "${item.quantidade}x (${String.format(Locale.getDefault(), "%,.2f", item.preco)})" else "${item.quantidade} ${item.unidade}",
                    color = Color(0xFF8B5CF6),
                    icon = Icons.Rounded.ShoppingBag
                )
            }
        )
    }

    // --- DIALOG: EDIT SHOPPING ITEM ---
    if (showEditDialogItem != null) {
        AddOrEditShoppingItemDialog(
            idioma = idioma,
            initialItem = showEditDialogItem,
            categories = categories,
            productSuggestions = productSuggestions,
            averagePrices = averagePrices,
            viewModel = viewModel,
            onDismiss = { showEditDialogItem = null },
            onConfirm = { updated ->
                viewModel.updateShoppingItem(updated)
                showEditDialogItem = null
                Toast.makeText(context, if (idioma == "PT") "Produto atualizado!" else "Product updated!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // --- DIALOG: CREATE NEW LIST ---
    if (showCreateListDialog) {
        CreateListDialog(
            idioma = idioma,
            onDismiss = { showCreateListDialog = false },
            onConfirm = { name, isTemplate ->
                viewModel.addShoppingList(name, isTemplate)
                showCreateListDialog = false
                TactileFeedbackHelper.triggerSuccessHaptic(haptic, context, scope)
                tactileState = TactileSuccessState(
                    visible = true,
                    title = if (idioma == "PT") "Nova Lista de Compras" else "New Shopping List Created",
                    detail = name,
                    color = Color(0xFF8B5CF6),
                    icon = Icons.Rounded.ShoppingBag
                )
            }
        )
    }

    // --- DIALOG: CATEGORY MANAGEMENT ---
    if (showCategoryMgmtDialog) {
        CategoryManagementDialog(
            idioma = idioma,
            categories = categories,
            onDismiss = { showCategoryMgmtDialog = false },
            onAddCategory = { nome ->
                viewModel.addShoppingCategory(nome)
            },
            onDeleteCategory = { cat ->
                viewModel.deleteShoppingCategory(cat)
            }
        )
    }

    // --- DIALOG: BATCH EXPENSE REGISTRATION FOR ENTIRE SHOPPING LIST ---
    if (showBatchExpenseDialog) {
        val boughtItems = rawItems.filter { it.pago }
        val targetItems = if (boughtItems.isNotEmpty()) boughtItems else rawItems
        val batchTotalMZN = targetItems.sumOf { it.preco * it.quantidade }
        val batchTotalConverted = viewModel.currencyService.convertFromMZN(batchTotalMZN, settings.moedaPadrao)

        var selectedWallet by remember { mutableStateOf(activeWallets.firstOrNull()) }
        var selectedCategory by remember { mutableStateOf(expenseCategories.firstOrNull()) }
        var description by remember { mutableStateOf(if (idioma == "PT") "Compras: ${activeList?.nome ?: "Lista de Compras"}" else "Shopping: ${activeList?.nome ?: "Shopping List"}") }

        var walletDropdownExpanded by remember { mutableStateOf(false) }
        var categoryDropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showBatchExpenseDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ShoppingCartCheckout,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (idioma == "PT") "Efetivar Toda a Compra" else "Settle Entire Shopping List",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") {
                            "Deseja debitar o total das compras (${targetItems.size} itens) do seu caixa financeiro?"
                        } else {
                            "Do you want to debit the total shopping items (${targetItems.size} items) from your account?"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )

                    // Total Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (idioma == "PT") "Total da Compra:" else "Shopping Total:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${String.format("%,.2f", batchTotalConverted)} ${settings.moedaPadrao}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Account Selection
                    Text(
                        text = if (idioma == "PT") "Conta de Pagamento:" else "Payment Account:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { walletDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedWallet?.nome ?: (if (idioma == "PT") "Selecionar Conta" else "Select Account"))
                                Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
                            }
                        }
                        DropdownMenu(
                            expanded = walletDropdownExpanded,
                            onDismissRequest = { walletDropdownExpanded = false }
                        ) {
                            activeWallets.forEach { w ->
                                DropdownMenuItem(
                                    leadingIcon = { AppIcon(iconKey = w.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary) },
                                    text = { Text("${w.nome} (${com.example.util.MoneyFormatter.format(w.saldoAtual, "MZN")})") },
                                    onClick = {
                                        selectedWallet = w
                                        walletDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Category Selection
                    Text(
                        text = if (idioma == "PT") "Categoria Financeira:" else "Expense Category:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { categoryDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedCategory?.nome ?: (if (idioma == "PT") "Selecionar Categoria" else "Select Category"))
                                Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
                            }
                        }
                        DropdownMenu(
                            expanded = categoryDropdownExpanded,
                            onDismissRequest = { categoryDropdownExpanded = false }
                        ) {
                            expenseCategories.forEach { cat ->
                                DropdownMenuItem(
                                    leadingIcon = { AppIcon(iconKey = cat.icone, modifier = Modifier.size(18.dp)) },
                                    text = { Text(cat.nome) },
                                    onClick = {
                                        selectedCategory = cat
                                        categoryDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Description
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text(if (idioma == "PT") "Descrição" else "Description") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val wallet = selectedWallet
                        val category = selectedCategory
                        if (wallet != null && category != null && batchTotalMZN > 0.0) {
                            viewModel.addTransaction(
                                descricao = description,
                                valor = batchTotalMZN,
                                tipo = "Despesa",
                                categoriaId = category.id,
                                carteiraId = wallet.id,
                                moedaTransacao = settings.moedaPadrao,
                                data = System.currentTimeMillis()
                            )
                            // Mark all target items as completed
                            targetItems.forEach { item ->
                                if (!item.pago) {
                                    viewModel.updateShoppingItem(item.copy(pago = true))
                                }
                            }
                            showBatchExpenseDialog = false
                            Toast.makeText(context, if (idioma == "PT") "Compra efetivada e debitada no caixa!" else "Purchase debited from account!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, if (idioma == "PT") "Selecione a conta e categoria!" else "Select account and category!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text(if (idioma == "PT") "Debitar no Caixa" else "Debit Account")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBatchExpenseDialog = false }) {
                    Text(if (idioma == "PT") "Cancelar" else "Cancel")
                }
            }
        )
    }

    // --- DIALOG: AUTOMATIC EXPENSE REGISTRATION ---
    showExpenseDialogForItem?.let { item ->
        val itemTotalMZN = item.preco * item.quantidade
        val itemTotalConverted = viewModel.currencyService.convertFromMZN(itemTotalMZN, settings.moedaPadrao)
        
        var selectedWallet by remember { mutableStateOf(activeWallets.firstOrNull()) }
        var selectedCategory by remember { mutableStateOf(expenseCategories.firstOrNull()) }
        var description by remember { mutableStateOf(if (idioma == "PT") "Compra: ${item.nome}" else "Purchase: ${item.nome}") }
        
        var walletDropdownExpanded by remember { mutableStateOf(false) }
        var categoryDropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showExpenseDialogForItem = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AccountBalanceWallet,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (idioma == "PT") "Registrar Despesa" else "Register Expense",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") {
                            "Deseja registrar esta compra como uma despesa automática no seu financeiro?"
                        } else {
                            "Do you want to register this purchase as an automatic expense in your finances?"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )

                    // Details Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = item.nome,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (idioma == "PT") {
                                    "Quantidade: ${item.quantidade} ${item.unidade}\nPreço Unitário: ${String.format("%,.2f", viewModel.currencyService.convertFromMZN(item.preco, settings.moedaPadrao))} ${settings.moedaPadrao}"
                                } else {
                                    "Quantity: ${item.quantidade} ${item.unidade}\nUnit Price: ${String.format("%,.2f", viewModel.currencyService.convertFromMZN(item.preco, settings.moedaPadrao))} ${settings.moedaPadrao}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                            )
                            Text(
                                text = if (idioma == "PT") {
                                    "Valor Total: ${String.format("%,.2f", itemTotalConverted)} ${settings.moedaPadrao}"
                                } else {
                                    "Total Value: ${String.format("%,.2f", itemTotalConverted)} ${settings.moedaPadrao}"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Description textfield
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text(if (idioma == "PT") "Descrição da Despesa" else "Expense Description") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Fund Account / Wallet Selection
                    ExposedDropdownMenuBox(
                        expanded = walletDropdownExpanded,
                        onExpandedChange = { walletDropdownExpanded = !walletDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedWallet?.nome ?: (if (idioma == "PT") "Selecionar Carteira" else "Select Wallet"),
                            onValueChange = {},
                            readOnly = true,
                            leadingIcon = {
                                selectedWallet?.let {
                                    AppIcon(iconKey = it.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                }
                            },
                            label = { Text(if (idioma == "PT") "Conta de Origem" else "Fund Source Account") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = walletDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = walletDropdownExpanded,
                            onDismissRequest = { walletDropdownExpanded = false }
                        ) {
                            activeWallets.forEach { wallet ->
                                DropdownMenuItem(
                                    leadingIcon = { AppIcon(iconKey = wallet.icone, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary) },
                                    text = { Text(wallet.nome) },
                                    onClick = {
                                        selectedWallet = wallet
                                        walletDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Expense Category Selection
                    ExposedDropdownMenuBox(
                        expanded = categoryDropdownExpanded,
                        onExpandedChange = { categoryDropdownExpanded = !categoryDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedCategory?.nome ?: (if (idioma == "PT") "Selecionar Categoria" else "Select Category"),
                            onValueChange = {},
                            readOnly = true,
                            leadingIcon = {
                                selectedCategory?.let {
                                    AppIcon(iconKey = it.icone, modifier = Modifier.size(18.dp))
                                }
                            },
                            label = { Text(if (idioma == "PT") "Categoria de Despesa" else "Expense Category") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = categoryDropdownExpanded,
                            onDismissRequest = { categoryDropdownExpanded = false }
                        ) {
                            expenseCategories.forEach { cat ->
                                DropdownMenuItem(
                                    leadingIcon = { AppIcon(iconKey = cat.icone, modifier = Modifier.size(18.dp)) },
                                    text = { Text(cat.nome) },
                                    onClick = {
                                        selectedCategory = cat
                                        categoryDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val wallet = selectedWallet
                        val category = selectedCategory
                        if (wallet != null && category != null) {
                            // Register the expense transaction
                            viewModel.addTransaction(
                                descricao = description,
                                valor = itemTotalConverted, // The amount in settings.moedaPadrao
                                tipo = "Despesa",
                                categoriaId = category.id,
                                carteiraId = wallet.id,
                                moedaTransacao = settings.moedaPadrao
                            )
                            
                            // Mark item as bought
                            viewModel.toggleShoppingItemPaid(item)
                            showExpenseDialogForItem = null
                            
                            // Set success dialog details
                            showExpenseSuccessDialog = Triple(description, itemTotalConverted, category.nome)
                        } else {
                            Toast.makeText(
                                context,
                                if (idioma == "PT") "Selecione uma carteira e categoria!" else "Select a wallet and category!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    enabled = selectedWallet != null && selectedCategory != null
                ) {
                    Text(if (idioma == "PT") "Registrar Despesa" else "Register Expense")
                }
            },
            dismissButton = {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            // Just mark the item as bought, no expense
                            viewModel.toggleShoppingItemPaid(item)
                            showExpenseDialogForItem = null
                            Toast.makeText(
                                context,
                                if (idioma == "PT") "Item marcado (sem despesa)" else "Item checked (no expense)",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    ) {
                        Text(if (idioma == "PT") "Apenas Marcar" else "Only Mark")
                    }
                    TextButton(
                        onClick = { showExpenseDialogForItem = null }
                    ) {
                        Text(if (idioma == "PT") "Cancelar" else "Cancel")
                    }
                }
            }
        )
    }

    // --- DIALOG: EXPENSE REGISTRATION SUCCESS ---
    showExpenseSuccessDialog?.let { (desc, valConv, catName) ->
        
        AlertDialog(
            onDismissRequest = { showExpenseSuccessDialog = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (idioma == "PT") "Sucesso!" else "Success!",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") {
                            "A despesa foi registrada com sucesso no seu sistema financeiro!"
                        } else {
                            "The expense was successfully registered in your financial system!"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = desc,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (idioma == "PT") {
                                    "Valor: ${String.format("%,.2f", valConv)} ${settings.moedaPadrao}\nCategoria: $catName"
                                } else {
                                    "Value: ${String.format("%,.2f", valConv)} ${settings.moedaPadrao}\nCategory: $catName"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Text(
                        text = if (idioma == "PT") {
                            "Dica: Se não encontrar esta despesa no histórico ou nos totais, certifique-se de que os seus filtros rápidos na página de histórico (tipo, período, conta) estão definidos para 'Todos'."
                        } else {
                            "Tip: If you cannot find this expense in the history or calculations, make sure your quick filters on the history page (type, period, account) are set to 'All'."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExpenseSuccessDialog = null
                        onNavigateToHistory()
                    }
                ) {
                    Text(if (idioma == "PT") "Ver no Histórico" else "View in History")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showExpenseSuccessDialog = null }
                ) {
                    Text(if (idioma == "PT") "Fechar" else "Close")
                }
            }
        )
    }

    // --- BOTTOM SHEET / DIALOG: LIST ACTIONS ---
    showListOptionsSheet?.let { list ->
        ListActionsDialog(
            idioma = idioma,
            list = list,
            onDismiss = { showListOptionsSheet = null },
            onDuplicate = { newName ->
                viewModel.duplicateList(list, newName)
                showListOptionsSheet = null
                Toast.makeText(context, if (idioma == "PT") "Lista duplicada!" else "List duplicated!", Toast.LENGTH_SHORT).show()
            },
            onDelete = {
                viewModel.deleteShoppingList(list)
                showListOptionsSheet = null
                Toast.makeText(context, if (idioma == "PT") "Lista excluída!" else "List deleted!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    TactileSuccessBannerOverlay(
        state = tactileState,
        onDismiss = { tactileState = tactileState.copy(visible = false) }
    )
}

@Composable
fun CategoryHeaderRow(
    category: ShoppingCategory?,
    count: Int,
    categoryTotal: Double = 0.0,
    currencySymbol: String = "MT",
    idioma: String,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    val catColor = remember(category) {
        if (category == null) Color(0xFF64748B) // Slate gray for Sem Categoria
        else {
            val hues = listOf(
                Color(0xFFE53935), // Red
                Color(0xFF1E88E5), // Blue
                Color(0xFF43A047), // Green
                Color(0xFFD81B60), // Pink
                Color(0xFF8E24AA), // Purple
                Color(0xFFFB8C00), // Orange
                Color(0xFF00ACC1), // Cyan
                Color(0xFF7CB342), // Light Green
                Color(0xFF5E35B1), // Deep Purple
                Color(0xFF00897B)  // Teal
            )
            hues[Math.abs(category.nome.hashCode()) % hues.size]
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(catColor.copy(alpha = 0.12f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(catColor)
                    )
                    Text(
                        text = (category?.nome ?: if (idioma == "PT") "Sem Categoria" else "Uncategorized").uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = catColor,
                        letterSpacing = 0.8.sp
                    )
                }
            }
            
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = count.toString(),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (categoryTotal > 0.0) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(catColor.copy(alpha = 0.1f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Total: ${String.format("%,.2f", categoryTotal)} $currencySymbol",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = catColor
                    )
                }
            }
        }

        // Up/Down reordering controls
        if (category != null && ShoppingFeatureFlags.CATEGORY_REORDERING_ENABLED) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                IconButton(onClick = onMoveUp, modifier = Modifier.size(24.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowUp,
                        contentDescription = "Move Up",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(onClick = onMoveDown, modifier = Modifier.size(24.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Move Down",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ShoppingItemDetailedRow(
    item: ShoppingItem,
    categories: List<ShoppingCategory> = emptyList(),
    settings: UserSettings,
    viewModel: MainViewModel,
    onEdit: () -> Unit,
    onTogglePaid: (ShoppingItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val unitPriceConverted = viewModel.currencyService.convertFromMZN(item.preco, settings.moedaPadrao)
    val totalPriceConverted = unitPriceConverted * item.quantidade

    val priorityColor = when (item.prioridade) {
        "ALTA" -> Color(0xFFE53935)
        "MEDIA" -> Color(0xFFFF9800)
        else -> Color(0xFF4CAF50)
    }

    val priorityText = when (item.prioridade) {
        "ALTA" -> if (settings.idioma == "PT") "Alta" else "High"
        "MEDIA" -> if (settings.idioma == "PT") "Média" else "Medium"
        else -> if (settings.idioma == "PT") "Baixa" else "Low"
    }

    val alpha = if (item.pago) 0.5f else 1f
    var showMoveCategoryMenu by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick()
            .testTag("shopping_item_${item.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.pago) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
            else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            1.dp,
            if (item.pago) MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
            else priorityColor.copy(alpha = 0.25f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Checked/Checkbox
            IconButton(
                onClick = { onTogglePaid(item) },
                modifier = Modifier
                    .testTag("checkbox_${item.id}")
                    .size(28.dp)
            ) {
                Icon(
                    imageVector = if (item.pago) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                    contentDescription = "Check item",
                    tint = if (item.pago) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(24.dp)
                )
            }

            // Product Details
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onEdit() },
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = item.nome,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            textDecoration = if (item.pago) TextDecoration.LineThrough else TextDecoration.None
                        ),
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha),
                        modifier = Modifier.weight(1f, fill = false),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    // Styled Priority Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(priorityColor.copy(alpha = 0.12f * alpha))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = priorityText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = priorityColor.copy(alpha = alpha)
                        )
                    }
                }

                // Interactive Quantity and Price Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Inline +/- Controller
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = if (item.pago) 0.05f else 0.1f))
                                .clickable(enabled = !item.pago) {
                                    if (item.quantidade > 1) {
                                        viewModel.updateShoppingItem(item.copy(quantidade = item.quantidade - 1))
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("-", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary.copy(alpha = alpha))
                        }
                        Text(
                            text = if (item.quantidade % 1.0 == 0.0) item.quantidade.toInt().toString() else String.format("%.1f", item.quantidade),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha)
                        )
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = if (item.pago) 0.05f else 0.1f))
                                .clickable(enabled = !item.pago) {
                                    viewModel.updateShoppingItem(item.copy(quantidade = item.quantidade + 1))
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("+", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary.copy(alpha = alpha))
                        }
                    }

                    Text(
                        text = item.unidade,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f * alpha)
                    )

                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f * alpha)
                    )

                    Text(
                        text = "${String.format("%,.2f", totalPriceConverted)} ${settings.moedaPadrao}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = alpha)
                    )

                    if (item.quantidade > 1) {
                        Text(
                            text = "(${String.format("%,.2f", unitPriceConverted)}/${item.unidade})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f * alpha)
                        )
                    }
                }

                // Note/Observações if present
                if (item.observacoes.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = item.observacoes,
                            style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f * alpha),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Action: Move Category, Edit, Delete Controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Quick Category Switcher / Move Category Button
                Box {
                    IconButton(
                        onClick = { showMoveCategoryMenu = true },
                        modifier = Modifier
                            .testTag("move_cat_${item.id}")
                            .size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.DriveFileMove,
                            contentDescription = "Mover Categoria",
                            tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMoveCategoryMenu,
                        onDismissRequest = { showMoveCategoryMenu = false }
                    ) {
                        Text(
                            text = if (settings.idioma == "PT") "Mover para Categoria:" else "Move to Category:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        HorizontalDivider()

                        DropdownMenuItem(
                            text = { Text(if (settings.idioma == "PT") "Sem Categoria" else "No Category") },
                            leadingIcon = { Icon(Icons.Rounded.FolderOff, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            onClick = {
                                viewModel.updateShoppingItem(item.copy(categoriaId = null))
                                showMoveCategoryMenu = false
                            }
                        )

                        categories.forEach { cat ->
                            val isCurrent = cat.id == item.categoriaId
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = cat.nome,
                                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                trailingIcon = if (isCurrent) {
                                    { Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp)) }
                                } else null,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Folder,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                onClick = {
                                    viewModel.updateShoppingItem(item.copy(categoriaId = cat.id))
                                    showMoveCategoryMenu = false
                                }
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Edit,
                        contentDescription = "Edit Item",
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = { viewModel.deleteShoppingItem(item) },
                    modifier = Modifier
                        .testTag("delete_${item.id}")
                        .size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Delete,
                        contentDescription = "Delete Item",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrEditShoppingItemDialog(
    idioma: String,
    initialItem: ShoppingItem?,
    categories: List<ShoppingCategory>,
    productSuggestions: List<String>,
    averagePrices: Map<String, Double>,
    viewModel: MainViewModel,
    activeListId: Int? = 1,
    onDismiss: () -> Unit,
    onConfirm: (ShoppingItem) -> Unit
) {
    val context = LocalContext.current

    var nome by remember { mutableStateOf(initialItem?.nome ?: "") }
    var precoStr by remember { mutableStateOf(if (initialItem != null && initialItem.preco > 0) initialItem.preco.toString() else "") }
    var quantidadeStr by remember { mutableStateOf(initialItem?.quantidade?.toString() ?: "1") }
    var showPriceCalculator by remember { mutableStateOf(false) }
    var showQtyCalculator by remember { mutableStateOf(false) }
    var unidade by remember { mutableStateOf(initialItem?.unidade ?: "un") }
    var prioridade by remember { mutableStateOf(initialItem?.prioridade ?: "MEDIA") }
    var categoriaId by remember { mutableStateOf(initialItem?.categoriaId) }
    var observacoes by remember { mutableStateOf(initialItem?.observacoes ?: "") }

    var expandedCategoryDropdown by remember { mutableStateOf(false) }
    var expandedUnitDropdown by remember { mutableStateOf(false) }

    // Filtering suggestions based on input
    val filteredSuggestions = remember(nome, productSuggestions) {
        if (nome.isBlank()) emptyList()
        else productSuggestions.filter { it.contains(nome, ignoreCase = true) && it != nome }.take(3)
    }

    // Auto load average price when nome changes
    LaunchedEffect(nome) {
        if (nome.isNotBlank() && ShoppingFeatureFlags.PRICE_HISTORY_SUGGESTIONS_ENABLED) {
            viewModel.loadAveragePrice(nome)
        }
    }

    val avgPrice = averagePrices[nome]

    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize().testTag("add_shopping_item_dialog"),
            color = MaterialTheme.colorScheme.background
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                        }
                        Text(
                            text = if (initialItem == null) {
                                if (idioma == "PT") "Adicionar Item" else "Add Item"
                            } else {
                                if (idioma == "PT") "Editar Item" else "Edit Item"
                            },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Name TextField with Suggestions
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(
                            value = nome,
                            onValueChange = { nome = it },
                            label = { Text(if (idioma == "PT") "Nome do Produto" else "Product Name") },
                            placeholder = { Text("Ex: Arroz, Tomates") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_item_name_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Autosuggestions chips
                        if (filteredSuggestions.isNotEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                filteredSuggestions.forEach { suggestion ->
                                    SuggestionChip(
                                        onClick = { nome = suggestion },
                                        label = { Text(suggestion) }
                                    )
                                }
                            }
                        }

                        // Price average suggestion alert (Clickable to auto-fill)
                        if (avgPrice != null && avgPrice > 0) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                    .clickable {
                                        precoStr = String.format(java.util.Locale.US, "%.2f", avgPrice)
                                        Toast.makeText(context, if (idioma == "PT") "Preço aplicado!" else "Price applied!", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.TrendingUp,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = if (idioma == "PT") {
                                            "Média de preço anterior: ${String.format("%,.2f", avgPrice)} MZN (Toque para aplicar)"
                                        } else {
                                            "Previous average price: ${String.format("%,.2f", avgPrice)} MZN (Tap to apply)"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Quantity & Unit
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = quantidadeStr,
                            onValueChange = { quantidadeStr = sanitizeDoubleInput(quantidadeStr, it) },
                            label = { Text(if (idioma == "PT") "Qtd" else "Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("add_item_qty_input"),
                            shape = RoundedCornerShape(12.dp),
                            trailingIcon = {
                                IconButton(onClick = { showQtyCalculator = true }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Calculate,
                                        contentDescription = "Calculadora",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        )

                        if (showQtyCalculator) {
                            CalculatorDialog(
                                initialValue = quantidadeStr,
                                idioma = idioma,
                                onDismiss = { showQtyCalculator = false },
                                onConfirm = { result ->
                                    quantidadeStr = result
                                    showQtyCalculator = false
                                }
                            )
                        }

                        // Unit Selector Dropdown
                        Box(modifier = Modifier.weight(1.2f)) {
                            ExposedDropdownMenuBox(
                                expanded = expandedUnitDropdown,
                                onExpandedChange = { expandedUnitDropdown = !expandedUnitDropdown }
                            ) {
                                OutlinedTextField(
                                    value = unidade,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text(if (idioma == "PT") "Unidade" else "Unit") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedUnitDropdown) },
                                    modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                ExposedDropdownMenu(
                                    expanded = expandedUnitDropdown,
                                    onDismissRequest = { expandedUnitDropdown = false }
                                ) {
                                    listOf("un", "kg", "g", "L", "ml", "pct", "cx").forEach { u ->
                                        DropdownMenuItem(
                                            text = { Text(u) },
                                            onClick = {
                                                unidade = u
                                                expandedUnitDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Unit Price
                item {
                    OutlinedTextField(
                        value = precoStr,
                        onValueChange = { precoStr = sanitizeDoubleInput(precoStr, it) },
                        label = { Text(if (idioma == "PT") "Preço Unitário (MZN)" else "Unit Price (MZN)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        placeholder = { Text("0.00") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_item_price_input"),
                        shape = RoundedCornerShape(12.dp),
                        trailingIcon = {
                            IconButton(onClick = { showPriceCalculator = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.Calculate,
                                    contentDescription = "Calculadora",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    )

                    if (showPriceCalculator) {
                        CalculatorDialog(
                            initialValue = precoStr,
                            idioma = idioma,
                            onDismiss = { showPriceCalculator = false },
                            onConfirm = { result ->
                                precoStr = result
                                showPriceCalculator = false
                            }
                        )
                    }
                }

                // Category Selector
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = if (idioma == "PT") "Categoria" else "Category",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Box(modifier = Modifier.fillMaxWidth()) {
                            val activeCatName = categories.find { it.id == categoriaId }?.nome
                                ?: (if (idioma == "PT") "Sem Categoria" else "No Category")

                            OutlinedButton(
                                onClick = { expandedCategoryDropdown = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(activeCatName, color = MaterialTheme.colorScheme.onSurface)
                                    Icon(
                                        imageVector = Icons.Rounded.ArrowDropDown,
                                        contentDescription = null
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = expandedCategoryDropdown,
                                onDismissRequest = { expandedCategoryDropdown = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(if (idioma == "PT") "Sem Categoria" else "No Category") },
                                    onClick = {
                                        categoriaId = null
                                        expandedCategoryDropdown = false
                                    }
                                )
                                categories.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat.nome) },
                                        onClick = {
                                            categoriaId = cat.id
                                            expandedCategoryDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Priority selector
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = if (idioma == "PT") "Prioridade" else "Priority",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("BAIXA", "MEDIA", "ALTA").forEach { level ->
                                val label = when (level) {
                                    "ALTA" -> if (idioma == "PT") "Alta" else "High"
                                    "MEDIA" -> if (idioma == "PT") "Média" else "Medium"
                                    else -> if (idioma == "PT") "Baixa" else "Low"
                                }
                                val levelColor = when (level) {
                                    "ALTA" -> Color(0xFFE53935)
                                    "MEDIA" -> Color(0xFFFF9800)
                                    else -> Color(0xFF4CAF50)
                                }
                                val isSelected = prioridade == level

                                val buttonColor = if (isSelected) levelColor else MaterialTheme.colorScheme.surface
                                val textColor = if (isSelected) Color.White else levelColor

                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { prioridade = level }
                                        .testTag("priority_chip_$level"),
                                    shape = RoundedCornerShape(12.dp),
                                    color = buttonColor,
                                    border = BorderStroke(1.dp, levelColor)
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = textColor
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Notes / Observações (e.g. "só se estiver em promoção")
                item {
                    OutlinedTextField(
                        value = observacoes,
                        onValueChange = { observacoes = it },
                        label = { Text(if (idioma == "PT") "Observações" else "Notes") },
                        placeholder = { Text("Ex: só se estiver em promoção") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Confirm / Cancel / Batch Buttons
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(if (idioma == "PT") "Cancelar" else "Cancel")
                            }

                            Button(
                                onClick = {
                                    val preco = precoStr.toDoubleOrNull() ?: 0.0
                                    val qtd = quantidadeStr.toDoubleOrNull() ?: 1.0
                                    if (nome.isBlank()) {
                                        Toast.makeText(context, if (idioma == "PT") "Por favor, digite o nome!" else "Please type a name!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        onConfirm(
                                            ShoppingItem(
                                                id = initialItem?.id ?: 0,
                                                listaId = initialItem?.listaId ?: 1,
                                                nome = nome.trim(),
                                                preco = preco,
                                                quantidade = qtd,
                                                unidade = unidade,
                                                prioridade = prioridade,
                                                pago = initialItem?.pago ?: false,
                                                categoriaId = categoriaId,
                                                observacoes = observacoes.trim()
                                            )
                                        )
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(if (initialItem == null) (if (idioma == "PT") "Adicionar" else "Add") else (if (idioma == "PT") "Salvar" else "Save"))
                            }
                        }

                        if (initialItem == null) {
                            OutlinedButton(
                                onClick = {
                                    val preco = precoStr.toDoubleOrNull() ?: 0.0
                                    val qtd = quantidadeStr.toDoubleOrNull() ?: 1.0
                                    if (nome.isBlank()) {
                                        Toast.makeText(context, if (idioma == "PT") "Por favor, digite o nome!" else "Please type a name!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        viewModel.addShoppingItem(
                                            nome = nome.trim(),
                                            preco = preco,
                                            quantidade = qtd,
                                            unidade = unidade,
                                            prioridade = prioridade,
                                            categoriaId = categoriaId,
                                            observacoes = observacoes.trim(),
                                            listaId = activeListId ?: 1
                                        )
                                        Toast.makeText(context, if (idioma == "PT") "Item adicionado! Digite o próximo." else "Item added! Type the next one.", Toast.LENGTH_SHORT).show()
                                        // Reset fields for batch mode
                                        nome = ""
                                        precoStr = ""
                                        quantidadeStr = "1"
                                        observacoes = ""
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (idioma == "PT") "Adicionar e Continuar (Lote)" else "Add & Continue (Batch)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateListDialog(
    idioma: String,
    onDismiss: () -> Unit,
    onConfirm: (String, Boolean) -> Unit
) {
    var nome by remember { mutableStateOf("") }
    var isTemplate by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (idioma == "PT") "Nova Lista" else "New Shopping List",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text(if (idioma == "PT") "Nome da Lista" else "List Name") },
                    placeholder = { Text("Ex: Feira de Domingo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                // Template Checkbox
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.clickable { isTemplate = !isTemplate }
                ) {
                    Checkbox(
                        checked = isTemplate,
                        onCheckedChange = { isTemplate = it }
                    )
                    Column {
                        Text(
                            text = if (idioma == "PT") "Salvar como modelo" else "Save as template",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (idioma == "PT") "Modelos podem ser duplicados para compras recorrentes." else "Templates can be duplicated for recurring shopping.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (idioma == "PT") "Cancelar" else "Cancel")
                    }

                    Button(
                        onClick = {
                            if (nome.isBlank()) {
                                onConfirm(if (idioma == "PT") "Minha Lista" else "My List", isTemplate)
                            } else {
                                onConfirm(nome, isTemplate)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (idioma == "PT") "Criar" else "Create")
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryManagementDialog(
    idioma: String,
    categories: List<ShoppingCategory>,
    onDismiss: () -> Unit,
    onAddCategory: (String) -> Unit,
    onDeleteCategory: (ShoppingCategory) -> Unit
) {
    var novaCategoria by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (idioma == "PT") "Gerenciar Categorias" else "Shopping Categories",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // Input to add category
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = novaCategoria,
                        onValueChange = { novaCategoria = it },
                        placeholder = { Text(if (idioma == "PT") "Nova Categoria" else "New Category") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )

                    IconButton(
                        onClick = {
                            if (novaCategoria.isNotBlank()) {
                                onAddCategory(novaCategoria.trim())
                                novaCategoria = ""
                            }
                        },
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                            .size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Add Category",
                            tint = Color.White
                        )
                    }
                }

                // List of existing categories
                Text(
                    text = if (idioma == "PT") "Suas Categorias:" else "Your Categories:",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(categories, key = { it.id }) { cat ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Label,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(cat.nome, style = MaterialTheme.typography.bodyMedium)
                            }

                            // Don't delete "Outros" default category to avoid empty states
                            if (cat.nome != "Outros") {
                                IconButton(onClick = { onDeleteCategory(cat) }, modifier = Modifier.size(28.dp)) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (idioma == "PT") "Fechar" else "Close")
                }
            }
        }
    }
}

@Composable
fun ListActionsDialog(
    idioma: String,
    list: ShoppingList,
    onDismiss: () -> Unit,
    onDuplicate: (String) -> Unit,
    onDelete: () -> Unit
) {
    var showRenameInput by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf(list.nome) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = list.nome,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                if (!showRenameInput) {
                    // Standard Options
                    ListItem(
                        headlineContent = { Text(if (idioma == "PT") "Duplicar Lista (Reutilizar)" else "Duplicate List (Re-use)") },
                        leadingContent = { Icon(Icons.Rounded.ContentCopy, contentDescription = null) },
                        modifier = Modifier.clickable {
                            onDuplicate(list.nome + " " + (if (idioma == "PT") "(Cópia)" else "(Copy)"))
                        }
                    )

                    ListItem(
                        headlineContent = { Text(if (idioma == "PT") "Excluir Lista" else "Delete List") },
                        leadingContent = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                        modifier = Modifier.clickable { onDelete() }
                    )
                } else {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Nome") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(if (idioma == "PT") "Cancelar" else "Cancel")
                    }
                }
            }
        }
    }
}
