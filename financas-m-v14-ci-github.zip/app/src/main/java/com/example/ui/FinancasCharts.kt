@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import com.example.util.AppIcon
import com.example.util.AppIcons
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.R
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import androidx.compose.foundation.ExperimentalFoundationApi
import java.io.File


@Composable
fun WavyLine(color: Color, isAscending: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val path = androidx.compose.ui.graphics.Path().apply {
            if (isAscending) {
                // Starts low, trends high (ascending)
                moveTo(0f, height * 0.85f)
                quadraticTo(width * 0.25f, height * 0.9f, width * 0.5f, height * 0.55f)
                quadraticTo(width * 0.75f, height * 0.15f, width, height * 0.15f)
            } else {
                // Starts high, trends low (descending)
                moveTo(0f, height * 0.15f)
                quadraticTo(width * 0.25f, height * 0.1f, width * 0.5f, height * 0.45f)
                quadraticTo(width * 0.75f, height * 0.85f, width, height * 0.85f)
            }
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
        // End point filled circle
        val circleY = if (isAscending) height * 0.15f else height * 0.85f
        drawCircle(
            color = color,
            radius = 4.dp.toPx(),
            center = androidx.compose.ui.geometry.Offset(width, circleY)
        )
    }
}

// ------------------- CUSTOM DASHBOARD CHARTS -------------------
@Composable
fun SparklineChart(
    modifier: Modifier = Modifier,
    dataPoints: List<Double> = listOf(60.0, 45.0, 65.0, 40.0, 75.0, 55.0, 85.0, 70.0, 95.0, 100.0),
    labels: List<String> = listOf("01", "04", "07", "10", "13", "16", "19", "22", "25", "28"),
    color: Color = Color(0xFF00E676),
    moeda: String = "MZN"
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    val minVal = (dataPoints.minOrNull() ?: 0.0) * 0.9
    val maxVal = (dataPoints.maxOrNull() ?: 100.0) * 1.1
    val range = (maxVal - minVal).coerceAtLeast(1.0)

    Box(modifier = modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(dataPoints) {
                    detectTapGestures(
                        onTap = { offset ->
                            val step = size.width / (dataPoints.size - 1).coerceAtLeast(1)
                            val idx = (offset.x / step).roundToInt().coerceIn(0, dataPoints.size - 1)
                            selectedIndex = if (selectedIndex == idx) null else idx
                        }
                    )
                }
        ) {
            val width = size.width
            val height = size.height
            val step = width / (dataPoints.size - 1).coerceAtLeast(1)

            val path = Path()
            dataPoints.forEachIndexed { index, p ->
                val x = index * step
                val normalized = (p - minVal) / range
                val y = height - (normalized.toFloat() * height * 0.75f + height * 0.12f)
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }

            drawPath(
                path = path,
                color = color,
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            selectedIndex?.let { idx ->
                val x = idx * step
                val normalized = (dataPoints[idx] - minVal) / range
                val y = height - (normalized.toFloat() * height * 0.75f + height * 0.12f)

                drawLine(
                    color = color.copy(alpha = 0.6f),
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1.dp.toPx(),
                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                )
                drawCircle(color = Color.White, radius = 5.dp.toPx(), center = Offset(x, y))
                drawCircle(color = color, radius = 3.5.dp.toPx(), center = Offset(x, y))
            }
        }

        selectedIndex?.let { idx ->
            val valStr = String.format("%,.1f", dataPoints[idx])
            val labelStr = labels.getOrElse(idx) { "" }
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-20).dp),
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                shadowElevation = 4.dp
            ) {
                Text(
                    text = "$labelStr: $valStr $moeda",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun ArcGaugeChart(
    score: Int,
    classification: String,
    modifier: Modifier = Modifier,
    arcColor: Color = Color(0xFF00E676)
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 8.dp.toPx()
            val diameter = minOf(size.width, size.height) - strokeWidth
            val topLeft = Offset((size.width - diameter) / 2, (size.height - diameter) / 2)
            val arcSize = Size(diameter, diameter)

            drawArc(
                color = arcColor.copy(alpha = 0.2f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            val sweep = (score / 100f).coerceIn(0f, 1f) * 270f
            drawArc(
                color = arcColor,
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$score",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = classification,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = arcColor
            )
        }
    }
}

@Composable
fun AreaPatrimonioChart(
    modifier: Modifier = Modifier,
    dataPoints: List<Double> = listOf(12000.0, 18500.0, 24000.0, 31000.0, 48500.0),
    labels: List<String> = listOf("Jan", "Fev", "Mar", "Abr", "Mai"),
    lineColor: Color = Color(0xFF00E676),
    currencySymbol: String = "MT"
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    val minVal = (dataPoints.minOrNull() ?: 0.0) * 0.85
    val maxVal = (dataPoints.maxOrNull() ?: 10000.0) * 1.15
    val range = (maxVal - minVal).coerceAtLeast(1.0)

    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(dataPoints) {
                        detectTapGestures(
                            onTap = { offset ->
                                val step = size.width / (dataPoints.size - 1).coerceAtLeast(1)
                                val idx = (offset.x / step).roundToInt().coerceIn(0, dataPoints.size - 1)
                                selectedIndex = if (selectedIndex == idx) null else idx
                            }
                        )
                    }
            ) {
                val width = size.width
                val height = size.height
                val step = width / (dataPoints.size - 1).coerceAtLeast(1)

                // Background horizontal gridlines (Y-axis grid)
                val gridLines = 3
                for (i in 0..gridLines) {
                    val y = height * (i.toFloat() / gridLines)
                    drawLine(
                        color = Color.White.copy(alpha = 0.08f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                val points = dataPoints.mapIndexed { index, valD ->
                    val x = index * step
                    val normalized = (valD - minVal) / range
                    val y = height - (normalized.toFloat() * height * 0.72f + height * 0.12f)
                    Offset(x, y)
                }

                val strokePath = Path().apply {
                    if (points.isNotEmpty()) {
                        moveTo(points.first().x, points.first().y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                    }
                }

                val fillPath = Path().apply {
                    addPath(strokePath)
                    lineTo(width, height)
                    lineTo(0f, height)
                    close()
                }

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(lineColor.copy(alpha = 0.35f), Color.Transparent)
                    )
                )

                drawPath(
                    path = strokePath,
                    color = lineColor,
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )

                points.forEach { pt ->
                    drawCircle(color = lineColor, radius = 3.5.dp.toPx(), center = pt)
                }

                selectedIndex?.let { idx ->
                    val selPt = points.getOrNull(idx)
                    if (selPt != null) {
                        drawLine(
                            color = lineColor.copy(alpha = 0.7f),
                            start = Offset(selPt.x, 0f),
                            end = Offset(selPt.x, height),
                            strokeWidth = 1.5.dp.toPx(),
                            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                        )
                        drawCircle(color = Color.White, radius = 6.5.dp.toPx(), center = selPt)
                        drawCircle(color = lineColor, radius = 4.5.dp.toPx(), center = selPt)
                    }
                }
            }

            selectedIndex?.let { idx ->
                val valD = dataPoints.getOrNull(idx) ?: 0.0
                val label = labels.getOrElse(idx) { "" }
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 2.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shadowElevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(lineColor)
                        )
                        Text(
                            text = "$label: ${String.format("%,.2f", valD)} $currencySymbol",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            labels.forEachIndexed { idx, label ->
                Text(
                    text = label,
                    fontSize = 10.sp,
                    fontWeight = if (selectedIndex == idx) FontWeight.ExtraBold else FontWeight.Normal,
                    color = if (selectedIndex == idx) lineColor else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
    }
}

// Custom Native Donut Chart Drawn on Canvas
@Composable
fun CategoryDonutChart(viewModel: MainViewModel, transactions: List<Transaction>, categories: List<Category>, settings: UserSettings) {
    val (totalExpense, categoryTotals, categoryList) = remember(transactions, categories) {
        val totals = transactions.groupBy { it.categoriaId }
            .mapValues { it.value.sumOf { t -> t.valor } }
        val list = categories.filter { it.tipo == "Despesa" && totals.containsKey(it.id) }
        Triple(transactions.sumOf { it.valor }, totals, list)
    }
    val idioma = settings.idioma
    val isDark = settings.tema == "dark"
    val themeColor = try {
        Color(android.graphics.Color.parseColor(settings.corPrimaria.ifEmpty { "#6D4AFF" }))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    if (totalExpense <= 0.0 || categoryList.isEmpty()) {
        Card(
            modifier = Modifier.fillMaxWidth().height(120.dp),
            colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF131524) else Color(0xFFF8FAFC)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFE2E8F0))
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (idioma == "PT") "Nenhuma despesa nos últimos 30 dias." else "No expenses in the last 30 days.",
                    color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        return
    }

    val animatedSweepRatio = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(transactions) {
        animatedSweepRatio.animateTo(
            targetValue = 1f,
            animationSpec = androidx.compose.animation.core.tween(
                durationMillis = 1000,
                easing = androidx.compose.animation.core.FastOutSlowInEasing
            )
        )
    }

    var selectedCategory by remember { mutableStateOf<Category?>(null) }
    var showDetailDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showDetailDialog = true },
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF131524) else Color.White
        ),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFEEF2F6))
    ) {
        Column(modifier = Modifier.padding(20.dp).fillMaxWidth()) {
            // Card Header with Call to Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (idioma == "PT") "Divisão por Categoria" else "Category Breakdown",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White.copy(alpha = 0.8f) else Color(0xFF475569)
                )
                Text(
                    text = if (idioma == "PT") "Detalhes ↗" else "Details ↗",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = themeColor,
                    modifier = Modifier
                        .background(themeColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Interactive Donut with text inside
                Box(
                    modifier = Modifier.size(110.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("donut_chart_canvas")
                            .pointerInput(categoryList) {
                                detectTapGestures { offset ->
                                    val centerX = size.width / 2f
                                    val centerY = size.height / 2f
                                    val dx = offset.x - centerX
                                    val dy = offset.y - centerY
                                    var angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                    angle += 90f
                                    if (angle < 0f) angle += 360f
                                    
                                    var currentAngle = 0f
                                    var found: Category? = null
                                    for (cat in categoryList) {
                                        val amount = categoryTotals[cat.id] ?: 0.0
                                        val sweepAngle = ((amount / totalExpense) * 360f).toFloat()
                                        if (angle >= currentAngle && angle <= currentAngle + sweepAngle) {
                                            found = cat
                                            break
                                        }
                                        currentAngle += sweepAngle
                                    }
                                    selectedCategory = if (selectedCategory?.id == found?.id) null else found
                                }
                            }
                    ) {
                        var startAngle = -90f
                        for (cat in categoryList) {
                            val amount = categoryTotals[cat.id] ?: 0.0
                            val sweepAngle = ((amount / totalExpense) * 360f).toFloat() * animatedSweepRatio.value
                            val color = try {
                                Color(android.graphics.Color.parseColor(cat.cor))
                            } catch (e: Exception) {
                                Color.Gray
                            }
                            val isSelected = selectedCategory?.id == cat.id
                            val strokeWidth = if (isSelected) 30f else 18f
                            
                            drawArc(
                                color = if (selectedCategory == null || isSelected) color else color.copy(alpha = 0.3f),
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                            startAngle += sweepAngle
                        }
                    }

                    // Central value display
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        val displayValue = if (selectedCategory != null) {
                            categoryTotals[selectedCategory!!.id] ?: 0.0
                        } else {
                            totalExpense
                        }
                        val displayValueConv = viewModel.currencyService.convertFromMZN(displayValue, settings.moedaPadrao)

                        Text(
                            text = if (selectedCategory != null) selectedCategory!!.nome else "Total",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B)
                        )
                        Text(
                            text = if (displayValueConv >= 1000000) {
                                String.format("%.1fM", displayValueConv / 1000000)
                            } else if (displayValueConv >= 10000) {
                                String.format("%.0fk", displayValueConv / 1000)
                            } else {
                                String.format("%.0f", displayValueConv)
                            },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isDark) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = settings.moedaPadrao,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = themeColor
                        )
                    }
                }

                // Legend column
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categoryList.take(4).forEach { cat ->
                        val amount = categoryTotals[cat.id] ?: 0.0
                        val pct = (amount / totalExpense) * 100
                        val color = try {
                            Color(android.graphics.Color.parseColor(cat.cor))
                        } catch (e: Exception) {
                            Color.Gray
                        }
                        val isSelected = selectedCategory?.id == cat.id
                        val isAnySelected = selectedCategory != null

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clickable { selectedCategory = if (isSelected) null else cat }
                                .graphicsLayer {
                                    alpha = if (!isAnySelected || isSelected) 1f else 0.4f
                                }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(color)
                            )
                            Text(
                                text = "${cat.nome} (${pct.roundToInt()}%)",
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = if (isDark) Color.White else Color(0xFF334155),
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            // Info Card when section is tapped
            selectedCategory?.let { cat ->
                val amount = categoryTotals[cat.id] ?: 0.0
                val pct = (amount / totalExpense) * 100
                val amountConv = viewModel.currencyService.convertFromMZN(amount, settings.moedaPadrao)
                
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            themeColor.copy(alpha = if (isDark) 0.12f else 0.06f),
                            RoundedCornerShape(12.dp)
                        )
                        .border(
                            1.dp,
                            themeColor.copy(alpha = if (isDark) 0.25f else 0.15f),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedCategory = null }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = cat.nome,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF1E293B)
                        )
                        Text(
                            text = "(${pct.roundToInt()}%)",
                            fontSize = 11.sp,
                            color = themeColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = "${String.format("%,.2f", amountConv)} ${settings.moedaPadrao}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = themeColor
                    )
                }
            }
        }
    }

    // Interactive Detailed Report Dialog
    if (showDetailDialog) {
        DetailedExpenseChartDialog(
            viewModel = viewModel,
            transactions = transactions,
            categories = categories,
            settings = settings,
            onDismiss = { showDetailDialog = false }
        )
    }
}

@Composable
fun DetailedExpenseChartDialog(
    viewModel: MainViewModel,
    transactions: List<Transaction>,
    categories: List<Category>,
    settings: UserSettings,
    onDismiss: () -> Unit
) {
    val idioma = settings.idioma
    val isDark = settings.tema == "dark"
    val themeColor = try {
        Color(android.graphics.Color.parseColor(settings.corPrimaria.ifEmpty { "#6D4AFF" }))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    data class BreakdownData(
        val totalExpense: Double,
        val categoryTotals: Map<Int, Double>,
        val categoryCounts: Map<Int, Int>,
        val sortedCategories: List<Category>
    )

    val breakdown = remember(transactions, categories) {
        val totals = HashMap<Int, Double>()
        val counts = HashMap<Int, Int>()
        var totExp = 0.0
        for (t in transactions) {
            totExp += t.valor
            val catId = t.categoriaId ?: 0
            totals[catId] = (totals[catId] ?: 0.0) + t.valor
            counts[catId] = (counts[catId] ?: 0) + 1
        }
        val sorted = categories
            .filter { it.tipo == "Despesa" && totals.containsKey(it.id) }
            .sortedByDescending { totals[it.id] ?: 0.0 }
        
        BreakdownData(totExp, totals, counts, sorted)
    }
    val totalExpense = breakdown.totalExpense
    val categoryTotals = breakdown.categoryTotals
    val categoryCounts = breakdown.categoryCounts
    val sortedCategories = breakdown.sortedCategories

    var selectedCategoryInDialog by remember { mutableStateOf<Category?>(sortedCategories.firstOrNull()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) Color(0xFF131524) else Color.White
            ),
            border = BorderStroke(
                1.dp,
                if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFE2E8F0)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (idioma == "PT") "Análise de Despesas" else "Expense Analytics",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = if (idioma == "PT") "Últimos 30 dias" else "Last 30 days",
                            fontSize = 12.sp,
                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B)
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (isDark) Color.White.copy(alpha = 0.05f) else Color(0xFFF1F5F9),
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close",
                            tint = if (isDark) Color.White else Color(0xFF475569),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Scrollable Content
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. Insights Box
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = themeColor.copy(alpha = if (isDark) 0.12f else 0.06f)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(themeColor.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.TrendingUp,
                                        contentDescription = null,
                                        tint = themeColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    val topCat = sortedCategories.firstOrNull()
                                    val topCatName = topCat?.nome ?: ""
                                    val topCatPct = if (totalExpense > 0) ((categoryTotals[topCat?.id] ?: 0.0) / totalExpense * 100).roundToInt() else 0
                                    val dailyAvg = totalExpense / 30.0
                                    val dailyAvgConv = viewModel.currencyService.convertFromMZN(dailyAvg, settings.moedaPadrao)

                                    Text(
                                        text = if (idioma == "PT") "Insight de Gastos" else "Spending Insight",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = themeColor
                                    )
                                    Text(
                                        text = if (idioma == "PT") {
                                            if (topCat != null) {
                                                "Sua maior despesa foi em $topCatName ($topCatPct%). Média diária de ${String.format("%,.2f", dailyAvgConv)} ${settings.moedaPadrao}."
                                            } else {
                                                "Nenhuma despesa registada neste período."
                                            }
                                        } else {
                                            if (topCat != null) {
                                                "Your highest expense was in $topCatName ($topCatPct%). Daily average of ${String.format("%,.2f", dailyAvgConv)} ${settings.moedaPadrao}."
                                            } else {
                                                "No expenses recorded in this period."
                                            }
                                        },
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp,
                                        color = if (isDark) Color.White.copy(alpha = 0.8f) else Color(0xFF334155)
                                    )
                                }
                            }
                        }
                    }

                    // 2. All Categories Breakdown List
                    item {
                        Text(
                            text = if (idioma == "PT") "Distribuição por Categoria" else "Category Distribution",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF475569)
                        )
                    }

                    items(sortedCategories, key = { it.id }) { cat ->
                        val amount = categoryTotals[cat.id] ?: 0.0
                        val count = categoryCounts[cat.id] ?: 0
                        val pct = if (totalExpense > 0) (amount / totalExpense) else 0.0
                        val amountConv = remember(amount, settings.moedaPadrao) { viewModel.currencyService.convertFromMZN(amount, settings.moedaPadrao) }
                        val color = remember(cat.cor) {
                            try {
                                Color(android.graphics.Color.parseColor(cat.cor))
                            } catch (e: Exception) {
                                Color.Gray
                            }
                        }
                        val isSelected = selectedCategoryInDialog?.id == cat.id

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isSelected) themeColor.copy(alpha = if (isDark) 0.1f else 0.05f) else Color.Transparent,
                                    RoundedCornerShape(12.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) themeColor.copy(alpha = 0.3f) else Color.Transparent,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    selectedCategoryInDialog = if (isSelected) null else cat
                                }
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(color.copy(alpha = 0.15f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        com.example.util.AppIcon(
                                            iconKey = if (cat.icone.isNotBlank()) cat.icone else cat.nome,
                                            contentDescription = cat.nome,
                                            tint = color,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = cat.nome,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = if (isDark) Color.White else Color(0xFF1E293B)
                                        )
                                        Text(
                                            text = if (idioma == "PT") "$count transações" else "$count transactions",
                                            fontSize = 11.sp,
                                            color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B)
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${String.format("%,.2f", amountConv)} ${settings.moedaPadrao}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isDark) Color.White else Color(0xFF0F172A)
                                    )
                                    Text(
                                        text = "${(pct * 100).roundToInt()}%",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = themeColor
                                    )
                                }
                            }

                            // Interactive M3 Progress indicator
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFE2E8F0))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(pct.toFloat())
                                        .fillMaxHeight()
                                        .clip(CircleShape)
                                        .background(color)
                                )
                            }
                        }
                    }

                    // 3. Transactions Drilldown Section
                    selectedCategoryInDialog?.let { cat ->
                        val catTransactions = transactions.filter { it.categoriaId == cat.id }
                        if (catTransactions.isNotEmpty()) {
                            item {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (idioma == "PT") "Últimos Lançamentos em ${cat.nome}" else "Recent Transactions in ${cat.nome}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF475569)
                                )
                            }

                            items(catTransactions.sortedByDescending { it.data }.take(5), key = { it.id }) { t ->
                                val tAmountConv = remember(t.valor, settings.moedaPadrao) { viewModel.currencyService.convertFromMZN(t.valor, settings.moedaPadrao) }
                                val dateStr = remember(t.data) { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(t.data)) }
                                
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            if (isDark) Color.White.copy(alpha = 0.02f) else Color(0xFFF8FAFC),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = t.descricao.ifEmpty { if (idioma == "PT") "Sem descrição" else "No description" },
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isDark) Color.White else Color(0xFF1E293B)
                                        )
                                        Text(
                                            text = dateStr,
                                            fontSize = 11.sp,
                                            color = if (isDark) Color.White.copy(alpha = 0.4f) else Color(0xFF64748B)
                                        )
                                    }
                                    Text(
                                        text = "-${String.format("%,.2f", tAmountConv)} ${settings.moedaPadrao}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color(0xFFF28B82) else Color(0xFFC62828)
                                    )
                                }
                            }
                        }
                    }
                }

                // Footer Actions
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = themeColor)
                ) {
                    Text(
                        text = if (idioma == "PT") "Fechar" else "Close",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

// Custom Balance Line Chart Drawn on Canvas (Past 10 Days)
@Composable
fun BalanceLineChart(viewModel: MainViewModel, transactions: List<Transaction>, initialBalance: Double, settings: UserSettings) {
    val themeColor = try {
        Color(android.graphics.Color.parseColor(settings.corPrimaria))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    val idioma = settings.idioma
    val isDark = settings.tema == "dark"
    val secondaryCurrency by viewModel.secondaryCurrency.collectAsStateWithLifecycle()

    // 1. Interactive Period Selection State (7 / 10 / 15 days)
    var selectedDays by remember { mutableStateOf(10) }

    // If transactions are empty, show a beautifully styled empty-state card consistent with the design
    if (transactions.isEmpty()) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("balance_history_card"),
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) Color(0xFF131824) else Color(0xFFF8FAFC)
            ),
            border = BorderStroke(1.dp, if (isDark) Color(0xFF232D42) else Color(0xFFE2E8F0)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(imageVector = Icons.Rounded.BarChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (idioma == "PT") "Insira lançamentos para ver o histórico." else "Insert transactions to see history.",
                    color = if (isDark) Color.LightGray else Color(0xFF64748B),
                    fontWeight = FontWeight.Medium,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
        return
    }

    // Compute balance points over the selected period
    val points = remember(transactions, initialBalance, selectedDays) {
        val list = ArrayList<Double>(selectedDays)
        var balance = initialBalance
        
        val dailyMap = DoubleArray(selectedDays) { 0.0 }
        val now = System.currentTimeMillis()
        val dayInMillis = 86400000L
        val cutOffTime = now - (selectedDays.toLong() + 1) * dayInMillis

        // Avoid looping over all historic transactions when we only care about the last few days
        for (t in transactions) {
            if (t.data < cutOffTime) continue
            if (t.ajusteCaixa) continue
            if (!t.isReceita() && !t.isDespesa()) continue
            val diffMs = now - t.data
            if (diffMs < 0) continue
            val diffDays = (diffMs / dayInMillis).toInt()
            if (diffDays in 0 until selectedDays) {
                val impact = if (t.isDespesa()) -t.valor else t.valor
                dailyMap[diffDays] += impact
            }
        }

        // Project daily balances backwards
        for (i in 0 until selectedDays) {
            list.add(0, balance)
            val dayImpact = dailyMap[i]
            balance -= dayImpact // Reverse impact to find previous balance
        }
        list
    }

    // 2. Trend Metrics and Stats Calculations
    val maxVal = points.maxOrNull() ?: 1.0
    val minVal = points.minOrNull() ?: 0.0
    val range = (maxVal - minVal).coerceAtLeast(1.0)
    val startBalance = points.firstOrNull() ?: 0.0
    val endBalance = points.lastOrNull() ?: 0.0
    val netChange = endBalance - startBalance
    val netChangePercent = if (startBalance != 0.0) (netChange / startBalance) * 100 else 0.0

    val animatedProgress = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(points) {
        animatedProgress.animateTo(
            targetValue = 1f,
            animationSpec = androidx.compose.animation.core.tween(durationMillis = 1000)
        )
    }

    var selectedPointIndex by remember { mutableStateOf<Int?>(null) }

    // 3. Time-based Auto-dismiss (8 seconds of inactivity)
    LaunchedEffect(selectedPointIndex) {
        if (selectedPointIndex != null) {
            delay(8000)
            selectedPointIndex = null
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("balance_history_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF131824) else Color(0xFFF8FAFC)
        ),
        border = BorderStroke(1.dp, if (isDark) Color(0xFF232D42) else Color(0xFFE2E8F0)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header with title and trend badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (netChange >= 0) Icons.AutoMirrored.Rounded.TrendingUp else Icons.AutoMirrored.Rounded.TrendingDown,
                        contentDescription = null,
                        tint = themeColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = if (idioma == "PT") "HISTÓRICO DO SALDO" else "BALANCE HISTORY",
                            color = themeColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = if (idioma == "PT") "Evolução do Patrimônio" else "Equity Evolution",
                            color = if (isDark) Color.White else Color(0xFF1E293B),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 4. Trend Indicator Badge with Arrow
                val badgeColor = if (netChange >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                val badgeBgColor = badgeColor.copy(alpha = 0.12f)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(badgeBgColor)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = if (netChange >= 0) "▲" else "▼",
                            color = badgeColor,
                            fontSize = 9.sp
                        )
                        Text(
                            text = String.format("%.1f%%", Math.abs(netChangePercent)),
                            color = badgeColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 5. KPI Summary Cards (Max / Min / Net)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Net Change Stat
                Column(
                    modifier = Modifier
                        .weight(1.5f)
                        .background(
                            if (isDark) Color(0xFF1E2638) else Color(0xFFECEFF1),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(8.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") "Variação Líquida" else "Net Change",
                        fontSize = 9.sp,
                        color = if (isDark) Color.LightGray.copy(alpha = 0.6f) else Color(0xFF64748B),
                        fontWeight = FontWeight.Medium
                    )
                    val netFormatted = viewModel.currencyService.convertFromMZN(netChange, settings.moedaPadrao)
                    Text(
                        text = "${if (netChange >= 0) "+" else ""}${String.format("%,.2f", netFormatted)} ${settings.moedaPadrao}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (netChange >= 0) Color(0xFF4CAF50) else Color(0xFFF44336),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Max balance Stat
                Column(
                    modifier = Modifier
                        .weight(1.2f)
                        .background(
                            if (isDark) Color(0xFF1E2638) else Color(0xFFECEFF1),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(8.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") "Máximo" else "Maximum",
                        fontSize = 9.sp,
                        color = if (isDark) Color.LightGray.copy(alpha = 0.6f) else Color(0xFF64748B),
                        fontWeight = FontWeight.Medium
                    )
                    val maxFormatted = viewModel.currencyService.convertFromMZN(maxVal, settings.moedaPadrao)
                    Text(
                        text = "${String.format("%,.2f", maxFormatted)} ${settings.moedaPadrao}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color.White else Color(0xFF334155),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Min balance Stat
                Column(
                    modifier = Modifier
                        .weight(1.2f)
                        .background(
                            if (isDark) Color(0xFF1E2638) else Color(0xFFECEFF1),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(8.dp)
                ) {
                    Text(
                        text = if (idioma == "PT") "Mínimo" else "Minimum",
                        fontSize = 9.sp,
                        color = if (isDark) Color.LightGray.copy(alpha = 0.6f) else Color(0xFF64748B),
                        fontWeight = FontWeight.Medium
                    )
                    val minFormatted = viewModel.currencyService.convertFromMZN(minVal, settings.moedaPadrao)
                    Text(
                        text = "${String.format("%,.2f", minFormatted)} ${settings.moedaPadrao}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color.White else Color(0xFF334155),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 6. Interactive Period Selector Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.Start),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (idioma == "PT") "Período:" else "Period:",
                    fontSize = 11.sp,
                    color = if (isDark) Color.LightGray else Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )
                listOf(7, 10, 15, 30, 60).forEach { days ->
                    val isSelected = selectedDays == days
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) themeColor else (if (isDark) Color(0xFF1E2638) else Color(0xFFE2E8F0))
                            )
                            .clickable {
                                selectedDays = days
                                selectedPointIndex = null
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (idioma == "PT") "$days dias" else "$days days",
                            color = if (isSelected) Color.White else (if (isDark) Color.LightGray else Color(0xFF475569)),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Canvas with fully animated Bezier charts, zero baselines, grid lines and custom indicator tooltips
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("line_chart_canvas")
                        .pointerInput(points, selectedDays) {
                            detectHorizontalDragGestures(
                                onDragStart = { offset ->
                                    val width = size.width
                                    val spacing = width / (selectedDays - 1).coerceAtLeast(1).toFloat()
                                    selectedPointIndex = ((offset.x / spacing) + 0.5f).toInt().coerceIn(0, selectedDays - 1)
                                },
                                onHorizontalDrag = { change, _ ->
                                    val width = size.width
                                    val spacing = width / (selectedDays - 1).coerceAtLeast(1).toFloat()
                                    selectedPointIndex = ((change.position.x / spacing) + 0.5f).toInt().coerceIn(0, selectedDays - 1)
                                }
                            )
                        }
                        .pointerInput(points, selectedDays) {
                            detectTapGestures { offset ->
                                val width = size.width
                                val spacing = width / (selectedDays - 1).coerceAtLeast(1).toFloat()
                                selectedPointIndex = ((offset.x / spacing) + 0.5f).toInt().coerceIn(0, selectedDays - 1)
                            }
                        }
                ) {
                    val width = size.width
                    val height = size.height
                    val spacing = width / (selectedDays - 1).coerceAtLeast(1).toFloat()

                    // 7. Y-Axis and Horizontal Guide Lines
                    val strokeColor = if (isDark) Color(0xFF232D42) else Color(0xFFE2E8F0)
                    drawLine(strokeColor, Offset(0f, 0f), Offset(width, 0f), strokeWidth = 1.dp.toPx())
                    drawLine(strokeColor, Offset(0f, height / 2f), Offset(width, height / 2f), strokeWidth = 1.dp.toPx())
                    drawLine(strokeColor, Offset(0f, height), Offset(width, height), strokeWidth = 1.dp.toPx())

                    // 8. Zero-Baseline Reference Marker (crosses if minVal < 0 && maxVal > 0)
                    if (minVal < 0.0 && maxVal > 0.0) {
                        val zeroY = height - (((0.0 - minVal) / range) * height).toFloat()
                        drawLine(
                            color = Color(0xFFFF9800).copy(alpha = 0.5f),
                            start = Offset(0f, zeroY),
                            end = Offset(width, zeroY),
                            strokeWidth = 1.5.dp.toPx(),
                            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                    }

                    // Compute coordinates for bezier curve
                    val coordinates = points.mapIndexed { idx, value ->
                        val x = idx * spacing
                        val y = height - (((value - minVal) / range) * height).toFloat()
                        Offset(x, y)
                    }

                    // 9. Selected Projection Guidelines and Pulsing Indicator Base
                    selectedPointIndex?.let { idx ->
                        if (idx in coordinates.indices) {
                            val cx = coordinates[idx].x
                            val cy = coordinates[idx].y
                            
                            // Vertical dotted guide
                            drawLine(
                                color = themeColor.copy(alpha = 0.4f),
                                start = Offset(cx, 0f),
                                end = Offset(cx, height),
                                strokeWidth = 1.5.dp.toPx(),
                                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                            )

                            // Horizontal dotted guide to Y axis
                            drawLine(
                                color = themeColor.copy(alpha = 0.25f),
                                start = Offset(0f, cy),
                                end = Offset(width, cy),
                                strokeWidth = 1.dp.toPx(),
                                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                            )
                        }
                    }

                    val currentWidth = width * animatedProgress.value
                    clipRect(right = currentWidth) {

                        // 10. Bezier Gradient Glowing Fill Area
                        if (coordinates.size >= 2) {
                            val fillPath = androidx.compose.ui.graphics.Path().apply {
                                moveTo(coordinates[0].x, height)
                                lineTo(coordinates[0].x, coordinates[0].y)
                                for (i in 0 until coordinates.size - 1) {
                                    val p0 = coordinates[i]
                                    val p1 = coordinates[i + 1]
                                    val cpX1 = p0.x + (p1.x - p0.x) / 2f
                                    val cpY1 = p0.y
                                    val cpX2 = p0.x + (p1.x - p0.x) / 2f
                                    val cpY2 = p1.y
                                    cubicTo(cpX1, cpY1, cpX2, cpY2, p1.x, p1.y)
                                }
                                lineTo(coordinates.last().x, height)
                                close()
                            }
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(themeColor.copy(alpha = 0.35f), Color.Transparent)
                                )
                            )

                            // 11. Dual-Tone Gradient Stroke Line (smooth curves)
                            val strokePath = androidx.compose.ui.graphics.Path().apply {
                                moveTo(coordinates[0].x, coordinates[0].y)
                                for (i in 0 until coordinates.size - 1) {
                                    val p0 = coordinates[i]
                                    val p1 = coordinates[i + 1]
                                    val cpX1 = p0.x + (p1.x - p0.x) / 2f
                                    val cpY1 = p0.y
                                    val cpX2 = p0.x + (p1.x - p0.x) / 2f
                                    val cpY2 = p1.y
                                    cubicTo(cpX1, cpY1, cpX2, cpY2, p1.x, p1.y)
                                }
                            }
                            drawPath(
                                path = strokePath,
                                brush = Brush.horizontalGradient(
                                    colors = listOf(themeColor, themeColor.copy(alpha = 0.7f))
                                ),
                                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                            )
                        } else {
                            // Fallback segment drawing
                            for (i in 0 until coordinates.size - 1) {
                                drawLine(
                                    color = themeColor,
                                    start = coordinates[i],
                                    end = coordinates[i + 1],
                                    strokeWidth = 3.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                            }
                        }

                        // Draw Endpoint dots
                        for (i in coordinates.indices) {
                            val coord = coordinates[i]
                            val isSelected = selectedPointIndex == i
                            if (isSelected) {
                                // Pulsing/Glow effect around chosen point
                                drawCircle(
                                    color = themeColor.copy(alpha = 0.2f),
                                    radius = 14.dp.toPx(),
                                    center = coord
                                )
                                drawCircle(
                                    color = themeColor,
                                    radius = 6.dp.toPx(),
                                    center = coord
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 3.dp.toPx(),
                                    center = coord
                                )
                            } else {
                                // Tiny clean endpoints
                                drawCircle(
                                    color = themeColor,
                                    radius = 3.dp.toPx(),
                                    center = coord
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 1.5.dp.toPx(),
                                    center = coord
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (idioma == "PT") "Há $selectedDays dias" else "$selectedDays days ago",
                    fontSize = 10.sp,
                    color = if (isDark) Color.LightGray.copy(alpha = 0.5f) else Color(0xFF64748B)
                )
                Text(
                    text = if (idioma == "PT") "Hoje" else "Today",
                    fontSize = 10.sp,
                    color = themeColor,
                    fontWeight = FontWeight.Bold
                )
            }

            // 12. Animated Custom Tooltip with Secondary Currency Support and Close CTA
            AnimatedVisibility(
                visible = selectedPointIndex != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                selectedPointIndex?.let { idx ->
                    if (idx in points.indices) {
                        val balanceValue = points[idx]
                        val convertedVal = viewModel.currencyService.convertFromMZN(balanceValue, settings.moedaPadrao)
                        
                        val dayText = remember(idx, selectedDays, idioma) {
                            val cal = java.util.Calendar.getInstance()
                            val daysAgo = (selectedDays - 1) - idx
                            cal.add(java.util.Calendar.DAY_OF_YEAR, -daysAgo)
                            val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
                            val formattedDate = sdf.format(cal.time)
                            when (idx) {
                                selectedDays - 1 -> if (idioma == "PT") "Hoje ($formattedDate)" else "Today ($formattedDate)"
                                selectedDays - 2 -> if (idioma == "PT") "Ontem ($formattedDate)" else "Yesterday ($formattedDate)"
                                else -> formattedDate
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isDark) Color(0xFF1E2638) else Color(0xFFE2E8F0),
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = dayText,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = themeColor
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${String.format("%,.2f", convertedVal)} ${settings.moedaPadrao}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (balanceValue >= 0) Color(0xFF4CAF50) else Color(0xFFF44336)
                                )
                                // Render secondary currency conversion if configured
                                if (secondaryCurrency.isNotEmpty() && secondaryCurrency != settings.moedaPadrao) {
                                    val secondaryVal = viewModel.currencyService.convertFromMZN(balanceValue, secondaryCurrency)
                                    Text(
                                        text = "≈ ${String.format("%,.2f", secondaryVal)} $secondaryCurrency",
                                        fontSize = 11.sp,
                                        color = if (isDark) Color.LightGray.copy(alpha = 0.6f) else Color(0xFF64748B)
                                    )
                                }
                            }

                            // Manual Dismiss Icon Button (Fechar / Close CTA)
                            IconButton(
                                onClick = { selectedPointIndex = null },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Fechar info",
                                    tint = if (isDark) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
