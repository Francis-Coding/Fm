package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.NotificationEntity
import com.example.data.model.UserSettings
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    viewModel: MainViewModel,
    settings: UserSettings,
    onBack: () -> Unit,
    onNavigateToEntity: (entityType: String, entityId: Int) -> Unit
) {
    val isDark = settings.tema == "dark"
    val themeColor = try {
        Color(android.graphics.Color.parseColor(settings.corPrimaria.ifEmpty { "#6D4AFF" }))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }
    
    val notifications by viewModel.notifications.collectAsStateWithLifecycle(initialValue = emptyList())
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Bar
        Surface(
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 2.dp,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (settings.idioma == "PT") "Notificações" else "Notifications",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                if (notifications.any { it.status == "UNREAD" }) {
                    TextButton(onClick = { viewModel.markAllNotificationsAsRead() }) {
                        Text(
                            text = if (settings.idioma == "PT") "Marcar todas como lidas" else "Mark all as read",
                            color = themeColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
        
        if (notifications.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.NotificationsOff,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = if (isDark) Color.White.copy(alpha = 0.3f) else Color.Black.copy(alpha = 0.3f)
                    )
                    Text(
                        text = if (settings.idioma == "PT") "Nenhuma notificação" else "No notifications",
                        fontSize = 16.sp,
                        color = if (isDark) Color.White.copy(alpha = 0.5f) else Color.Black.copy(alpha = 0.5f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(notifications, key = { it.notificationId }) { notification ->
                    NotificationItem(
                        notification = notification,
                        settings = settings,
                        themeColor = themeColor,
                        onClick = {
                            viewModel.markNotificationAsRead(notification.notificationId)
                            onNavigateToEntity(notification.entityType, notification.entityId)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun NotificationItem(
    notification: NotificationEntity,
    settings: UserSettings,
    themeColor: Color,
    onClick: () -> Unit
) {
    val isDark = settings.tema == "dark"
    val isUnread = notification.status == "UNREAD"
    val sdf = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    val dateStr = sdf.format(java.util.Date(notification.createdAt))
    
    val icon = when (notification.type) {
        "LOAN_OVERDUE" -> Icons.Rounded.MoneyOff
        "PURCHASE_REGISTERED" -> Icons.Rounded.ShoppingCart
        "GOAL_OVERDUE" -> Icons.Rounded.TrackChanges
        "INSUFFICIENT_BALANCE" -> Icons.Rounded.Warning
        "RECURRING_PAYMENT" -> Icons.Rounded.Autorenew
        else -> Icons.Rounded.Notifications
    }
    
    val color = when (notification.type) {
        "LOAN_OVERDUE", "INSUFFICIENT_BALANCE" -> Color(0xFFE53935)
        "GOAL_OVERDUE" -> Color(0xFFFB8C00)
        "PURCHASE_REGISTERED", "RECURRING_PAYMENT" -> themeColor
        else -> themeColor
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) {
                if (isUnread) Color(0xFF2C3E50) else Color(0xFF1E293B)
            } else {
                if (isUnread) Color(0xFFF0F4F8) else Color.White
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isUnread) 4.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
                if (isUnread) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(Color.Red)
                            .padding(2.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize().clip(CircleShape).background(Color.Red))
                    }
                }
            }
            
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = notification.title,
                        fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 16.sp,
                        color = if (isDark) Color.White else Color(0xFF1E293B),
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = dateStr,
                        fontSize = 12.sp,
                        color = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF64748B)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = notification.message,
                    fontSize = 14.sp,
                    color = if (isDark) Color.White.copy(alpha = 0.7f) else Color(0xFF475569),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (notification.status == "RESOLVED") {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (settings.idioma == "PT") "Resolvida" else "Resolved",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4CAF50)
                    )
                }
            }
        }
    }
}
