package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import com.example.ui.MainAppContainer
import com.example.ui.MainViewModel
import com.example.ui.theme.FinancasMTheme

class MainActivity : FragmentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
            viewModel.toggleNotifications(granted)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Read theme settings synchronously from theme_prefs to prevent light-mode startup flicker
        val prefs = getSharedPreferences("theme_prefs", MODE_PRIVATE)
        val savedTema = prefs.getString("tema", "dark")
        val savedColor = prefs.getString("cor_primaria", "#6D4AFF") ?: "#6D4AFF"

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            val permission = android.Manifest.permission.POST_NOTIFICATIONS
            if (checkSelfPermission(permission) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(permission), 101)
            }
        }

        setContent {
            val settings by viewModel.userSettings.collectAsState(initial = null)
            
            val isDarkTheme = if (settings == null) {
                savedTema == "dark"
            } else {
                settings?.tema == "dark"
            }
            
            val primaryColorHex = if (settings == null) {
                savedColor
            } else {
                settings?.corPrimaria ?: "#6D4AFF"
            }

            FinancasMTheme(
                darkTheme = isDarkTheme,
                primaryHexColor = primaryColorHex
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainAppContainer(viewModel = viewModel)
                }
            }
        }
    }
}
