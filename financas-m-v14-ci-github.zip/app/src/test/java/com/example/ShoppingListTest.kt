package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.AppDatabase
import com.example.data.model.ShoppingCategory
import com.example.data.model.ShoppingItem
import com.example.data.model.ShoppingList
import com.example.data.model.ShoppingPriceHistory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ShoppingListTest {
    private lateinit var db: AppDatabase

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun testBasicShoppingItemCrud() = runBlocking {
        val itemDao = db.shoppingItemDao()
        
        val item = ShoppingItem(
            nome = "Arroz",
            preco = 65.0,
            quantidade = 2.0,
            unidade = "kg",
            prioridade = "ALTA"
        )
        
        val id = itemDao.insertShoppingItem(item)
        assertTrue(id > 0)
        
        val items = itemDao.getShoppingItemsForList(1).first()
        assertEquals(1, items.size)
        assertEquals("Arroz", items[0].nome)
        assertEquals(65.0, items[0].preco, 0.0)
        assertEquals(2.0, items[0].quantidade, 0.0)
    }

    @Test
    fun testCategoryOrdering() = runBlocking {
        val categoryDao = db.shoppingCategoryDao()
        
        val cat1 = ShoppingCategory(nome = "Limpeza", ordem = 2)
        val cat2 = ShoppingCategory(nome = "Hortifruti", ordem = 1)
        
        categoryDao.insertCategory(cat1)
        categoryDao.insertCategory(cat2)
        
        val categories = categoryDao.getAllCategories().first()
        assertEquals(2, categories.size)
        // Check order (since query orders by ordem ASC)
        assertEquals("Hortifruti", categories[0].nome)
        assertEquals("Limpeza", categories[1].nome)
        
        // Reorder cat1 to have higher priority
        categoryDao.updateCategoryOrder(categories[0].id, 3) // move Hortifruti to 3
        val updatedCategories = categoryDao.getAllCategories().first()
        assertEquals("Limpeza", updatedCategories[0].nome)
    }

    @Test
    fun testPriceHistoryAverages() = runBlocking {
        val historyDao = db.shoppingPriceHistoryDao()
        
        historyDao.insertPriceHistory(ShoppingPriceHistory(nomeProduto = "Tomate", preco = 40.0))
        historyDao.insertPriceHistory(ShoppingPriceHistory(nomeProduto = "Tomate", preco = 50.0))
        historyDao.insertPriceHistory(ShoppingPriceHistory(nomeProduto = "Tomate", preco = 60.0))
        
        val avg = historyDao.getAveragePriceForProduct("Tomate")
        assertNotNull(avg)
        assertEquals(50.0, avg!!, 0.0)
    }

    @Test
    fun testTemplateAndDuplication() = runBlocking {
        val listDao = db.shoppingListDao()
        val itemDao = db.shoppingItemDao()
        
        // Create template list
        val listId = listDao.insertList(ShoppingList(nome = "Modelo de Sábado", isTemplate = true))
        
        // Insert items
        itemDao.insertShoppingItem(ShoppingItem(listaId = listId.toInt(), nome = "Cebola", preco = 30.0))
        itemDao.insertShoppingItem(ShoppingItem(listaId = listId.toInt(), nome = "Batata", preco = 50.0))
        
        // Duplicate list
        val copyId = listDao.insertList(ShoppingList(nome = "Lista Real 01/07", isTemplate = false, originalListId = listId.toInt()))
        
        // Fetch original items and copy
        val originalItems = itemDao.getShoppingItemsForList(listId.toInt()).first()
        assertEquals(2, originalItems.size)
        
        originalItems.forEach { item ->
            itemDao.insertShoppingItem(item.copy(id = 0, listaId = copyId.toInt(), pago = false))
        }
        
        val copiedItems = itemDao.getShoppingItemsForList(copyId.toInt()).first()
        assertEquals(2, copiedItems.size)
        assertEquals("Batata", copiedItems[0].nome) // Sorted alphabetically by default query order
        assertEquals("Cebola", copiedItems[1].nome)
    }
}
