package com.example

import com.example.data.model.FinancialGoal
import com.example.data.model.Wallet
import com.example.domain.usecases.CalculateGoalProgressUseCase
import com.example.domain.usecases.FinancialDomainDelegates
import com.example.domain.usecases.TransactionValidationResult
import com.example.domain.usecases.ValidateTransactionUseCase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialDomainDelegatesTest {

    @Test
    fun testGoalProgressCalculation() {
        val useCase = CalculateGoalProgressUseCase()
        val targetDateMs = System.currentTimeMillis() + (10 * 24 * 60 * 60 * 1000L) // 10 days
        val result = useCase.execute(
            valorAtual = 500.0,
            valorObjetivo = 1000.0,
            targetDateMs = targetDateMs
        )

        assertEquals(50.0, result.percentage, 0.01)
        assertEquals(500.0, result.remainingAmount, 0.01)
        assertTrue(!result.isCompleted)
        assertTrue(result.dailySavingNeeded > 0)
    }

    @Test
    fun testTransactionValidation() {
        val useCase = ValidateTransactionUseCase()

        val invalidResult = useCase.execute(
            amount = 0.0,
            categoryName = "Alimentação",
            walletBalance = 100.0,
            isExpense = true
        )
        assertTrue(invalidResult is TransactionValidationResult.Invalid)

        val validResult = useCase.execute(
            amount = 50.0,
            categoryName = "Alimentação",
            walletBalance = 100.0,
            isExpense = true
        )
        assertTrue(validResult is TransactionValidationResult.Valid)
    }

    @Test
    fun testNetBalanceCalculation() {
        val wallets = listOf(
            Wallet(id = 1, nome = "Conta Corrente", saldoInicial = 1500.0, saldoAtual = 1500.0, cor = "#4CAF50", icone = "account_balance", ordem = 0),
            Wallet(id = 2, nome = "Carteira", saldoInicial = 300.0, saldoAtual = 300.0, cor = "#2196F3", icone = "payments", ordem = 1)
        )

        val totalNet = FinancialDomainDelegates.calculateNetBalance(wallets)
        assertEquals(1800.0, totalNet, 0.01)
    }
}
