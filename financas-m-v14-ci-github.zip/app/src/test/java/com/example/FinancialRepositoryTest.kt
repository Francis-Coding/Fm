package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.AppDatabase
import com.example.data.model.Category
import com.example.data.model.Wallet
import com.example.data.repository.FinancialRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FinancialRepositoryTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var repository: FinancialRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        AppDatabase.INSTANCE = db
        repository = FinancialRepository(context)
    }

    @After
    fun tearDown() {
        db.close()
        AppDatabase.INSTANCE = null
    }

    @Test
    fun testWalletOrderingAndReordering() = runBlocking {
        // Insert some wallets
        val walletA = Wallet(id = 1, nome = "Conta A", saldoInicial = 100.0, saldoAtual = 100.0, icone = "💰", cor = "#123456", ordem = 0)
        val walletB = Wallet(id = 2, nome = "Conta B", saldoInicial = 200.0, saldoAtual = 200.0, icone = "💳", cor = "#654321", ordem = 1)
        val walletC = Wallet(id = 3, nome = "Conta C", saldoInicial = 300.0, saldoAtual = 300.0, icone = "📱", cor = "#abcdef", ordem = 2)

        db.walletDao().insertWallet(walletA)
        db.walletDao().insertWallet(walletB)
        db.walletDao().insertWallet(walletC)

        // Retrieve wallets and check ordering (defaults to 0, 1, 2)
        var wallets = db.walletDao().getAllWalletsDirect()
        assertEquals(3, wallets.size)
        assertEquals("Conta A", wallets[0].nome)
        assertEquals("Conta B", wallets[1].nome)
        assertEquals("Conta C", wallets[2].nome)

        // Reorder (swap Wallet A with Wallet B by swapping their order values)
        db.walletDao().updateWallet(walletA.copy(ordem = 1))
        db.walletDao().updateWallet(walletB.copy(ordem = 0))

        wallets = db.walletDao().getAllWalletsDirect()
        assertEquals("Conta B", wallets[0].nome)
        assertEquals("Conta A", wallets[1].nome)
        assertEquals("Conta C", wallets[2].nome)
    }

    @Test
    fun testDailyClosureAndConsolidatedReconciliation() = runBlocking {
        // Insert wallets
        val wallet1 = Wallet(id = 1, nome = "Principal", saldoInicial = 500.0, saldoAtual = 500.0, icone = "💰", cor = "#1A73E8", ordem = 0)
        val wallet2 = Wallet(id = 2, nome = "E-Mola", saldoInicial = 300.0, saldoAtual = 300.0, icone = "💸", cor = "#34A853", ordem = 1)
        db.walletDao().insertWallet(wallet1)
        db.walletDao().insertWallet(wallet2)

        // Let's create an "Ajuste" category
        val category = Category(id = 1, nome = "Ajuste", icone = "⚖️", cor = "#607D8B", tipo = "Injecao")
        db.categoryDao().insertCategory(category)

        // Test applyConsolidatedReconciliation
        // We set Principal to 520 and E-Mola to 290
        val actualBalances = mapOf(1 to 520.0, 2 to 290.0)
        repository.applyConsolidatedReconciliation(actualBalances)

        // Retrieve and check that balances match EXACTLY what was entered (replaced previous values with actual values)
        val updatedWallet1 = db.walletDao().getWalletById(1)
        val updatedWallet2 = db.walletDao().getWalletById(2)
        assertNotNull(updatedWallet1)
        assertNotNull(updatedWallet2)
        assertEquals(520.0, updatedWallet1!!.saldoAtual, 0.001)
        assertEquals(290.0, updatedWallet2!!.saldoAtual, 0.001)

        // Check that adjustment transactions were created for the differences per wallet
        val transactions = db.transactionDao().getAllTransactionsFlow().first()
        assertEquals(2, transactions.size)
        assertEquals(20.0, transactions.find { it.carteiraOrigemId == 1 }!!.valor, 0.001)
        assertEquals(10.0, transactions.find { it.carteiraOrigemId == 2 }!!.valor, 0.001)
    }

    @Test
    fun testScheduledTransferExecution() = runBlocking {
        val srcWallet = Wallet(id = 1, nome = "Principal", saldoInicial = 1000.0, saldoAtual = 1000.0, icone = "💰", cor = "#1A73E8")
        val destWallet = Wallet(id = 2, nome = "Poupança", saldoInicial = 500.0, saldoAtual = 500.0, icone = "🏦", cor = "#34A853")
        db.walletDao().insertWallet(srcWallet)
        db.walletDao().insertWallet(destWallet)

        val category = Category(id = 1, nome = "Transferência", icone = "🔄", cor = "#1A73E8", tipo = "Transferencia")
        db.categoryDao().insertCategory(category)

        val transfer = com.example.data.model.ScheduledTransfer(
            id = 1,
            carteiraOrigemId = 1,
            carteiraDestinoId = 2,
            valor = 200.0,
            dataHora = System.currentTimeMillis() - 1000,
            executada = false
        )
        repository.addScheduledTransfer(transfer)

        repository.processPendingScheduledTransfers()

        val updatedSrc = db.walletDao().getWalletById(1)
        val updatedDest = db.walletDao().getWalletById(2)
        assertNotNull(updatedSrc)
        assertNotNull(updatedDest)
        assertEquals(800.0, updatedSrc!!.saldoAtual, 0.001)
        assertEquals(700.0, updatedDest!!.saldoAtual, 0.001)

        val transfers = db.scheduledTransferDao().getAllScheduledTransfersDirect()
        assertEquals(true, transfers.first().executada)
    }

    @Test
    fun testSubscriptionPaymentNow() = runBlocking {
        val wallet = Wallet(id = 1, nome = "Principal", saldoInicial = 500.0, saldoAtual = 500.0, icone = "💰", cor = "#1A73E8")
        db.walletDao().insertWallet(wallet)

        val category = Category(id = 1, nome = "Serviços", icone = "🎬", cor = "#E50914", tipo = "DESPESA")
        db.categoryDao().insertCategory(category)

        val sub = com.example.data.model.Subscription(
            id = 1,
            nome = "Netflix",
            valor = 50.0,
            carteiraId = 1,
            categoriaId = 1,
            ativa = true
        )
        repository.addSubscription(sub)
        repository.paySubscriptionNow(sub)

        val updatedWallet = db.walletDao().getWalletById(1)
        assertEquals(450.0, updatedWallet!!.saldoAtual, 0.001)

        val txs = db.transactionDao().getAllTransactionsFlow().first()
        val subTx = txs.find { it.descricao.contains("Netflix") }
        assertNotNull(subTx)
        assertEquals(50.0, subTx!!.valor, 0.001)
    }
}
