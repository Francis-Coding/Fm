import re

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'r') as f:
    content = f.read()

replacement = """
    val today = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    
    val sevenDaysAgo = today - (6L * 24 * 60 * 60 * 1000)
    val last7DaysTxs = transactions.filter { it.data >= sevenDaysAgo && !it.ajusteCaixa }
    
    val incomeMap = mutableMapOf<String, Double>()
    val expenseMap = mutableMapOf<String, Double>()
    val daysList = mutableListOf<String>()
    
    val cal = Calendar.getInstance()
    cal.timeInMillis = sevenDaysAgo
    for (i in 0..6) {
        val dayStr = SimpleDateFormat("dd", Locale.getDefault()).format(cal.time)
        daysList.add(dayStr)
        val dayStart = cal.timeInMillis
        val dayEnd = dayStart + (24L * 60 * 60 * 1000) - 1
        
        val dayTxs = last7DaysTxs.filter { it.data in dayStart..dayEnd }
        incomeMap[dayStr] = dayTxs.filter { it.tipo == "Receita" }.sumOf { it.valor }
        expenseMap[dayStr] = dayTxs.filter { it.tipo == "Despesa" }.sumOf { it.valor }
        
        cal.add(Calendar.DAY_OF_YEAR, 1)
    }
    
    val maxIncome = incomeMap.values.maxOrNull() ?: 0.0
    val maxExpense = expenseMap.values.maxOrNull() ?: 0.0
    val maxVal = maxOf(maxIncome, maxExpense, 1.0)
    
    val incomeRatios = daysList.map { (incomeMap[it] ?: 0.0) / maxVal }.map { it.toFloat() }
    val expenseRatios = daysList.map { -(expenseMap[it] ?: 0.0) / maxVal }.map { it.toFloat() }
"""

sig_old = 'fun CashFlowCard(idioma: String)'
sig_new = 'fun CashFlowCard(idioma: String, transactions: List<Transaction>)'
content = content.replace(sig_old, sig_new)
content = content.replace('CashFlowCard(idioma)', 'CashFlowCard(idioma, transactions)')

content = content.replace('fun CashFlowCard(idioma: String, transactions: List<Transaction>) {', 'fun CashFlowCard(idioma: String, transactions: List<Transaction>) {' + replacement)

# Replace the hardcoded bars data
chart_data_old = """                    // Bars data
                    val income = listOf(0.8f, 0.7f, 0.1f, 0f, 0.5f, 0.55f, 0.6f)
                    val expenses = listOf(0f, 0f, 0f, -0.2f, 0f, 0f, 0f)
                    val days = listOf("23", "24", "25", "26", "27", "28", "29")"""
chart_data_new = """                    // Bars data
                    val income = incomeRatios
                    val expenses = expenseRatios
                    val days = daysList"""
content = content.replace(chart_data_old, chart_data_new)

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'w') as f:
    f.write(content)
