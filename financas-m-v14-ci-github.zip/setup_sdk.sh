#!/bin/bash
# Script para configurar automaticamente o Android SDK no Google Cloud Shell
set -e

# Cores para o terminal
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== 🚀 CONFIGURANDO ANDROID SDK NO GOOGLE CLOUD SHELL ===${NC}"

# === DETECÇÃO AUTOMÁTICA DE DIRETÓRIO ===
if [ ! -f "settings.gradle.kts" ] && [ ! -f "build.gradle.kts" ]; then
    echo -e "${YELLOW}🔍 Você não está na raiz do projeto. Buscando pasta correta...${NC}"
    CANDIDATE_DIR=$(find . -name "settings.gradle.kts" -maxdepth 3 -print -quit | xargs dirname 2>/dev/null)
    if [ -n "$CANDIDATE_DIR" ] && [ "$CANDIDATE_DIR" != "." ]; then
        echo -e "${GREEN}📂 Projeto encontrado em: $CANDIDATE_DIR. Entrando na pasta...${NC}"
        cd "$CANDIDATE_DIR"
    else
        echo -e "${RED}❌ ERRO: Não foi possível localizar os arquivos do projeto (settings.gradle.kts/build.gradle.kts).${NC}"
        echo -e "Por favor, entre no diretório correto do projeto usando o comando: cd nome-da-pasta"
        exit 1
    fi
fi

# === VALIDAÇÃO E CONFIGURAÇÃO DA VERSÃO DO JAVA (Mínimo Java 17 para Gradle 9+) ===
echo -e "${YELLOW}☕ Verificando versão do Java...${NC}"
JAVA_VM_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f1)
if [ "$JAVA_VM_VERSION" = "1" ]; then
    JAVA_VM_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f2)
fi

if [ -z "$JAVA_VM_VERSION" ] || [ "$JAVA_VM_VERSION" -lt 17 ] 2>/dev/null; then
    echo -e "${YELLOW}⚠️ Java atual ($JAVA_VM_VERSION) é menor que 17. Procurando JDK 17 ou 21 no Cloud Shell...${NC}"
    FOUND_JDK=""
    for candidate in /usr/lib/jvm/java-17-openjdk-amd64 /usr/lib/jvm/java-21-openjdk-amd64 /usr/lib/jvm/java-17-openjdk /usr/lib/jvm/java-21-openjdk /usr/lib/jvm/jdk-17* /usr/lib/jvm/jdk-21*; do
        if [ -d "$candidate" ]; then
            FOUND_JDK="$candidate"
            break
        fi
    done
    
    if [ -n "$FOUND_JDK" ]; then
        export JAVA_HOME="$FOUND_JDK"
        export PATH="$JAVA_HOME/bin:$PATH"
        echo -e "${GREEN}✅ JAVA_HOME configurado temporariamente para: $JAVA_HOME${NC}"
    else
        echo -e "${RED}❌ ERRO: Gradle requer Java 17 ou superior, mas nenhum JDK compatível foi encontrado em /usr/lib/jvm/.${NC}"
        echo -e "Por favor, tente instalar rodando: sudo apt-get update && sudo apt-get install -y openjdk-17-jdk"
    fi
fi
echo -e "${GREEN}☕ Usando Java: $(java -version 2>&1 | head -n 1)${NC}"

# 1. Definir caminhos para o SDK no diretório home (persistente entre sessões do Cloud Shell)
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

# Criar pasta para o SDK
mkdir -p "$ANDROID_HOME"

# 2. Baixar as ferramentas de linha de comando do Android (Command Line Tools)
if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    echo -e "${YELLOW}📥 Baixando Android Command Line Tools (esta etapa pode levar alguns segundos)...${NC}"
    wget -q --show-progress https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdline-tools.zip
    
    echo -e "${YELLOW}📦 Descompactando ferramentas...${NC}"
    mkdir -p "$ANDROID_HOME/cmdline-tools-temp"
    unzip -q cmdline-tools.zip -d "$ANDROID_HOME/cmdline-tools-temp"
    
    # O zip do Google descompacta em uma pasta chamada 'cmdline-tools'.
    # O sdkmanager exige a estrutura exata: cmdline-tools/latest/...
    mkdir -p "$ANDROID_HOME/cmdline-tools/latest"
    mv "$ANDROID_HOME/cmdline-tools-temp/cmdline-tools/"* "$ANDROID_HOME/cmdline-tools/latest/"
    
    # Limpar arquivos temporários
    rm -rf cmdline-tools.zip "$ANDROID_HOME/cmdline-tools-temp"
    echo -e "${GREEN}✅ Command Line Tools instalados com sucesso!${NC}"
else
    echo -e "${GREEN}✅ Command Line Tools já instalados.${NC}"
fi

# 3. Aceitar as Licenças do Android (O passo que costuma falhar!)
echo -e "${YELLOW}📝 Aceitando licenças do Android SDK...${NC}"
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null

# 4. Instalar as dependências de plataforma e build correspondentes ao projeto (Android 36)
echo -e "${YELLOW}⚙️ Instalando Platform-Tools, SDK Platform 36 e Build-Tools 36.0.0...${NC}"
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-36" "build-tools;36.0.0" > /dev/null

# 5. Criar/Atualizar o arquivo local.properties apontando para o SDK recém-configurado
echo -e "${YELLOW}✍️ Configurando local.properties...${NC}"
echo "sdk.dir=$ANDROID_HOME" > local.properties

# 5.5 Verificar integridade do gradle-wrapper.jar e baixar se estiver corrompido
echo -e "${YELLOW}🔍 Verificando integridade do gradle-wrapper.jar...${NC}"
mkdir -p gradle/wrapper
if [ ! -f gradle/wrapper/gradle-wrapper.jar ] || ! unzip -t gradle/wrapper/gradle-wrapper.jar >/dev/null 2>&1; then
    echo -e "${YELLOW}⚠️ gradle-wrapper.jar corrompido ou ausente. Baixando uma cópia limpa...${NC}"
    wget -q --show-progress "https://github.com/gradle/gradle/raw/v9.3.1/gradle/wrapper/gradle-wrapper.jar" -O gradle/wrapper/gradle-wrapper.jar || \
    curl -L -s "https://github.com/gradle/gradle/raw/v9.3.1/gradle/wrapper/gradle-wrapper.jar" -o gradle/wrapper/gradle-wrapper.jar
    echo -e "${GREEN}✅ gradle-wrapper.jar recuperado com sucesso!${NC}"
else
    echo -e "${GREEN}✅ gradle-wrapper.jar íntegro e pronto para uso.${NC}"
fi

# 5.6 Restaurar ou gerar o arquivo debug.keystore de assinatura
echo -e "${YELLOW}🔑 Verificando keystore de assinatura...${NC}"
if [ ! -f debug.keystore ] && [ -f debug.keystore.base64 ]; then
    echo -e "${YELLOW}📦 Decodificando debug.keystore de debug.keystore.base64...${NC}"
    base64 --decode debug.keystore.base64 > debug.keystore 2>/dev/null || \
    base64 -d debug.keystore.base64 > debug.keystore 2>/dev/null || \
    openssl base64 -d -in debug.keystore.base64 -out debug.keystore 2>/dev/null
    echo -e "${GREEN}✅ debug.keystore decodificado com sucesso!${NC}"
elif [ -f debug.keystore ]; then
    echo -e "${GREEN}✅ debug.keystore já está presente.${NC}"
else
    echo -e "${YELLOW}🔑 debug.keystore ausente. Gerando uma nova chave de debug local...${NC}"
    keytool -genkey -v -keystore debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US" > /dev/null 2>&1 || true
    if [ -f debug.keystore ]; then
        echo -e "${GREEN}✅ debug.keystore gerado localmente com sucesso!${NC}"
    else
        echo -e "${YELLOW}⚠️ Aviso: Não foi possível gerar debug.keystore local. O Gradle tentará usar a chave padrão do usuário ou dinâmica.${NC}"
    fi
fi

# Corrigir permissões e fins de linha do gradlew
echo -e "${YELLOW}🔒 Ajustando permissões e quebras de linha do Gradle Wrapper...${NC}"
sed -i 's/\r$//' gradlew
chmod +x gradlew

echo -e "=== 🎉 CONFIGURAÇÃO DO SDK CONCLUÍDA! ==="
echo "Para compilar o APK agora, execute os seguintes comandos no seu Cloud Shell:"
echo ""
echo "export ANDROID_HOME=\$HOME/android-sdk"
echo "export PATH=\$ANDROID_HOME/platform-tools:\$ANDROID_HOME/cmdline-tools/latest/bin:\$PATH"
echo "./gradlew assembleDebug"
echo ""
echo "Isso gerará o APK em: app/build/outputs/apk/debug/app-debug.apk"
