import sys

kotlin_code = """package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Category
import com.example.data.model.FinancialGoal
import com.example.data.model.Subscription
import com.example.data.model.Transaction
import com.example.data.model.Wallet
import com.example.domain.usecases.GroupedLoan
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FutureFlowCalendarDialog(
    idioma: String,
    currentBalance: Double,
    rawTransactions: List<Transaction>,
    groupedLoans: List<GroupedLoan>,
    goals: List<FinancialGoal>,
    viewModel: MainViewModel? = null,
    wallets: List<Wallet> = emptyList(),
    categories: List<Category> = emptyList(),
    subscriptions: List<Subscription> = emptyList(),
    onDismiss: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val formatter = remember { java.text.DecimalFormat("#,##0.00") }
    val isSystemDark = isSystemInDarkTheme()
    val bgColor = if (isSystemDark) Color(0xFF0F172A) else Color(0xFFF8FAFC)
    val surfaceColor = if (isSystemDark) Color(0xFF1E293B) else Color(0xFFFFFFFF)
    val textColor = if (isSystemDark) Color.White else Color(0xFF0F172A)
    val textMuted = if (isSystemDark) Color(0xFF94A3B8) else Color(0xFF64748B)

    var selectedWalletId by remember { mutableStateOf<Int?>(null) }
    var selectedFilter by remember { mutableStateOf("Hoje") } // Hoje, 30 dias, 90 dias, Ano
    var viewedDate by remember { mutableStateOf(Calendar.getInstance()) }
    var selectedDate by remember { mutableStateOf(Calendar.getInstance()) }
    var isWalletMenuOpen by remember { mutableStateOf(false) }

    val subscriptionsState = viewModel?.subscriptions?.collectAsStateWithLifecycle(initialValue = subscriptions)
    val activeSubscriptions = remember(subscriptionsState?.value, subscriptions) {
        (subscriptionsState?.value ?: subscriptions).filter { it.ativa }
    }

    val todayCal = remember { Calendar.getInstance() }
    
    // Filtering Logic
    val filteredTransactions = remember(rawTransactions, selectedWalletId) {
        if (selectedWalletId == null) rawTransactions else rawTransactions.filter { it.walletId == selectedWalletId }
    }
    
    // Pre-calculate projection balances
    val projectionStartBalance = remember(selectedWalletId, currentBalance, wallets) {
        if (selectedWalletId == null) currentBalance else wallets.find { it.id == selectedWalletId }?.saldoAtual ?: 0.0
    }

    fun getDailyEvents(year: Int, month: Int, day: Int): List<Triple<String, Double, String>> {
        val events = mutableListOf<Triple<String, Double, String>>() 
        val dayCal = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0) }

        // Non-recurring
        filteredTransactions.filter { !it.recorrente }.forEach { t ->
            val tCal = Calendar.getInstance().apply { timeInMillis = t.data }
            if (tCal.get(Calendar.YEAR) == year && tCal.get(Calendar.MONTH) == month && tCal.get(Calendar.DAY_OF_MONTH) == day) {
                events.add(Triple(t.descricao, if (t.tipo == "Despesa") -t.valor else t.valor, if (t.tipo == "Despesa") "Saída" else "Entrada"))
            }
        }
        // Recurring
        filteredTransactions.filter { it.recorrente }.forEach { t ->
            val tCal = Calendar.getInstance().apply { timeInMillis = t.data }
            // Basic recurrence logic: matches day of month
            if (tCal.get(Calendar.DAY_OF_MONTH) == day && dayCal.timeInMillis >= tCal.timeInMillis) {
                events.add(Triple(t.descricao, if (t.tipo == "Despesa") -t.valor else t.valor, "Recorrente"))
            }
        }
        activeSubscriptions.forEach { sub ->
            if (sub.diaCobranca == day) {
                events.add(Triple(sub.nome, -sub.valor, "Recorrente"))
            }
        }
        groupedLoans.forEach { g ->
            g.installments.forEach { inst ->
                val instCal = Calendar.getInstance().apply { timeInMillis = inst.dueDate }
                if (instCal.get(Calendar.YEAR) == year && instCal.get(Calendar.MONTH) == month && instCal.get(Calendar.DAY_OF_MONTH) == day) {
                    events.add(Triple(g.loan.counterparty, -inst.remainingBalance, "Empréstimo"))
                }
            }
        }
        goals.forEach { g ->
            val gCal = Calendar.getInstance().apply { timeInMillis = g.dataLimite }
            if (gCal.get(Calendar.YEAR) == year && gCal.get(Calendar.MONTH) == month && gCal.get(Calendar.DAY_OF_MONTH) == day) {
                events.add(Triple(g.nome, -g.valorTotal, "Meta"))
            }
        }
        return events
    }

    val viewedYear = viewedDate.get(Calendar.YEAR)
    val viewedMonth = viewedDate.get(Calendar.MONTH)
    
    // Range based on selectedFilter
    val periodSummary = remember(selectedFilter, viewedDate, filteredTransactions, activeSubscriptions, groupedLoans, goals) {
        val startCal = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }
        val endCal = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }
        when (selectedFilter) {
            "Hoje" -> { endCal.set(Calendar.DAY_OF_MONTH, endCal.getActualMaximum(Calendar.DAY_OF_MONTH)) }
            "30 dias" -> { endCal.add(Calendar.DAY_OF_MONTH, 30) }
            "90 dias" -> { endCal.add(Calendar.DAY_OF_MONTH, 90) }
            "Ano" -> { 
                startCal.set(Calendar.MONTH, 0); startCal.set(Calendar.DAY_OF_MONTH, 1)
                endCal.set(Calendar.MONTH, 11); endCal.set(Calendar.DAY_OF_MONTH, 31) 
            }
        }
        
        var totRec = 0.0
        var totDes = 0.0
        
        val curr = startCal.clone() as Calendar
        while (!curr.after(endCal)) {
            val evs = getDailyEvents(curr.get(Calendar.YEAR), curr.get(Calendar.MONTH), curr.get(Calendar.DAY_OF_MONTH))
            evs.forEach { ev ->
                if (ev.second > 0) totRec += ev.second
                else totDes += Math.abs(ev.second)
            }
            curr.add(Calendar.DAY_OF_MONTH, 1)
        }
        Pair(totRec, totDes)
    }

    val monthEvents = remember(viewedYear, viewedMonth, filteredTransactions, groupedLoans, activeSubscriptions, goals) {
        val maxDays = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }.getActualMaximum(Calendar.DAY_OF_MONTH)
        (1..maxDays).associateWith { d -> getDailyEvents(viewedYear, viewedMonth, d) }
    }
    
    // Month Summary Variables
    var monthReceitas = 0.0
    var monthDespesas = 0.0
    var monthMetas = 0
    monthEvents.values.flatten().forEach { ev ->
        if (ev.second > 0) monthReceitas += ev.second
        else monthDespesas += Math.abs(ev.second)
        if (ev.third == "Meta") monthMetas++
    }
    val monthSaldo = monthReceitas - monthDespesas
    
    // Calculate past balance to add to projection
    val startOfMonthBal = remember(viewedYear, viewedMonth, projectionStartBalance, filteredTransactions) {
        // Simplified: use projectionStartBalance for UI. A robust implementation would calculate from genesis.
        projectionStartBalance
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = bgColor) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                // HEADER
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${viewedMonth + 1} / $viewedYear",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                    }
                    Row {
                        IconButton(onClick = { /* TODO */ }) { Icon(Icons.Rounded.Add, contentDescription = "Add", tint = textColor) }
                        IconButton(onClick = { /* TODO */ }) { Icon(Icons.Rounded.MoreVert, contentDescription = "More", tint = textColor) }
                    }
                }

                // FILTERS
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = surfaceColor,
                            border = BorderStroke(1.dp, textMuted.copy(alpha = 0.2f)),
                            modifier = Modifier.clickable { isWalletMenuOpen = true }
                        ) {
                            Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(16.dp), tint = textColor)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (selectedWalletId == null) "Todas Carteiras" else wallets.find { it.id == selectedWalletId }?.nome ?: "Carteira",
                                    fontSize = 13.sp,
                                    color = textColor,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = textMuted)
                            }
                        }
                        DropdownMenu(expanded = isWalletMenuOpen, onDismissRequest = { isWalletMenuOpen = false }) {
                            DropdownMenuItem(text = { Text("Todas Carteiras") }, onClick = { selectedWalletId = null; isWalletMenuOpen = false })
                            wallets.forEach { w ->
                                DropdownMenuItem(text = { Text(w.nome) }, onClick = { selectedWalletId = w.id; isWalletMenuOpen = false })
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val filters = listOf("Hoje", "30 dias", "90 dias", "Ano")
                        filters.forEach { f ->
                            val isSel = selectedFilter == f
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) surfaceColor else Color.Transparent,
                                border = BorderStroke(1.dp, if (isSel) textMuted.copy(alpha = 0.3f) else Color.Transparent),
                                modifier = Modifier.clickable {
                                    selectedFilter = f
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    if (f == "Hoje") {
                                        viewedDate = Calendar.getInstance()
                                        selectedDate = Calendar.getInstance()
                                    }
                                }
                            ) {
                                Text(
                                    text = f,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    fontSize = 13.sp,
                                    color = if (isSel) textColor else textMuted,
                                    fontWeight = if (isSel) FontWeight.Medium else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // RESUMO FINANCEIRO (Cards) - Based on Period
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val cardMod = Modifier.weight(1f)
                    
                    val dispRec = periodSummary.first
                    val dispDes = periodSummary.second
                    val dispSal = dispRec - dispDes
                    
                    // Receitas
                    Surface(shape = RoundedCornerShape(12.dp), color = surfaceColor, modifier = cardMod, border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.TrendingUp, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF10B981))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Receitas", fontSize = 11.sp, color = textColor)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("+${formatter.format(dispRec)}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Previsto: +${formatter.format(dispRec)}", fontSize = 9.sp, color = textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    // Despesas
                    Surface(shape = RoundedCornerShape(12.dp), color = surfaceColor, modifier = cardMod, border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.TrendingDown, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFFEF4444))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Despesas", fontSize = 11.sp, color = textColor)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("-${formatter.format(dispDes)}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Previsto: -${formatter.format(dispDes)}", fontSize = 9.sp, color = textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    // Saldo
                    Surface(shape = RoundedCornerShape(12.dp), color = surfaceColor, modifier = cardMod, border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF3B82F6))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Saldo Líquido", fontSize = 11.sp, color = textColor)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "${if (dispSal > 0) "+" else ""}${formatter.format(dispSal)}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF3B82F6),
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(if (dispSal >= 0) "Superávit" else "Déficit", fontSize = 9.sp, color = textMuted)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // LEGEND
                var showLegend by remember { mutableStateOf(true) }
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                    Row(modifier = Modifier.fillMaxWidth().clickable { showLegend = !showLegend }, horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(if (showLegend) "Mostrar legenda ∨" else "Mostrar legenda >", fontSize = 11.sp, color = textMuted)
                        if (showLegend) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                @Composable
                                fun LegendItem(color: Color, text: String) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(text, fontSize = 9.sp, color = textMuted)
                                    }
                                }
                                LegendItem(Color(0xFF10B981), "Entrada")
                                LegendItem(Color(0xFFEF4444), "Saída")
                                LegendItem(Color(0xFFA855F7), "Empréstimo")
                                LegendItem(Color(0xFF3B82F6), "Recorrente")
                                LegendItem(Color(0xFFFFB300), "Meta")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // CALENDAR GRID
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = surfaceColor,
                    border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        // Weekdays header
                        Row(modifier = Modifier.fillMaxWidth()) {
                            val days = listOf("DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB")
                            days.forEachIndexed { i, d ->
                                val isWeekend = i == 0 || i == 6
                                Text(
                                    text = d,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Center,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isWeekend) Color(0xFF3B82F6) else textMuted
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        val cal = Calendar.getInstance().apply { set(viewedYear, viewedMonth, 1) }
                        val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = Sun
                        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                        
                        val prevMonthMax = Calendar.getInstance().apply { set(viewedYear, viewedMonth - 1, 1) }.getActualMaximum(Calendar.DAY_OF_MONTH)
                        
                        var dayCounter = 1
                        var nextMonthCounter = 1
                        
                        val touchGestures = Modifier.pointerInput(Unit) {
                            detectHorizontalDragGestures { change, dragAmount ->
                                change.consume()
                                if (dragAmount > 30) {
                                    viewedDate = (viewedDate.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                } else if (dragAmount < -30) {
                                    viewedDate = (viewedDate.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                        }
                        
                        Column(modifier = touchGestures) {
                            for (row in 0..5) {
                                Row(modifier = Modifier.fillMaxWidth()) {
                                    for (col in 0..6) {
                                        val isWeekend = col == 0 || col == 6
                                        
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(56.dp)
                                                .padding(2.dp)
                                                .clip(RoundedCornerShape(8.dp)),
                                            contentAlignment = Alignment.TopCenter
                                        ) {
                                            if (row == 0 && col < firstDayOfWeek) {
                                                // Prev month
                                                val d = prevMonthMax - firstDayOfWeek + col + 1
                                                Text(
                                                    text = "$d",
                                                    modifier = Modifier.padding(top = 4.dp).clickable {
                                                        viewedDate = (viewedDate.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
                                                    },
                                                    fontSize = 14.sp,
                                                    color = textMuted.copy(alpha = 0.4f)
                                                )
                                            } else if (dayCounter > maxDays) {
                                                // Next month
                                                val d = nextMonthCounter++
                                                Text(
                                                    text = "$d",
                                                    modifier = Modifier.padding(top = 4.dp).clickable {
                                                        viewedDate = (viewedDate.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
                                                    },
                                                    fontSize = 14.sp,
                                                    color = if (isWeekend) Color(0xFF3B82F6).copy(alpha = 0.4f) else textMuted.copy(alpha = 0.4f)
                                                )
                                            } else {
                                                // Current month
                                                val d = dayCounter
                                                val isSelected = selectedDate.get(Calendar.DAY_OF_MONTH) == d && selectedDate.get(Calendar.MONTH) == viewedMonth && selectedDate.get(Calendar.YEAR) == viewedYear
                                                
                                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxSize().clickable {
                                                    selectedDate = Calendar.getInstance().apply { set(viewedYear, viewedMonth, d) }
                                                }) {
                                                    Box(
                                                        modifier = Modifier
                                                            .padding(top = 2.dp)
                                                            .size(28.dp)
                                                            .clip(RoundedCornerShape(8.dp))
                                                            .background(if (isSelected) Color(0xFF3B82F6) else Color.Transparent),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = "$d",
                                                            fontSize = 14.sp,
                                                            color = if (isSelected) Color.White else if (isWeekend) Color(0xFF3B82F6) else textColor
                                                        )
                                                    }
                                                    // Indicators below
                                                    val evs = monthEvents[d] ?: emptyList()
                                                    if (evs.isNotEmpty()) {
                                                        Spacer(modifier = Modifier.height(1.dp))
                                                        // Priority: Limit to 2 indicators to save space
                                                        val displayEvs = evs.take(2)
                                                        displayEvs.forEach { ev ->
                                                            val color = when (ev.third) {
                                                                "Entrada" -> Color(0xFF10B981)
                                                                "Saída" -> Color(0xFFEF4444)
                                                                "Empréstimo" -> Color(0xFFA855F7)
                                                                "Recorrente" -> Color(0xFF3B82F6)
                                                                "Meta" -> Color(0xFFFFB300)
                                                                else -> textMuted
                                                            }
                                                            val label = when (ev.third) {
                                                                "Empréstimo" -> "Emprést."
                                                                "Recorrente" -> "Recorr."
                                                                "Meta" -> "Meta"
                                                                else -> "${if (ev.second > 0) "+" else ""}${ev.second.toInt()}"
                                                            }
                                                            Surface(
                                                                color = color.copy(alpha = 0.15f),
                                                                shape = RoundedCornerShape(4.dp),
                                                                modifier = Modifier.padding(bottom = 1.dp)
                                                            ) {
                                                                Text(
                                                                    text = label,
                                                                    fontSize = 7.sp,
                                                                    color = color,
                                                                    modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp),
                                                                    maxLines = 1
                                                                )
                                                            }
                                                        }
                                                        if (evs.size > 2) {
                                                            Box(modifier = Modifier.size(4.dp).clip(CircleShape).background(Color(0xFF3B82F6)))
                                                        }
                                                    }
                                                }
                                                dayCounter++
                                            }
                                        }
                                    }
                                }
                                if (dayCounter > maxDays && row >= 4) break
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // BOTTOM SECTION
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Left: Hoje / Selected Date Events
                    val selD = selectedDate.get(Calendar.DAY_OF_MONTH)
                    val isSelToday = selectedDate.get(Calendar.YEAR) == todayCal.get(Calendar.YEAR) && selectedDate.get(Calendar.DAY_OF_YEAR) == todayCal.get(Calendar.DAY_OF_YEAR)
                    val selEvs = if (selectedDate.get(Calendar.MONTH) == viewedMonth) (monthEvents[selD] ?: emptyList()) else emptyList()
                    val dateLabel = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(selectedDate.time)
                    
                    // Simple cumulative logic for UI projection
                    val selBal = startOfMonthBal + (monthEvents.filterKeys { it <= selD }.values.flatten().sumOf { it.second })

                    Surface(
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(12.dp),
                        color = surfaceColor,
                        border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(if (isSelToday) "Hoje • $dateLabel" else dateLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textColor)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(4.dp)) {
                                        Text("${selEvs.size} eventos", fontSize = 9.sp, color = Color(0xFF3B82F6), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Saldo previsto", fontSize = 9.sp, color = textMuted)
                                    Text("${if (selBal > 0) "+" else ""}${formatter.format(selBal)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (selBal >= 0) Color(0xFF10B981) else Color(0xFFEF4444))
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            selEvs.take(4).forEach { ev ->
                                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    val iconColor = when (ev.third) {
                                        "Entrada" -> Color(0xFF10B981)
                                        "Saída" -> Color(0xFFEF4444)
                                        "Empréstimo" -> Color(0xFFA855F7)
                                        "Recorrente" -> Color(0xFF3B82F6)
                                        "Meta" -> Color(0xFFFFB300)
                                        else -> textMuted
                                    }
                                    val icon = when (ev.third) {
                                        "Entrada" -> Icons.Rounded.ArrowDownward
                                        "Saída" -> Icons.Rounded.ArrowUpward
                                        "Empréstimo" -> Icons.Rounded.AccountBalance
                                        "Recorrente" -> Icons.Rounded.Loop
                                        "Meta" -> Icons.Rounded.Star
                                        else -> Icons.Rounded.AttachMoney
                                    }
                                    Box(modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(iconColor.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
                                        Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(16.dp))
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(ev.first, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        Surface(color = iconColor.copy(alpha = 0.1f), shape = RoundedCornerShape(2.dp)) {
                                            Text(ev.third, fontSize = 7.sp, color = iconColor, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                                        }
                                    }
                                    Text(
                                        "${if (ev.second > 0) "+" else ""}${formatter.format(ev.second)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (ev.second > 0) Color(0xFF10B981) else Color(0xFFEF4444)
                                    )
                                }
                            }
                            if (selEvs.isEmpty()) {
                                Text("Nenhum evento financeiro neste dia.", fontSize = 11.sp, color = textMuted, modifier = Modifier.padding(vertical = 12.dp))
                            }
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth().clickable { /* TODO */ }, horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                Text("Ver todos os eventos do dia", fontSize = 11.sp, color = Color(0xFF3B82F6))
                                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(14.dp))
                            }
                        }
                    }

                    // Right: Resumo do mês
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        color = surfaceColor,
                        border = BorderStroke(1.dp, textMuted.copy(alpha = 0.1f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Resumo do mês", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = textColor)
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            @Composable
                            fun SumRow(label: String, value: String, color: Color) {
                                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(label, fontSize = 11.sp, color = textMuted)
                                    Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
                                }
                            }
                            
                            SumRow("Entradas", "+${formatter.format(monthReceitas)}", Color(0xFF10B981))
                            SumRow("Saídas", "-${formatter.format(monthDespesas)}", Color(0xFFEF4444))
                            SumRow("Saldo Previsto", "${if (monthSaldo > 0) "+" else ""}${formatter.format(monthSaldo)}", Color(0xFF3B82F6))
                            Spacer(modifier = Modifier.height(8.dp))
                            SumRow("Metas", "$monthMetas / ${goals.size}", textColor)
                            Box(modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(textMuted.copy(alpha = 0.2f))) {
                                Box(modifier = Modifier.fillMaxWidth(if (goals.isEmpty()) 0f else monthMetas.toFloat()/goals.size.toFloat()).height(4.dp).clip(CircleShape).background(Color(0xFFFFB300)))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            SumRow("Recorrentes", "${activeSubscriptions.size} ativos", textColor)
                            
                            Spacer(modifier = Modifier.weight(1f))
                            Row(modifier = Modifier.fillMaxWidth().clickable { /* TODO */ }, horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                Text("Ver mais detalhes", fontSize = 11.sp, color = Color(0xFF3B82F6))
                                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
