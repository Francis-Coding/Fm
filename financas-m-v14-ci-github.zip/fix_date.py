with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'r') as f:
    content = f.read()

replacement = """
            val currentMonth = SimpleDateFormat(if (idioma == "PT") "MMMM 'de' yyyy" else "MMMM yyyy", Locale(if (idioma == "PT") "pt" else "en")).format(Calendar.getInstance().time).replaceFirstChar { it.uppercase() }
            Text(
                text = currentMonth,
"""

content = content.replace('            Text(\n                text = if (idioma == "PT") "Maio de 2024" else "May 2024",', replacement)

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'w') as f:
    f.write(content)
