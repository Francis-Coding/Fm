import re

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'r') as f:
    content = f.read()

replacement = """
    // Real data calculation
    val startOfMonth = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    
    val startOfLastMonth = Calendar.getInstance().apply {
        add(Calendar.MONTH, -1)
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    
    val currentMonthTransactions = transactions.filter { it.data >= startOfMonth && !it.ajusteCaixa }
    val lastMonthTransactions = transactions.filter { it.data in startOfLastMonth until startOfMonth && !it.ajusteCaixa }
    
    val receitas = currentMonthTransactions.filter { it.tipo == "Receita" }.sumOf { it.valor }
    val despesas = currentMonthTransactions.filter { it.tipo == "Despesa" }.sumOf { it.valor }
    val saldo = wallets.sumOf { it.saldoAtual }
    
    val receitasAnteriores = lastMonthTransactions.filter { it.tipo == "Receita" }.sumOf { it.valor }
    val despesasAnteriores = lastMonthTransactions.filter { it.tipo == "Despesa" }.sumOf { it.valor }
    val saldoAnterior = saldo - receitas + despesas // Simplified estimation
    
    val varReceitas = if (receitasAnteriores > 0) ((receitas - receitasAnteriores) / receitasAnteriores) * 100 else 0.0
    val varDespesas = if (despesasAnteriores > 0) ((despesas - despesasAnteriores) / despesasAnteriores) * 100 else 0.0
    val varSaldo = if (saldoAnterior > 0) ((saldo - saldoAnterior) / saldoAnterior) * 100 else 0.0
    
    val poupanca = if (receitas > 0) ((receitas - despesas) / receitas * 100).toInt().coerceAtLeast(0) else 0
    val mo = settings.moedaPadrao
"""

content = re.sub(r'    // Mock data for UI fidelity\n.*val mo = if \(idioma == "PT"\) "MZN" else "MZN"\n', replacement, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'w') as f:
    f.write(content)
