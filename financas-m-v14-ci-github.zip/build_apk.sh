#!/bin/bash
# Script unificado para configurar o SDK, compilar o APK e facilitar o download no Google Cloud Shell
set -e

# Cores para o terminal
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== 🚀 INICIANDO PROCESSO COMPLETO DE CONSTRUÇÃO DO APK ===${NC}"

# === DETECÇÃO AUTOMÁTICA DE DIRETÓRIO ===
if [ ! -f "settings.gradle.kts" ] && [ ! -f "build.gradle.kts" ]; then
    echo -e "${YELLOW}🔍 Você não está na raiz do projeto. Buscando pasta correta...${NC}"
    CANDIDATE_DIR=$(find . -name "settings.gradle.kts" -maxdepth 3 -print -quit | xargs dirname 2>/dev/null)
    if [ -n "$CANDIDATE_DIR" ] && [ "$CANDIDATE_DIR" != "." ]; then
        echo -e "${GREEN}📂 Projeto encontrado em: $CANDIDATE_DIR. Entrando na pasta...${NC}"
        cd "$CANDIDATE_DIR"
    else
        echo -e "${RED}❌ ERRO: Não foi possível localizar os arquivos do projeto (settings.gradle.kts/build.gradle.kts).${NC}"
        echo -e "Por favor, entre no diretório correto do projeto usando o comando: cd nome-da-pasta"
        exit 1
    fi
fi

# === VALIDAÇÃO E CONFIGURAÇÃO DA VERSÃO DO JAVA (Mínimo Java 17 para Gradle 9+) ===
echo -e "${YELLOW}☕ Verificando versão do Java...${NC}"
JAVA_VM_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f1)
if [ "$JAVA_VM_VERSION" = "1" ]; then
    JAVA_VM_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f2)
fi

if [ -z "$JAVA_VM_VERSION" ] || [ "$JAVA_VM_VERSION" -lt 17 ] 2>/dev/null; then
    echo -e "${YELLOW}⚠️ Java atual ($JAVA_VM_VERSION) é menor que 17. Procurando JDK 17 ou 21 no Cloud Shell...${NC}"
    FOUND_JDK=""
    for candidate in /usr/lib/jvm/java-17-openjdk-amd64 /usr/lib/jvm/java-21-openjdk-amd64 /usr/lib/jvm/java-17-openjdk /usr/lib/jvm/java-21-openjdk /usr/lib/jvm/jdk-17* /usr/lib/jvm/jdk-21*; do
        if [ -d "$candidate" ]; then
            FOUND_JDK="$candidate"
            break
        fi
    done
    
    if [ -n "$FOUND_JDK" ]; then
        export JAVA_HOME="$FOUND_JDK"
        export PATH="$JAVA_HOME/bin:$PATH"
        echo -e "${GREEN}✅ JAVA_HOME configurado temporariamente para: $JAVA_HOME${NC}"
    else
        echo -e "${RED}❌ ERRO: Gradle requer Java 17 ou superior, mas nenhum JDK compatível foi encontrado em /usr/lib/jvm/.${NC}"
        echo -e "Por favor, tente instalar rodando: sudo apt-get update && sudo apt-get install -y openjdk-17-jdk"
    fi
fi
echo -e "${GREEN}☕ Usando Java: $(java -version 2>&1 | head -n 1)${NC}"

# 1. Definir caminhos para o SDK no diretório home (persistente entre sessões do Cloud Shell)
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

mkdir -p "$ANDROID_HOME"

# 2. Baixar as ferramentas de linha de comando do Android (Command Line Tools) se não existirem ou estiverem corrompidas
if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ] || [ ! -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
    echo -e "${YELLOW}📥 Baixando Android Command Line Tools...${NC}"
    rm -f cmdline-tools.zip
    wget -q --show-progress "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -O cmdline-tools.zip || \
    curl -L -s "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -o cmdline-tools.zip
    
    # Validar integridade do arquivo zip baixado
    if command -v unzip >/dev/null 2>&1 && ! unzip -t cmdline-tools.zip >/dev/null 2>&1; then
        echo -e "${RED}⚠️ Arquivo cmdline-tools.zip corrompido no download. Tentando baixar via curl com opções alternativas...${NC}"
        rm -f cmdline-tools.zip
        curl -L -k -s "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -o cmdline-tools.zip
    fi

    echo -e "${YELLOW}📦 Descompactando ferramentas...${NC}"
    rm -rf "$ANDROID_HOME/cmdline-tools-temp" "$ANDROID_HOME/cmdline-tools/latest"
    mkdir -p "$ANDROID_HOME/cmdline-tools-temp"
    unzip -q cmdline-tools.zip -d "$ANDROID_HOME/cmdline-tools-temp"
    
    mkdir -p "$ANDROID_HOME/cmdline-tools/latest"
    mv "$ANDROID_HOME/cmdline-tools-temp/cmdline-tools/"* "$ANDROID_HOME/cmdline-tools/latest/" 2>/dev/null || true
    
    rm -rf cmdline-tools.zip "$ANDROID_HOME/cmdline-tools-temp"
    echo -e "${GREEN}✅ Command Line Tools instalados com sucesso!${NC}"
else
    echo -e "${GREEN}✅ Command Line Tools já instalados.${NC}"
fi

# 3. Limpar temporários corrompidos e Aceitar as Licenças do Android
echo -e "${YELLOW}📝 Aceitando licenças do Android SDK automaticamente...${NC}"
rm -rf "$ANDROID_HOME/.temp" "$ANDROID_HOME/tmp" 2>/dev/null || true
mkdir -p "$ANDROID_HOME/licenses"
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_HOME" --licenses > /dev/null 2>&1 || true

# 4. Instalar as dependências de plataforma e build correspondentes ao projeto (Android 36)
echo -e "${YELLOW}⚙️ Instalando Platform-Tools, SDK Platform 36 e Build-Tools 36.0.0...${NC}"
rm -rf "$ANDROID_HOME/.temp" "$ANDROID_HOME/tmp" 2>/dev/null || true

if ! yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_HOME" "platform-tools" "platforms;android-36" "build-tools;36.0.0" > /dev/null 2>&1; then
    echo -e "${YELLOW}🔄 Falha inicial na instalação das ferramentas do SDK. Limpando temporários e tentando novamente com feedback visual...${NC}"
    rm -rf "$ANDROID_HOME/.temp" "$ANDROID_HOME/tmp" "$ANDROID_HOME/platform-tools/.installer" 2>/dev/null || true
    yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_HOME" "platform-tools" "platforms;android-36" "build-tools;36.0.0"
fi

# 5. Criar/Atualizar o arquivo local.properties
echo -e "${YELLOW}✍️ Atualizando local.properties...${NC}"
echo "sdk.dir=$ANDROID_HOME" > local.properties

# 5.5 Verificar integridade do gradle-wrapper.jar e baixar se estiver corrompido
echo -e "${YELLOW}🔍 Verificando integridade do gradle-wrapper.jar...${NC}"
mkdir -p gradle/wrapper

JAR_INTEGRO=false
if [ -f gradle/wrapper/gradle-wrapper.jar ]; then
    if command -v unzip >/dev/null 2>&1; then
        if unzip -t gradle/wrapper/gradle-wrapper.jar >/dev/null 2>&1; then
            JAR_INTEGRO=true
        fi
    else
        # Se unzip não estiver instalado, verificamos se o arquivo existe e tem tamanho plausível (>10KB)
        FILE_SIZE=$(wc -c < gradle/wrapper/gradle-wrapper.jar 2>/dev/null || echo 0)
        if [ "$FILE_SIZE" -gt 10000 ]; then
            JAR_INTEGRO=true
        fi
    fi
fi

if [ "$JAR_INTEGRO" = false ]; then
    echo -e "${YELLOW}⚠️ gradle-wrapper.jar corrompido ou ausente. Baixando uma cópia limpa e funcional...${NC}"
    # Tentativas de download com fallback e bypass de certificado SSL (útil em ambientes corporativos/Cloud Shell com CAs desatualizadas)
    wget -q --no-check-certificate --show-progress "https://github.com/gradle/gradle/raw/v9.3.1/gradle/wrapper/gradle-wrapper.jar" -O gradle/wrapper/gradle-wrapper.jar || \
    curl -L -k -s "https://github.com/gradle/gradle/raw/v9.3.1/gradle/wrapper/gradle-wrapper.jar" -o gradle/wrapper/gradle-wrapper.jar || \
    wget -q --show-progress "https://github.com/gradle/gradle/raw/v9.3.1/gradle/wrapper/gradle-wrapper.jar" -O gradle/wrapper/gradle-wrapper.jar || \
    curl -L -s "https://github.com/gradle/gradle/raw/v9.3.1/gradle/wrapper/gradle-wrapper.jar" -o gradle/wrapper/gradle-wrapper.jar

    # Validar se o arquivo baixado é realmente válido (>10KB)
    DOWNLOAD_SIZE=$(wc -c < gradle/wrapper/gradle-wrapper.jar 2>/dev/null || echo 0)
    if [ "$DOWNLOAD_SIZE" -gt 10000 ]; then
        echo -e "${GREEN}✅ gradle-wrapper.jar recuperado com sucesso! ($DOWNLOAD_SIZE bytes)${NC}"
    else
        echo -e "${RED}❌ ERRO: Falha crítica ao baixar gradle-wrapper.jar. Arquivo ausente ou corrompido ($DOWNLOAD_SIZE bytes).${NC}"
        echo -e "Por favor, verifique sua conexão com a internet ou adicione o arquivo gradle-wrapper.jar manualmente.${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}✅ gradle-wrapper.jar íntegro e pronto para uso.${NC}"
fi

# 5.6 Restaurar ou gerar o arquivo debug.keystore de assinatura
echo -e "${YELLOW}🔑 Verificando keystore de assinatura...${NC}"
if [ ! -f debug.keystore ] && [ -f debug.keystore.base64 ]; then
    echo -e "${YELLOW}📦 Decodificando debug.keystore de debug.keystore.base64...${NC}"
    base64 --decode debug.keystore.base64 > debug.keystore 2>/dev/null || \
    base64 -d debug.keystore.base64 > debug.keystore 2>/dev/null || \
    openssl base64 -d -in debug.keystore.base64 -out debug.keystore 2>/dev/null
    echo -e "${GREEN}✅ debug.keystore decodificado com sucesso!${NC}"
elif [ -f debug.keystore ]; then
    echo -e "${GREEN}✅ debug.keystore já está presente.${NC}"
else
    echo -e "${YELLOW}🔑 debug.keystore ausente. Gerando uma nova chave de debug local...${NC}"
    keytool -genkey -v -keystore debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US" > /dev/null 2>&1 || true
    if [ -f debug.keystore ]; then
        echo -e "${GREEN}✅ debug.keystore gerado localmente com sucesso!${NC}"
    else
        echo -e "${YELLOW}⚠️ Aviso: Não foi possível gerar debug.keystore local. O Gradle tentará usar a chave padrão do usuário ou dinâmica.${NC}"
    fi
fi

# 6. Dar permissão de execução ao Gradle Wrapper e corrigir fins de linha do script
echo -e "${YELLOW}🔒 Ajustando permissões e quebras de linha do Gradle Wrapper...${NC}"
sed -i 's/\r$//' gradlew
chmod +x gradlew

# 7. Compilar o APK
echo -e "${BLUE}🔨 Compilando o APK com Gradle (esta etapa pode levar alguns minutos)...${NC}"
./gradlew assembleDebug

# 8. Trazer o APK compilado para locais estratégicos e iniciar download automático
if [ -f app/build/outputs/apk/debug/app-debug.apk ]; then
    cp app/build/outputs/apk/debug/app-debug.apk ./meu-aplicativo.apk
    cp app/build/outputs/apk/debug/app-debug.apk ../meu-aplicativo.apk 2>/dev/null || true
    cp app/build/outputs/apk/debug/app-debug.apk "$HOME/meu-aplicativo.apk" 2>/dev/null || true
    
    echo -e "\n${GREEN}=======================================================${NC}"
    echo -e "${GREEN}🎉 SUCESSO! O APK foi compilado com excelência!${NC}"
    echo -e "${GREEN}=======================================================${NC}"
    echo -e "O arquivo está pronto em vários locais:"
    echo -e "  📍 Na pasta atual: ${YELLOW}meu-aplicativo.apk${NC}"
    echo -e "  📍 No topo do EXPLORER: ${YELLOW}meu-aplicativo.apk${NC} (ao lado da pasta do projeto)"
    echo -e "  📍 Na sua pasta Home: ${YELLOW}~/meu-aplicativo.apk${NC}"
    echo ""

    # === TENTAR DOWNLOAD AUTOMÁTICO VIA CLOUD SHELL ===
    TRIGGERED_AUTO_DOWNLOAD=false
    echo -e "${BLUE}⚡ [AUTO-DOWNLOAD] Iniciando download nativo do Cloud Shell...${NC}"
    if command -v cloudshell &>/dev/null; then
        echo -e "${YELLOW}📥 Comando 'cloudshell download' encontrado! Iniciando...${NC}"
        # Executar em background para não travar o script se houver alguma interação
        cloudshell download ./meu-aplicativo.apk &
        TRIGGERED_AUTO_DOWNLOAD=true
    elif command -v dl-files &>/dev/null; then
        echo -e "${YELLOW}📥 Comando 'dl-files' encontrado! Iniciando...${NC}"
        dl-files ./meu-aplicativo.apk &
        TRIGGERED_AUTO_DOWNLOAD=true
    fi

    if [ "$TRIGGERED_AUTO_DOWNLOAD" = true ]; then
        echo -e "${GREEN}✅ Solicitação de download enviada para o seu navegador! (Verifique se há bloqueador de pop-ups)${NC}"
        echo ""
    fi

    echo -e "${BLUE}🌐 SE O DOWNLOAD AUTOMÁTICO NÃO ABRIU, USE UMA DESSAS OPÇÕES SUPER FÁCEIS:${NC}"
    echo ""
    echo -e "👉 ${YELLOW}OPÇÃO 1: Executar o comando de download direto${NC}"
    echo -e "   Basta copiar e colar este comando no terminal e dar ENTER:"
    echo -e "   ${GREEN}cloudshell download meu-aplicativo.apk${NC}"
    echo ""
    echo -e "👉 ${YELLOW}OPÇÃO 2: Baixar pelo menu lateral esquerdo (EXPLORER)${NC}"
    echo -e "   1. Olhe para a barra lateral esquerda (onde mostra as pastas do seu projeto)."
    echo -e "   2. O arquivo ${GREEN}meu-aplicativo.apk${NC} agora está visível no topo da lista (fora da pasta meu-projeto-financas)."
    echo -e "   3. Clique com o ${YELLOW}botão direito${NC} nele e selecione ${GREEN}Download (Fazer download)${NC}!"
    echo ""
    echo -e "👉 ${YELLOW}OPÇÃO 3: Download pelo menu superior do terminal${NC}"
    echo -e "   1. Clique no ícone de ${YELLOW}Três Pontinhos (More)${NC} no canto superior direito do painel do terminal."
    echo -e "   2. Escolha ${YELLOW}Download File (Fazer download do arquivo)${NC}."
    echo -e "   3. Digite o seguinte caminho exato do arquivo: ${GREEN}meu-aplicativo.apk${NC}"
    echo -e "   4. Clique em Download."
    echo ""
    echo -e "👉 ${YELLOW}OPÇÃO 4: Servidor Web Temporário (Para Baixar no Celular ou Navegador)${NC}"
    echo -e "   1. Execute este comando no terminal: ${YELLOW}python3 -m http.server 8080${NC}"
    echo -e "   2. No canto superior direito do Cloud Shell, clique no ícone de ${YELLOW}Web Preview (Visualização Web)${NC} (parece um navegador com olho)."
    echo -e "   3. Clique em ${GREEN}Preview on port 8080 (Visualizar na porta 8080)${NC}."
    echo -e "   4. Na página que abrir, clique em ${GREEN}meu-aplicativo.apk${NC} para baixar."
    echo -e "   5. Pressione ${YELLOW}Ctrl + C${NC} no terminal para desligar o servidor quando terminar."
    echo -e "${GREEN}=======================================================${NC}"
else
    echo -e "${RED}❌ Ocorreu um erro: O arquivo APK não foi encontrado após a compilação.${NC}"
    exit 1
fi
