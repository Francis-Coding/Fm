#!/bin/bash
# Script utilitário de download fácil para o aplicativo financas
set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=======================================================${NC}"
echo -e "${BLUE}📥   ASSISTENTE DE DOWNLOAD DO SEU APLICATIVO APK     📥${NC}"
echo -e "${BLUE}=======================================================${NC}"

# Buscar arquivo APK compilado
APK_SRC="app/build/outputs/apk/debug/app-debug.apk"
APK_DEST="meu-aplicativo.apk"

if [ ! -f "$APK_SRC" ] && [ ! -f "$APK_DEST" ]; then
    echo -e "${YELLOW}⚠️  Aviso: Nenhum APK compilado encontrado.${NC}"
    echo -e "${BLUE}🔨 Iniciando a compilação automática para você...${NC}"
    if [ -f "./build_apk.sh" ]; then
        bash ./build_apk.sh
    else
        echo -e "${RED}❌ ERRO: Script build_apk.sh não encontrado na raiz.${NC}"
        exit 1
    fi
fi

# Garantir que o arquivo está na raiz para download simples
if [ -f "$APK_SRC" ]; then
    cp "$APK_SRC" ./"$APK_DEST"
    echo -e "${GREEN}✅ APK localizado e preparado para download!${NC}"
fi

echo -e "\n${BLUE}=======================================================${NC}"
echo -e "${GREEN}🎉 Escolha uma das opções abaixo para baixar o APK:${NC}"
echo -e "${BLUE}=======================================================${NC}"
echo ""
echo -e "👉 ${YELLOW}MÉTODO 1: Download direto no Google Cloud Shell${NC}"
echo -e "   Copie e cole este comando exato no terminal e dê ENTER:"
echo -e "   ${GREEN}cloudshell download meu-aplicativo.apk${NC}"
echo ""
echo -e "👉 ${YELLOW}MÉTODO 2: Baixar pelo Painel Lateral Esquerdo (EXPLORER)${NC}"
echo -e "   1. Procure pelo arquivo ${GREEN}meu-aplicativo.apk${NC} na lista de arquivos à esquerda."
echo -e "   2. Clique com o ${YELLOW}botão direito${NC} nele e selecione ${GREEN}Download${NC}."
echo ""
echo -e "👉 ${YELLOW}MÉTODO 3: Baixar usando o Menu Superior do Cloud Shell${NC}"
echo -e "   1. Clique nos ${YELLOW}Três Pontinhos (More)${NC} no topo direito do terminal."
echo -e "   2. Escolha ${YELLOW}Download File${NC}."
echo -e "   3. Digite o caminho exato: ${GREEN}meu-aplicativo.apk${NC} e clique em Baixar."
echo ""
echo -e "👉 ${YELLOW}MÉTODO 4: Baixar direto no Celular (Servidor Web)${NC}"
echo -e "   Iniciando um servidor web local temporário na porta ${YELLOW}8080${NC}..."
echo -e "   1. Clique no ícone de ${YELLOW}Web Preview (Visualização Web)${NC} no canto superior direito do Cloud Shell."
echo -e "   2. Selecione ${GREEN}Preview on port 8080 (Visualizar na porta 8080)${NC}."
echo -e "   3. Na página que abrir, clique em ${GREEN}meu-aplicativo.apk${NC} para instalar no celular!"
echo -e "   ${RED}Pressione Ctrl + C no terminal para encerrar o servidor quando terminar.${NC}"
echo ""

python3 -m http.server 8080
