import re

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'r') as f:
    content = f.read()

replacement_call = """
        item {
            val formatNumber = { num: Double -> String.format(Locale.getDefault(), "%,.2f", num).replace(",", "X").replace(".", ",").replace("X", ".") }
            val formatVar = { vari: Double -> if (vari >= 0) "↑ ${vari.toInt()}%" else "↓ ${-vari.toInt()}%" }
            val colorVar = { vari: Double, invert: Boolean -> if ((vari >= 0) xor invert) Color(0xFF10B981) else Color(0xFFEF4444) }
            
            SummaryGrid(
                idioma = idioma,
                receitasStr = formatNumber(receitas),
                despesasStr = formatNumber(despesas),
                saldoStr = formatNumber(saldo),
                poupanca = poupanca,
                mo = mo,
                varRecText = formatVar(varReceitas),
                varRecColor = colorVar(varReceitas, false),
                varDesText = formatVar(varDespesas),
                varDesColor = colorVar(varDespesas, true),
                varSalText = formatVar(varSaldo),
                varSalColor = colorVar(varSaldo, false)
            )
        }
"""

content = re.sub(r'        item \{\n            SummaryGrid\(idioma, receitas, despesas, saldo, poupanca, mo\)\n        \}', replacement_call, content)

sig_old = 'fun SummaryGrid(idioma: String, receitas: Double, despesas: Double, saldo: Double, poupanca: Int, mo: String)'
sig_new = 'fun SummaryGrid(idioma: String, receitasStr: String, despesasStr: String, saldoStr: String, poupanca: Int, mo: String, varRecText: String, varRecColor: Color, varDesText: String, varDesColor: Color, varSalText: String, varSalColor: Color)'

content = content.replace(sig_old, sig_new)

content = content.replace('value = "32.500",', 'value = receitasStr,')
content = content.replace('trendText = "↑ 8%",', 'trendText = varRecText,')
content = content.replace('trendColor = Color(0xFF10B981),', 'trendColor = varRecColor,', 1)

content = content.replace('value = "14.300",', 'value = saldoStr,')
content = content.replace('trendText = "↑ 16%",', 'trendText = varSalText,')
content = content.replace('trendColor = Color(0xFF3B82F6),', 'trendColor = varSalColor,', 1)

content = content.replace('value = "18.200",', 'value = despesasStr,')
content = content.replace('trendText = "↓ 4%",', 'trendText = varDesText,')
content = content.replace('trendColor = Color(0xFFEF4444),', 'trendColor = varDesColor,', 1)

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'w') as f:
    f.write(content)
