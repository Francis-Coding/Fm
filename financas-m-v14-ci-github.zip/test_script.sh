#!/bin/bash
tail -n 20 .gradle/daemon/*/daemon-*.out.log 2>/dev/null || echo "No daemon log"
