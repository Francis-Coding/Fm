import re

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'r') as f:
    content = f.read()

replacement = """
            val subsList = transactions.filter { it.recorrente && it.tipo == "Despesa" }.distinctBy { it.descricao.trim().lowercase() }.take(3)
            val totalSubsValue = transactions.filter { it.recorrente && it.tipo == "Despesa" }.distinctBy { it.descricao.trim().lowercase() }.sumOf { it.valor }
            val activeCount = transactions.filter { it.recorrente && it.tipo == "Despesa" }.distinctBy { it.descricao.trim().lowercase() }.size
            
            val colors = listOf(Color.Black, Color(0xFF1DB954), Color(0xFFE50914), Color(0xFF3B82F6))
            
            subsList.forEachIndexed { index, sub ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(colors[index % colors.size]), contentAlignment = Alignment.Center) {
                        Text(sub.descricao.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(sub.descricao, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                    Text(String.format(Locale.getDefault(), "%,.0f $mo", sub.valor).replace(",", "X").replace(".", ",").replace("X", "."), fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("/${if (idioma == "PT") "mês" else "month"}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Color(0xFFDCFCE7)).padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(if (idioma == "PT") "Ativa" else "Active", fontSize = 10.sp, color = Color(0xFF166534))
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (idioma == "PT") "$activeCount subscrições ativas" else "$activeCount active subscriptions", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row {
                    Text(String.format(Locale.getDefault(), "%,.0f $mo", totalSubsValue).replace(",", "X").replace(".", ",").replace("X", "."), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text("/${if (idioma == "PT") "mês" else "month"}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
"""

# Regex matching to replace the subs logic
content = re.sub(
    r'            val subs = listOf\(\n.*?Row \{\n                    Text\("898 \$mo".*?\n                \}\n            \}',
    replacement,
    content,
    flags=re.DOTALL
)

# And update the function signature
content = content.replace('fun SubscriptionsCard(idioma: String, mo: String)', 'fun SubscriptionsCard(idioma: String, mo: String, transactions: List<Transaction>)')
content = content.replace('SubscriptionsCard(idioma, mo)', 'SubscriptionsCard(idioma, mo, transactions)')

with open('app/src/main/java/com/example/ui/RelatoriosDashboard.kt', 'w') as f:
    f.write(content)
